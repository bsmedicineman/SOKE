"""
soke.command_router — turn a plain-English message into an app action, so you can text the advisor to do
anything SOKE can do without remembering slash commands.

It is a DETERMINISTIC intent matcher (a lexicon + a little argument extraction), not an LLM guess: the same text
always routes the same way, and it is conservative — a definitional question ("what is a mixture of experts?")
stays a chat, only a clear instruction ("build a kimi moe with 12 experts") routes to an action. Anything it
isn't sure about falls through to a normal chat with the advisor. Side-effectful actions (promote, go online,
browse, evolve) route to handlers that keep their own gates/consent — the router opens no gate of its own.

    from soke.command_router import route_intent
    route_intent("build a better version of the model and prove it")   -> Intent(action="evolve", ...)
    route_intent("what is a router network?")                          -> Intent(action="chat", ...)
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class Intent:
    action: str                      # "chat" | diagnose | probes | ... (see ACTIONS)
    arg: Optional[str] = None        # a number, url, query, or on/off, when the action takes one
    phrase: str = ""                 # the phrase that matched (for the echo)

    def __bool__(self) -> bool:
        return self.action != "chat"


# actions the router can reach, and the phrases that signal each. Order matters: most specific first, so
# "test the logic" beats a bare "logic", and "self-improve/evolve" beats "improve".
PATTERNS = [
    ("help", ("what can you do", "list commands", "list the commands", "show commands", "your commands", "help me use")),
    ("testbehavior", ("test the behavior", "test behaviour", "test behavior", "run the behavior", "check the behavior",
                      "test the emotion", "test the mind", "behavior test", "behaviour test", "test its behavior")),
    ("testlogic", ("test the logic", "run the logic", "check the logic", "test jev", "logic test", "test the proof",
                   "test the gate", "test its logic")),
    ("evolve", ("evolve", "self-improve", "self improve", "prove a better", "prove it beats", "full cycle",
                "run a cycle", "and prove", "then prove", "prove the improvement", "prove it's better", "prove its better")),
    ("kimi", ("kimi", "wide moe", "wide mixture", "wide-moe", "build a moe", "build an moe", "build a mixture of experts",
              "mixture-of-experts model", "moe model", "fuse the models", "fuse models")),
    ("research", ("research", "look up", "find techniques", "search for techniques", "read up on", "find papers on",
                  "look for techniques")),
    ("browse", ("browse", "read the page", "read this page", "open the url", "fetch the page", "read the url", "read this url")),
    ("online", ("go online", "turn on the internet", "enable the internet", "enable internet", "internet on", "connect to the internet",
                "go offline", "turn off the internet", "disable the internet", "internet off")),
    ("models", ("list ollama", "ollama models", "installed models", "list models", "show models", "what models do i have",
                "which models", "models are installed")),
    ("advisor", ("load model", "use model", "load advisor", "switch to model", "use ollama model", "set advisor", "make it the advisor")),
    ("improve", ("improve the model", "improve it", "make it better", "make the model better", "tune the model", "tune it",
                 "build a better", "optimize the model", "optimise the model", "refine the model")),
    ("promote", ("promote", "save the model", "write the model", "ship it", "export the model", "write it to disk", "save it to disk")),
    ("diagnose", ("diagnose", "what's wrong", "whats wrong", "why isn't it improving", "why isnt it improving",
                  "why is it stalling", "what is wrong with the build", "why won't it improve")),
    ("probes", ("make probes", "generate probes", "build probes", "create probes", "new probes")),
    ("suggest", ("suggest edits", "suggest changes", "what should i change", "suggest template", "suggest improvements")),
    ("jev", ("make a decision", "jev decision", "logic decision", "decide the next", "what should i do next", "decide next")),
    ("train", ("train the model", "start training", "train it", "run the trainer")),
]

# a definitional / explanatory question is a chat, not a command (unless a diagnose phrase already matched)
DEFN_LEADS = ("what is", "what's a", "what are", "whats a", "what does", "explain", "how do", "how does", "how can",
              "tell me about", "define", "describe ", "who ", "when ", "which is", "is it possible", "do you know")

_URL = re.compile(r"https?://[^\s]+")
_INT = re.compile(r"\b(\d{1,4})\b")


def _extract_arg(action: str, text: str, phrase: str) -> Optional[str]:
    if action in ("browse",):
        m = _URL.search(text)
        return m.group(0) if m else None
    if action in ("kimi", "evolve", "advisor"):
        m = _INT.search(text)
        return m.group(1) if m else None
    if action == "online":
        return "off" if any(w in text for w in ("offline", "off the internet", "turn off", "disable")) else "on"
    if action == "research":
        # the query is whatever follows the trigger word
        for trig in ("research", "look up", "read up on", "find techniques for", "find papers on", "techniques for", "about"):
            i = text.find(trig)
            if i >= 0:
                q = text[i + len(trig):].strip(" :.-")
                if q:
                    return q
        return None
    return None


def route_intent(text: str) -> Intent:
    """Map a message to an Intent. Conservative: returns action='chat' unless a clear command phrase matches."""
    t = " ".join((text or "").lower().split())
    if not t:
        return Intent("chat")
    # diagnose-style questions ARE commands, so check them before the definitional-question guard
    for phrase in dict(PATTERNS)["diagnose"]:
        if phrase in t:
            return Intent("diagnose", None, phrase)
    # a definitional / explanatory question is a chat
    if any(t.startswith(q) for q in DEFN_LEADS):
        return Intent("chat")
    for action, phrases in PATTERNS:
        for p in phrases:
            if p in t:
                return Intent(action, _extract_arg(action, t, p), p)
    return Intent("chat")


# the canonical command menu the advisor picks from — kept close to route_intent's own phrasings so the LLM's
# answer maps cleanly back through the deterministic router.
ACTION_MENU = ("diagnose the build | generate probes | suggest edits | make a decision | test the behavior | "
               "test the logic | list ollama models | load model <n> | build a kimi moe <n> | evolve and prove it | "
               "research <topic> | go online | go offline | browse <url> | improve the model | promote it | train it")

_CLASSIFY_PROMPT = (
    "You route a user's message in an AI-model-building app to exactly ONE command from this list:\n"
    f"{ACTION_MENU}\n"
    "Rules: copy the <...> parts filled in from the message. If the message is a QUESTION, an explanation "
    "request, or plain conversation, output exactly: chat\n"
    "Output ONLY the one command line and nothing else.\n\n"
    "Message: ")


def _clean_line(out: str) -> str:
    """First non-empty line of the model's output, stripped of labels/quotes/markup."""
    for ln in (out or "").splitlines():
        ln = ln.strip().strip("`\"'*").strip()
        if not ln:
            continue
        low = ln.lower()
        for pre in ("command:", "action:", "answer:", "output:", "the command is", "->", "•", "-"):
            if low.startswith(pre):
                ln = ln[len(pre):].strip(); low = ln.lower()
        return ln
    return ""


def llm_classify(advisor, text: str, generate=None) -> Intent:
    """Understand free phrasing with the advisor LLM: it normalises the message into a canonical command, which
    the deterministic router then maps. Conservative — anything that doesn't cleanly map to an action becomes a
    chat, so a weak model can never fire a wrong action from noise. `generate` is injectable for testing."""
    gen = generate if generate is not None else (lambda p: advisor.generate(p, max_new=16, temperature=0.0, chat=True)[0])
    try:
        line = _clean_line(gen(_CLASSIFY_PROMPT + (text or "").strip() + "\nCommand:"))
    except Exception:
        return Intent("chat")
    low = line.lower()
    if not low or low.split()[0] in ("chat", "none", "answer", "reply", "conversation", "converse", "n/a"):
        return Intent("chat")
    it = route_intent(line)                                   # map the canonical phrasing deterministically
    if it.action == "chat":
        return Intent("chat")
    arg = it.arg if it.arg is not None else _extract_arg(it.action, (text or "").lower(), "")
    return Intent(it.action, arg, "llm")


# ==========================================================================
# self-test
# ==========================================================================
def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("command_router")

    cases = {
        "build a better version of the model and prove it": "evolve",
        "improve the model": "improve",
        "make it better": "improve",
        "build a kimi moe with 12 experts": "kimi",
        "test the behavior it's putting in": "testbehavior",
        "test the logic gate": "testlogic",
        "research mixture of experts upcycling": "research",
        "browse https://arxiv.org/abs/2401.00001 for me": "browse",
        "go online": "online",
        "list my ollama models": "models",
        "load model 2 as the advisor": "advisor",
        "diagnose the build": "diagnose",
        "why isn't it improving?": "diagnose",
        "generate probes": "probes",
        "promote it": "promote",
        "what can you do?": "help",
    }
    for text, want in cases.items():
        got = route_intent(text)
        chk(f"routes: {text!r} -> {want}", got.action == want, f"got {got.action}")

    # definitional questions must stay chat (not hijacked by keyword)
    for q in ("what is a mixture of experts?", "explain how MoE routing works", "what does the token bank do",
              "tell me about expert pruning"):
        chk(f"chat (not a command): {q!r}", route_intent(q).action == "chat", route_intent(q).action)

    # argument extraction
    chk("kimi extracts the expert count", route_intent("build a kimi moe with 12 experts").arg == "12")
    chk("browse extracts the url", route_intent("browse https://arxiv.org/x").arg == "https://arxiv.org/x")
    chk("advisor extracts the number", route_intent("use model 3").arg == "3")
    chk("online reads off", route_intent("turn off the internet").arg == "off" and route_intent("go online").arg == "on")
    chk("research extracts the query", "expert pruning" in (route_intent("research expert pruning methods").arg or ""))
    chk("evolve extracts optional rounds", route_intent("evolve for 5 rounds").arg == "5")

    # --- LLM understanding: the advisor normalises free phrasing into a canonical command (stubbed generate)
    def stub(reply):
        return lambda prompt: reply
    chk("llm: a novel phrasing the lexicon misses is understood via the model",
        route_intent("cook up a beefier network and make sure it's actually better").action == "chat"
        and llm_classify(None, "cook up a beefier network and make sure it's actually better", generate=stub("evolve and prove it")).action == "evolve")
    chk("llm: normalised command carries its arg", llm_classify(None, "spin up a big sparse model", generate=stub("build a kimi moe 12")).arg == "12")
    chk("llm: research topic survives", llm_classify(None, "dig into distillation", generate=stub("research knowledge distillation")).arg == "knowledge distillation")
    chk("llm: a 'chat' answer stays chat", llm_classify(None, "how does routing work?", generate=stub("chat")).action == "chat")
    chk("llm: a label prefix is stripped", llm_classify(None, "x", generate=stub("Command: diagnose the build")).action == "diagnose")
    chk("llm: junk that maps to nothing -> chat", llm_classify(None, "x", generate=stub("asdf qwerty zzz")).action == "chat")
    chk("llm: a raising generate is caught -> chat", llm_classify(None, "x", generate=lambda p: (_ for _ in ()).throw(RuntimeError("boom"))).action == "chat")
    chk("llm: url survives normalisation from the original text", llm_classify(None, "take a look at https://arxiv.org/abs/1 please", generate=stub("browse the url")).arg == "https://arxiv.org/abs/1")
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
