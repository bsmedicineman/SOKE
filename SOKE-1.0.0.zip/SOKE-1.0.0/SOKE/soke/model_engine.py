"""
soke.model_engine — the Model Core (MCGE): SOKE-LM, a byte-level transformer
with knowledge-tower domain experts, written in numpy with an explicit backward
pass, trained on streamed bytes and stored in SFF.

Architecture (per layer):
    a  = RMSNorm(x)                     x <- x + Attn(a)              (causal MHA)
    b  = RMSNorm(x)                     x <- x + MLP(b) + gate * Expert_k(b)
  Expert_k: top-1 domain expert chosen by a learned router over the residual stream,
  with a DLP lexicon prior (tower.route_text) added to the router logits per
  sequence. Each expert's weights are a separate helix in the SFF file (its own
  knowledge-tower domain), so inference loads only the experts a query routes to.
  Aux loss (Switch-style load balance): E * sum_e f_e * P_e.
  Output head tied to the byte embedding. Softmax through the L-gauge route (log-sum-exp).

Standing nulls respected: no orthometric frame weights inside the net (SEPHIRA
epsilon), no pillar routing (delta). Frames live in storage and verification.
"""
from __future__ import annotations

import json
import math
import os
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Iterator, Optional

import numpy as np

from .rng import Rng

from . import kernels
from .sff import (ENC_BY_BUDGET, HELIX_KIND_TENSOR, NO_PAGE, SFFReader, SFFWriter, TensorInfo)
from .teeth import ENC_DELTA8, ENC_F32
from .tower import DOMAINS, domain_id, route_text

VOCAB = 259                    # 256 bytes + BOS(256) + EOS(257) + PAD(258)
BOS, EOS, PAD = 256, 257, 258
DEFAULT_EXPERT_DOMAINS = ["math", "language", "science", "technology", "culture", "art", "behavior", "philosophy"]


@dataclass
class ModelConfig:
    d_model: int = 128
    n_heads: int = 4
    n_layers: int = 3
    d_ff: int = 512
    ctx: int = 128
    experts: list = field(default_factory=lambda: list(DEFAULT_EXPERT_DOMAINS))
    d_expert: int = 256
    aux_weight: float = 0.01
    prior_weight: float = 0.5
    dtype: str = "float32"
    vocab: int = VOCAB
    eps: float = 1e-5

    @property
    def n_experts(self) -> int:
        return len(self.experts)

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "ModelConfig":
        return ModelConfig(**{k: v for k, v in d.items() if k in ModelConfig.__dataclass_fields__})


def silu(x: np.ndarray) -> np.ndarray:
    return x / (1.0 + np.exp(-x))


def silu_grad(x: np.ndarray) -> np.ndarray:
    s = 1.0 / (1.0 + np.exp(-x))
    return s * (1.0 + x * (1.0 - s))


class SokeLM:
    """Parameters live in self.p (name -> ndarray). Names are SFF tensor names."""

    def __init__(self, cfg: ModelConfig, seed: int = 369, init: bool = True):
        self.cfg = cfg
        self.dt = np.float64 if cfg.dtype == "float64" else np.float32
        self.rng = Rng(seed)
        self.p: dict[str, np.ndarray] = {}
        self.step = 0
        self.lineage: list[dict] = []
        if init:
            self._init_params()

    # ------------------------------------------------------------- params
    def _init_params(self) -> None:
        c, dt, r = self.cfg, self.dt, self.rng
        D, F, E, Fe = c.d_model, c.d_ff, c.n_experts, c.d_expert
        s = 0.02
        self.p["tok_emb"] = (r.normal(0, s, (c.vocab, D))).astype(dt)
        self.p["pos_emb"] = (r.normal(0, s, (c.ctx, D))).astype(dt)
        for l in range(c.n_layers):
            self.p[f"blk.{l}.ln1"] = np.ones(D, dt)
            for n in ("wq", "wk", "wv"):
                self.p[f"blk.{l}.{n}"] = (r.normal(0, s, (D, D))).astype(dt)
            self.p[f"blk.{l}.wo"] = (r.normal(0, s / math.sqrt(2 * c.n_layers), (D, D))).astype(dt)
            self.p[f"blk.{l}.ln2"] = np.ones(D, dt)
            self.p[f"blk.{l}.w1"] = (r.normal(0, s, (D, F))).astype(dt)
            self.p[f"blk.{l}.w2"] = (r.normal(0, s / math.sqrt(2 * c.n_layers), (F, D))).astype(dt)
            self.p[f"blk.{l}.router"] = (r.normal(0, s, (D, E))).astype(dt)
            self.p[f"blk.{l}.router_b"] = np.zeros(E, dt)
            for e in range(E):
                self.p[f"blk.{l}.expert.{e}.w1"] = (r.normal(0, s, (D, Fe))).astype(dt)
                self.p[f"blk.{l}.expert.{e}.w2"] = (r.normal(0, s / math.sqrt(2 * c.n_layers), (Fe, D))).astype(dt)
        self.p["lnf"] = np.ones(D, dt)

    def n_params(self) -> int:
        return int(sum(v.size for v in self.p.values() if v is not None))

    def expert_weights(self, l: int, e: int) -> tuple[np.ndarray, np.ndarray]:
        return self.p[f"blk.{l}.expert.{e}.w1"], self.p[f"blk.{l}.expert.{e}.w2"]

    def tensor_domain(self, name: str) -> str:
        if ".expert." in name:
            e = int(name.split(".expert.")[1].split(".")[0])
            return self.cfg.experts[e]
        return "language"

    def param_names(self) -> list[str]:
        return list(self.p.keys())

    # ------------------------------------------------------------ helpers
    def _rmsnorm(self, x: np.ndarray, g: np.ndarray):
        inv = 1.0 / np.sqrt(np.mean(x * x, axis=-1, keepdims=True) + self.cfg.eps)
        n = x * inv
        return n * g, (n, inv)

    @staticmethod
    def _rmsnorm_back(dy: np.ndarray, cache, g: np.ndarray):
        n, inv = cache
        dg = np.sum(dy * n, axis=tuple(range(dy.ndim - 1)))
        dn = dy * g
        dx = inv * (dn - n * np.mean(dn * n, axis=-1, keepdims=True))
        return dx, dg

    def prior_bias(self, texts: list[str]) -> np.ndarray:
        """DLP lexicon prior per sequence -> (B, E) router bias."""
        c = self.cfg
        out = np.zeros((len(texts), c.n_experts), dtype=self.dt)
        if c.prior_weight == 0:
            return out
        for i, t in enumerate(texts):
            for dom, score in route_text(t, top=4):
                if dom in c.experts:
                    out[i, c.experts.index(dom)] += c.prior_weight * min(score, 3.0)
        return out

    # ------------------------------------------------------------ forward
    def forward(self, ids: np.ndarray, targets: Optional[np.ndarray] = None, prior: Optional[np.ndarray] = None,
                cache: bool = True) -> dict:
        c, p, dt = self.cfg, self.p, self.dt
        B, T = ids.shape
        D, H = c.d_model, c.n_heads
        dh = D // H
        scale = 1.0 / math.sqrt(dh)
        mask = np.triu(np.full((T, T), -np.inf, dtype=dt), 1)
        x = p["tok_emb"][ids] + p["pos_emb"][:T][None, :, :]
        caches = []
        aux_terms = []
        route_hist = np.zeros(c.n_experts, dtype=np.int64)
        attn_route = kernels.get("attention")
        for l in range(c.n_layers):
            a, ln1c = self._rmsnorm(x, p[f"blk.{l}.ln1"])
            q = (a @ p[f"blk.{l}.wq"]).reshape(B, T, H, dh).transpose(0, 2, 1, 3)
            k = (a @ p[f"blk.{l}.wk"]).reshape(B, T, H, dh).transpose(0, 2, 1, 3)
            v = (a @ p[f"blk.{l}.wv"]).reshape(B, T, H, dh).transpose(0, 2, 1, 3)
            o, prob = attn_route(q, k, v, scale, mask)
            o2 = o.transpose(0, 2, 1, 3).reshape(B, T, D)
            attn = o2 @ p[f"blk.{l}.wo"]
            x = x + attn
            b, ln2c = self._rmsnorm(x, p[f"blk.{l}.ln2"])
            h = b @ p[f"blk.{l}.w1"]
            s = silu(h)
            m = s @ p[f"blk.{l}.w2"]
            # router + experts
            r = b @ p[f"blk.{l}.router"] + p[f"blk.{l}.router_b"]
            if prior is not None:
                r = r + prior[:, None, :]
            pr = kernels.softmax_lse(r)
            kidx = np.argmax(pr, axis=-1)                           # (B,T)
            gate = np.take_along_axis(pr, kidx[..., None], axis=-1)  # (B,T,1)
            ex = np.zeros_like(b)
            ecache = []
            flat_b = b.reshape(B * T, D)
            flat_k = kidx.reshape(-1)
            flat_ex = ex.reshape(B * T, D)
            for e in range(c.n_experts):
                idx = np.nonzero(flat_k == e)[0]
                route_hist[e] += idx.size
                if idx.size == 0:
                    ecache.append(None)
                    continue
                Xe = flat_b[idx]
                ew1, ew2 = self.expert_weights(l, e)
                Hp = Xe @ ew1
                Se = silu(Hp)
                Ye = Se @ ew2
                flat_ex[idx] = Ye
                ecache.append((idx, Xe, Hp, Se, Ye))
            ex = flat_ex.reshape(B, T, D) * gate
            x = x + m + ex
            f_e = np.bincount(flat_k, minlength=c.n_experts) / float(B * T)
            P_e = pr.reshape(-1, c.n_experts).mean(axis=0)
            aux_terms.append(c.n_experts * float(np.sum(f_e * P_e)))
            if cache:
                caches.append({"a": a, "ln1c": ln1c, "q": q, "k": k, "v": v, "prob": prob, "o2": o2, "b": b, "ln2c": ln2c,
                               "h": h, "s": s, "pr": pr, "kidx": kidx, "gate": gate, "ecache": ecache, "f_e": f_e})
        f, lnfc = self._rmsnorm(x, p["lnf"])
        logits = f @ p["tok_emb"].T
        out = {"logits": logits, "aux": float(np.mean(aux_terms)) if aux_terms else 0.0, "route_hist": route_hist}
        if targets is not None:
            lse = kernels.logsumexp(logits, axis=-1)
            nll = lse - np.take_along_axis(logits, targets[..., None], axis=-1)[..., 0]
            out["loss"] = float(np.mean(nll))
            out["total"] = out["loss"] + c.aux_weight * out["aux"]
            out["per_token_nll"] = nll
        if cache:
            out["_cache"] = {"ids": ids, "caches": caches, "f": f, "lnfc": lnfc, "logits": logits, "T": T, "mask": mask,
                             "targets": targets, "prior": prior}
        return out

    # ----------------------------------------------------------- backward
    def backward(self, out: dict) -> dict[str, np.ndarray]:
        c, p, dt = self.cfg, self.p, self.dt
        C = out["_cache"]
        ids, targets = C["ids"], C["targets"]
        B, T = ids.shape
        D, H = c.d_model, c.n_heads
        dh = D // H
        scale = 1.0 / math.sqrt(dh)
        N = B * T
        g: dict[str, np.ndarray] = {k: np.zeros_like(v) for k, v in p.items()}
        logits = C["logits"]
        probs = kernels.softmax_lse(logits)
        dlogits = probs
        np.put_along_axis(dlogits, targets[..., None], np.take_along_axis(dlogits, targets[..., None], axis=-1) - 1.0, axis=-1)
        dlogits /= N
        f = C["f"]
        g["tok_emb"] += dlogits.reshape(N, -1).T @ f.reshape(N, D)
        df = dlogits @ p["tok_emb"]
        dx, dg = self._rmsnorm_back(df, C["lnfc"], p["lnf"])
        g["lnf"] += dg
        for l in reversed(range(c.n_layers)):
            L = C["caches"][l]
            b, pr, kidx, gate = L["b"], L["pr"], L["kidx"], L["gate"]
            # residual: x = x_prev + m + ex ; dx flows to m, ex, and x_prev
            dm = dx
            dex_gated = dx
            # experts
            flat_b = b.reshape(N, D)
            db_flat = np.zeros((N, D), dtype=dt)
            dgate = np.zeros((N,), dtype=dt)
            dexg = dex_gated.reshape(N, D)
            gate_flat = gate.reshape(N, 1)
            for e, ec in enumerate(L["ecache"]):
                if ec is None:
                    continue
                idx, Xe, Hp, Se, Ye = ec
                dY = dexg[idx] * gate_flat[idx]
                dgate[idx] = np.sum(dexg[idx] * Ye, axis=-1)
                g[f"blk.{l}.expert.{e}.w2"] += Se.T @ dY
                dSe = dY @ p[f"blk.{l}.expert.{e}.w2"].T
                dHp = dSe * silu_grad(Hp)
                g[f"blk.{l}.expert.{e}.w1"] += Xe.T @ dHp
                db_flat[idx] += dHp @ p[f"blk.{l}.expert.{e}.w1"].T
            # router: gate = pr[k]; aux = E * sum_e f_e * P_e, P_e = mean pr
            E = c.n_experts
            pr_flat = pr.reshape(N, E)
            k_flat = kidx.reshape(N)
            dpr = np.zeros((N, E), dtype=dt)
            dpr[np.arange(N), k_flat] = dgate
            dpr += (c.aux_weight * E * L["f_e"] / N)[None, :] / c.n_layers
            dr = pr_flat * (dpr - np.sum(dpr * pr_flat, axis=-1, keepdims=True))
            g[f"blk.{l}.router"] += flat_b.T @ dr
            g[f"blk.{l}.router_b"] += np.sum(dr, axis=0)
            db_flat += dr @ p[f"blk.{l}.router"].T
            # mlp
            s, h = L["s"], L["h"]
            g[f"blk.{l}.w2"] += s.reshape(N, -1).T @ dm.reshape(N, D)
            ds = dm @ p[f"blk.{l}.w2"].T
            dhp = ds * silu_grad(h)
            g[f"blk.{l}.w1"] += b.reshape(N, D).T @ dhp.reshape(N, -1)
            db = dhp @ p[f"blk.{l}.w1"].T + db_flat.reshape(B, T, D)
            dx2, dg2 = self._rmsnorm_back(db, L["ln2c"], p[f"blk.{l}.ln2"])
            g[f"blk.{l}.ln2"] += dg2
            dx = dx + dx2
            # attention
            o2, prob, q, k, v, a = L["o2"], L["prob"], L["q"], L["k"], L["v"], L["a"]
            dattn = dx
            g[f"blk.{l}.wo"] += o2.reshape(N, D).T @ dattn.reshape(N, D)
            do2 = dattn @ p[f"blk.{l}.wo"].T
            do = do2.reshape(B, T, H, dh).transpose(0, 2, 1, 3)
            dprob = do @ np.swapaxes(v, -1, -2)
            dv = np.swapaxes(prob, -1, -2) @ do
            dsc = prob * (dprob - np.sum(dprob * prob, axis=-1, keepdims=True)) * scale
            dq = dsc @ k
            dk = np.swapaxes(dsc, -1, -2) @ q
            dq2 = dq.transpose(0, 2, 1, 3).reshape(B, T, D)
            dk2 = dk.transpose(0, 2, 1, 3).reshape(B, T, D)
            dv2 = dv.transpose(0, 2, 1, 3).reshape(B, T, D)
            a2 = a.reshape(N, D)
            g[f"blk.{l}.wq"] += a2.T @ dq2.reshape(N, D)
            g[f"blk.{l}.wk"] += a2.T @ dk2.reshape(N, D)
            g[f"blk.{l}.wv"] += a2.T @ dv2.reshape(N, D)
            da = dq2 @ p[f"blk.{l}.wq"].T + dk2 @ p[f"blk.{l}.wk"].T + dv2 @ p[f"blk.{l}.wv"].T
            dx1, dg1 = self._rmsnorm_back(da, L["ln1c"], p[f"blk.{l}.ln1"])
            g[f"blk.{l}.ln1"] += dg1
            dx = dx + dx1
        np.add.at(g["tok_emb"], ids, dx)
        g["pos_emb"][:T] += np.sum(dx, axis=0)
        return g

    # ----------------------------------------------------------- generate
    def generate(self, prompt: bytes, max_new: int = 200, temperature: float = 0.8, top_k: int = 40,
                 seed: int = 0, prior_text: Optional[str] = None) -> bytes:
        rng = Rng(seed)
        ids = [BOS] + list(prompt[-(self.cfg.ctx - 1):])
        prior = self.prior_bias([prior_text or prompt.decode("utf-8", errors="replace")])
        out = []
        for _ in range(max_new):
            ctx = np.array([ids[-self.cfg.ctx:]], dtype=np.int64)
            res = self.forward(ctx, prior=prior, cache=False)
            logits = res["logits"][0, -1, :256].astype(np.float64)
            if temperature <= 0:
                nxt = int(np.argmax(logits))
            else:
                logits = logits / temperature
                if top_k and top_k < logits.size:
                    thr = np.partition(logits, -top_k)[-top_k]
                    logits = np.where(logits < thr, -np.inf, logits)
                pr = kernels.softmax_lse(logits)
                nxt = int(rng.choice(256, p=pr))
            out.append(nxt)
            ids.append(nxt)
        return bytes(out)

    # ------------------------------------------------------------- SFF io
    def save_sff(self, path: Path, mode: str = "create", budget: Optional[str] = None, keyframe: bool = True,
                 ledger=None, note: str = "", state: Optional[dict] = None) -> dict:
        """
        create: fresh SFF with every parameter as a helix of pages (F32 key-frames, or a bit band).
        append: new checkpoint pages — DELTA8 against the current key-frame page (or a new key-frame),
                page map re-pointed, patch log written. Old checkpoints stay readable (rollback = pointer).
        """
        path = Path(path)
        meta = {"model_id": path.stem, "arch": {"family": "soke-lm", "version": 1, "config": self.cfg.to_dict(),
                                                "tensors": self.param_names()},
                "tokenizer": {"kind": "bytes", "vocab": self.cfg.vocab, "bos": BOS, "eos": EOS, "pad": PAD},
                "state": dict(state or {}, step=self.step)}
        if mode == "create" or not path.exists():
            w = SFFWriter(path, file_kind=0, meta=meta, model_id=path.stem)
            model_node = w.add_lineage_node(6, f"model:{path.stem}")
            for name, arr in self.p.items():
                hid = w.add_helix(name, domain_id=domain_id(self.tensor_domain(name)), register_kind=5, kind=HELIX_KIND_TENSOR)
                w.write_tensor(name, arr, hid, ENC_F32, budget=budget, dtype_orig=100)
                tn = w.add_lineage_node(4, name, ref_index=w.tensors[name].tensor_id)
                w.add_lineage_edge(model_node, tn, 15)
            w.add_exp(0, {"event": "create", "step": self.step, "note": note, "n_params": self.n_params()})
            from .frame_engine import certified_rows
            for r in certified_rows():          # the calculus' own certified Third-Law table rides in every model
                w.add_opt_row(f"calculus:{r['pipeline']}", r["baseline_ops"], r["ortho_ops"], r["status"], cut_pct=r["cut_pct"], note=r["note"])
            pages = w.next_page_id
            if ledger is not None:
                w.set_ledger_bytes(ledger.export_bytes())
            w.commit()
            w.close()
            return {"mode": "create", "pages": pages, "params": self.n_params()}
        w = SFFWriter(path, mode="append")
        w.meta["state"] = dict(state or {}, step=self.step)
        w.meta["arch"] = meta["arch"]
        rd = SFFReader(path)
        n_delta = n_key = 0
        ck = w.add_lineage_node(5, f"checkpoint:step{self.step}")
        model_node = w.add_lineage_node(6, f"model:{path.stem}@step{self.step}")
        for name, arr in self.p.items():
            ti = w.tensors.get(name)
            if ti is None or tuple(ti.shape) != tuple(np.shape(arr)):
                # new or resized tensor (expansion): new helix, fresh key-frame pages, lineage edge to the old one
                hid = w.add_helix(f"{name}@{self.step}", domain_id=domain_id(self.tensor_domain(name)), register_kind=5, kind=HELIX_KIND_TENSOR)
                old_id = ti.tensor_id if ti is not None else -1
                w.tensors.pop(name, None)
                nti = w.write_tensor(name, arr, hid, ENC_F32, dtype_orig=100)
                tn = w.add_lineage_node(4, name, ref_index=nti.tensor_id)
                w.add_lineage_edge(model_node, tn, 11 if old_id >= 0 else 13)
                n_key += nti.page_count
                continue
            flat = np.ascontiguousarray(arr, dtype=np.float32).ravel()
            pv = w.page_values
            for i in range(ti.page_count):
                chunk = flat[i * pv:(i + 1) * pv]
                old = w.pmap[ti.helix_id][ti.page_start + i]
                if keyframe:
                    new = w.write_page(ti.helix_id, ti.page_start + i, chunk, ENC_F32)
                    n_key += 1
                    kind = 0
                else:
                    e = rd.page_entry(old)
                    base_id = old if int(e["encoding"]) != ENC_DELTA8 else int(e["base_page"])
                    base = rd.read_page(base_id)
                    new = w.write_page(ti.helix_id, ti.page_start + i, chunk, ENC_DELTA8, base_page=base_id, base_array=base)
                    n_delta += 1
                    kind = 4
                w.add_patch(ti.helix_id, ti.page_start + i, old, new, kind, note or f"step {self.step}")
        rd.close()
        w.add_lineage_edge(ck, ck, 15)
        w.add_exp(0, {"event": "checkpoint", "step": self.step, "keyframe": keyframe, "note": note})
        if ledger is not None:
            w.set_ledger_bytes(ledger.export_bytes())
        w.commit()
        w.close()
        return {"mode": "append", "keyframe_pages": n_key, "delta_pages": n_delta}

    @staticmethod
    def load_sff(path: Path, max_params: int = 200_000_000) -> "SokeLM":
        rd = SFFReader(path)
        arch = rd.meta.get("arch", {})
        if arch.get("family") not in ("soke-lm", "skynet-lm"):   # accept legacy skynet-lm SFFs (existing models)
            rd.close()
            raise ValueError("not a soke-lm SFF model")
        cfg = ModelConfig.from_dict(arch["config"])
        m = SokeLM(cfg, init=False)
        total = sum(t.n_elem for t in rd.tensors.values())
        if total > max_params:
            rd.close()
            raise MemoryError(f"model has {total} params > max_params guard; use StreamingModel")
        for name in arch["tensors"]:
            m.p[name] = rd.read_tensor(name).astype(m.dt)
        m.step = int(rd.meta.get("state", {}).get("step", 0))
        rd.close()
        return m

    def rollback_sff(self, path: Path, to_step: Optional[int] = None) -> dict:
        """
        Re-point every page to the version recorded at the last checkpoint at or before `to_step`
        (pointer change only; no bytes rewritten). to_step=None -> the previous checkpoint.
        """
        import re
        rd = SFFReader(path)
        patches = rd.patches()
        rd.close()
        timeline: dict[tuple[int, int], list[tuple[int, int, int]]] = {}    # key -> [(step, old, new)]
        for pt in patches:
            m = re.search(r"step\s*(\d+)", pt["note"])
            st = int(m.group(1)) if m else -1
            timeline.setdefault((pt["helix"], pt["index"]), []).append((st, pt["old_page"], pt["new_page"]))
        if to_step is None:
            steps = sorted({st for rows in timeline.values() for st, _, _ in rows if st >= 0})
            to_step = steps[-2] if len(steps) >= 2 else 0
        w = SFFWriter(path, mode="append")
        n = 0
        for (hid, idx), rows in timeline.items():
            candidates = [r for r in rows if 0 <= r[0] <= to_step]
            target = candidates[-1][2] if candidates else rows[0][1]       # creation page if nothing at/before to_step
            cur = w.pmap[hid][idx]
            if cur != target:
                w.add_patch(hid, idx, cur, target, 5, f"rollback to step {to_step}")
                w.point_page(hid, idx, target)
                n += 1
        w.add_exp(0, {"event": "rollback", "to_step": to_step, "repointed": n})
        w.commit()
        w.close()
        return {"repointed": n, "to_step": to_step}


class StreamingModel(SokeLM):
    """
    Inference over an SFF model without holding the whole file: the shared trunk is
    read once (small), expert tensors are fetched on demand from their helices and
    kept in a small LRU — only the domains a query routes to are ever loaded.
    """

    def __init__(self, path: Path, expert_cache: Optional[int] = None):
        self.rd = SFFReader(path)
        arch = self.rd.meta["arch"]
        cfg = ModelConfig.from_dict(arch["config"])
        super().__init__(cfg, init=False)
        self.loaded_experts: list[int] = []
        self.expert_cache = expert_cache or cfg.n_experts      # on-demand loading; LRU eviction only when capped
        self.expert_loads = 0
        for name in arch["tensors"]:
            if ".expert." not in name:
                self.p[name] = self.rd.read_tensor(name).astype(self.dt)
        self.step = int(self.rd.meta.get("state", {}).get("step", 0))

    def expert_weights(self, l: int, e: int) -> tuple[np.ndarray, np.ndarray]:
        if e not in self.loaded_experts:
            for ll in range(self.cfg.n_layers):
                for w in ("w1", "w2"):
                    n = f"blk.{ll}.expert.{e}.{w}"
                    self.p[n] = self.rd.read_tensor(n).astype(self.dt)
            self.loaded_experts.append(e)
            self.expert_loads += 1
            while len(self.loaded_experts) > self.expert_cache:
                old = self.loaded_experts.pop(0)
                for ll in range(self.cfg.n_layers):
                    for w in ("w1", "w2"):
                        self.p.pop(f"blk.{ll}.expert.{old}.{w}", None)
            self.rd.clear_cache()
        return self.p[f"blk.{l}.expert.{e}.w1"], self.p[f"blk.{l}.expert.{e}.w2"]

    def generate(self, prompt: bytes, max_new: int = 100, **kw) -> tuple[bytes, dict]:
        text = prompt.decode("utf-8", errors="replace")
        out = super().generate(prompt, max_new=max_new, prior_text=text, **kw)
        return out, {"experts_loaded": list(self.loaded_experts), "expert_loads": self.expert_loads,
                     "experts_total": self.cfg.n_experts, "resident_params": self.n_params()}

    def close(self):
        self.rd.close()


# ==========================================================================
# optimizer + trainer
# ==========================================================================
class AdamW:
    def __init__(self, params: dict[str, np.ndarray], lr: float = 3e-3, betas=(0.9, 0.99), wd: float = 0.01, eps: float = 1e-8):
        self.lr, self.b1, self.b2, self.wd, self.eps = lr, betas[0], betas[1], wd, eps
        self.m = {k: np.zeros_like(v) for k, v in params.items()}
        self.v = {k: np.zeros_like(v) for k, v in params.items()}
        self.t = 0

    def reset(self, params: dict[str, np.ndarray]) -> None:
        self.m = {k: np.zeros_like(v) for k, v in params.items()}
        self.v = {k: np.zeros_like(v) for k, v in params.items()}
        self.t = 0

    def resize(self, params: dict[str, np.ndarray]) -> None:
        """After expansion: keep moments for unchanged shapes, zero new ones (identity-init safe)."""
        for k, v in params.items():
            if k not in self.m or self.m[k].shape != v.shape:
                self.m[k] = np.zeros_like(v)
                self.v[k] = np.zeros_like(v)

    def step(self, params: dict[str, np.ndarray], grads: dict[str, np.ndarray], clip: float = 1.0) -> float:
        self.t += 1
        gn = math.sqrt(sum(float(np.sum(g * g)) for g in grads.values()))
        sc = min(1.0, clip / (gn + 1e-12)) if clip else 1.0
        b1t, b2t = 1 - self.b1 ** self.t, 1 - self.b2 ** self.t
        for k, p in params.items():
            g = grads[k] * sc
            self.m[k] = self.b1 * self.m[k] + (1 - self.b1) * g
            self.v[k] = self.b2 * self.v[k] + (1 - self.b2) * g * g
            mhat = self.m[k] / b1t
            vhat = self.v[k] / b2t
            if p.ndim >= 2 and self.wd:
                p *= (1 - self.lr * self.wd)
            p -= self.lr * mhat / (np.sqrt(vhat) + self.eps)
        return gn


class ByteStream:
    """
    Streams training bytes from files (or a HelicalMemory) with a bounded rolling
    buffer; batches are random windows from the buffer, which is refilled from the
    next file chunk every `refill_every` batches. The corpus is never loaded whole.
    """

    def __init__(self, sources: list, buffer_bytes: int = 4 << 20, chunk_bytes: int = 256 << 10, seed: int = 369,
                 val_fraction: float = 0.05):
        self.sources = [Path(s) for s in sources]
        self.buffer_bytes = buffer_bytes
        self.chunk_bytes = chunk_bytes
        self.rng = Rng(seed)
        self.buf = bytearray()
        self.val = bytearray()
        self.val_fraction = val_fraction
        self._file_i = 0
        self._pos = 0
        self.total_read = 0
        self.epochs = 0
        self.texts_seen = 0
        self._fill()

    def _next_chunk(self) -> bytes:
        if not self.sources:
            return b""
        for _ in range(len(self.sources) + 1):
            src = self.sources[self._file_i % len(self.sources)]
            try:
                with open(src, "rb") as f:
                    f.seek(self._pos)
                    b = f.read(self.chunk_bytes)
            except OSError:
                b = b""
            if b:
                self._pos += len(b)
                self.total_read += len(b)
                return b
            self._file_i += 1
            self._pos = 0
            if self._file_i % len(self.sources) == 0:
                self.epochs += 1
        return b""

    def _fill(self) -> None:
        while len(self.buf) < self.buffer_bytes:
            b = self._next_chunk()
            if not b:
                break
            cut = int(len(b) * self.val_fraction)
            if cut and len(self.val) < self.buffer_bytes // 8:
                self.val += b[:cut]
                b = b[cut:]
            self.buf += b
        if len(self.buf) > self.buffer_bytes:
            del self.buf[: len(self.buf) - self.buffer_bytes]

    def refill(self) -> None:
        b = self._next_chunk()
        if b:
            self.buf += b
            if len(self.buf) > self.buffer_bytes:
                del self.buf[: len(self.buf) - self.buffer_bytes]

    def batch(self, B: int, T: int, val: bool = False) -> tuple[np.ndarray, np.ndarray, list[str]]:
        src = self.val if (val and len(self.val) > T + 2) else self.buf
        if len(src) < T + 2:
            raise ValueError("not enough data in the stream buffer")
        ids = np.empty((B, T), dtype=np.int64)
        tgt = np.empty((B, T), dtype=np.int64)
        texts = []
        for i in range(B):
            s = int(self.rng.integers(0, len(src) - T - 1))
            seq = np.frombuffer(bytes(src[s:s + T + 1]), dtype=np.uint8).astype(np.int64)
            ids[i] = seq[:-1]
            tgt[i] = seq[1:]
            texts.append(bytes(src[s:s + T]).decode("utf-8", errors="replace"))
        return ids, tgt, texts


def gradient_check(seed: int = 3, eps: float = 1e-5) -> dict:
    """Finite-difference check of the full backward pass in float64 on a tiny model (two routes: analytic vs numeric)."""
    cfg = ModelConfig(d_model=8, n_heads=2, n_layers=2, d_ff=12, ctx=6, experts=["math", "music", "art"], d_expert=6,
                      dtype="float64", aux_weight=0.05, prior_weight=0.0)
    m = SokeLM(cfg, seed=seed)
    # scale up weights so routing has structure
    for k in m.p:
        if m.p[k].ndim == 2:
            m.p[k] *= 20.0
    rng = Rng(seed)
    ids = rng.integers(0, 256, (2, 6))
    tgt = rng.integers(0, 256, (2, 6))
    out = m.forward(ids, tgt)
    g = m.backward(out)
    worst = 0.0
    checked = 0
    report = {}
    for name, arr in m.p.items():
        flat = arr.reshape(-1)
        idxs = rng.choice(flat.size, size=min(6, flat.size), replace=False)
        errs = []
        for i in idxs:
            old = flat[i]
            flat[i] = old + eps
            lp = m.forward(ids, tgt, cache=False)["total"]
            flat[i] = old - eps
            lm = m.forward(ids, tgt, cache=False)["total"]
            flat[i] = old
            num = (lp - lm) / (2 * eps)
            ana = g[name].reshape(-1)[i]
            rel = abs(num - ana) / max(1e-8, abs(num) + abs(ana))
            errs.append(rel)
            checked += 1
        report[name] = max(errs)
        worst = max(worst, max(errs))
    return {"worst_rel_err": worst, "checked": checked, "per_tensor": report}


def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    chk = chk or Check("model")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_model_"))
    gc = gradient_check()
    chk("backward pass == finite differences (float64, all tensors incl. router/experts)", gc["worst_rel_err"] < 1e-5,
        f"worst rel err {gc['worst_rel_err']:.2e} over {gc['checked']} coordinates")
    cfg = ModelConfig(d_model=32, n_heads=4, n_layers=2, d_ff=64, ctx=32, experts=["math", "music", "art", "technology"], d_expert=32)
    m = SokeLM(cfg, seed=1)
    chk("param count", m.n_params() == sum(v.size for v in m.p.values()) and m.n_params() > 20000, str(m.n_params()))
    # a tiny corpus: learn a repeating pattern; loss must drop
    corpus = tmpdir / "c.txt"
    corpus.write_bytes(b"the chord and the melody in harmony. " * 400 + b"prove the theorem by induction. " * 400)
    bs = ByteStream([corpus], buffer_bytes=1 << 16, chunk_bytes=1 << 12)
    opt = AdamW(m.p, lr=3e-3)
    losses = []
    for step in range(60):
        ids, tgt, texts = bs.batch(8, 32)
        out = m.forward(ids, tgt, prior=m.prior_bias(texts))
        g = m.backward(out)
        opt.step(m.p, g)
        losses.append(out["loss"])
        m.step += 1
    chk("training reduces loss on a streamed corpus", losses[-1] < losses[0] * 0.6, f"{losses[0]:.3f} -> {losses[-1]:.3f}")
    chk("router uses several experts", int(np.count_nonzero(out["route_hist"])) >= 2, str(out["route_hist"].tolist()))
    chk("stream never loaded the file whole (bounded buffer)", len(bs.buf) <= 1 << 16 and bs.total_read > 0)
    # save/load/append/rollback through SFF
    p = tmpdir / "m.sff"
    st = m.save_sff(p, "create")
    m2 = SokeLM.load_sff(p)
    chk("SFF save/load round trip (exact F32)", all(np.array_equal(m.p[k], m2.p[k]) for k in m.p) and st["params"] == m.n_params())
    snapshot = {k: v.copy() for k, v in m.p.items()}
    for step in range(10):
        ids, tgt, texts = bs.batch(8, 32)
        out = m.forward(ids, tgt)
        opt.step(m.p, m.backward(out))
        m.step += 1
    st2 = m.save_sff(p, "append", keyframe=False, note=f"step {m.step}")
    m3 = SokeLM.load_sff(p)
    err = max(float(np.max(np.abs(m.p[k] - m3.p[k]))) for k in m.p)
    chk("DELTA8 checkpoint append reloads within tolerance", st2["delta_pages"] > 0 and err < 5e-3, f"max err {err:.2e}")
    rb = m.rollback_sff(p, to_step=0)
    m4 = SokeLM.load_sff(p)
    chk("rollback to step 0 is byte-identical (pointer change)", rb["repointed"] > 0 and all(np.array_equal(snapshot[k], m4.p[k]) for k in m.p))
    # streaming inference loads only routed experts
    sm = StreamingModel(p, expert_cache=2)
    txt, info = sm.generate(b"the chord and the melody", max_new=12, temperature=0.0)
    chk("streaming model loads only routed experts (LRU 2 of 4)", 0 < len(info["experts_loaded"]) <= 2 and info["experts_total"] == 4 and info["resident_params"] < m.n_params(), str(info))
    chk("generation produces bytes", isinstance(txt, bytes) and len(txt) == 12)
    sm.close()
    g1 = m.generate(b"prove the theorem", max_new=8, temperature=0.0)
    g2 = m.generate(b"prove the theorem", max_new=8, temperature=0.0)
    chk("greedy generation deterministic", g1 == g2)
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
