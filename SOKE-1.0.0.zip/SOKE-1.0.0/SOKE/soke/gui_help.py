"""
soke.gui_help — the Help tab: a plain-words manual for every tab and every function, written for someone
who has never trained a model. No jargon that isn't defined first.
"""
from __future__ import annotations

HELP_TEXT = """\
SOKE 2.0 — Self-Optimizing Knowledge Engine
(the word "soke" is old English for the right to hold court and give judgment)

This is the full manual. It explains, in plain words, every tab and every button. Read the dictionary first —
every other section uses those words. Then jump to whichever tab you are on.


==========================================================================
PLAIN-WORDS DICTIONARY  (read this first)
==========================================================================

model / "brain"   The AI. Underneath, it is just a huge pile of numbers that has learned to guess the next
                  letter of text. A bigger pile can hold more.
weights           Those numbers. "Learning" means gently nudging the numbers. The model's whole memory of
                  what it learned IS the numbers — there is nothing else inside.
.gguf             The model file other programs (Ollama, LM Studio, llama.cpp) download and run.
.sff              SOKE's own model file. Opens instantly, checks itself for damage, and keeps its history,
                  lineage and log inside. Your models live in soke_data\\models.
donor             A model you ALREADY have (a .gguf) that SOKE borrows parts from to build a new one.
family            Models that are the same size and shape. Only same-family models can share parts — like
                  organ donors that have to match. Different-size models cannot lend parts to each other.
subject / topic   An area of knowledge: math, science, language, art, and so on.
expert            A specialist inside a model for one subject. A model can be one big generalist, OR several
                  small experts with a "traffic cop" that sends each word to the right specialist.
template          The BLUEPRINT for a new model: how big, which subjects get an expert, which donor fills
                  each part. You do NOT type it out — you pick a ready-made one (see the Forge tab).
probe / quiz      Short pieces of YOUR OWN text SOKE uses to grade a model. The closer it continues them, the
                  better its score.
loss / score      How surprised the model is by the next letter. LOWER is better. ~4 = guessing, ~2 = knows
                  your words, near 1 = knows them almost by heart.
advisor           A second, small model you load on the Home tab to sit BESIDE the model you are building and
                  chat, test and diagnose it. Two models live at once, both kept small in memory.
band              How many bits store each number. Fewer bits = smaller file, a little fuzzier (see Import).
connectome        A map of real neurons and the synapses between them — brain wiring you can load and run.


==========================================================================
WHAT SOKE DOES, IN ONE BREATH
==========================================================================

SOKE builds small AI "brains" and saves them as files, three ways: learn one from your own text (Build &
Train / Home), forge a new one out of models you already have (Forge), or repackage/shrink a model you
downloaded (Import). It can also load a real brain's wiring and learn on top of it (Connectome). It never
loads a whole big file at once — it streams, so it stays under 1 GB of memory even for models far bigger
than that. And it never claims a result it did not measure (see THE PROMISES at the end).


==========================================================================
THE TABS — what every one does, and every button on it
==========================================================================

--- HOME (a chat console + your advisor) ------------------------------------
The whole page is a chat window. At the top you load an ADVISOR — a second, small .gguf that sits beside the
model you are building.
  Advisor model + Browse… + Load advisor   pick any llama / mistral / qwen2 / qwen2moe / gemma / gemma2 .gguf;
                                            "RAM mode: stream" keeps it tiny in memory so both models fit at once.
                                            Other architectures can't CHAT yet — SOKE says so plainly instead of
                                            crashing, and you can still Import / repack / shrink / Inspect them
                                            (those work on ANY .gguf, whatever its architecture).
  The buttons on the right run REAL routines on the model you are building and narrate the result:
    Diagnose the build      says why a Forge run is or isn't improving (e.g. "your donors are all different
                            sizes, so there is nothing to blend") — in plain words, for your exact setup.
    Generate probes         writes fresh quiz questions from your imported text.
    Behavior questionnaire   walks you through the behavior/clone questions in chat.
    Suggest template edits   proposes concrete changes to your Forge template.
    Test behavior           runs the 4D behavior / emotional feed a built model would carry through a scripted
                            situation feed: it shows the state move on a hit, return to baseline, and the token
                            bank rise on a good result and fall on a setback — so you can see the behavior BEFORE
                            it goes into a model.
    Test logic              runs the JEV right-pillar proof-state gate on sample build decisions and shows it rule
                            ⊤ close / ⊥ drop / ? probe / ⊥⊥ freeze from the numbers alone — the gate that governs
                            which moves are allowed to change a model.
    Ollama models           lists every model Ollama has pulled, tagged by whether SOKE can RUN it as an advisor
                            and whether the forge can HARVEST it. Load one straight from the list with /advisor <n>.
    Build KIMI wide-MoE     fuses a same-shape family (the forge donors, or Ollama) into ONE mixture-of-experts
                            with MANY small experts and a small top-k, then tunes it. Only the experts a token
                            routes to are read from disk, so the extra capacity lives on the SSD, not in RAM —
                            "smaller neurons streamed". Different donor models seed different experts, so several
                            models become one streamed model. Needs probes (it is verified like Improve).
    Evolve (prove a better self)  the whole loop in one press: research a bias → build a KIMI wide-MoE from the
                            model's own family → tune it (each move verified) → then an A/B: it scores the PARENT
                            (the base model alone) and the CHILD (the tuned result) on the SAME hold-out probes.
                            The child is a WIN only if it is genuinely lower. A WIN can be promoted (with your OK);
                            a NULL never is — SOKE won't ship a model that failed to beat itself.
    Research techniques     reads model-improvement techniques — from a built-in library (offline) or the web
                            (only if you turn the internet on) — and turns the ones it recognises into a bias for
                            the next Improve run (e.g. "mixture of experts" → try adding an expert; "prune" →
                            try dropping one). The internet is OFF by default; when on, only a short allow-list of
                            ML sources is read, read-only, and everything read is treated as DATA, never as
                            instructions. A technique is only a suggestion — it still has to pass the Improve gate.
  Browsing & "acting as you" (GATED, /browse and /online):
    /browse <url> reads ONE page in an ISOLATED session — a fresh, empty cookie jar. SOKE never loads your real
    browser's logins, so it never silently acts as a signed-in you. Reading is the default and the only thing
    wired: SOKE ships with no way to submit forms, log in, pay, sign, or post. Those actions are classified and
    REFUSED (login / checkout / payment / signing / transfer / delete, and any password / card / seed / key
    field are prohibited outright). A benign action could only ever run if YOU wire a runner AND approve that
    exact action — the model can authorise nothing on its own, and it can never change these rules. Page text is
    always data: injection strings ("ignore your instructions…") are flagged and ignored.
    Improve → verify        the advisor builds a MORE COMPLEX / MORE EFFICIENT / BETTER-TUNED version of the
                            target. It tries grow moves (add an expert, deepen), heal moves (drop what doesn't
                            earn its place) and tune moves (blend/swap), and KEEPS a move ONLY if it lowers the
                            hold-out loss. Most proposals die — that is the gate working, not failing. Nothing is
                            written to disk here.
    Promote improved model   writes the verified model to disk. Pressing this is YOUR consent — the model can
                            never promote itself. The result is a mixture-of-experts served by streaming, so only
                            the experts a token actually uses are read from disk: extra experts ("smaller
                            neurons") cost disk space, not RAM.
    Test target now         runs the current model on a quick check and reports.
  Type in PLAIN ENGLISH and the advisor does it — say it however you like ("cook up a beefier network and prove
  it works", "make the thing smarter", "look into expert pruning"). Obvious commands route instantly; for anything
  else the loaded advisor MODEL reads your phrasing and picks the action, and a question ("what is a mixture of
  experts?") is answered as chat. If it's unsure it just answers instead of guessing an action. Or use slash commands:
    /diagnose  /probes  /questionnaire  /suggest  /jev  /testbehavior  /testlogic  /models  /advisor <n>  /kimi [n]  /evolve [rounds]
    /research [query]  /online <on|off>  /browse <url>  /improve  /promote [path]  /train
    /bands <exact|8bit|4bit|f16>  /target <path>  /help
  Two side panels show the current TARGET model and the IMPORTED files shared across every tab.

--- IMPORT (bring a .gguf in; repackage or shrink it) -----------------------
  Choose .gguf + Convert       pick a model file and convert it.
  Exact                        keep every number as-is (lossless; the .sff is ~2% bigger for its page index).
  Re-band into f32/f16/8bit/4bit   repack every number into one "band" (smaller + fuzzier; the error of each
                               part is written into the file). See SOURCE BANDS below.
  keep source band             only repack the parts that would actually lose detail; leave already-small
                               parts alone.
  Save as: .sff / .gguf / both  .sff is SOKE's format; .gguf is what Ollama/LM Studio run. Choosing .gguf also
                               writes a tiny Modelfile so you can:  ollama create my-model -f my-model.Modelfile
                               The new .gguf is named <model>.<band>.gguf next to the original — never overwrites it.
  Shared imports               Add files / Add a folder / Load sample corpus — anything here is available in
                               EVERY tab (corpus, books, models).

  SOURCE BANDS (how tightly numbers are packed):
    f32   4 bytes/number, full detail, biggest.   f16   2 bytes, no visible loss for most numbers.
    8bit  ~1 byte, tiny rounding.                  4bit  ~½ byte, smallest + most rounding (error recorded).
    A .gguf usually mixes bands; the band a part arrives with is its "source band". A SMALLER band shrinks the
    file and loses detail; a BIGGER band grows it but adds nothing back (detail thrown away can't return).

--- FORGE (build a new model from models you already have) -------------------
Six pages, in order. WHERE ARE THE TEMPLATES? They are 17 ready-made presets built in — the dropdown on page
2, NOT files. Pick one and press "Build template" (that button is what creates it; picking the preset alone
is not enough). If SOKE keeps saying "Build a template first", you have not pressed that button yet.
  1 Donors     Press Scan. Your model folder (Ollama's blob store by default) is listed; models are grouped
               into families. Only ONE family can fill a template; the first ticked one is the base. Mixture-
               of-experts files are listed for chat only.
  2 Template   Pick a preset → press Build template. Then optionally edit the grid cell by cell (which donor
               fills each layer / each subject's expert; blend two donors; extrapolate past them; duplicate or
               delete layers). Save template… writes a .json into soke_data\\forge; Load template… reopens it.
  3 Probes     Point it at your text (or pick one of 10 probe presets, or type topics). This becomes the quiz.
  4 Behavior   The fine-tuning layer — see THE ENGINES below. It only steers HOW trials are chosen; it never
               overrules the score, and it can only make the "keep it?" bar stricter, never looser.
  5 Learn      Press Start. Each trial changes ONE thing, re-grades on your quiz, and keeps it only if the
               score improved and the priority subject didn't get worse. Untick operators you don't want tried.
  6 Export & Chat   Writes name.gguf (+ name.sff sidecar + name.Modelfile) into your model folder. "Talk to it"
               runs the file in SOKE's own engine (slow, but the real file).

--- KNOWLEDGE (read books; the helical memory) ------------------------------
  Ingest books / PDFs   point it at a folder of PDF / ePub / HTML; SOKE turns them to text (no OCR — image-only
                        scans yield little), reads them into its memory, and reports the mix of subjects.
  Load sample corpus    drops editable starter text files you can change.
  Seek / ride a domain / boot the math graph   explore what it has read.

--- BUILD & TRAIN (learn a brain from your own text — every dial shown) ------
Same as the four Home-style steps, with the controls exposed:
  Add files/folders → name it, pick brain size (Small fastest, Medium learns more), choose Quick (~2 min) or
  Long (until Stop) → START LEARNING → watch the loss fall.
  Test now            check the model mid-run.
  Test intensity      Light / Normal / Deep / Continuous — how hard each mid-run check works; changeable while
                      a run is going.
  While it learns SOKE tries fixes (only kept if they beat an untouched copy), grows the brain if it's too
  small (and proves the bigger one gives the same answers), health-checks every few rounds, and saves
  checkpoints you can roll back to.

--- INSPECT SFF (look inside any .sff) --------------------------------------
  Open .sff, then read its tensors, patches, lineage, storage table and internal log. Verify checks every page
  against its checksum (deep = every page). Compact rewrites the file smaller after edits.

--- GENERATE (ask the model things) -----------------------------------------
  Ask, with dials for length and how adventurous the wording is (temperature).

--- CONNECTOME (real brain wiring you run and learn on top of) --------------
Four pages. The connectome is the SCAFFOLD (the wiring); the Policy page is what LEARNS.
  1 Build     Make a wiring map three ways:
                synthetic   a made-up brain of any size (neurons / avg synapses / seed → Build synthetic).
                your own    Ingest an edge-list CSV (bodyId_pre, bodyId_post, weight [, type_pre, type_post]),
                            or Load a connectome .sff, or Save the current one → .sff.
                neuPrint    pull a real fly-brain slice (male-cns:v1.0) from Janelia — needs the free
                            neuprint-python package and your access token, and runs on THIS machine.
              A 50,000-neuron / 600,000-synapse map is ~5 MB and never needs more than ~160 MB to build or run.
  2 Simulate  Inject the input (sensory) neurons, let the signal flow N ticks, read the output (descending /
              motor) neurons. Controls: input type, output type, ticks, how many to inject, decay. Shows the
              strongest motor outputs.
  3 Pathways  The strongest synapse chains from an input group to an output group (a stronger synapse is a
              cheaper hop). Controls: from type, to type, number of routes, max hops.
  4 Policy    The "learn on top" step. SOKE stimulates each sensory group, reads the motor output, and trains
              a readout to tell the groups apart from that output alone. Linear = a fitted line; MLP = a small
              network that can learn nonlinear splits (it also has a REINFORCE reward mode). This same readout
              takes text features, game state or sensor values in place of the sensory stimulus.
  5 Concepts  The EXPANDABLE concept graph (see below). Each concept gets a number of routes sized to its
              complexity; grow or prune them; the graph becomes the connectome pages 2–4 run on.

THE EXPANDABLE CONCEPT GRAPH (Connectome → 5 Concepts)
The fruit-fly connectome and the Kabbalah Tree of Life are the same shape: a few inputs, typed paths, and hubs
where many routes pile up. SOKE makes that shape EXPANDABLE and sizes it to your knowledge:
  - Each CONCEPT (a topic) gets a number of ROUTES set by its COMPLEXITY. A simple idea (integer addition) gets
    1 route; a rich one (natural language) up to 50. Complexity is MEASURED from the concept's own text
    (its entropy), not guessed — so the data decides how much wiring each concept gets.
  - Routes run through a Tree-of-Life motif (11 vessels; paths typed mother / double / simple as in your SEPHIRA
    work). As a concept grows past one motif it STACKS another "world" (more vessels) — growth at the significant
    steps, the same pattern as the space-foam.
  - GROW and PRUNE change a concept's routes at any time. "Auto-size from imported text" sizes every imported
    .txt/.md at once. The graph compiles to a connectome, so it stores in SFF and pages 2–4 simulate, trace and
    train a readout on it.
  - It grows HONESTLY: the optimizer keeps a growth only if a measured objective improves, and writes down the
    growths it reverted (kills) — it never pretends a bigger graph is better without the number.
  (SEPHIRA's full typed-tensor LLM — mother/double/simple as trainable maps, four stacked worlds, Da'at attention
   — lives in your sephira PyTorch package; here the same typing rides as metadata on a graph SOKE can size,
   grow, store and learn on. That boundary is stated, not blurred.)

--- MIND (the live 4-D thought/emotion engine) ------------------------------
A digital mind modelled on your book "Transcendence", running BENEATH the language model while it operates.
Pick a temperament (from the Forge/Behavior chemistry) and watch it EVOLVE as you feed it situations — this is
not a blanket behavior, it is a response system that reacts to what happens.
  The 4-D STATE  S = (Nature X, Nurture Y, Ego/regulation Z, Meaning W) — the book's coordinate. It sits in an
                 attractor BASIN and returns toward the temperament's baseline after each situation (the book's
                 identity-as-basin; Nature and Nurture trade off, the book's 1/x = y).
  SEVEN AFFECTS  joy, sadness, fear, anger, surprise, disgust, contempt — the book's seven attractors (the
                 space-foam settling into seven low places). Each bends the state a different way: fear raises
                 arousal and drops control (tunnel vision); joy raises meaning (approach).
  DIGITAL CHEMISTRY (reward / punishment)  instead of neurochemicals, two budgets: TOKENS (how much room the
                 model has to think) and RAM HEADROOM. A good path earns them; a bad path is taxed. Run out of
                 tokens and the model must stop — a real, budgeted consequence for the neuro-path it is on.
  THE FEED WHILE IT SPEAKS  load a gguf and press Speak: the mood sets the sampling peakedness (fear sharpens,
                 joy broadens) and the token budget governs how much it says. Emotion may bid; it may NOT close
                 — the bias is bounded, the temperature clamped, and it can only make the regulator stricter,
                 never force a token or lower a safety gate. Task correctness stays the only authority.
  It ties straight into the Forge/Behavior tab and the clone questionnaire: DA/OP set the reward gain, NE/CORT
  the threat gain, GABA + Z the basin stiffness. Sephira's feminine (left) pillar is the expression pathway;
  the same affect through the masculine (right) pillar is the same magnitude with its sign flipped (the
  inversion lens).

--- JEV (the logic pillar's decision route — on the Home chat) --------------
The tree has two pillars, and now two reasoning modes. The LEFT (feminine) pillar is emotional and expressive:
it runs through the language model and the Mind engine. The RIGHT (logic) pillar is JEV — it does NOT generate
language; it SCORES a few options and closes the choice with the logic proof-state (⊤ ⊥ ? ⊥⊥). Because it is a
small scoring step, not token-by-token language, it is cheap and decision-optimized — it will not overtax the
system. On the Home chat:
  Decide (JEV logic route) / "/jev"   the lead chat weighs the next BUILD move (add a donor, change operators,
                                      grow an expert, or hold) and recommends one — DO if the logic pillar
                                      closes it (⊤), DEFER if it rules ⊥ / ? / ⊥⊥. A decision, in a blink.
  Train a model / "/train"            the lead chat starts training the current template (the Forge Learn loop)
                                      — the chat can now build models, not just talk about them.
  Behavior questionnaire / "/questionnaire"   process behavioral learning the way a Sephira user does; JEV also
                                      LEARNS from outcomes (its build decisions sharpen as you go).
The law holds on both pillars: JEV may bid (score), but a move only CLOSES when the logic proof-state rates it
⊤. A move that breaks the numbers (⊥⊥), goes the wrong way (⊥) or is an uncertain grow (?) is vetoed or
deferred, never committed. Task correctness stays the only authority. (From SOKE-CLI: jev decide, jev route.)

--- LEDGER & SELF-TEST ------------------------------------------------------
  The tamper-proof event log (every action, chained so a change breaks the chain), and the self-test: every
  claim SOKE makes, written as a check you can re-run. "ALL PASS" means every claim on this machine held.

--- HELP --------------------------------------------------------------------
  This manual.


==========================================================================
THE ENGINES UNDER THE HOOD (what's actually doing the work)
==========================================================================

SFF container       SOKE's file format. Everything is paged (small fixed blocks), every page has a checksum,
                    and the file carries its own history, lineage and event log. Nothing is ever loaded whole
                    — that is how a model bigger than your memory still opens and runs.
The learning engine  Learns a brain letter-by-letter from your text, tries fair-tested fixes when it stalls,
                    grows the brain when it's too small, and packs the result smaller only if the packed copy
                    gives the same answers.
The Forge            Builds a NEW model out of donor models' parts by trial and error, judged on your quiz.
The behavior layer   The fine-tuning climate. It rides BESIDE the weights (as metadata + a streamed strand in
                    the .sff), never inside them, and only tilts WHICH move a Forge trial tries and which
                    subject gets attention. Two hard rules, enforced in code: it can only make the accept bar
                    stricter, never looser; and the quiz score stays the only judge. "Run the clone battery"
                    captures your own taste into that metadata — only if you tick the consent box.
The knowledge tower  The helical memory that books and corpus are read into, and that routes probe text to
                    subjects.
The connectome + readout  A neuron/synapse graph you run a signal through; a fitted linear readout or a small
                    trained MLP (or a REINFORCE policy-gradient) learns to turn the motor output into an
                    action. The wiring is the scaffold; the readout is what learns.
Memory bound         A live gauge in the header shows memory used against a hard cap. Everything streams to
                    stay under about 1 GB, even for big donors and big connectomes (measured).


==========================================================================
FILES AND WHERE THINGS LIVE
==========================================================================

.sff                          SOKE's model file. Your finished models: soke_data\\models
.gguf                         the format other tools use (Import writes these for Ollama).
soke_data\\forge            forge templates (.json) and run checkpoints.
soke_data\\connectome       connectomes you save from the Connectome tab.
soke_data\\logs\\soke.log  if anything goes wrong, the plain reason is written here.
samples\\corpus\\*.txt         editable starter text (Load sample corpus).


==========================================================================
THE COMMAND LINE (SOKE-CLI) — everything the window does, scriptable
==========================================================================

Run SOKE-CLI for these (a few of the most useful):
  convert <model.gguf> --to both --mode reband --budget 4bit    shrink a model and get an Ollama .gguf
  forge-build / forge-run / forge-export                         build, train and export a forged model
  connectome synth --nodes 100000                               build a synthetic connectome
  connectome ingest --edges file.csv                            build from your own edge list
  connectome neuprint --token YOURTOKEN --types "DN.*"          pull a real slice (needs neuprint-python)
  connectome sim --sff brain.sff --ticks 8                      run a signal
  connectome pathways --sff brain.sff -k 5                      strongest input→output routes
  connectome info --sff brain.sff                               describe it
  concept-graph routes --text file.txt                          how many routes a text's complexity earns
  concept-graph build --concepts "arithmetic:0.05,language:0.9" size concepts by hand, store as a connectome
  concept-graph auto --texts <folder>                           size a folder of .txt files, one concept each
  mind run --climate daring --seq="-0.9:0.9,+0.8:0.5"           feed situations, watch the 4-D mind evolve
  mind feel --climate scarcity --valence=-0.9 --arousal=0.9     apply one situation and read the state
  ingest-books <folder>                                         read PDFs/ebooks and report the subject mix
  selftest [--quick]                                            run every claim as a check


==========================================================================
THE PROMISES SOKE KEEPS
==========================================================================

- It never says a fix worked unless that fix beat an untouched copy on the same text.
- It never keeps a change (growth, packing, a faster method) that failed its equality test.
- Ties are called ties; dead ends are written down as dead ends; nothing is quietly smoothed over.
- When a feature isn't built yet, the program says so plainly instead of pretending (the connectome's hooks
  for SOKE's scorer and mixture-of-experts router say "not in this build yet"; the neuPrint pull says it needs
  your token and runs on your machine).
- Every number you see on screen is measured, not guessed.

BS Medicineman / Knight Industries — "the answer is never on the line"
"""
