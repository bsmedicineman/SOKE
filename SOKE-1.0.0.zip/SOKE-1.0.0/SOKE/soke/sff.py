"""
soke.sff — the SFF container (SOKE File Format, magic "SKNT").

WHY NOT GGUF (each point is a measured property of this file, not a slogan):
  * paged, gauge-tagged storage: every tensor is a helix of pages; a reader maps the
    file and touches only the pages it needs (constant RAM, O(log N) seek);
  * append-only: a page is never overwritten — new versions are new pages, the
    page map (PMP1) points at the current ones, the patch log (PAT1) is the
    history, rollback is a pointer change; checkpoints are DELTA8 pages against
    key-frame pages (video-style seek to any checkpoint);
  * the lineage graph, the Third-Law table, the ledger (hash-chained, signed),
    the domain lattice index and the architecture all live INSIDE the file;
  * every section and every page carries its own checksum.

FILE LAYOUT
  [header 64 B][segment 0 sections...][dir 0][segment 1 sections...][dir 1]...
  The header always points at the newest directory. Old directories become
  garbage (reclaimed by compact()). Replaceable section types (META, HLX1, TNS1,
  PMP1, REG1, IDX1) are re-emitted whole each commit; append-only types (PTB1,
  PDT1, LIN1, PAT1, EXP1, OPT1, LDG1) accumulate, one entry per segment.

HEADER (little-endian, 64 bytes)
  0  4  magic "SKNT"        4  2 major      6  2 minor       8 1 endianness (0=LE)
  9  1  file_kind (0 model, 1 knowledge, 2 patch bundle, 3 forge sidecar)  10 2 header_flags
  12 8  creation_unix_ns    20 8 soke_build_id  28 8 dir_offset  36 4 section_count
  40 8  payload_checksum (sha256[:8] of the concatenated directory-entry checksums)
  48 8  reserved           56 8 header_checksum (sha256[:8] of bytes 0..55)
DIRECTORY
  "SECT" u32 count, entries of 32 B: section_id u16 | type u16 | flags u32 | offset u64 | length u64 | checksum u64
  (checksum = sha256[:8] of the section bytes; flags>>16 = segment number)
"""
from __future__ import annotations

import hashlib
import io
import json
import mmap
import os
import struct
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator, Optional

import numpy as np

from .rng import Rng

from . import SFF_SCHEMA, SOKE_VERSION, AUTHOR
from .teeth import (ENC_DELTA8, ENC_F32, ENC_NAMES, ENC_RAW, ENC_TOOTH, ENC_ZERO, PAGE_VALUES,
                    decode_page, encode_page)
from .util import crc32, sha256_8

MAGIC = b"SKNT"
MAJOR, MINOR = 1, 0
HEADER_FMT = struct.Struct("<4sHHBBHQQQIQQQ")
assert HEADER_FMT.size == 64
DIR_ENTRY = struct.Struct("<HHIQQQ")
assert DIR_ENTRY.size == 32

# section types
T_META, T_HLX, T_PTB, T_PDT, T_PMP, T_TNS, T_REG, T_LIN, T_PAT, T_EXP, T_OPT, T_LDG, T_IDX = range(1, 14)
TAGS = {T_META: b"META", T_HLX: b"HLX1", T_PTB: b"PTB1", T_PDT: b"PDT1", T_PMP: b"PMP1", T_TNS: b"TNS1",
        T_REG: b"REG1", T_LIN: b"LIN1", T_PAT: b"PAT1", T_EXP: b"EXP1", T_OPT: b"OPT1", T_LDG: b"LDG1", T_IDX: b"IDX1"}
TYPE_NAMES = {v: k.decode() for k, v in {v: k for k, v in TAGS.items()}.items()}
REPLACEABLE = {T_META, T_HLX, T_TNS, T_PMP, T_REG, T_IDX}
APPEND_ONLY = {T_PTB, T_PDT, T_LIN, T_PAT, T_EXP, T_OPT, T_LDG}

# META TLV type registry (the doc's 0x0001.. numbering, extended)
META_KEYS = {1: "model_id", 2: "schema", 3: "author", 4: "cost_model", 5: "gauge_policy", 6: "lineage_root",
             7: "arch", 8: "tokenizer", 9: "page_values", 10: "created_by", 11: "source", 12: "notes",
             13: "pairing_rules", 14: "tower", 15: "state", 16: "routes", 17: "file_kind_name"}
META_IDS = {v: k for k, v in META_KEYS.items()}
FILE_KINDS = {0: "SFF-model", 1: "SFF-knowledge", 2: "SFF-patch", 3: "SFF-forge-sidecar"}

# page-table entry: page_id u32 | helix_id u32 | index u32 | offset u64 | length u32 | count u32 |
#                   base_page u32 | err f32 | crc u32 | encoding u8 | flags u8 | pad u16      = 44 bytes
PTAB_DTYPE = np.dtype([("page_id", "<u4"), ("helix_id", "<u4"), ("index", "<u4"), ("offset", "<u8"),
                       ("length", "<u4"), ("count", "<u4"), ("base_page", "<u4"), ("err", "<f4"),
                       ("crc", "<u4"), ("encoding", "u1"), ("flags", "u1"), ("pad", "<u2")])
assert PTAB_DTYPE.itemsize == 44
PF_KEYFRAME, PF_ZERO, PF_RAW, PF_TOOTH, PF_EVICTED = 1, 2, 4, 8, 128
NO_PAGE = 0xFFFFFFFF

HELIX_KIND_TENSOR, HELIX_KIND_KNOWLEDGE, HELIX_KIND_STAGING = 0, 1, 2
LIN_NODE_KINDS = {0: "frame", 1: "helix", 2: "register", 3: "external", 4: "tensor", 5: "checkpoint", 6: "model"}
LIN_OPS = {0: "quadrature", 1: "harmonic", 2: "gnomon", 3: "leg_swap", 4: "orth_solve", 5: "agm", 6: "lill",
           10: "train_step", 11: "widen", 12: "deepen", 13: "add_expert", 14: "heal_patch", 15: "checkpoint",
           16: "rollback", 17: "import", 18: "consolidate"}
PATCH_KINDS = {0: "replace", 1: "add", 2: "scale", 3: "gauge_change", 4: "delta", 5: "rollback", 6: "prune", 7: "requant"}
OPT_STATUS = {0: "VERIFIED", 1: "DERIVED", 2: "TIE", 3: "BOUNDARY", 4: "NULL", 5: "EXACT", 6: "BASELINE"}
OPT_STATUS_ID = {v: k for k, v in OPT_STATUS.items()}


class SFFError(Exception):
    pass


# ==========================================================================
# records
# ==========================================================================
@dataclass
class HelixInfo:
    helix_id: int
    name: str
    domain_id: int = 0
    register_kind: int = 5
    kind: int = HELIX_KIND_TENSOR
    flags: int = 0
    page_count: int = 0
    frame_count: int = 0

    def to_bytes(self) -> bytes:
        nb = self.name.encode("utf-8")
        return struct.pack("<IHBBIIQH", self.helix_id, self.domain_id, self.register_kind, self.kind,
                           self.flags, self.page_count, self.frame_count, len(nb)) + nb

    @staticmethod
    def parse(b: bytes, off: int) -> tuple["HelixInfo", int]:
        hid, dom, rk, kind, flags, pc, fc, nl = struct.unpack_from("<IHBBIIQH", b, off)
        off += struct.calcsize("<IHBBIIQH")
        name = bytes(b[off:off + nl]).decode("utf-8")
        return HelixInfo(hid, name, dom, rk, kind, flags, pc, fc), off + nl


@dataclass
class TensorInfo:
    tensor_id: int
    name: str
    helix_id: int
    shape: tuple
    dtype_orig: int = 100           # 100 = SFF native f32; otherwise GGML type id of the source
    flags: int = 0
    n_elem: int = 0
    page_start: int = 0
    page_count: int = 0
    enc_default: int = ENC_F32
    bpv: float = 32.0
    err_base: float = 0.0
    err_chosen: float = 0.0
    status: str = "EXACT"

    def to_bytes(self) -> bytes:
        nb = self.name.encode("utf-8")
        sb = self.status.encode("utf-8")
        return (struct.pack("<IIHBB", self.tensor_id, self.helix_id, self.dtype_orig, len(self.shape), self.flags)
                + struct.pack("<" + "Q" * len(self.shape), *[int(d) for d in self.shape])
                + struct.pack("<QIIBfff", self.n_elem, self.page_start, self.page_count, self.enc_default,
                              self.bpv, self.err_base, self.err_chosen)
                + struct.pack("<H", len(nb)) + nb + struct.pack("<H", len(sb)) + sb)

    @staticmethod
    def parse(b: bytes, off: int) -> tuple["TensorInfo", int]:
        tid, hid, dt, nd, flags = struct.unpack_from("<IIHBB", b, off)
        off += 12
        shape = struct.unpack_from("<" + "Q" * nd, b, off)
        off += 8 * nd
        n_elem, ps, pc, enc, bpv, eb, ec = struct.unpack_from("<QIIBfff", b, off)
        off += struct.calcsize("<QIIBfff")
        nl = struct.unpack_from("<H", b, off)[0]
        off += 2
        name = bytes(b[off:off + nl]).decode("utf-8")
        off += nl
        sl = struct.unpack_from("<H", b, off)[0]
        off += 2
        status = bytes(b[off:off + sl]).decode("utf-8")
        off += sl
        return TensorInfo(tid, name, hid, tuple(shape), dt, flags, n_elem, ps, pc, enc, bpv, eb, ec, status), off


def _pack_str(s: str, width: str = "H") -> bytes:
    b = s.encode("utf-8")
    return struct.pack("<" + width, len(b)) + b


def _read_str(b: bytes, off: int, width: str = "H") -> tuple[str, int]:
    n = struct.unpack_from("<" + width, b, off)[0]
    off += struct.calcsize("<" + width)
    return bytes(b[off:off + n]).decode("utf-8", errors="replace"), off + n


def _meta_tlvs(meta: dict) -> bytes:
    out = io.BytesIO()
    items = list(meta.items())
    out.write(b"META" + struct.pack("<I", len(items)))
    for k, v in items:
        tid = META_IDS.get(k, 0x00FF)
        val = json.dumps(v, sort_keys=True, default=str).encode("utf-8")
        if tid == 0x00FF:
            val = k.encode("utf-8") + b"\x00" + val
        out.write(struct.pack("<HHI", tid, 0, len(val)) + val)
    return out.getvalue()


def _parse_meta(b: bytes) -> dict:
    if b[:4] != b"META":
        raise SFFError("bad META tag")
    n = struct.unpack_from("<I", b, 4)[0]
    off = 8
    meta = {}
    for _ in range(n):
        tid, _fl, ln = struct.unpack_from("<HHI", b, off)
        off += 8
        val = bytes(b[off:off + ln])
        off += ln
        if tid == 0x00FF:
            k, _, val = val.partition(b"\x00")
            key = k.decode("utf-8")
        else:
            key = META_KEYS.get(tid, f"meta_{tid}")
        try:
            meta[key] = json.loads(val.decode("utf-8"))
        except Exception:
            meta[key] = val.decode("utf-8", errors="replace")
    return meta


def _section_hash(b: bytes) -> int:
    return sha256_8(b)


# ==========================================================================
# WRITER
# ==========================================================================
class SFFWriter:
    """
    Streams pages to disk as they are produced; commits a segment (sections +
    directory + header) at once. Reopen an existing file with mode="append".
    """

    def __init__(self, path: Path, file_kind: int = 0, page_values: int = PAGE_VALUES,
                 meta: Optional[dict] = None, mode: str = "create", model_id: str = "soke-v001"):
        self.path = Path(path)
        self.page_values = page_values
        self.meta: dict = {}
        self.helices: dict[int, HelixInfo] = {}
        self.tensors: dict[str, TensorInfo] = {}
        self.pmap: dict[int, list[int]] = {}          # helix_id -> page_id per index (NO_PAGE = missing)
        self.registers: list[dict] = []
        self.dir_entries: list[tuple[int, int, int, int, int, int]] = []   # (id, type, flags, offset, length, checksum)
        self.segment = 0
        self.next_page_id = 0
        self.next_helix_id = 0
        self.next_tensor_id = 0
        self.next_section_id = 0
        self.next_patch_id = 0
        self.next_lin_node = 0
        self.next_exp_id = 0
        self.next_opt_row = 0
        self.file_kind = file_kind
        self.creation_ns = time.time_ns()
        # per-segment buffers
        self._ptab: list[tuple] = []
        self._lin_nodes: list[bytes] = []
        self._lin_edges: list[bytes] = []
        self._patches: list[bytes] = []
        self._exps: list[bytes] = []
        self._opts: list[bytes] = []
        self._ledger_bytes: bytes = b""
        self._idx_keys: dict[int, list[tuple[int, int, int]]] = {}
        self._pdt_open = False
        self._pdt_start = 0
        self._pdt_hash = None
        self._new_keys_all: list[tuple[int, int, int]] = []
        if mode == "create":
            self.meta = {"model_id": model_id, "schema": SFF_SCHEMA, "author": AUTHOR,
                         "created_by": f"SOKE {SOKE_VERSION}", "page_values": page_values,
                         "file_kind_name": FILE_KINDS.get(file_kind, "SFF"),
                         "cost_model": {"add": 1, "mul": 1, "div": 4, "sqrt": 4, "transcendental": 20},
                         "gauge_policy": ["R", "Q", "T", "L", "H"],
                         "pairing_rules": {"legal": ["AT", "CG", "AC", "TG"], "illegal": ["AG", "CT"]},
                         "lineage_root": model_id}
            if meta:
                self.meta.update(meta)
            self.registers = [{"kind": 0, "name": "R", "desc": "reciprocal (alpha, 1/alpha)"},
                              {"kind": 1, "name": "Q", "desc": "quadrature x^2"},
                              {"kind": 2, "name": "T", "desc": "half-tangent tan(theta/2)"},
                              {"kind": 3, "name": "L", "desc": "log ln x / log2 storage"},
                              {"kind": 4, "name": "H", "desc": "braid (quaternion)"},
                              {"kind": 5, "name": "LIN", "desc": "raw line (steel-man baseline)"}]
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.f = open(self.path, "w+b")
            self.f.write(b"\x00" * 64)
            self._idx_keys_existing: list[tuple[int, int, int]] = []
        elif mode == "append":
            rd = SFFReader(self.path)
            self._load_state_from(rd)
            rd.close()
            self.f = open(self.path, "r+b")
            self.f.seek(0, os.SEEK_END)
        else:
            raise ValueError("mode must be create|append")

    # ------------------------------------------------------------ state load
    def _load_state_from(self, rd: "SFFReader") -> None:
        self.meta = dict(rd.meta)
        self.page_values = int(self.meta.get("page_values", PAGE_VALUES))
        self.file_kind = rd.file_kind
        self.creation_ns = rd.creation_ns
        self.helices = {h.helix_id: HelixInfo(**h.__dict__) for h in rd.helices.values()}
        self.tensors = {t.name: TensorInfo(**t.__dict__) for t in rd.tensors.values()}
        self.pmap = {hid: list(map(int, arr)) for hid, arr in rd.pmap.items()}
        self.registers = list(rd.registers)
        # keep append-only + latest replaceable entries
        self.dir_entries = list(rd.dir_entries)
        self.segment = rd.segment_count
        self.next_page_id = int(rd.ptab["page_id"].max()) + 1 if rd.ptab.size else 0
        self.next_helix_id = max(self.helices) + 1 if self.helices else 0
        self.next_tensor_id = max(t.tensor_id for t in self.tensors.values()) + 1 if self.tensors else 0
        self.next_section_id = max((e[0] for e in self.dir_entries), default=-1) + 1
        self.next_patch_id = rd.patch_count
        self.next_lin_node = rd.lineage_node_count
        self.next_exp_id = rd.exp_count
        self.next_opt_row = rd.opt_count
        self._idx_keys_existing = rd.index_keys_list()

    # ---------------------------------------------------------------- helices
    def add_helix(self, name: str, domain_id: int = 0, register_kind: int = 5,
                  kind: int = HELIX_KIND_TENSOR, flags: int = 0) -> int:
        hid = self.next_helix_id
        self.next_helix_id += 1
        self.helices[hid] = HelixInfo(hid, name, domain_id, register_kind, kind, flags)
        self.pmap[hid] = []
        return hid

    def helix_by_name(self, name: str) -> Optional[HelixInfo]:
        for h in self.helices.values():
            if h.name == name:
                return h
        return None

    # ------------------------------------------------------------------ pages
    def _ensure_pdt(self) -> None:
        if not self._pdt_open:
            self.f.seek(0, os.SEEK_END)
            self._pdt_start = self.f.tell()
            self.f.write(b"PDT1")
            self._pdt_hash = hashlib.sha256(b"PDT1")
            self._pdt_open = True

    def write_page(self, helix_id: int, index: int, data, encoding: int, flags: int = 0,
                   base_page: int = NO_PAGE, count: Optional[int] = None, err: float = 0.0,
                   base_array: Optional[np.ndarray] = None) -> int:
        """
        data: np.ndarray (numeric encodings; encoded here) or bytes (RAW / TOOTH / pre-encoded payload).
        Returns the new page_id and points the page map at it.
        """
        self._ensure_pdt()
        if isinstance(data, (bytes, bytearray, memoryview)):
            payload = bytes(data)
            if count is None:
                raise ValueError("count required for byte pages")
        else:
            arr = np.ascontiguousarray(data, dtype=np.float32).ravel()
            count = arr.size
            if encoding == ENC_DELTA8:
                if base_array is None:
                    raise ValueError("DELTA8 page needs base_array")
                payload = encode_page(arr, encoding, base=base_array)
            else:
                payload = encode_page(arr, encoding)
            if encoding == ENC_ZERO:
                flags |= PF_ZERO
        if encoding == ENC_RAW:
            flags |= PF_RAW
        if encoding == ENC_TOOTH:
            flags |= PF_TOOTH
        if encoding in (ENC_F32,) or (encoding != ENC_DELTA8 and not (flags & PF_TOOTH)):
            flags |= PF_KEYFRAME if encoding != ENC_DELTA8 else 0
        pid = self.next_page_id
        self.next_page_id += 1
        off = self.f.tell()
        self.f.write(payload)
        self._pdt_hash.update(payload)
        self._ptab.append((pid, helix_id, index, off, len(payload), count, base_page, float(err),
                           crc32(payload), encoding, flags & 0xFF, 0))
        pm = self.pmap.setdefault(helix_id, [])
        while len(pm) <= index:
            pm.append(NO_PAGE)
        pm[index] = pid
        h = self.helices[helix_id]
        h.page_count = len(pm)
        return pid

    def write_tensor(self, name: str, arr: np.ndarray, helix_id: int, encoding: int = ENC_F32,
                     budget: Optional[str] = None, dtype_orig: int = 100, page_start: Optional[int] = None,
                     keyframe: bool = True) -> TensorInfo:
        """Write a whole (in-memory) tensor as pages; for streaming use write_page directly."""
        from .teeth import choose_encoding, ENC_BPV
        flat = np.ascontiguousarray(arr, dtype=np.float32).ravel()
        pm = self.pmap.setdefault(helix_id, [])
        start = len(pm) if page_start is None else page_start
        n_pages = (flat.size + self.page_values - 1) // self.page_values
        eb = ec = 0.0
        status = "EXACT"
        for i in range(n_pages):
            chunk = flat[i * self.page_values:(i + 1) * self.page_values]
            if budget:
                pc = choose_encoding(chunk, budget)
                self.write_page(helix_id, start + i, pc.payload, pc.enc, count=chunk.size, err=pc.mse)
                eb += pc.baseline_mse * chunk.size
                ec += pc.mse * chunk.size
                if pc.status == "VERIFIED":
                    status = "VERIFIED" if status in ("EXACT", "VERIFIED") else "MIXED"
                elif pc.status in ("TIE", "NULL", "BASELINE"):
                    status = "TIE" if status in ("EXACT", "TIE") else "MIXED"
            else:
                self.write_page(helix_id, start + i, chunk, encoding)
        n = max(flat.size, 1)
        ti = TensorInfo(self.next_tensor_id, name, helix_id, tuple(int(d) for d in np.shape(arr)), dtype_orig, 0,
                        int(flat.size), start, n_pages, encoding if not budget else ENC_BY_BUDGET.get(budget, encoding),
                        ENC_BPV.get(encoding, 32.0), eb / n, ec / n, status)
        self.next_tensor_id += 1
        self.tensors[name] = ti
        self.helices[helix_id].frame_count += int(flat.size)
        return ti

    def register_tensor(self, ti: TensorInfo) -> TensorInfo:
        if ti.tensor_id < 0:
            ti.tensor_id = self.next_tensor_id
            self.next_tensor_id += 1
        self.tensors[ti.name] = ti
        return ti

    def point_page(self, helix_id: int, index: int, page_id: int) -> None:
        """Re-point (rollback) the page map without writing bytes."""
        pm = self.pmap.setdefault(helix_id, [])
        while len(pm) <= index:
            pm.append(NO_PAGE)
        pm[index] = page_id

    # ------------------------------------------------------- history sections
    def add_lineage_node(self, kind: int, label: str, ref_section: int = 0, ref_index: int = 0, flags: int = 0) -> int:
        nid = self.next_lin_node
        self.next_lin_node += 1
        self._lin_nodes.append(struct.pack("<IBBHQ", nid, kind, flags, ref_section, ref_index) + _pack_str(label))
        return nid

    def add_lineage_edge(self, src: int, dst: int, op: int, flags: int = 0) -> None:
        self._lin_edges.append(struct.pack("<IIHHQ", src, dst, op, flags, time.time_ns()))

    def add_patch(self, helix_id: int, index: int, old_page: int, new_page: int, kind: int, note: str = "", flags: int = 0) -> int:
        pid = self.next_patch_id
        self.next_patch_id += 1
        self._patches.append(struct.pack("<IIIIIHHQ", pid, helix_id, index, old_page, new_page, kind, flags, time.time_ns())
                             + _pack_str(note))
        return pid

    def add_exp(self, exp_type: int, payload: Any) -> int:
        eid = self.next_exp_id
        self.next_exp_id += 1
        pb = json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
        self._exps.append(struct.pack("<IIQI", eid, exp_type, time.time_ns(), len(pb)) + pb)
        return eid

    def add_opt_row(self, pipeline: str, baseline_ops: float, ortho_ops: float, status: str,
                    baseline_w: float = 0.0, ortho_w: float = 0.0, cut_pct: float = 0.0, note: str = "") -> int:
        rid = self.next_opt_row
        self.next_opt_row += 1
        self._opts.append(struct.pack("<I", rid) + _pack_str(pipeline)
                          + struct.pack("<ddddiB", baseline_ops, ortho_ops, baseline_w, ortho_w, int(round(cut_pct * 100)),
                                        OPT_STATUS_ID.get(status, 4)) + _pack_str(note))
        return rid

    def set_ledger_bytes(self, b: bytes) -> None:
        self._ledger_bytes = b

    def add_index_keys(self, keys: list[tuple[int, int, int]]) -> None:
        """(key_hash u64, page_id, record_offset) for the knowledge seek index."""
        self._new_keys_all.extend(keys)

    # ------------------------------------------------------------------ commit
    def _emit(self, stype: int, body: bytes, flags: int = 0) -> None:
        self._close_pdt()
        self.f.seek(0, os.SEEK_END)
        off = self.f.tell()
        self.f.write(body)
        sid = self.next_section_id
        self.next_section_id += 1
        self.dir_entries.append((sid, stype, flags | (self.segment << 16), off, len(body), _section_hash(body)))

    def _close_pdt(self) -> None:
        if not self._pdt_open:
            return
        self.f.seek(0, os.SEEK_END)
        end = self.f.tell()
        sid = self.next_section_id
        self.next_section_id += 1
        digest = struct.unpack("<Q", self._pdt_hash.digest()[:8])[0]
        self.dir_entries.append((sid, T_PDT, self.segment << 16, self._pdt_start, end - self._pdt_start, digest))
        self._pdt_open = False

    def commit(self, ledger_bytes: Optional[bytes] = None) -> None:
        if ledger_bytes is not None:
            self._ledger_bytes = ledger_bytes
        self._close_pdt()
        # drop old replaceable entries
        self.dir_entries = [e for e in self.dir_entries if e[1] not in REPLACEABLE]
        # PTB1 (this segment)
        if self._ptab:
            arr = np.zeros(len(self._ptab), dtype=PTAB_DTYPE)
            for i, row in enumerate(self._ptab):
                arr[i] = row
            self._emit(T_PTB, b"PTB1" + struct.pack("<I", len(self._ptab)) + arr.tobytes())
            self._ptab = []
        # HLX1
        body = b"HLX1" + struct.pack("<I", len(self.helices)) + b"".join(h.to_bytes() for h in sorted(self.helices.values(), key=lambda h: h.helix_id))
        self._emit(T_HLX, body)
        # TNS1
        body = b"TNS1" + struct.pack("<I", len(self.tensors)) + b"".join(t.to_bytes() for t in sorted(self.tensors.values(), key=lambda t: t.tensor_id))
        self._emit(T_TNS, body)
        # PMP1
        out = io.BytesIO()
        out.write(b"PMP1" + struct.pack("<I", len(self.pmap)))
        for hid in sorted(self.pmap):
            ids = np.asarray(self.pmap[hid], dtype="<u4")
            out.write(struct.pack("<II", hid, ids.size) + ids.tobytes())
        self._emit(T_PMP, out.getvalue())
        # META
        self.meta["page_values"] = self.page_values
        self.meta["committed_ns"] = time.time_ns()
        self.meta["segment"] = self.segment
        self._emit(T_META, _meta_tlvs(self.meta))
        # REG1
        out = io.BytesIO()
        out.write(b"REG1" + struct.pack("<I", len(self.registers)))
        for r in self.registers:
            out.write(struct.pack("<B", r["kind"]) + _pack_str(r["name"]) + _pack_str(r.get("desc", "")))
        self._emit(T_REG, out.getvalue())
        # LIN1 / PAT1 / EXP1 / OPT1 / LDG1 (append-only, only if non-empty)
        if self._lin_nodes or self._lin_edges:
            self._emit(T_LIN, b"LIN1" + struct.pack("<II", len(self._lin_nodes), len(self._lin_edges))
                       + b"".join(self._lin_nodes) + b"".join(self._lin_edges))
            self._lin_nodes, self._lin_edges = [], []
        if self._patches:
            self._emit(T_PAT, b"PAT1" + struct.pack("<I", len(self._patches)) + b"".join(self._patches))
            self._patches = []
        if self._exps:
            self._emit(T_EXP, b"EXP1" + struct.pack("<I", len(self._exps)) + b"".join(self._exps))
            self._exps = []
        if self._opts:
            self._emit(T_OPT, b"OPT1" + struct.pack("<I", len(self._opts)) + b"".join(self._opts))
            self._opts = []
        if self._ledger_bytes:
            self._emit(T_LDG, b"LDG1" + struct.pack("<I", len(self._ledger_bytes)) + self._ledger_bytes)
            self._ledger_bytes = b""
        # IDX1: domain -> helices, plus sorted seek keys
        out = io.BytesIO()
        by_dom: dict[int, list[int]] = {}
        for h in self.helices.values():
            by_dom.setdefault(h.domain_id, []).append(h.helix_id)
        out.write(b"IDX1" + struct.pack("<I", len(by_dom)))
        for dom in sorted(by_dom):
            ids = np.asarray(sorted(by_dom[dom]), dtype="<u4")
            out.write(struct.pack("<HI", dom, ids.size) + ids.tobytes())
        keys = self._idx_keys_existing + self._new_keys_all
        keys.sort()
        karr = np.zeros(len(keys), dtype=[("key", "<u8"), ("page", "<u4"), ("off", "<u4")])
        for i, k in enumerate(keys):
            karr[i] = k
        out.write(struct.pack("<I", len(keys)) + karr.tobytes())
        self._emit(T_IDX, out.getvalue())
        self._idx_keys_existing = keys
        self._new_keys_all = []
        # directory
        self.f.seek(0, os.SEEK_END)
        dir_off = self.f.tell()
        body = b"SECT" + struct.pack("<I", len(self.dir_entries))
        for e in self.dir_entries:
            body += DIR_ENTRY.pack(*e)
        self.f.write(body)
        # header
        payload_ck = sha256_8(b"".join(struct.pack("<Q", e[5]) for e in self.dir_entries))
        build_id = sha256_8(f"SOKE {SOKE_VERSION}".encode())
        hdr = HEADER_FMT.pack(MAGIC, MAJOR, MINOR, 0, self.file_kind, 0, self.creation_ns, build_id,
                              dir_off, len(self.dir_entries), payload_ck, 0, 0)
        hck = sha256_8(hdr[:56])
        hdr = hdr[:56] + struct.pack("<Q", hck)
        self.f.seek(0)
        self.f.write(hdr)
        self.f.flush()
        os.fsync(self.f.fileno())
        self.segment += 1

    def close(self) -> None:
        try:
            self.f.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


ENC_BY_BUDGET = {"f32": ENC_F32, "f16": 1, "8bit": 2, "4bit": 3}


# ==========================================================================
# READER
# ==========================================================================
class SFFReader:
    """mmap-backed, page-granular reader. Never loads a tensor unless asked page by page."""

    def __init__(self, path: Path, max_cache_pages: int = 64):
        self.path = Path(path)
        self.f = open(self.path, "rb")
        size = os.fstat(self.f.fileno()).st_size
        if size < 64:
            raise SFFError("file too small")
        self.mm = mmap.mmap(self.f.fileno(), 0, access=mmap.ACCESS_READ)
        self.size = size
        self._cache: dict[int, np.ndarray] = {}
        self._cache_order: list[int] = []
        self.max_cache_pages = max_cache_pages
        self._parse()

    # -------------------------------------------------------------- parsing
    def _parse(self) -> None:
        hdr = bytes(self.mm[:64])
        (magic, major, minor, endian, file_kind, hflags, cns, build, dir_off, n_sec,
         payload_ck, _res, hck) = HEADER_FMT.unpack(hdr)
        if magic != MAGIC:
            raise SFFError("not an SFF file (magic)")
        if sha256_8(hdr[:56]) != hck:
            raise SFFError("header checksum mismatch")
        if major != MAJOR:
            raise SFFError(f"unsupported SFF major version {major}")
        self.file_kind = file_kind
        self.creation_ns = cns
        self.header_flags = hflags
        if dir_off + 8 > self.size or bytes(self.mm[dir_off:dir_off + 4]) != b"SECT":
            raise SFFError("directory missing (uncommitted file?)")
        n = struct.unpack_from("<I", self.mm, dir_off + 4)[0]
        if n != n_sec:
            raise SFFError("directory count mismatch")
        self.dir_entries = []
        off = dir_off + 8
        for _ in range(n):
            self.dir_entries.append(DIR_ENTRY.unpack_from(self.mm, off))
            off += DIR_ENTRY.size
        if sha256_8(b"".join(struct.pack("<Q", e[5]) for e in self.dir_entries)) != payload_ck:
            raise SFFError("payload checksum (directory chain) mismatch")
        self.segment_count = max((e[2] >> 16 for e in self.dir_entries), default=-1) + 1
        self.sections: dict[int, list[tuple]] = {}
        for e in self.dir_entries:
            self.sections.setdefault(e[1], []).append(e)
        for t in self.sections:
            self.sections[t].sort(key=lambda e: e[3])
        # META
        self.meta = _parse_meta(self._sec_bytes(self.sections[T_META][-1])) if T_META in self.sections else {}
        self.page_values = int(self.meta.get("page_values", PAGE_VALUES))
        # HLX
        self.helices: dict[int, HelixInfo] = {}
        if T_HLX in self.sections:
            b = self._sec_bytes(self.sections[T_HLX][-1])
            n = struct.unpack_from("<I", b, 4)[0]
            off = 8
            for _ in range(n):
                h, off = HelixInfo.parse(b, off)
                self.helices[h.helix_id] = h
        self.helix_by_name = {h.name: h for h in self.helices.values()}
        # TNS
        self.tensors: dict[str, TensorInfo] = {}
        if T_TNS in self.sections:
            b = self._sec_bytes(self.sections[T_TNS][-1])
            n = struct.unpack_from("<I", b, 4)[0]
            off = 8
            for _ in range(n):
                t, off = TensorInfo.parse(b, off)
                self.tensors[t.name] = t
        # PMP
        self.pmap: dict[int, np.ndarray] = {}
        if T_PMP in self.sections:
            e = self.sections[T_PMP][-1]
            b = self.mm
            off = e[3] + 4
            n = struct.unpack_from("<I", b, off)[0]
            off += 4
            for _ in range(n):
                hid, cnt = struct.unpack_from("<II", b, off)
                off += 8
                self.pmap[hid] = np.frombuffer(b, dtype="<u4", count=cnt, offset=off).copy()
                off += 4 * cnt
        # PTB (concatenate all segments)
        parts = []
        for e in self.sections.get(T_PTB, []):
            cnt = struct.unpack_from("<I", self.mm, e[3] + 4)[0]
            parts.append(np.frombuffer(self.mm, dtype=PTAB_DTYPE, count=cnt, offset=e[3] + 8))
        self.ptab = np.concatenate(parts) if parts else np.zeros(0, dtype=PTAB_DTYPE)
        if self.ptab.size:
            order = np.argsort(self.ptab["page_id"], kind="stable")
            self.ptab = self.ptab[order]
            self._pid_index = np.full(int(self.ptab["page_id"].max()) + 1, -1, dtype=np.int64)
            self._pid_index[self.ptab["page_id"]] = np.arange(self.ptab.size)
        else:
            self._pid_index = np.zeros(0, dtype=np.int64)
        # REG
        self.registers: list[dict] = []
        if T_REG in self.sections:
            b = self._sec_bytes(self.sections[T_REG][-1])
            n = struct.unpack_from("<I", b, 4)[0]
            off = 8
            for _ in range(n):
                kind = b[off]
                off += 1
                name, off = _read_str(b, off)
                desc, off = _read_str(b, off)
                self.registers.append({"kind": kind, "name": name, "desc": desc})
        # counts for append-only sections
        self.patch_count = sum(struct.unpack_from("<I", self.mm, e[3] + 4)[0] for e in self.sections.get(T_PAT, []))
        self.lineage_node_count = sum(struct.unpack_from("<I", self.mm, e[3] + 4)[0] for e in self.sections.get(T_LIN, []))
        self.exp_count = sum(struct.unpack_from("<I", self.mm, e[3] + 4)[0] for e in self.sections.get(T_EXP, []))
        self.opt_count = sum(struct.unpack_from("<I", self.mm, e[3] + 4)[0] for e in self.sections.get(T_OPT, []))
        # IDX
        self.domain_helices: dict[int, list[int]] = {}
        self._keys = np.zeros(0, dtype=[("key", "<u8"), ("page", "<u4"), ("off", "<u4")])
        if T_IDX in self.sections:
            e = self.sections[T_IDX][-1]
            off = e[3] + 4
            n = struct.unpack_from("<I", self.mm, off)[0]
            off += 4
            for _ in range(n):
                dom, cnt = struct.unpack_from("<HI", self.mm, off)
                off += 6
                self.domain_helices[dom] = np.frombuffer(self.mm, dtype="<u4", count=cnt, offset=off).tolist()
                off += 4 * cnt
            nk = struct.unpack_from("<I", self.mm, off)[0]
            off += 4
            self._keys = np.frombuffer(self.mm, dtype=self._keys.dtype, count=nk, offset=off)

    def _sec_bytes(self, e: tuple) -> bytes:
        return bytes(self.mm[e[3]:e[3] + e[4]])

    # ---------------------------------------------------------------- pages
    def page_entry(self, page_id: int):
        if page_id >= self._pid_index.size or self._pid_index[page_id] < 0:
            raise SFFError(f"unknown page {page_id}")
        return self.ptab[self._pid_index[page_id]]

    def page_bytes(self, page_id: int) -> memoryview:
        e = self.page_entry(page_id)
        off, ln = int(e["offset"]), int(e["length"])
        return memoryview(self.mm)[off:off + ln]

    def read_page(self, page_id: int, verify: bool = False) -> np.ndarray:
        if page_id in self._cache:
            return self._cache[page_id]
        e = self.page_entry(page_id)
        raw = self.page_bytes(page_id)
        if verify and crc32(bytes(raw)) != int(e["crc"]):
            raise SFFError(f"page {page_id} crc mismatch")
        enc, cnt = int(e["encoding"]), int(e["count"])
        if enc == ENC_RAW:
            # verbatim GGUF block bytes (exact import): decoded on read by the GGML dequantizer
            from .gguf_rewrites import DEQUANT, GGML_TYPES
            gt = int(e["base_page"])
            fn = DEQUANT.get(gt)
            if fn is None:
                raise SFFError(f"page {page_id} is RAW {GGML_TYPES.get(gt, ('?',))[0]} — no dequantizer for that type")
            arr = np.asarray(fn(bytes(raw)), dtype=np.float32).ravel()[:cnt]
            self._cache_put(page_id, arr)
            return arr
        if enc == ENC_TOOTH:
            raise SFFError(f"page {page_id} is not numeric ({ENC_NAMES[enc]})")
        if enc == ENC_DELTA8:
            base = self.read_page(int(e["base_page"]), verify)
            arr = decode_page(bytes(raw), enc, cnt, base=base)
        else:
            arr = decode_page(bytes(raw), enc, cnt)
        self._cache_put(page_id, arr)
        return arr

    def _cache_put(self, pid: int, arr: np.ndarray) -> None:
        self._cache[pid] = arr
        self._cache_order.append(pid)
        while len(self._cache_order) > self.max_cache_pages:
            old = self._cache_order.pop(0)
            self._cache.pop(old, None)

    def clear_cache(self) -> None:
        self._cache.clear()
        self._cache_order.clear()

    def current_page(self, helix_id: int, index: int) -> int:
        pm = self.pmap.get(helix_id)
        if pm is None or index >= pm.size or int(pm[index]) == NO_PAGE:
            raise SFFError(f"helix {helix_id} has no page {index}")
        return int(pm[index])

    def helix_pages(self, helix_id: int) -> list[int]:
        return [int(p) for p in self.pmap.get(helix_id, np.zeros(0, "<u4"))]

    # --------------------------------------------------------------- tensors
    def iter_tensor(self, name: str, verify: bool = False) -> Iterator[np.ndarray]:
        """Stream a tensor page by page (the face-gear ride)."""
        t = self.tensors[name]
        for i in range(t.page_start, t.page_start + t.page_count):
            yield self.read_page(self.current_page(t.helix_id, i), verify)

    def read_tensor(self, name: str, max_elements: int = 64 * 1024 * 1024) -> np.ndarray:
        t = self.tensors[name]
        if t.n_elem > max_elements:
            raise SFFError(f"tensor {name} has {t.n_elem} elements > max_elements; stream it with iter_tensor")
        out = np.empty(t.n_elem, dtype=np.float32)
        pos = 0
        for page in self.iter_tensor(name):
            out[pos:pos + page.size] = page
            pos += page.size
        return out.reshape(t.shape)

    def tensor_rows(self, name: str, row0: int, row1: int) -> np.ndarray:
        """Rows [row0,row1) of a 2-D tensor, touching only the pages they span."""
        t = self.tensors[name]
        if len(t.shape) != 2:
            raise SFFError("tensor_rows needs a 2-D tensor")
        cols = t.shape[1]
        if not (0 <= row0 < row1 <= t.shape[0]):
            raise SFFError(f"rows [{row0}, {row1}) out of range for {name} with shape {tuple(t.shape)}")
        e0, e1 = row0 * cols, row1 * cols
        p0, p1 = e0 // self.page_values, (e1 - 1) // self.page_values
        chunks = [self.read_page(self.current_page(t.helix_id, t.page_start + p)) for p in range(p0, p1 + 1)]
        flat = np.concatenate(chunks)
        s = e0 - p0 * self.page_values
        return flat[s:s + (e1 - e0)].reshape(row1 - row0, cols)

    def tensor_page_ids(self, name: str) -> list[int]:
        t = self.tensors[name]
        return [self.current_page(t.helix_id, i) for i in range(t.page_start, t.page_start + t.page_count)]

    # --------------------------------------------------------------- history
    def patches(self) -> list[dict]:
        out = []
        for e in self.sections.get(T_PAT, []):
            b = self._sec_bytes(e)
            n = struct.unpack_from("<I", b, 4)[0]
            off = 8
            for _ in range(n):
                pid, hid, idx, old, new, kind, flags, ts = struct.unpack_from("<IIIIIHHQ", b, off)
                off += struct.calcsize("<IIIIIHHQ")
                note, off = _read_str(b, off)
                out.append({"patch_id": pid, "helix": hid, "index": idx, "old_page": old, "new_page": new,
                            "kind": PATCH_KINDS.get(kind, kind), "flags": flags, "ts_ns": ts, "note": note})
        return out

    def lineage(self) -> tuple[list[dict], list[dict]]:
        nodes, edges = [], []
        for e in self.sections.get(T_LIN, []):
            b = self._sec_bytes(e)
            nn, ne = struct.unpack_from("<II", b, 4)
            off = 12
            for _ in range(nn):
                nid, kind, flags, rs, ri = struct.unpack_from("<IBBHQ", b, off)
                off += struct.calcsize("<IBBHQ")
                label, off = _read_str(b, off)
                nodes.append({"node_id": nid, "kind": LIN_NODE_KINDS.get(kind, kind), "flags": flags,
                              "ref_section": rs, "ref_index": ri, "label": label})
            for _ in range(ne):
                s, d, op, fl, ts = struct.unpack_from("<IIHHQ", b, off)
                off += struct.calcsize("<IIHHQ")
                edges.append({"src": s, "dst": d, "op": LIN_OPS.get(op, op), "flags": fl, "ts_ns": ts})
        return nodes, edges

    def experiments(self) -> list[dict]:
        out = []
        for e in self.sections.get(T_EXP, []):
            b = self._sec_bytes(e)
            n = struct.unpack_from("<I", b, 4)[0]
            off = 8
            for _ in range(n):
                eid, et, ts, ln = struct.unpack_from("<IIQI", b, off)
                off += struct.calcsize("<IIQI")
                payload = json.loads(b[off:off + ln].decode("utf-8"))
                off += ln
                out.append({"exp_id": eid, "exp_type": et, "ts_ns": ts, "payload": payload})
        return out

    def opt_rows(self) -> list[dict]:
        out = []
        for e in self.sections.get(T_OPT, []):
            b = self._sec_bytes(e)
            n = struct.unpack_from("<I", b, 4)[0]
            off = 8
            for _ in range(n):
                rid = struct.unpack_from("<I", b, off)[0]
                off += 4
                name, off = _read_str(b, off)
                bo, oo, bw, ow, cut, st = struct.unpack_from("<ddddiB", b, off)
                off += struct.calcsize("<ddddiB")
                note, off = _read_str(b, off)
                out.append({"row_id": rid, "pipeline": name, "baseline_ops": bo, "ortho_ops": oo, "baseline_w": bw,
                            "ortho_w": ow, "cut_pct": cut / 100.0, "status": OPT_STATUS.get(st, st), "note": note})
        return out

    def ledger_bytes(self) -> bytes:
        out = []
        for e in self.sections.get(T_LDG, []):
            n = struct.unpack_from("<I", self.mm, e[3] + 4)[0]
            out.append(bytes(self.mm[e[3] + 8:e[3] + 8 + n]))
        return b"".join(out)

    def ledger_records(self) -> list[dict]:
        recs = []
        for line in self.ledger_bytes().decode("utf-8", errors="replace").splitlines():
            line = line.strip()
            if line:
                try:
                    recs.append(json.loads(line))
                except Exception:
                    pass
        return recs

    # ---------------------------------------------------------------- index
    def index_keys_list(self) -> list[tuple[int, int, int]]:
        return [(int(k["key"]), int(k["page"]), int(k["off"])) for k in self._keys]

    def seek_key(self, key_hash: int) -> list[tuple[int, int]]:
        """O(log N): all (page_id, record_offset) hits for a seek key."""
        if self._keys.size == 0:
            return []
        keys = self._keys["key"]
        lo = int(np.searchsorted(keys, key_hash, side="left"))
        hi = int(np.searchsorted(keys, key_hash, side="right"))
        return [(int(self._keys[i]["page"]), int(self._keys[i]["off"])) for i in range(lo, hi)]

    # ---------------------------------------------------------------- verify
    def verify(self, deep: bool = False) -> dict:
        report = {"sections": 0, "section_ok": 0, "pages": int(self.ptab.size), "page_ok": 0, "errors": []}
        for e in self.dir_entries:
            report["sections"] += 1
            body = self.mm[e[3]:e[3] + e[4]]
            if sha256_8(bytes(body)) == e[5]:
                report["section_ok"] += 1
            else:
                report["errors"].append(f"section {e[0]} ({TYPE_NAMES.get(e[1], e[1])}) checksum mismatch")
        if deep:
            for i in range(self.ptab.size):
                e = self.ptab[i]
                if e["flags"] & PF_EVICTED:
                    report["page_ok"] += 1
                    continue
                raw = self.mm[int(e["offset"]):int(e["offset"]) + int(e["length"])]
                if crc32(bytes(raw)) == int(e["crc"]):
                    report["page_ok"] += 1
                else:
                    report["errors"].append(f"page {int(e['page_id'])} crc mismatch")
        report["ok"] = not report["errors"]
        return report

    def summary(self) -> dict:
        live = sum(int(np.sum(pm != NO_PAGE)) for pm in self.pmap.values())
        by_enc: dict[str, int] = {}
        for i in range(self.ptab.size):
            en = ENC_NAMES.get(int(self.ptab[i]["encoding"]), "?")
            by_enc[en] = by_enc.get(en, 0) + 1
        return {"path": str(self.path), "size": self.size, "file_kind": FILE_KINDS.get(self.file_kind, self.file_kind),
                "model_id": self.meta.get("model_id"), "segments": self.segment_count, "sections": len(self.dir_entries),
                "helices": len(self.helices), "tensors": len(self.tensors), "pages_total": int(self.ptab.size),
                "pages_live": live, "pages_by_encoding": by_enc, "patches": self.patch_count,
                "lineage_nodes": self.lineage_node_count, "experiments": self.exp_count, "opt_rows": self.opt_count,
                "index_keys": int(self._keys.size), "params": int(sum(t.n_elem for t in self.tensors.values()))}

    def close(self) -> None:
        try:
            self.mm.close()
        except Exception:
            pass
        try:
            self.f.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


# ==========================================================================
# compaction: drop bytes of unreferenced pages and stale directories
# ==========================================================================
def compact(src: Path, dst: Path) -> dict:
    rd = SFFReader(src)
    live = set()
    for pm in rd.pmap.values():
        live.update(int(p) for p in pm if int(p) != NO_PAGE)
    # base pages of live DELTA pages are live too
    stack = list(live)
    while stack:
        pid = stack.pop()
        e = rd.page_entry(pid)
        if int(e["encoding"]) == ENC_DELTA8:
            bp = int(e["base_page"])
            if bp not in live:
                live.add(bp)
                stack.append(bp)
    w = SFFWriter(dst, file_kind=rd.file_kind, page_values=rd.page_values, meta=dict(rd.meta), mode="create",
                  model_id=str(rd.meta.get("model_id", "soke")))
    w.creation_ns = rd.creation_ns
    w.registers = list(rd.registers)
    w.helices = {h.helix_id: HelixInfo(**h.__dict__) for h in rd.helices.values()}
    w.tensors = {t.name: TensorInfo(**t.__dict__) for t in rd.tensors.values()}
    w.pmap = {hid: [int(p) for p in pm] for hid, pm in rd.pmap.items()}
    w.next_helix_id = max(w.helices) + 1 if w.helices else 0
    w.next_tensor_id = max((t.tensor_id for t in w.tensors.values()), default=-1) + 1
    w.next_page_id = int(rd.ptab["page_id"].max()) + 1 if rd.ptab.size else 0
    w.next_patch_id = rd.patch_count
    w.next_lin_node = rd.lineage_node_count
    w.next_exp_id = rd.exp_count
    w.next_opt_row = rd.opt_count
    # copy live pages byte-for-byte keeping page ids
    w._ensure_pdt()
    kept = evicted = 0
    for i in range(rd.ptab.size):
        e = rd.ptab[i]
        pid = int(e["page_id"])
        if pid in live and not (e["flags"] & PF_EVICTED):
            raw = bytes(rd.page_bytes(pid))
            off = w.f.tell()
            w.f.write(raw)
            w._pdt_hash.update(raw)
            w._ptab.append((pid, int(e["helix_id"]), int(e["index"]), off, len(raw), int(e["count"]), int(e["base_page"]),
                            float(e["err"]), int(e["crc"]), int(e["encoding"]), int(e["flags"]), 0))
            kept += 1
        else:
            w._ptab.append((pid, int(e["helix_id"]), int(e["index"]), 0, 0, int(e["count"]), int(e["base_page"]),
                            float(e["err"]), int(e["crc"]), int(e["encoding"]), int(e["flags"]) | PF_EVICTED, 0))
            evicted += 1
    # copy history sections verbatim
    for t in (T_LIN, T_PAT, T_EXP, T_OPT, T_LDG):
        for e in rd.sections.get(t, []):
            w._emit(t, rd._sec_bytes(e))
    w._idx_keys_existing = rd.index_keys_list()
    w.commit()
    w.close()
    rd.close()
    return {"kept": kept, "evicted": evicted, "src_bytes": os.path.getsize(src), "dst_bytes": os.path.getsize(dst)}


# ==========================================================================
# self-checks
# ==========================================================================
def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    chk = chk or Check("sff")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_sff_"))
    p = tmpdir / "t.sff"
    rng = Rng(5)
    A = rng.normal(0, 1, (300, 70)).astype(np.float32)
    B = rng.normal(0, 0.1, (5000,)).astype(np.float32)
    B[:4096] = 0
    with SFFWriter(p, meta={"model_id": "unit-test"}, page_values=1024) as w:
        h1 = w.add_helix("A", domain_id=1)
        h2 = w.add_helix("B", domain_id=2)
        ta = w.write_tensor("A", A, h1, ENC_F32)
        tb = w.write_tensor("B", B, h2, budget="8bit")
        n0 = w.add_lineage_node(4, "A")
        n1 = w.add_lineage_node(4, "B")
        w.add_lineage_edge(n0, n1, 17)
        w.add_opt_row("test_row", 45, 28, "VERIFIED", cut_pct=37.8, note="28 vs 45")
        w.add_exp(1, {"hello": "world"})
        w.add_index_keys([(12345, 0, 0), (12, 1, 8)])
        w.commit(ledger_bytes=b'{"seq":0}\n')
    rd = SFFReader(p)
    chk("header/dir parse", rd.summary()["tensors"] == 2 and rd.summary()["segments"] == 1)
    chk("tensor A round trip (F32 pages)", np.array_equal(rd.read_tensor("A"), A))
    bb = rd.read_tensor("B")
    chk("tensor B budgeted (8bit) within tolerance", bb.shape == (5000,) and np.max(np.abs(bb - B)) < 0.01, f"max err {np.max(np.abs(bb - B)):.2e}")
    chk("zero page packed", ENC_NAMES[int(rd.page_entry(rd.tensor_page_ids('B')[0])['encoding'])] == "ZERO")
    chk("tensor_rows touches a page window", np.array_equal(rd.tensor_rows("A", 100, 130), A[100:130]))
    chk("verify sections + pages", rd.verify(deep=True)["ok"])
    chk("lineage/opt/exp/ledger/idx present", len(rd.lineage()[1]) == 1 and rd.opt_rows()[0]["status"] == "VERIFIED"
        and rd.experiments()[0]["payload"]["hello"] == "world" and rd.ledger_records()[0]["seq"] == 0
        and rd.seek_key(12345) == [(0, 0)] and rd.seek_key(99) == [])
    chk("O(log N) seek keys sorted", rd._keys["key"][0] == 12 and rd.domain_helices[1] == [0])
    rd.close()
    # append segment: new version of one page as DELTA8 + rollback pointer
    w = SFFWriter(p, mode="append")
    tA = w.tensors["A"]
    old_pid = w.pmap[tA.helix_id][tA.page_start]
    rd0 = SFFReader(p)
    base = rd0.read_page(old_pid)
    rd0.close()
    newvals = base + 0.001
    new_pid = w.write_page(tA.helix_id, tA.page_start, newvals, ENC_DELTA8, base_page=old_pid, base_array=base)
    w.add_patch(tA.helix_id, tA.page_start, old_pid, new_pid, 4, "checkpoint delta")
    w.commit()
    w.close()
    rd = SFFReader(p)
    a2 = rd.read_tensor("A")
    chk("append segment visible (segments=2)", rd.summary()["segments"] == 2 and rd.patch_count == 1)
    chk("DELTA8 page decodes against key-frame", np.max(np.abs(a2.ravel()[:1024] - (A.ravel()[:1024] + 0.001))) < 1e-4)
    chk("old page still present (append-only)", np.array_equal(rd.read_page(old_pid), base))
    rd.close()
    # rollback = pointer change
    w = SFFWriter(p, mode="append")
    w.point_page(tA.helix_id, tA.page_start, old_pid)
    w.add_patch(tA.helix_id, tA.page_start, new_pid, old_pid, 5, "rollback")
    w.commit()
    w.close()
    rd = SFFReader(p)
    chk("rollback restores byte-identical tensor", np.array_equal(rd.read_tensor("A"), A) and rd.patch_count == 2)
    rd.close()
    # compaction
    q = tmpdir / "c.sff"
    info = compact(p, q)
    rd = SFFReader(q)
    chk("compact keeps live data + history", np.array_equal(rd.read_tensor("A"), A) and rd.patch_count == 2 and info["evicted"] >= 1,
        f"kept {info['kept']} evicted {info['evicted']}")
    chk("compacted file verifies", rd.verify(deep=True)["ok"])
    rd.close()
    # corruption detection
    data = bytearray(p.read_bytes())
    data[100] ^= 0xFF
    (tmpdir / "bad.sff").write_bytes(bytes(data))
    try:
        rb = SFFReader(tmpdir / "bad.sff")
        rep = rb.verify(deep=True)
        rb.close()
        chk("corruption detected by checksums", not rep["ok"])
    except SFFError:
        chk("corruption detected by checksums", True)
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
