"""
soke.model_tests — let the chat TEST the behavior and logic it bakes into the models it builds.

A forged model carries two things that are not weights:
  - a BEHAVIOR (the 4D mind / emotional feed: soke.mind_engine + soke.behavior) — how it feels its way through
    generation, rewarded/taxed in tokens and RAM, returning to a baseline.
  - a LOGIC gate (the JEV right-pillar proof-state: soke.jev_engine + behavior.proof_state) — which build moves
    are allowed to close.

These two functions RUN those engines on demand and return a readable report, so from the Home chat you can watch
the emotional feed evolve and return to baseline, and see the logic gate rule ⊤/⊥/?/⊥⊥ on real decisions —
before and after you commit them to a model.
"""
from __future__ import annotations

from typing import Optional

import numpy as np


def behavior_report(climate="seeking", base_tokens: float = 32.0, seed: int = 0) -> dict:
    """Run the 4D mind engine through a scripted situational feed and report the trajectory: it moves under a
    perturbation, returns toward baseline under the OU relaxation, and the reward/punishment moves the token bank.
    `climate` is a name in behavior.CLIMATES or a BehaviorProfile."""
    from .behavior import CLIMATES
    from .mind_engine import MindEngine, reciprocal_error
    prof = CLIMATES.get(climate, CLIMATES["neutral"]) if isinstance(climate, str) else climate
    name = climate if isinstance(climate, str) else getattr(prof, "name", "custom")
    eng = MindEngine.from_behavior(prof, base_tokens=base_tokens, seed=seed)
    S0 = eng.state.baseline.copy()

    def dist() -> float:
        return float(np.linalg.norm(eng.state.S - S0))

    base_temp = 0.7
    feed = []

    def rec(event, step):
        snap = eng.snapshot()
        feed.append({"event": event, "S": snap["S"], "affect": snap["affect"], "mood": snap["mood"],
                     "tokens": snap["tokens"], "dist_to_baseline": round(dist(), 3),
                     "temp": round(float(eng.temperature(step, base_temp)), 3)})

    rec("start (at baseline)", 0)
    eng.step(+0.8, 0.7, "joy"); rec("reward: a good result (joy)", 1)
    peak_reward = dist(); tokens_reward = eng.state.tokens
    for i in range(3):
        eng.relax(1.0); rec(f"relax {i + 1}", 2 + i)
    settled_reward = dist()
    eng.step(-0.8, 0.85, "fear"); rec("punish: a setback (fear)", 6)
    tokens_punish = eng.state.tokens
    for i in range(3):
        eng.relax(1.0); rec(f"relax {i + 1}", 7 + i)
    settled_punish = dist()

    temps = [f["temp"] for f in feed]
    return {
        "climate": name,
        "baseline": {k: round(float(S0[i]), 3) for i, k in enumerate(("nature", "nurture", "regulation", "meaning"))},
        "feed": feed,
        "moved_on_perturbation": peak_reward > feed[0]["dist_to_baseline"] + 1e-9,
        "returned_to_baseline": settled_reward < peak_reward - 1e-9 and settled_punish <= max(peak_reward, dist()) + 1e-9,
        "reward_raised_token_bank": tokens_reward > base_tokens - 1e-9,
        "punish_lowered_token_bank": tokens_punish < tokens_reward + 1e-9,
        "temp_range": [round(min(temps), 3), round(max(temps), 3)],
        "reciprocal_error_end": round(reciprocal_error(eng.state.S), 4),
        "note": "the emotional feed: a situation moves the state; the OU return pulls it back; good paths earn tokens, bad paths are taxed.",
    }


# a default decision set for the logic gate: a clear improvement, a worsening move, an uncertain grow, and hold
DEFAULT_DECISIONS = [
    {"name": "blend two donors (lowers loss)", "op": "blend_expert", "before": 1.0, "after": 0.90, "finite": True},
    {"name": "swap an expert (raises loss)", "op": "swap_expert", "before": 1.0, "after": 1.08, "finite": True},
    {"name": "grow an expert (uncertain)", "op": "add_expert", "before": 1.0, "after": 0.995, "finite": True},
    {"name": "keep the current template (hold)", "op": "hold", "before": 1.0, "after": 1.0, "finite": True},
]


def logic_report(candidates: Optional[list] = None, tol: float = 0.02) -> dict:
    """Run the JEV logic route on a set of build decisions and demonstrate the proof-state gate ruling ⊤/⊥/?/⊥⊥.
    The gate reads only the numeric task health — it invents no fact and may only veto/shape, never force a close."""
    from .behavior import proof_state
    from .jev_engine import JEVEngine
    cands = candidates or DEFAULT_DECISIONS
    jev = JEVEngine(tol=tol)
    d = jev.decide(cands)
    demo = {
        "improves -> TT (close)": proof_state(1.0, 0.9, {"math": 1.0}, {"math": 0.9}, "blend_expert", True, None, tol),
        "worsens -> BOT (drop)": proof_state(1.0, 1.1, {}, {}, "swap_expert", True, None, tol),
        "non-finite -> BOTBOT (freeze+rollback)": proof_state(1.0, float("nan"), {}, {}, "add_expert", False, None, tol),
        "grow drifts the priority up -> Q (don't promote)": proof_state(1.0, 0.9, {"math": 1.0}, {"math": 1.5}, "add_expert", True, "math", tol),
    }
    sym = {"TT": "⊤ close", "BOT": "⊥ drop", "Q": "? probe", "BOTBOT": "⊥⊥ freeze"}
    return {
        "decision": {"choice": d.choice, "verdict": d.verdict, "verdict_glyph": sym.get(d.verdict, d.verdict),
                     "committed": bool(d.committed), "reason": d.reason,
                     "scores": {k: round(float(v), 3) for k, v in d.scores.items()},
                     "verdicts": d.verdicts},
        "proof_state_demo": demo,
        "note": "the logic pillar (JEV): it scores the next move and the proof-state closes it only when the task metric agrees.",
    }


# ==========================================================================
# self-test
# ==========================================================================
def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("model_tests")

    # --- behavior: the emotional feed moves, returns to baseline, and reward/punishment moves the token bank
    r = behavior_report("seeking", base_tokens=32.0)
    chk("behavior: a perturbation moves the state off baseline", r["moved_on_perturbation"], str(r["feed"][1]["dist_to_baseline"]))
    chk("behavior: the OU relaxation returns it toward baseline", r["returned_to_baseline"])
    chk("behavior: a good result raises the token bank, a setback lowers it", r["reward_raised_token_bank"] and r["punish_lowered_token_bank"])
    lo, hi = r["temp_range"]
    chk("behavior: the temperature it would apply stays finite and bounded", np.isfinite(lo) and np.isfinite(hi) and 0.05 <= lo <= hi <= 5.0, str(r["temp_range"]))
    def _sig(rep):
        f0 = rep["feed"][0]
        return (tuple(sorted(f0["affect"].items())), f0["mood"].get("dominant"), tuple(rep["temp_range"]))
    chk("behavior: a different climate gives a different behavioral signature (affect / mood / temperature)", _sig(behavior_report("scarcity")) != _sig(r))

    # --- logic: the proof-state gate rules correctly and the JEV route picks the improving move
    lg = logic_report()
    demo = lg["proof_state_demo"]
    chk("logic: an improving move is ⊤ (TT)", demo["improves -> TT (close)"] == "TT")
    chk("logic: a worsening move is ⊥ (BOT)", demo["worsens -> BOT (drop)"] == "BOT")
    chk("logic: a non-finite move is ⊥⊥ (BOTBOT freeze)", demo["non-finite -> BOTBOT (freeze+rollback)"] == "BOTBOT")
    chk("logic: a grow move that drifts the priority up is ? (Q)", demo["grow drifts the priority up -> Q (don't promote)"] == "Q")
    chk("logic: the JEV route commits to the loss-lowering move", lg["decision"]["choice"] == "blend two donors (lowers loss)" and lg["decision"]["committed"], str(lg["decision"]))
    return chk


if __name__ == "__main__":
    import json
    print(json.dumps(behavior_report(), indent=1))
    print(json.dumps(logic_report(), indent=1))
    print(verify_suite().report())
