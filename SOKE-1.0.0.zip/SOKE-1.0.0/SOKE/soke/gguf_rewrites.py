"""
soke.gguf_rewrites — streaming GGUF reader, block dequantization, GGUF -> SFF
conversion, and the GGUF metadata rewrite layer.

RULE (operator requirement): a GGUF file is NEVER loaded whole. The reader parses
the header, the KV metadata and the tensor directory, then serves any tensor as a
stream of dequantized float32 chunks (block-aligned, bounded by the memory guard).

Supported source types (dequantized): F32, F16, BF16, F64, I8, I16, I32, I64,
Q4_0, Q4_1, Q5_0, Q5_1, Q8_0, Q8_1, Q2_K, Q3_K, Q4_K, Q5_K, Q6_K, Q8_K.
Everything else (IQ*, TQ*) is carried through verbatim as RAW pages with the source
type id recorded, so nothing is dropped.

Layouts follow ggml-common.h (SOURCED). Every dequantizer is checked by a second
route: a pure-Python scalar transcription of the ggml reference loops.
"""
from __future__ import annotations

import json
import os
import struct
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterator, Optional

import numpy as np

from .rng import Rng

from .sff import (ENC_BY_BUDGET, HELIX_KIND_TENSOR, SFFWriter, TensorInfo)
from .teeth import (ENC_BPV, ENC_F32, ENC_LIN4, ENC_LIN8, ENC_NAMES, ENC_RAW, PAGE_VALUES, choose_encoding, decode_page)

GGUF_MAGIC = 0x46554747
QK_K = 256

# ggml type id -> (name, block_size, type_size)
GGML_TYPES = {
    0: ("F32", 1, 4), 1: ("F16", 1, 2), 2: ("Q4_0", 32, 18), 3: ("Q4_1", 32, 20),
    6: ("Q5_0", 32, 22), 7: ("Q5_1", 32, 24), 8: ("Q8_0", 32, 34), 9: ("Q8_1", 32, 36),
    10: ("Q2_K", 256, 84), 11: ("Q3_K", 256, 110), 12: ("Q4_K", 256, 144), 13: ("Q5_K", 256, 176),
    14: ("Q6_K", 256, 210), 15: ("Q8_K", 256, 292),
    16: ("IQ2_XXS", 256, 66), 17: ("IQ2_XS", 256, 74), 18: ("IQ3_XXS", 256, 98), 19: ("IQ1_S", 256, 50),
    20: ("IQ4_NL", 32, 18), 21: ("IQ3_S", 256, 110), 22: ("IQ2_S", 256, 82), 23: ("IQ4_XS", 256, 136),
    24: ("I8", 1, 1), 25: ("I16", 1, 2), 26: ("I32", 1, 4), 27: ("I64", 1, 8), 28: ("F64", 1, 8),
    29: ("IQ1_M", 256, 56), 30: ("BF16", 1, 2), 34: ("TQ1_0", 256, 54), 35: ("TQ2_0", 256, 66),
}
DEQUANTIZABLE = {0, 1, 2, 3, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 30}
GGUF_VALUE_TYPES = {0: "u8", 1: "i8", 2: "u16", 3: "i16", 4: "u32", 5: "i32", 6: "f32", 7: "bool",
                    8: "string", 9: "array", 10: "u64", 11: "i64", 12: "f64"}
_SCALAR_FMT = {0: "<B", 1: "<b", 2: "<H", 3: "<h", 4: "<I", 5: "<i", 6: "<f", 7: "<?", 10: "<Q", 11: "<q", 12: "<d"}


class GGUFError(Exception):
    pass


@dataclass
class GGUFTensor:
    name: str
    dims: tuple          # as stored (ne[0] fastest)
    ggml_type: int
    offset: int          # relative to data start
    n_elem: int
    n_bytes: int
    abs_offset: int

    @property
    def type_name(self) -> str:
        return GGML_TYPES.get(self.ggml_type, ("UNKNOWN", 1, 1))[0]

    @property
    def shape(self) -> tuple:
        return tuple(reversed(self.dims))   # numpy row-major shape


# ==========================================================================
# f16 / bf16 helpers
# ==========================================================================
def f16_to_f32(b: bytes | memoryview | np.ndarray, count: Optional[int] = None) -> np.ndarray:
    return np.frombuffer(b, dtype="<f2", count=-1 if count is None else count).astype(np.float32)


def bf16_to_f32(b: bytes) -> np.ndarray:
    u = np.frombuffer(b, dtype="<u2").astype(np.uint32) << 16
    return u.view(np.float32)


# ==========================================================================
# block dequantizers (vectorized). Input: raw bytes of N whole blocks.
# ==========================================================================
def _blocks(raw: bytes, tsize: int) -> np.ndarray:
    a = np.frombuffer(raw, dtype=np.uint8)
    n = a.size // tsize
    return a[:n * tsize].reshape(n, tsize)


def _f16col(blk: np.ndarray, off: int) -> np.ndarray:
    return blk[:, off:off + 2].copy().view("<f2").astype(np.float32).ravel()


def deq_q4_0(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 18)
    d = _f16col(blk, 0)
    qs = blk[:, 2:18]
    lo = (qs & 0xF).astype(np.int8) - 8
    hi = (qs >> 4).astype(np.int8) - 8
    return (np.concatenate([lo, hi], axis=1).astype(np.float32) * d[:, None]).ravel()


def deq_q4_1(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 20)
    d = _f16col(blk, 0)
    m = _f16col(blk, 2)
    qs = blk[:, 4:20]
    lo = (qs & 0xF).astype(np.float32)
    hi = (qs >> 4).astype(np.float32)
    return (np.concatenate([lo, hi], axis=1) * d[:, None] + m[:, None]).ravel()


def deq_q5_0(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 22)
    d = _f16col(blk, 0)
    qh = blk[:, 2:6].copy().view("<u4").ravel()
    qs = blk[:, 6:22]
    j = np.arange(16, dtype=np.uint32)
    xh0 = ((qh[:, None] >> j[None, :]) << 4) & 0x10
    xh1 = (qh[:, None] >> (j[None, :] + 12)) & 0x10
    x0 = ((qs & 0xF).astype(np.int32) | xh0.astype(np.int32)) - 16
    x1 = ((qs >> 4).astype(np.int32) | xh1.astype(np.int32)) - 16
    return (np.concatenate([x0, x1], axis=1).astype(np.float32) * d[:, None]).ravel()


def deq_q5_1(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 24)
    d = _f16col(blk, 0)
    m = _f16col(blk, 2)
    qh = blk[:, 4:8].copy().view("<u4").ravel()
    qs = blk[:, 8:24]
    j = np.arange(16, dtype=np.uint32)
    xh0 = ((qh[:, None] >> j[None, :]) << 4) & 0x10
    xh1 = (qh[:, None] >> (j[None, :] + 12)) & 0x10
    x0 = (qs & 0xF).astype(np.int32) | xh0.astype(np.int32)
    x1 = (qs >> 4).astype(np.int32) | xh1.astype(np.int32)
    return (np.concatenate([x0, x1], axis=1).astype(np.float32) * d[:, None] + m[:, None]).ravel()


def deq_q8_0(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 34)
    d = _f16col(blk, 0)
    qs = blk[:, 2:34].view(np.int8).astype(np.float32)
    return (qs * d[:, None]).ravel()


def deq_q8_1(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 36)
    d = _f16col(blk, 0)
    qs = blk[:, 4:36].view(np.int8).astype(np.float32)
    return (qs * d[:, None]).ravel()


# ---- exact transcoders: GGUF block bytes -> SFF LIN pages without dequantizing (values bit-identical)
def q8_0_to_lin8(raw: bytes) -> bytes:
    """Q8_0 blocks (f16 d + 32 int8, interleaved) -> LIN8 page payload (all d's, then all codes)."""
    blk = _blocks(raw, 34)
    return blk[:, 0:2].tobytes() + blk[:, 2:34].tobytes()


def q4_0_to_lin4(raw: bytes) -> bytes:
    """Q4_0 blocks -> LIN4 payload. Q4_0 stores values 0..15 in the low nibbles and 16..31 in the high
    nibbles of 16 bytes; LIN4 packs consecutive values low-nibble-first. Codes and scales are untouched."""
    blk = _blocks(raw, 18)
    qs = blk[:, 2:18]
    lo = qs & 0xF                    # values 0..15
    hi = qs >> 4                     # values 16..31
    codes = np.concatenate([lo, hi], axis=1)                  # (n, 32) in value order
    packed = (codes[:, 0::2] | (codes[:, 1::2] << 4)).astype(np.uint8)
    return blk[:, 0:2].tobytes() + packed.tobytes()


EXACT_TRANSCODE = {8: q8_0_to_lin8, 2: q4_0_to_lin4}       # ggml type -> transcoder (target enc below)


def deq_q2_k(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 84)
    n = blk.shape[0]
    scales = blk[:, 0:16]
    qs = blk[:, 16:80]
    d = _f16col(blk, 80)
    dmin = _f16col(blk, 82)
    out = np.empty((n, 256), dtype=np.float32)
    is_ = 0
    y = 0
    for half in range(2):                       # n = 0, 128
        q = qs[:, half * 32:(half + 1) * 32]
        for j in range(4):
            shift = 2 * j
            for part in range(2):
                sc = scales[:, is_]
                is_ += 1
                dl = d * (sc & 0xF).astype(np.float32)
                ml = dmin * (sc >> 4).astype(np.float32)
                qq = ((q[:, part * 16:(part + 1) * 16] >> shift) & 3).astype(np.float32)
                out[:, y:y + 16] = dl[:, None] * qq - ml[:, None]
                y += 16
    return out.ravel()


def _q3k_scales(scales12: np.ndarray) -> np.ndarray:
    """Unpack the 12-byte Q3_K scale block into 16 signed 6-bit scales (per block row)."""
    aux = scales12.copy().view("<u4")           # (n, 3)
    a0, a1, a2 = aux[:, 0].astype(np.uint32), aux[:, 1].astype(np.uint32), aux[:, 2].astype(np.uint32)
    kmask1, kmask2 = np.uint32(0x03030303), np.uint32(0x0f0f0f0f)
    tmp = a2
    b2 = ((a0 >> 4) & kmask2) | (((tmp >> 4) & kmask1) << 4)
    b3 = ((a1 >> 4) & kmask2) | (((tmp >> 6) & kmask1) << 4)
    b0 = (a0 & kmask2) | (((tmp >> 0) & kmask1) << 4)
    b1 = (a1 & kmask2) | (((tmp >> 2) & kmask1) << 4)
    packed = np.stack([b0, b1, b2, b3], axis=1).astype("<u4")     # (n,4)
    return packed.view(np.int8).reshape(-1, 16)                    # 16 int8 scales


def deq_q3_k(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 110)
    n = blk.shape[0]
    hmask = blk[:, 0:32]
    qs = blk[:, 32:96]
    scales = _q3k_scales(blk[:, 96:108])
    d = _f16col(blk, 108)
    out = np.empty((n, 256), dtype=np.float32)
    is_ = 0
    m = 1
    y = 0
    for half in range(2):
        q = qs[:, half * 32:(half + 1) * 32]
        for j in range(4):
            shift = 2 * j
            for part in range(2):
                dl = d * (scales[:, is_].astype(np.float32) - 32.0)
                is_ += 1
                qq = ((q[:, part * 16:(part + 1) * 16] >> shift) & 3).astype(np.int32)
                hm = hmask[:, part * 16:(part + 1) * 16]
                qq = qq - np.where((hm & m) != 0, 0, 4)
                out[:, y:y + 16] = dl[:, None] * qq.astype(np.float32)
                y += 16
            m <<= 1
    return out.ravel()


def _scale_min_k4(j: int, sc: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """get_scale_min_k4 on a (n,12) uint8 scale block -> (d, m) uint8 arrays of shape (n,)."""
    if j < 4:
        return sc[:, j] & 63, sc[:, j + 4] & 63
    d = (sc[:, j + 4] & 0xF) | ((sc[:, j - 4] >> 6) << 4)
    m = (sc[:, j + 4] >> 4) | ((sc[:, j] >> 6) << 4)
    return d, m


def deq_q4_k(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 144)
    n = blk.shape[0]
    d = _f16col(blk, 0)
    dmin = _f16col(blk, 2)
    sc = blk[:, 4:16]
    qs = blk[:, 16:144]
    out = np.empty((n, 256), dtype=np.float32)
    is_ = 0
    y = 0
    for j in range(0, 256, 64):
        q = qs[:, (j // 64) * 32:(j // 64 + 1) * 32]
        s1, m1 = _scale_min_k4(is_, sc)
        s2, m2 = _scale_min_k4(is_ + 1, sc)
        d1, mm1 = d * s1.astype(np.float32), dmin * m1.astype(np.float32)
        d2, mm2 = d * s2.astype(np.float32), dmin * m2.astype(np.float32)
        out[:, y:y + 32] = d1[:, None] * (q & 0xF).astype(np.float32) - mm1[:, None]
        out[:, y + 32:y + 64] = d2[:, None] * (q >> 4).astype(np.float32) - mm2[:, None]
        y += 64
        is_ += 2
    return out.ravel()


def deq_q5_k(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 176)
    n = blk.shape[0]
    d = _f16col(blk, 0)
    dmin = _f16col(blk, 2)
    sc = blk[:, 4:16]
    qh = blk[:, 16:48]
    qs = blk[:, 48:176]
    out = np.empty((n, 256), dtype=np.float32)
    is_ = 0
    y = 0
    u1, u2 = 1, 2
    for j in range(0, 256, 64):
        ql = qs[:, (j // 64) * 32:(j // 64 + 1) * 32]
        s1, m1 = _scale_min_k4(is_, sc)
        s2, m2 = _scale_min_k4(is_ + 1, sc)
        d1, mm1 = d * s1.astype(np.float32), dmin * m1.astype(np.float32)
        d2, mm2 = d * s2.astype(np.float32), dmin * m2.astype(np.float32)
        h1 = np.where((qh & u1) != 0, 16, 0).astype(np.float32)
        h2 = np.where((qh & u2) != 0, 16, 0).astype(np.float32)
        out[:, y:y + 32] = d1[:, None] * ((ql & 0xF).astype(np.float32) + h1) - mm1[:, None]
        out[:, y + 32:y + 64] = d2[:, None] * ((ql >> 4).astype(np.float32) + h2) - mm2[:, None]
        y += 64
        is_ += 2
        u1 <<= 2
        u2 <<= 2
    return out.ravel()


def deq_q6_k(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 210)
    n = blk.shape[0]
    ql_all = blk[:, 0:128]
    qh_all = blk[:, 128:192]
    scales = blk[:, 192:208].view(np.int8).astype(np.float32)
    d = _f16col(blk, 208)
    out = np.empty((n, 256), dtype=np.float32)
    for half in range(2):
        ql = ql_all[:, half * 64:(half + 1) * 64].astype(np.int32)
        qh = qh_all[:, half * 32:(half + 1) * 32].astype(np.int32)
        sc = scales[:, half * 8:(half + 1) * 8]
        l = np.arange(32)
        is_ = l // 16                       # 0 or 1
        q1 = ((ql[:, :32] & 0xF) | (((qh >> 0) & 3) << 4)) - 32
        q2 = ((ql[:, 32:] & 0xF) | (((qh >> 2) & 3) << 4)) - 32
        q3 = ((ql[:, :32] >> 4) | (((qh >> 4) & 3) << 4)) - 32
        q4 = ((ql[:, 32:] >> 4) | (((qh >> 6) & 3) << 4)) - 32
        base = half * 128
        out[:, base:base + 32] = d[:, None] * sc[:, is_ + 0] * q1
        out[:, base + 32:base + 64] = d[:, None] * sc[:, is_ + 2] * q2
        out[:, base + 64:base + 96] = d[:, None] * sc[:, is_ + 4] * q3
        out[:, base + 96:base + 128] = d[:, None] * sc[:, is_ + 6] * q4
    return out.ravel()


def deq_q8_k(raw: bytes) -> np.ndarray:
    blk = _blocks(raw, 292)
    d = blk[:, 0:4].copy().view("<f4").ravel()
    qs = blk[:, 4:260].view(np.int8).astype(np.float32)
    return (qs * d[:, None]).ravel()


DEQUANT: dict[int, Callable[[bytes], np.ndarray]] = {
    0: lambda b: np.frombuffer(b, dtype="<f4").astype(np.float32),
    1: lambda b: f16_to_f32(b),
    30: bf16_to_f32,
    28: lambda b: np.frombuffer(b, dtype="<f8").astype(np.float32),
    24: lambda b: np.frombuffer(b, dtype="<i1").astype(np.float32),
    25: lambda b: np.frombuffer(b, dtype="<i2").astype(np.float32),
    26: lambda b: np.frombuffer(b, dtype="<i4").astype(np.float32),
    27: lambda b: np.frombuffer(b, dtype="<i8").astype(np.float32),
    2: deq_q4_0, 3: deq_q4_1, 6: deq_q5_0, 7: deq_q5_1, 8: deq_q8_0, 9: deq_q8_1,
    10: deq_q2_k, 11: deq_q3_k, 12: deq_q4_k, 13: deq_q5_k, 14: deq_q6_k, 15: deq_q8_k,
}


# ==========================================================================
# reference quantizers (for round-trip tests and SFF->GGUF export)
# ==========================================================================
def quant_q8_0(x: np.ndarray) -> bytes:
    x = np.ascontiguousarray(x, dtype=np.float32).ravel().reshape(-1, 32)
    idx = np.argmax(np.abs(x), axis=1)
    amax = x[np.arange(x.shape[0]), idx]
    d = (amax / 127.0).astype(np.float16)
    dd = d.astype(np.float32)
    inv = np.where(dd != 0, 1.0 / np.where(dd != 0, dd, 1), 0.0)
    q = np.clip(np.rint(x * inv[:, None]), -127, 127).astype(np.int8)
    out = np.empty((x.shape[0], 34), dtype=np.uint8)
    out[:, 0:2] = d.view(np.uint8).reshape(-1, 2)
    out[:, 2:] = q.view(np.uint8)
    return out.tobytes()


def quant_q4_0(x: np.ndarray) -> bytes:
    x = np.ascontiguousarray(x, dtype=np.float32).ravel().reshape(-1, 32)
    idx = np.argmax(np.abs(x), axis=1)
    amax = x[np.arange(x.shape[0]), idx]
    d = (amax / -8.0).astype(np.float16)
    dd = d.astype(np.float32)
    inv = np.where(dd != 0, 1.0 / np.where(dd != 0, dd, 1), 0.0)
    q = np.clip(np.rint(x * inv[:, None]) + 8, 0, 15).astype(np.uint8)
    out = np.empty((x.shape[0], 18), dtype=np.uint8)
    out[:, 0:2] = d.view(np.uint8).reshape(-1, 2)
    out[:, 2:] = (q[:, :16] | (q[:, 16:] << 4))
    return out.tobytes()


# ==========================================================================
# streaming reader
# ==========================================================================
class GGUFReader:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.size = os.path.getsize(self.path)
        self.f = open(self.path, "rb")
        self.kv: dict = {}
        self.tensors: dict[str, GGUFTensor] = {}
        self.tensor_order: list[str] = []
        self._parse()

    def _read(self, n: int) -> bytes:
        b = self.f.read(n)
        if len(b) != n:
            raise GGUFError("truncated GGUF file")
        return b

    def _u32(self) -> int:
        return struct.unpack("<I", self._read(4))[0]

    def _u64(self) -> int:
        return struct.unpack("<Q", self._read(8))[0]

    def _str(self) -> str:
        n = self._u64()
        return self._read(n).decode("utf-8", errors="replace")

    def _value(self, vtype: int):
        if vtype == 8:
            return self._str()
        if vtype == 9:
            et = self._u32()
            n = self._u64()
            if et in _SCALAR_FMT:
                fmt = _SCALAR_FMT[et]
                sz = struct.calcsize(fmt)
                raw = self._read(sz * n)
                return list(struct.unpack("<" + fmt[1] * n, raw)) if n else []
            return [self._value(et) for _ in range(n)]
        fmt = _SCALAR_FMT.get(vtype)
        if fmt is None:
            raise GGUFError(f"unknown GGUF value type {vtype}")
        return struct.unpack(fmt, self._read(struct.calcsize(fmt)))[0]

    def _parse(self) -> None:
        self.f.seek(0)
        if self._u32() != GGUF_MAGIC:
            raise GGUFError("not a GGUF file")
        self.version = self._u32()
        if self.version not in (2, 3):
            raise GGUFError(f"unsupported GGUF version {self.version}")
        n_tensors = self._u64()
        n_kv = self._u64()
        self.kv_types: dict[str, tuple] = {}
        for _ in range(n_kv):
            key = self._str()
            vtype = self._u32()
            if vtype == 9:                      # remember the element type of arrays too
                pos = self.f.tell()
                et = self._u32()
                self.f.seek(pos)
                self.kv_types[key] = (9, et)
            else:
                self.kv_types[key] = (vtype, None)
            self.kv[key] = self._value(vtype)
        infos = []
        for _ in range(n_tensors):
            name = self._str()
            nd = self._u32()
            dims = tuple(self._u64() for _ in range(nd))
            ttype = self._u32()
            off = self._u64()
            infos.append((name, dims, ttype, off))
        self.alignment = int(self.kv.get("general.alignment", 32))
        pos = self.f.tell()
        self.data_start = (pos + self.alignment - 1) // self.alignment * self.alignment
        for name, dims, ttype, off in infos:
            n_elem = 1
            for d in dims:
                n_elem *= int(d)
            tn, bs, ts = GGML_TYPES.get(ttype, (f"TYPE{ttype}", 1, 1))
            if ttype not in GGML_TYPES:
                raise GGUFError(f"tensor {name}: unknown ggml type {ttype}")
            if n_elem % bs:
                raise GGUFError(f"tensor {name}: {n_elem} elements not a multiple of block {bs}")
            n_bytes = n_elem // bs * ts
            t = GGUFTensor(name, dims, ttype, off, n_elem, n_bytes, self.data_start + off)
            if t.abs_offset + n_bytes > self.size:
                raise GGUFError(f"tensor {name} extends past EOF")
            self.tensors[name] = t
            self.tensor_order.append(name)

    # ------------------------------------------------------------ streaming
    def iter_chunks(self, name: str, chunk_bytes: int = 8 << 20) -> Iterator[tuple[int, np.ndarray]]:
        """Yield (element_offset, float32 chunk) — block aligned; never more than chunk_bytes raw + its float expansion."""
        t = self.tensors[name]
        if t.ggml_type not in DEQUANTIZABLE:
            raise GGUFError(f"tensor {name} type {t.type_name} is not dequantizable; use iter_raw")
        _, bs, ts = GGML_TYPES[t.ggml_type]
        blocks_per_chunk = max(1, chunk_bytes // ts)
        n_blocks = t.n_elem // bs
        deq = DEQUANT[t.ggml_type]
        self.f.seek(t.abs_offset)
        done = 0
        while done < n_blocks:
            nb = min(blocks_per_chunk, n_blocks - done)
            raw = self._read(nb * ts)
            yield done * bs, deq(raw)
            done += nb

    def iter_raw(self, name: str, chunk_bytes: int = 8 << 20) -> Iterator[tuple[int, bytes]]:
        t = self.tensors[name]
        _, bs, ts = GGML_TYPES[t.ggml_type]
        blocks_per_chunk = max(1, chunk_bytes // ts)
        n_blocks = t.n_elem // bs
        self.f.seek(t.abs_offset)
        done = 0
        while done < n_blocks:
            nb = min(blocks_per_chunk, n_blocks - done)
            yield done * bs, self._read(nb * ts)
            done += nb

    def read_tensor(self, name: str, max_elements: int = 16 << 20) -> np.ndarray:
        """Small tensors only (norms, biases) — guarded."""
        t = self.tensors[name]
        if t.n_elem > max_elements:
            raise GGUFError(f"{name}: {t.n_elem} elements exceeds the whole-tensor read guard; stream it")
        parts = [c for _, c in self.iter_chunks(name)]
        return np.concatenate(parts).reshape(t.shape)

    def architecture(self) -> str:
        return str(self.kv.get("general.architecture", "unknown"))

    def summary(self) -> dict:
        by_type: dict[str, int] = {}
        total = 0
        for t in self.tensors.values():
            by_type[t.type_name] = by_type.get(t.type_name, 0) + 1
            total += t.n_elem
        return {"path": str(self.path), "version": self.version, "size": self.size, "arch": self.architecture(),
                "n_tensors": len(self.tensors), "n_kv": len(self.kv), "params": total, "types": by_type,
                "alignment": self.alignment, "data_start": self.data_start}

    def close(self) -> None:
        self.f.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


# ==========================================================================
# GGUF -> SFF conversion (streaming, bounded memory)
# ==========================================================================
def guess_tensor_domain(name: str) -> str:
    """Route a tensor to a knowledge-tower domain by role (INFERRED heuristic; recorded as such)."""
    n = name.lower()
    if "token_embd" in n or "embed" in n or "output" in n or "lm_head" in n:
        return "language"
    if "attn" in n or "attention" in n:
        return "senses_perception"
    if "ffn" in n or "mlp" in n or "expert" in n:
        return "technology"
    if "norm" in n:
        return "measurement"
    return "parametric"


def convert_gguf_to_sff(src: Path, dst: Path, budget: str = "8bit", memguard=None, ledger=None,
                        progress: Optional[Callable[[dict], None]] = None, tower=None,
                        keep_types: bool = True, max_tensors: Optional[int] = None,
                        mode: str = "exact") -> dict:
    """
    Streams every tensor of `src` into a new SFF model at `dst`.

    mode="exact" (default): every weight keeps its exact value. F32/F16 -> native pages; Q8_0 -> LIN8 and
        Q4_0 -> LIN4 by byte transcoding (no dequantization); every other type (Q4_1, Q5_*, K-quants,
        BF16, F64, ints, IQ*/TQ*) -> RAW pages holding the source block bytes, decoded on read by the
        GGML dequantizer. Output size = source + page-table/section overhead (~1.7 %). No storage contest.
    mode="reband": the Third-Law contest. budget "f32" | "f16" | "8bit" | "4bit" is the storage bit band;
        within it the per-page encoding with the lower measured error is kept (log gauge only at a >= 33.3 %
        cut); keep_types keeps 2-5-bit sources in the 4bit band and Q6_K/Q8 in the 8bit band. LOSSY for
        every source type except Q4_0 -> 4bit and Q8_0 -> 8bit; the error is recorded per tensor.
    """
    if mode not in ("exact", "reband"):
        raise ValueError("mode must be 'exact' or 'reband'")
    from .memguard import MemGuard
    from .tower import domain_id as tower_domain_id
    mg = memguard or MemGuard()
    t0 = time.time()
    gr = GGUFReader(src)
    src_meta = {}
    for k, v in gr.kv.items():
        if isinstance(v, list) and len(v) > 1_000_000:
            src_meta[k] = {"_truncated_array": len(v)}
        else:
            src_meta[k] = v
    meta = {"model_id": Path(src).stem, "source": {"gguf_path": str(src), "gguf_version": gr.version,
                                                    "gguf_size": gr.size, "arch": gr.architecture(),
                                                    "kv": src_meta, "budget": budget if mode == "reband" else "exact",
                                                    "mode": mode},
            "arch": {"family": "gguf-import", "arch": gr.architecture(), "tensor_order": gr.tensor_order},
            "tokenizer": {"kind": "gguf", "model": gr.kv.get("tokenizer.ggml.model", "?")}}
    w = SFFWriter(dst, file_kind=0, meta=meta, model_id=Path(src).stem)
    stats = {"tensors": 0, "params": 0, "raw_tensors": 0, "pages": 0, "verified": 0, "tie": 0, "exact": 0,
             "bytes_in": gr.size, "peak_rss_mb": 0.0, "budget": budget if mode == "reband" else "exact", "mode": mode,
             "lossy_tensors": 0, "by_type": {}}
    model_node = w.add_lineage_node(6, f"model:{Path(src).stem}")
    import_node = w.add_lineage_node(3, f"gguf:{src}")
    w.add_lineage_edge(import_node, model_node, 17)
    names = gr.tensor_order[:max_tensors] if max_tensors else gr.tensor_order
    for ti, name in enumerate(names):
        t = gr.tensors[name]
        dom_name = guess_tensor_domain(name)
        dom = tower_domain_id(dom_name)
        hid = w.add_helix(name, domain_id=dom, register_kind=5, kind=HELIX_KIND_TENSOR)
        chunk = mg.chunk_bytes()
        page_index = 0
        eb = ec = 0.0
        n_pages = 0
        enc_default = ENC_BY_BUDGET.get(budget, ENC_F32)
        status = "EXACT"
        stats["by_type"][t.type_name] = stats["by_type"].get(t.type_name, 0) + 1
        _, bs_t, ts_t = GGML_TYPES[t.ggml_type]
        if mode == "exact" and t.ggml_type in EXACT_TRANSCODE:
            # Q8_0 -> LIN8 / Q4_0 -> LIN4: block bytes re-arranged, scales and codes untouched
            enc_default = ENC_BY_BUDGET["8bit"] if t.ggml_type == 8 else ENC_BY_BUDGET["4bit"]
            trans = EXACT_TRANSCODE[t.ggml_type]
            page_bytes = (w.page_values // bs_t) * ts_t
            for eoff, raw in gr.iter_raw(name, max(page_bytes, chunk // page_bytes * page_bytes)):
                mg.check(f"transcode {name}")
                for off in range(0, len(raw), page_bytes):
                    blob = raw[off:off + page_bytes]
                    cnt = len(blob) // ts_t * bs_t
                    w.write_page(hid, page_index, trans(blob), enc_default, count=cnt, err=0.0)
                    page_index += 1
                    n_pages += 1
                    stats["exact"] += 1
            bpv = ENC_BPV.get(enc_default, 32.0)
        elif mode == "exact" and t.ggml_type not in (0, 1):
            # RAW pages of exactly page_values values: source bytes verbatim, decoded on read
            page_bytes = max(1, w.page_values // bs_t) * ts_t
            for eoff, raw in gr.iter_raw(name, max(page_bytes, chunk // page_bytes * page_bytes)):
                mg.check(f"raw {name}")
                for off in range(0, len(raw), page_bytes):
                    blob = raw[off:off + page_bytes]
                    w.write_page(hid, page_index, blob, ENC_RAW, count=len(blob) // ts_t * bs_t, base_page=t.ggml_type)
                    page_index += 1
                    n_pages += 1
                    stats["exact"] += 1
            stats["raw_tensors"] += 1
            status = "EXACT" if t.ggml_type in DEQUANTIZABLE else "RAW"
            enc_default = ENC_RAW
            bpv = ts_t * 8.0 / bs_t
        elif t.ggml_type in DEQUANTIZABLE:
            tb = budget if mode == "reband" else ("f16" if t.ggml_type == 1 else "f32")
            if mode == "reband" and keep_types and t.ggml_type in (2, 3, 6, 7, 10, 11, 12, 13, 16, 17, 18, 19, 20, 21, 22, 23, 29):
                tb = "4bit"          # 2-5 bit sources stay in the 4-bit band (Q4_0 round-trips exactly)
            elif mode == "reband" and keep_types and t.ggml_type in (8, 9, 14, 15):
                tb = "8bit"          # Q6_K/Q8 sources stay in the 8-bit band (Q8_0 round-trips exactly)
            carry = np.zeros(0, dtype=np.float32)
            for eoff, arr in gr.iter_chunks(name, chunk):
                mg.check(f"convert {name}")
                buf = np.concatenate([carry, arr]) if carry.size else arr
                full = buf.size // w.page_values * w.page_values
                for p in range(0, full, w.page_values):
                    page = buf[p:p + w.page_values]
                    pc = choose_encoding(page, tb)
                    w.write_page(hid, page_index, pc.payload, pc.enc, count=page.size, err=pc.mse)
                    eb += pc.baseline_mse * page.size
                    ec += pc.mse * page.size
                    if pc.status == "VERIFIED":
                        stats["verified"] += 1
                    elif pc.status == "EXACT":
                        stats["exact"] += 1
                    else:
                        stats["tie"] += 1
                    page_index += 1
                    n_pages += 1
                carry = buf[full:].copy()
                del buf, arr
            if carry.size:
                pc = choose_encoding(carry, tb)
                w.write_page(hid, page_index, pc.payload, pc.enc, count=carry.size, err=pc.mse)
                eb += pc.baseline_mse * carry.size
                ec += pc.mse * carry.size
                stats["verified" if pc.status == "VERIFIED" else ("exact" if pc.status == "EXACT" else "tie")] += 1
                page_index += 1
                n_pages += 1
            n = max(t.n_elem, 1)
            eb, ec = eb / n, ec / n
            if ec == 0:
                status = "EXACT"
            elif eb > 0 and (eb - ec) / eb >= 1 / 3:
                status = "VERIFIED"
            else:
                status = "TIE"
            if ec > 0:
                stats["lossy_tensors"] += 1
            enc_default = ENC_BY_BUDGET.get(tb, ENC_F32)
            bpv = ENC_BPV.get(enc_default, 32.0)
        else:
            # RAW passthrough — nothing dropped, type id recorded in base_page
            _, bs, ts = GGML_TYPES[t.ggml_type]
            for eoff, raw in gr.iter_raw(name, chunk):
                mg.check(f"raw {name}")
                w.write_page(hid, page_index, raw, ENC_RAW, count=len(raw) // ts * bs, base_page=t.ggml_type)
                page_index += 1
                n_pages += 1
            stats["raw_tensors"] += 1
            status = "RAW"
            enc_default = ENC_RAW
            bpv = ts * 8.0 / bs
        tinfo = TensorInfo(-1, name, hid, t.shape, t.ggml_type, 0, t.n_elem, 0, n_pages, enc_default, bpv, eb, ec, status)
        w.register_tensor(tinfo)
        w.helices[hid].frame_count = t.n_elem
        node = w.add_lineage_node(4, name, ref_index=tinfo.tensor_id)
        w.add_lineage_edge(model_node, node, 17)
        if mode == "reband" and t.ggml_type in DEQUANTIZABLE and eb > 0:
            w.add_opt_row(f"storage:{name}", eb, ec, status if status in ("VERIFIED", "TIE", "EXACT") else "NULL",
                          cut_pct=(eb - ec) / eb * 100.0, note=f"{t.type_name}->{ENC_NAMES.get(enc_default)} band {budget} (mse)")
        stats["tensors"] += 1
        stats["params"] += t.n_elem
        stats["pages"] += n_pages
        stats["peak_rss_mb"] = max(stats["peak_rss_mb"], mg.status()["rss_mb"])
        if progress:
            progress({"i": ti + 1, "n": len(names), "tensor": name, "type": t.type_name, "pages": n_pages,
                      "status": status, "rss_mb": mg.status()["rss_mb"], "elapsed": time.time() - t0})
    gr.close()
    if ledger is not None:
        rec = ledger.append("SFF", "gguf_import", {"src": str(src), "dst": str(dst), **stats}, domain="parametric")
        w.set_ledger_bytes(ledger.export_bytes())
    w.commit()
    w.close()
    stats["elapsed_s"] = round(time.time() - t0, 2)
    stats["bytes_out"] = os.path.getsize(dst)
    stats["peak_rss_mb"] = max(stats["peak_rss_mb"], mg.status()["peak_mb"])
    return stats


def explain_conversion(stats: dict, src: Path, dst: Path) -> str:
    """Plain-language account of what a conversion did (shown by the CLI and the window)."""
    from .util import human_bytes
    bin_, bout = stats.get("bytes_in", 0), stats.get("bytes_out", 0)
    growth = (bout - bin_) / bin_ * 100.0 if bin_ else 0.0
    types = ", ".join(f"{k} x{v}" for k, v in sorted(stats.get("by_type", {}).items(), key=lambda kv: -kv[1]))
    lines = [f"Made {dst.name} from {src.name}.",
             f"  Tensors: {stats.get('tensors', 0)} ({types}); weights: {stats.get('params', 0) / 1e9:.2f} billion; pages: {stats.get('pages', 0):,}."]
    if stats.get("mode") == "exact":
        lines.append("  Mode: EXACT - every weight has the same value it had in the .gguf (0 error, nothing re-quantized).")
        lines.append(f"  Size: {human_bytes(bout)} vs {human_bytes(bin_)} source ({growth:+.1f} %). The extra is the page table (44 bytes per 4096 values),"
                     f" the checksums, the lineage, the ledger and the index - not bigger weights.")
    else:
        lines.append(f"  Mode: RE-BAND to the {stats.get('budget')} band - {stats.get('lossy_tensors', 0)} tensors were re-quantized (LOSSY; the error of each is recorded in the file),"
                     f" {stats.get('exact', 0)} pages stayed exact, {stats.get('verified', 0)} pages took the log gauge (>= 33.3 % cut), {stats.get('tie', 0)} tied and kept the linear baseline.")
        lines.append(f"  Size: {human_bytes(bout)} vs {human_bytes(bin_)} source ({growth:+.1f} %). 8-bit pages are 8.5 bits per weight, 4-bit pages 4.5;"
                     f" a 4-6-bit K-quant source re-banded to 8-bit grows, one re-banded to 4-bit shrinks and loses precision.")
    lines.append(f"  Peak memory while converting: {stats.get('peak_rss_mb', 0):.0f} MB (the file was streamed, never loaded whole); {stats.get('elapsed_s', 0):.0f} s.")
    lines.append("  What you gained: the model opens in milliseconds, any slice of any tensor can be read without loading the file,"
                 " every page is checksummed, and its history, lineage and ledger live inside the file.")
    lines.append("  What you can do now: Inspect it, Verify it, read any slice of it, roll it forward with SOKE's page tools.")
    lines.append("  Not in the .sff: the import only re-packs the weights; it does not re-organize them. To chat with the .gguf itself,")
    lines.append("  or to build a NEW model from its weights (layer by layer, topic by topic), use the Forge tab - it reads the .gguf")
    lines.append("  directly (llama / mistral / qwen2 families; other architectures are not supported by the forge yet).")
    return "\n".join(lines)


# ==========================================================================
# GGUF -> GGUF repackaging (for Ollama / LM Studio / llama.cpp)
# ==========================================================================
_BAND_BPV = {"f32": 32.0, "f16": 16.0, "8bit": 8.5, "4bit": 4.5}
_BAND_GTYPE = {"f32": 0, "f16": 1, "8bit": 8, "4bit": 2}          # ggml type for the band's block quant
_BAND_FILETYPE = {"f32": 0, "f16": 1, "8bit": 7, "4bit": 2}       # llama.cpp general.file_type code


def _reband_target_gtype(band: str, shape: tuple, name: str) -> int:
    """The ggml type a tensor should become in the chosen band. Block quants (Q8_0/Q4_0) need the fastest
    dimension to be a multiple of 32; 1-D tensors and the router (ffn_gate_inp) stay F32, exactly as
    llama.cpp keeps norms/gates full precision."""
    cols = shape[-1] if len(shape) else 0
    block_ok = len(shape) > 1 and cols % 32 == 0 and not name.endswith("ffn_gate_inp.weight")
    gt = _BAND_GTYPE.get(band, 0)
    if gt in (8, 2) and not block_ok:
        return 0                                                  # fall back to F32 (tiny tensors; keeps precision)
    return gt


def _requant_stream(gr: "GGUFReader", name: str, gt: int, mg):
    """Dequantize a source tensor to f32 and re-emit it as ggml type `gt`, streamed. Block quants flush in
    multiples of 32 values; f16/f32 flush every chunk."""
    carry = np.zeros(0, dtype=np.float32)
    for _, arr in gr.iter_chunks(name, mg.chunk_bytes()):
        buf = np.concatenate([carry, arr]) if carry.size else arr
        if gt in (8, 2):
            k = (buf.size // 32) * 32
            head, carry = buf[:k], buf[k:].copy()
            if head.size:
                yield quant_q8_0(head) if gt == 8 else quant_q4_0(head)
        elif gt == 1:
            yield np.ascontiguousarray(buf, dtype="<f2").tobytes(); carry = np.zeros(0, dtype=np.float32)
        else:
            yield np.ascontiguousarray(buf, dtype="<f4").tobytes(); carry = np.zeros(0, dtype=np.float32)
        mg.check(f"requant {name}")
    if carry.size:
        if gt in (8, 2):
            yield quant_q8_0(carry) if gt == 8 else quant_q4_0(carry)
        elif gt == 1:
            yield np.ascontiguousarray(carry, dtype="<f2").tobytes()
        else:
            yield np.ascontiguousarray(carry, dtype="<f4").tobytes()


def repack_gguf(src: Path, dst: Path, budget: str = "8bit", mode: str = "exact", keep_types: bool = True,
                memguard=None, ledger=None, progress: Optional[Callable[[dict], None]] = None,
                max_tensors: Optional[int] = None) -> dict:
    """
    Repack a .gguf into ANOTHER .gguf that Ollama / LM Studio / llama.cpp run directly. All metadata (arch,
    hyperparameters, the whole tokenizer) is carried over unchanged from the source.

    mode="exact"  : every tensor is copied byte-for-byte at its own type (a faithful repack; same size).
    mode="reband" : every tensor is repacked into `budget` = "f32" | "f16" | "8bit" (Q8_0) | "4bit" (Q4_0).
        keep_types leaves a tensor at its own type when it is ALREADY at or below the band's bits-per-weight
        (so K-quants and already-small tensors are copied verbatim, not re-quantized). 1-D tensors and the
        router stay F32. LOSSY only for the tensors that are actually made smaller.
    """
    if mode not in ("exact", "reband"):
        raise ValueError("mode must be 'exact' or 'reband'")
    if mode == "reband" and budget not in _BAND_GTYPE:
        raise ValueError(f"budget must be one of {sorted(_BAND_GTYPE)}")
    from .memguard import MemGuard
    mg = memguard or MemGuard()
    t0 = time.time()
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    gr = GGUFReader(src)
    kv = dict(gr.kv)
    kv_types = dict(gr.kv_types) if getattr(gr, "kv_types", None) else {}
    if mode == "reband" and "general.file_type" in kv:
        kv["general.file_type"] = _BAND_FILETYPE.get(budget, kv["general.file_type"])
    names = gr.tensor_order[:max_tensors] if max_tensors else gr.tensor_order
    stats = {"tensors": 0, "copied": 0, "requantized": 0, "bytes_in": gr.size, "mode": mode,
             "budget": budget if mode == "reband" else "exact", "peak_rss_mb": 0.0, "out_types": {}}
    plan = []
    for name in names:
        t = gr.tensors[name]
        src_bpv = GGML_TYPES[t.ggml_type][2] * 8.0 / GGML_TYPES[t.ggml_type][1]
        if mode == "exact":
            gt, kind = t.ggml_type, "copy"
        elif keep_types and src_bpv <= _BAND_BPV.get(budget, 32.0) + 1e-6:
            gt, kind = t.ggml_type, "copy"                       # already small enough — keep verbatim
        elif t.ggml_type not in DEQUANTIZABLE:
            gt, kind = t.ggml_type, "copy"                       # cannot dequantize this type — keep verbatim
        else:
            gt = _reband_target_gtype(budget, t.shape, name)
            kind = "copy" if gt == t.ggml_type else "requant"
        plan.append((name, tuple(reversed(t.shape)), gt, kind, t.ggml_type, t.n_elem))

    def tensor_iter():
        for j, (name, dims, gt, kind, src_type, n_elem) in enumerate(plan):
            _, bs, ts = GGML_TYPES[gt]
            n_bytes = n_elem // bs * ts
            if kind == "copy":
                gen = (raw for _, raw in gr.iter_raw(name, mg.chunk_bytes()))
                stats["copied"] += 1
            else:
                gen = _requant_stream(gr, name, gt, mg)
                stats["requantized"] += 1
            tn = GGML_TYPES[gt][0]
            stats["out_types"][tn] = stats["out_types"].get(tn, 0) + 1
            stats["tensors"] += 1
            stats["peak_rss_mb"] = max(stats["peak_rss_mb"], mg.status()["rss_mb"])
            if progress:
                progress({"i": j + 1, "n": len(plan), "tensor": name, "out_type": tn, "kind": kind,
                          "rss_mb": mg.status()["rss_mb"], "elapsed": time.time() - t0})
            yield (name, dims, gt, gen, n_bytes)

    written = write_gguf(dst, kv, tensor_iter(), kv_types=kv_types or None)
    gr.close()
    stats["bytes_out"] = written
    stats["elapsed_s"] = round(time.time() - t0, 2)
    stats["peak_rss_mb"] = max(stats["peak_rss_mb"], mg.status()["peak_mb"])
    if ledger is not None:
        ledger.append("GGUF", "gguf_repack", {"src": str(src), "dst": str(dst), **{k: v for k, v in stats.items() if k != "out_types"}}, domain="parametric")
    return stats


def write_modelfile(gguf_path: Path, name: Optional[str] = None) -> Path:
    """Write a minimal Ollama Modelfile beside a .gguf so `ollama create <name> -f <file>` registers it."""
    gguf_path = Path(gguf_path)
    mf = gguf_path.with_suffix(".Modelfile")
    mf.write_text(f"FROM ./{gguf_path.name}\n", encoding="utf-8")
    return mf


def explain_repack(stats: dict, src: Path, dst: Path) -> str:
    from .util import human_bytes
    bin_, bout = stats.get("bytes_in", 0), stats.get("bytes_out", 0)
    growth = (bout - bin_) / bin_ * 100.0 if bin_ else 0.0
    outs = ", ".join(f"{k} x{v}" for k, v in sorted(stats.get("out_types", {}).items(), key=lambda kv: -kv[1]))
    lines = [f"Repacked {src.name} -> {dst.name} (a .gguf you can run in Ollama / LM Studio / llama.cpp)."]
    if stats.get("mode") == "exact":
        lines.append(f"  Mode: EXACT - {stats.get('tensors', 0)} tensors copied byte-for-byte ({outs}); nothing re-quantized.")
    else:
        lines.append(f"  Mode: RE-BAND to {stats.get('budget')} - {stats.get('requantized', 0)} tensors re-quantized, "
                     f"{stats.get('copied', 0)} kept as-is ({outs}).")
    lines.append(f"  Size: {human_bytes(bout)} vs {human_bytes(bin_)} source ({growth:+.1f} %).")
    lines.append(f"  Peak memory: {stats.get('peak_rss_mb', 0):.0f} MB (streamed, never loaded whole); {stats.get('elapsed_s', 0):.0f} s.")
    lines.append("  To use it in Ollama:  put the .gguf and its .Modelfile in a folder, then run  ollama create <name> -f <name>.Modelfile")
    return "\n".join(lines)


# ==========================================================================
# minimal GGUF writer (SFF -> GGUF export of F32/Q8_0/Q4_0 tensors; for interop)
# ==========================================================================
def write_gguf(path: Path, kv: dict, tensors: Iterator[tuple[str, tuple, int, Iterator[bytes], int]],
               alignment: int = 32, kv_types: Optional[dict] = None) -> int:
    """
    tensors: iterable of (name, dims_as_stored, ggml_type, raw_chunk_iterator, n_bytes).
    kv values: python scalars (int -> u32 when 0 <= v < 2^32 as llama.cpp expects for hyperparameters,
    else i32/u64 by range; float -> f32; str; bool; list of same). kv_types (from GGUFReader.kv_types)
    pins the exact GGUF value type per key so re-emitted metadata keeps its original type.
    Streams tensor bytes; returns bytes written.
    """
    kv_types = kv_types or {}

    def enc_str(s: str) -> bytes:
        b = s.encode("utf-8")
        return struct.pack("<Q", len(b)) + b

    def enc_scalar(v, vt: int) -> bytes:
        fmt = _SCALAR_FMT[vt]
        if vt == 7:
            return struct.pack(fmt, bool(v))
        if vt == 6 or vt == 12:
            return struct.pack(fmt, float(v))
        return struct.pack(fmt, int(v))

    def enc_val(v, forced: Optional[tuple] = None) -> tuple[int, bytes]:
        if forced is not None:
            vt, et = forced
            if vt == 8:
                return 8, enc_str(str(v))
            if vt == 9:
                lst = list(v)
                if et == 8:
                    return 9, struct.pack("<IQ", 8, len(lst)) + b"".join(enc_str(str(x)) for x in lst)
                return 9, struct.pack("<IQ", et, len(lst)) + b"".join(enc_scalar(x, et) for x in lst)
            return vt, enc_scalar(v, vt)
        if isinstance(v, bool):
            return 7, struct.pack("<?", v)
        if isinstance(v, int):
            if 0 <= v < 2 ** 32:
                return 4, struct.pack("<I", v)
            if -2 ** 31 <= v < 2 ** 31:
                return 5, struct.pack("<i", v)
            return 10, struct.pack("<Q", v)
        if isinstance(v, float):
            return 6, struct.pack("<f", v)
        if isinstance(v, str):
            return 8, enc_str(v)
        if isinstance(v, list):
            if not v:
                return 9, struct.pack("<IQ", 5, 0)
            if all(isinstance(x, int) and not isinstance(x, bool) for x in v):
                return 9, struct.pack("<IQ", 5, len(v)) + b"".join(struct.pack("<i", int(x)) for x in v)
            et, _ = enc_val(v[0])
            body = b"".join(enc_val(x)[1] for x in v)
            return 9, struct.pack("<IQ", et, len(v)) + body
        raise GGUFError(f"cannot encode kv value {type(v)}")

    tl = list(tensors)
    with open(path, "wb") as f:
        f.write(struct.pack("<IIQQ", GGUF_MAGIC, 3, len(tl), len(kv)))
        for k, v in kv.items():
            vt, vb = enc_val(v, kv_types.get(k))
            f.write(enc_str(k) + struct.pack("<I", vt) + vb)
        off = 0
        for name, dims, ttype, _it, n_bytes in tl:
            f.write(enc_str(name) + struct.pack("<I", len(dims)) + struct.pack("<" + "Q" * len(dims), *dims)
                    + struct.pack("<IQ", ttype, off))
            off += (n_bytes + alignment - 1) // alignment * alignment
        pos = f.tell()
        pad = (-pos) % alignment
        f.write(b"\x00" * pad)
        for name, dims, ttype, it, n_bytes in tl:
            written = 0
            for chunk in it:
                f.write(chunk)
                written += len(chunk)
            if written != n_bytes:
                raise GGUFError(f"{name}: wrote {written} bytes, expected {n_bytes}")
            f.write(b"\x00" * ((-n_bytes) % alignment))
        return f.tell()


# ==========================================================================
# metadata rewrite layer (the "gguf_rewrites" of the guide, kept honest):
# rewrites are recorded as a manifest — SFF pages are never overwritten.
# ==========================================================================
def rewrite_manifest(reader, routes: dict) -> dict:
    """Build the soke.rewrites manifest for an SFF/GGUF model: op -> chosen route (from kernels.py)."""
    return {"routes": routes, "model": getattr(reader, "meta", {}).get("model_id", "?"), "ts": time.time_ns()}


# ==========================================================================
# second-route scalar dequantizers (pure Python transcription of ggml loops)
# ==========================================================================
def _f16(b: bytes) -> float:
    return float(np.frombuffer(b, dtype="<f2")[0])


def scalar_deq_q4_k(block: bytes) -> list[float]:
    d, dmin = _f16(block[0:2]), _f16(block[2:4])
    sc = block[4:16]
    q = block[16:144]
    y = []
    is_ = 0
    qi = 0
    for j in range(0, 256, 64):
        def gsm(k):
            if k < 4:
                return sc[k] & 63, sc[k + 4] & 63
            return (sc[k + 4] & 0xF) | ((sc[k - 4] >> 6) << 4), (sc[k + 4] >> 4) | ((sc[k] >> 6) << 4)
        s1, m1 = gsm(is_)
        s2, m2 = gsm(is_ + 1)
        d1, mm1, d2, mm2 = d * s1, dmin * m1, d * s2, dmin * m2
        for l in range(32):
            y.append(d1 * (q[qi + l] & 0xF) - mm1)
        for l in range(32):
            y.append(d2 * (q[qi + l] >> 4) - mm2)
        qi += 32
        is_ += 2
    return y


def scalar_deq_q6_k(block: bytes) -> list[float]:
    ql, qh = block[0:128], block[128:192]
    sc = struct.unpack("<16b", block[192:208])
    d = _f16(block[208:210])
    y = [0.0] * 256
    qli = qhi = sci = 0
    for n in range(0, 256, 128):
        for l in range(32):
            is_ = l // 16
            q1 = ((ql[qli + l] & 0xF) | (((qh[qhi + l] >> 0) & 3) << 4)) - 32
            q2 = ((ql[qli + l + 32] & 0xF) | (((qh[qhi + l] >> 2) & 3) << 4)) - 32
            q3 = ((ql[qli + l] >> 4) | (((qh[qhi + l] >> 4) & 3) << 4)) - 32
            q4 = ((ql[qli + l + 32] >> 4) | (((qh[qhi + l] >> 6) & 3) << 4)) - 32
            y[n + l] = d * sc[sci + is_] * q1
            y[n + l + 32] = d * sc[sci + is_ + 2] * q2
            y[n + l + 64] = d * sc[sci + is_ + 4] * q3
            y[n + l + 96] = d * sc[sci + is_ + 6] * q4
        qli += 64
        qhi += 32
        sci += 8
    return y


def scalar_deq_q5_k(block: bytes) -> list[float]:
    d, dmin = _f16(block[0:2]), _f16(block[2:4])
    sc = block[4:16]
    qh = block[16:48]
    ql = block[48:176]
    y = []
    is_ = 0
    qi = 0
    u1, u2 = 1, 2
    for j in range(0, 256, 64):
        def gsm(k):
            if k < 4:
                return sc[k] & 63, sc[k + 4] & 63
            return (sc[k + 4] & 0xF) | ((sc[k - 4] >> 6) << 4), (sc[k + 4] >> 4) | ((sc[k] >> 6) << 4)
        s1, m1 = gsm(is_)
        s2, m2 = gsm(is_ + 1)
        d1, mm1, d2, mm2 = d * s1, dmin * m1, d * s2, dmin * m2
        for l in range(32):
            y.append(d1 * ((ql[qi + l] & 0xF) + (16 if qh[l] & u1 else 0)) - mm1)
        for l in range(32):
            y.append(d2 * ((ql[qi + l] >> 4) + (16 if qh[l] & u2 else 0)) - mm2)
        qi += 32
        is_ += 2
        u1 <<= 2
        u2 <<= 2
    return y


def scalar_deq_q2_k(block: bytes) -> list[float]:
    scales, qs = block[0:16], block[16:80]
    d, dmin = _f16(block[80:82]), _f16(block[82:84])
    y = []
    is_ = 0
    qi = 0
    for n in range(0, 256, 128):
        shift = 0
        for j in range(4):
            sc = scales[is_]
            is_ += 1
            dl, ml = d * (sc & 0xF), dmin * (sc >> 4)
            for l in range(16):
                y.append(dl * ((qs[qi + l] >> shift) & 3) - ml)
            sc = scales[is_]
            is_ += 1
            dl, ml = d * (sc & 0xF), dmin * (sc >> 4)
            for l in range(16):
                y.append(dl * ((qs[qi + l + 16] >> shift) & 3) - ml)
            shift += 2
        qi += 32
    return y


def scalar_deq_q3_k(block: bytes) -> list[float]:
    hm, qs, scb = block[0:32], block[32:96], block[96:108]
    d = _f16(block[108:110])
    aux = list(struct.unpack("<3I", scb)) + [0]
    k1, k2 = 0x03030303, 0x0f0f0f0f
    tmp = aux[2]
    a2 = ((aux[0] >> 4) & k2) | (((tmp >> 4) & k1) << 4)
    a3 = ((aux[1] >> 4) & k2) | (((tmp >> 6) & k1) << 4)
    a0 = (aux[0] & k2) | (((tmp >> 0) & k1) << 4)
    a1 = (aux[1] & k2) | (((tmp >> 2) & k1) << 4)
    scales = list(struct.unpack("<16b", struct.pack("<4I", a0, a1, a2, a3)))
    y = []
    is_ = 0
    m = 1
    qi = 0
    for n in range(0, 256, 128):
        shift = 0
        for j in range(4):
            dl = d * (scales[is_] - 32)
            is_ += 1
            for l in range(16):
                y.append(dl * (((qs[qi + l] >> shift) & 3) - (0 if hm[l] & m else 4)))
            dl = d * (scales[is_] - 32)
            is_ += 1
            for l in range(16):
                y.append(dl * (((qs[qi + l + 16] >> shift) & 3) - (0 if hm[l + 16] & m else 4)))
            shift += 2
            m <<= 1
        qi += 32
    return y


SCALAR_ROUTES = {10: scalar_deq_q2_k, 11: scalar_deq_q3_k, 12: scalar_deq_q4_k, 13: scalar_deq_q5_k, 14: scalar_deq_q6_k}


# ==========================================================================
# self-checks
# ==========================================================================
def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    chk = chk or Check("gguf")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_gguf_"))
    rng = Rng(11)
    x = rng.normal(0, 0.05, 32 * 64).astype(np.float32)
    # Q8_0 / Q4_0 round trips against our own reference quantizers (route 1) + error bound (route 2)
    y8 = deq_q8_0(quant_q8_0(x))
    chk("Q8_0 quant->dequant", y8.size == x.size and np.max(np.abs(y8 - x)) <= np.max(np.abs(x)) / 127 * 0.51 + 1e-6, f"max err {np.max(np.abs(y8 - x)):.2e}")
    y4 = deq_q4_0(quant_q4_0(x))
    chk("Q4_0 quant->dequant (asymmetric: error <= |d| = amax/8)", np.max(np.abs(y4 - x)) <= np.max(np.abs(x)) / 8 * 1.01 + 1e-6, f"max err {np.max(np.abs(y4 - x)):.2e}")
    # nibble order: low nibbles are the first 16 values of the block
    blk = bytearray(18)
    blk[0:2] = np.float16(1.0).tobytes()
    blk[2] = (9) | (8 << 4)                 # value0 = 9-8 = +1, value16 = 8-8 = 0
    yb = deq_q4_0(bytes(blk))
    chk("Q4_0 nibble order (low nibble first)", yb[0] == 1.0 and yb[16] == 0.0 and yb[1] == -8.0)
    # K-quants: vectorized vs scalar transcription on random block bytes (structural second route)
    for tid, sizes in ((10, 84), (11, 110), (12, 144), (13, 176), (14, 210)):
        nb = 3
        raw = bytes(rng.integers(0, 256, nb * sizes, dtype=np.uint8))
        # avoid NaN/inf halves in scale slots: overwrite the f16 fields with sane values
        raw = bytearray(raw)
        for b in range(nb):
            base = b * sizes
            if tid == 10:
                raw[base + 80:base + 84] = np.array([0.01, 0.002], np.float16).tobytes()
            elif tid == 11:
                raw[base + 108:base + 110] = np.float16(0.01).tobytes()
            elif tid in (12, 13):
                raw[base:base + 4] = np.array([0.01, 0.002], np.float16).tobytes()
            elif tid == 14:
                raw[base + 208:base + 210] = np.float16(0.01).tobytes()
        raw = bytes(raw)
        vec = DEQUANT[tid](raw)
        sca = np.array(sum((SCALAR_ROUTES[tid](raw[i * sizes:(i + 1) * sizes]) for i in range(nb)), []), dtype=np.float32)
        name = GGML_TYPES[tid][0]
        chk(f"{name} vectorized == scalar ggml transcription", vec.shape == sca.shape and np.allclose(vec, sca, rtol=1e-5, atol=1e-7),
            f"max |d| {np.max(np.abs(vec - sca)) if vec.shape == sca.shape else 'shape'}")
    # Q5_0 / Q5_1 high-bit path: construct a block with known bits
    b5 = bytearray(22)
    b5[0:2] = np.float16(1.0).tobytes()
    b5[2:6] = struct.pack("<I", 0x00000001 | (1 << 16))    # high bit for value0 (bit 0) and value16 (bit 16)
    b5[6] = 0x00
    y5 = deq_q5_0(bytes(b5))
    chk("Q5_0 high bits", y5[0] == 0.0 and y5[16] == 0.0 and y5[1] == -16.0 and y5[17] == -16.0, f"{y5[:2]} {y5[16:18]}")
    b51 = bytearray(24)
    b51[0:2] = np.float16(2.0).tobytes()
    b51[2:4] = np.float16(1.0).tobytes()
    b51[4:8] = struct.pack("<I", 1)
    y51 = deq_q5_1(bytes(b51))
    chk("Q5_1 d*q+m", y51[0] == 2.0 * 16 + 1.0 and y51[1] == 1.0)
    # write a small GGUF (v3) with mixed types, read it back streaming, convert to SFF under the guard
    A = rng.normal(0, 1, (64, 128)).astype(np.float32)      # F32 tensor (dims stored reversed)
    B = rng.normal(0, 0.1, (32, 96)).astype(np.float32)     # Q8_0
    C = rng.normal(0, 0.1, (16, 64)).astype(np.float32)     # Q4_0
    D = np.arange(48, dtype=np.float32)                     # F16
    q8 = quant_q8_0(B)
    q4 = quant_q4_0(C)
    tl = [("blk.0.attn_q.weight", (128, 64), 0, iter([A.tobytes()]), A.nbytes),
          ("blk.0.ffn_up.weight", (96, 32), 8, iter([q8]), len(q8)),
          ("blk.0.ffn_down.weight", (64, 16), 2, iter([q4]), len(q4)),
          ("output_norm.weight", (48,), 1, iter([D.astype(np.float16).tobytes()]), 96)]
    gp = tmpdir / "mini.gguf"
    write_gguf(gp, {"general.architecture": "llama", "general.name": "mini", "llama.block_count": 1,
                    "tokenizer.ggml.tokens": ["<s>", "a", "b"]}, tl)
    gr = GGUFReader(gp)
    chk("GGUF header/kv/tensors parsed", gr.version == 3 and gr.kv["general.name"] == "mini" and len(gr.tensors) == 4
        and gr.kv["tokenizer.ggml.tokens"] == ["<s>", "a", "b"])
    a_back = np.concatenate([c for _, c in gr.iter_chunks("blk.0.attn_q.weight", chunk_bytes=1024)]).reshape(64, 128)
    chk("streamed F32 tensor in 1 KB chunks == source", np.array_equal(a_back, A))
    b_back = gr.read_tensor("blk.0.ffn_up.weight")
    chk("Q8_0 tensor via GGUF matches quantizer", np.array_equal(b_back.ravel(), deq_q8_0(q8)))
    chk("F16 tensor", np.array_equal(gr.read_tensor("output_norm.weight"), D))
    chk("tensor shape reversed from dims", gr.tensors["blk.0.attn_q.weight"].shape == (64, 128))
    gr.close()
    from .memguard import MemGuard
    from .sff import SFFReader
    sp = tmpdir / "mini.sff"
    mg = MemGuard(soft_mb=512, hard_mb=900, chunk_mb=1)
    st = convert_gguf_to_sff(gp, sp, budget="8bit", memguard=mg, mode="reband")
    rd = SFFReader(sp)
    a_sff = rd.read_tensor("blk.0.attn_q.weight")
    chk("GGUF->SFF re-band conversion (4 tensors, streamed)", st["tensors"] == 4 and a_sff.shape == (64, 128), f"{st}")
    chk("re-banded F32 tensor within 8-bit band error", np.max(np.abs(a_sff - A)) < 0.05, f"max err {np.max(np.abs(a_sff - A)):.3e}")
    chk("re-band mode counts its lossy tensors", st["lossy_tensors"] >= 1 and st["mode"] == "reband", f"lossy={st['lossy_tensors']}")
    chk("source dtype recorded", rd.tensors["blk.0.ffn_up.weight"].dtype_orig == 8 and rd.tensors["blk.0.attn_q.weight"].dtype_orig == 0)
    chk("storage verdict rows written", len(rd.opt_rows()) >= 1 and all(r["status"] in ("VERIFIED", "TIE", "EXACT", "NULL") for r in rd.opt_rows()))
    chk("Q8_0 and Q4_0 sources round-trip EXACT in their own bands (keep_types)", rd.tensors["blk.0.ffn_up.weight"].status == "EXACT" and rd.tensors["blk.0.ffn_down.weight"].status == "EXACT"
        and np.array_equal(rd.read_tensor("blk.0.ffn_up.weight").ravel(), deq_q8_0(q8)) and np.array_equal(rd.read_tensor("blk.0.ffn_down.weight").ravel(), deq_q4_0(q4)))
    chk("lineage import edges", any(e["op"] == "import" for e in rd.lineage()[1]))
    chk("memory guard peak recorded (<1 GB)", 0 < st["peak_rss_mb"] < 1024, f"peak {st['peak_rss_mb']} MB")
    rd.close()
    # ---- exact mode (the default): transcoders, RAW pages, K-quant / Q5 / BF16 sources kept verbatim
    chk("Q8_0->LIN8 transcode bit-exact (no dequantization)", np.array_equal(decode_page(q8_0_to_lin8(q8), ENC_LIN8, B.size), deq_q8_0(q8)))
    chk("Q4_0->LIN4 transcode bit-exact (nibble reorder only)", np.array_equal(decode_page(q4_0_to_lin4(q4), ENC_LIN4, C.size), deq_q4_0(q4)))
    # K-quant and Q5_1/BF16 tensors built from raw block bytes with sane scales (same construction as above)
    def sane_blocks(tid, sizes, nb):
        raw = bytearray(bytes(rng.integers(0, 256, nb * sizes, dtype=np.uint8)))
        for b in range(nb):
            base = b * sizes
            if tid == 12:
                raw[base:base + 4] = np.array([0.01, 0.002], np.float16).tobytes()
            elif tid == 14:
                raw[base + 208:base + 210] = np.float16(0.01).tobytes()
            elif tid == 7:
                raw[base:base + 4] = np.array([0.01, 0.002], np.float16).tobytes()
        return bytes(raw)
    k4 = sane_blocks(12, 144, 40)            # Q4_K: 40 super-blocks = 10240 values = 2.5 pages
    k6 = sane_blocks(14, 210, 16)            # Q6_K: 16 super-blocks = 4096 values = exactly 1 page
    q51 = sane_blocks(7, 24, 130)            # Q5_1: 130 blocks = 4160 values = 1 page + 64
    bf = rng.normal(0, 1, 4200).astype(np.float32)
    bf_raw = (bf.view(np.uint32) >> 16).astype(np.uint16).tobytes()      # BF16 = top half of f32
    tl2 = [("blk.0.attn_q.weight", (128, 64), 0, iter([A.tobytes()]), A.nbytes),
           ("blk.0.ffn_up.weight", (96, 32), 8, iter([q8]), len(q8)),
           ("blk.0.ffn_down.weight", (64, 16), 2, iter([q4]), len(q4)),
           ("blk.0.ffn_gate.weight", (256, 40), 12, iter([k4]), len(k4)),
           ("blk.0.attn_v.weight", (256, 16), 14, iter([k6]), len(k6)),
           ("blk.0.attn_k.weight", (32, 130), 7, iter([q51]), len(q51)),
           ("token_embd.weight", (100, 42), 30, iter([bf_raw]), len(bf_raw)),
           ("output_norm.weight", (48,), 1, iter([D.astype(np.float16).tobytes()]), 96)]
    gp2 = tmpdir / "mixed.gguf"
    write_gguf(gp2, {"general.architecture": "llama", "general.name": "mixed"}, tl2)
    sp2 = tmpdir / "mixed.sff"
    st2 = convert_gguf_to_sff(gp2, sp2, memguard=MemGuard(soft_mb=512, hard_mb=900, chunk_mb=1))   # default mode = exact
    rd2 = SFFReader(sp2)
    chk("exact mode is the default and re-bands nothing", st2["mode"] == "exact" and st2["lossy_tensors"] == 0 and st2["tie"] == 0 and st2["verified"] == 0, f"{ {k: st2[k] for k in ('exact', 'tie', 'verified', 'raw_tensors', 'lossy_tensors')} }")
    chk("exact: F32 / F16 native pages bit-identical", np.array_equal(rd2.read_tensor("blk.0.attn_q.weight"), A) and np.array_equal(rd2.read_tensor("output_norm.weight"), D))
    chk("exact: Q8_0 / Q4_0 transcoded pages bit-identical", np.array_equal(rd2.read_tensor("blk.0.ffn_up.weight").ravel(), deq_q8_0(q8)) and np.array_equal(rd2.read_tensor("blk.0.ffn_down.weight").ravel(), deq_q4_0(q4)))
    chk("exact: Q4_K kept as RAW pages, decoded on read == GGML dequant", rd2.tensors["blk.0.ffn_gate.weight"].enc_default == ENC_RAW and np.array_equal(rd2.read_tensor("blk.0.ffn_gate.weight").ravel(), deq_q4_k(k4)))
    chk("exact: Q6_K RAW page (exactly one page of 4096)", rd2.tensors["blk.0.attn_v.weight"].page_count == 1 and np.array_equal(rd2.read_tensor("blk.0.attn_v.weight").ravel(), deq_q6_k(k6)))
    chk("exact: Q5_1 RAW pages (partial last page)", rd2.tensors["blk.0.attn_k.weight"].page_count == 2 and np.array_equal(rd2.read_tensor("blk.0.attn_k.weight").ravel(), deq_q5_1(q51)))
    chk("exact: BF16 RAW pages decode to the source values", np.array_equal(rd2.read_tensor("token_embd.weight").ravel(), bf16_to_f32(bf_raw)))
    rows = rd2.tensor_rows("blk.0.ffn_gate.weight", 3, 5)
    chk("exact: row window through RAW pages", np.array_equal(rows, deq_q4_k(k4).reshape(40, 256)[3:5]))
    chk("exact: pages are 4096 values (page table paging kept)", all(int(c) <= PAGE_VALUES for c in rd2.ptab["count"]) and rd2.tensors["blk.0.ffn_gate.weight"].page_count == 3)
    src_bytes = sum(n for *_, n in [(None, None, None, None, len(q8)), (None, None, None, None, len(q4)), (None, None, None, None, len(k4)), (None, None, None, None, len(k6)), (None, None, None, None, len(q51)), (None, None, None, None, len(bf_raw)), (None, None, None, None, A.nbytes), (None, None, None, None, 96)])
    pay = int(rd2.ptab["length"].sum())
    chk("exact: page payload bytes == source tensor bytes (no growth beyond the table)", pay == src_bytes, f"payload {pay} B vs source {src_bytes} B; file {st2['bytes_out']} B")
    chk("exact: deep verify (every page CRC)", rd2.verify(deep=True)["ok"])
    rd2.close()

    # ---- GGUF -> GGUF repack (for Ollama): exact copy, and re-band to smaller bands ----------------
    # exact repack of mini.gguf: types unchanged, weights identical, tokenizer/kv carried over
    rp_e = tmpdir / "mini.repack.gguf"
    se = repack_gguf(gp, rp_e, mode="exact", memguard=MemGuard(soft_mb=512, hard_mb=900, chunk_mb=1))
    ge = GGUFReader(rp_e)
    chk("repack exact: tensor types unchanged", [ge.tensors[n].ggml_type for n in ("blk.0.attn_q.weight", "blk.0.ffn_up.weight", "blk.0.ffn_down.weight", "output_norm.weight")] == [0, 8, 2, 1])
    chk("repack exact: weights byte-identical (dequant matches source)",
        np.array_equal(ge.read_tensor("blk.0.attn_q.weight").reshape(64, 128), A)
        and np.array_equal(ge.read_tensor("blk.0.ffn_up.weight").ravel(), deq_q8_0(q8))
        and np.array_equal(ge.read_tensor("blk.0.ffn_down.weight").ravel(), deq_q4_0(q4)))
    chk("repack exact: architecture + full tokenizer carried over",
        ge.kv.get("general.architecture") == "llama" and ge.kv.get("tokenizer.ggml.tokens") == ["<s>", "a", "b"])
    chk("repack exact: memory streamed (<1 GB)", 0 < se["peak_rss_mb"] < 1024 and se["copied"] == 4 and se["requantized"] == 0, f"{se}")
    ge.close()
    # re-band mini.gguf to 8-bit: F32 -> Q8_0, Q8_0 kept, Q4_0 kept (already <= band), 1-D F16 -> F32
    rp8 = tmpdir / "mini.8bit.gguf"
    s8 = repack_gguf(gp, rp8, mode="reband", budget="8bit", keep_types=True, memguard=MemGuard(soft_mb=512, hard_mb=900, chunk_mb=1))
    g8 = GGUFReader(rp8)
    chk("repack 8bit: F32->Q8_0, already-small tensors kept, 1-D norm -> F32",
        [g8.tensors[n].ggml_type for n in ("blk.0.attn_q.weight", "blk.0.ffn_up.weight", "blk.0.ffn_down.weight", "output_norm.weight")] == [8, 8, 2, 0])
    chk("repack 8bit: re-quantized F32 tensor within 8-bit error", np.max(np.abs(g8.read_tensor("blk.0.attn_q.weight").reshape(64, 128) - A)) < 0.05,
        f"max err {np.max(np.abs(g8.read_tensor('blk.0.attn_q.weight').reshape(64, 128) - A)):.3e}")
    chk("repack 8bit: kept tensors are verbatim (Q4_0 exact) and the norm is lossless F32",
        np.array_equal(g8.read_tensor("blk.0.ffn_down.weight").ravel(), deq_q4_0(q4)) and np.array_equal(g8.read_tensor("output_norm.weight"), D))
    chk("repack 8bit: it re-reads as a valid GGUF our engine (and llama.cpp) can load", g8.version == 3 and len(g8.tensors) == 4)
    g8.close()
    # re-band to 4-bit: everything driveable becomes Q4_0 (F32 and Q8_0 requantized; Q4_0 kept)
    rp4 = tmpdir / "mini.4bit.gguf"
    s4 = repack_gguf(gp, rp4, mode="reband", budget="4bit", keep_types=True, memguard=MemGuard(soft_mb=512, hard_mb=900, chunk_mb=1))
    g4 = GGUFReader(rp4)
    chk("repack 4bit: F32 and Q8_0 -> Q4_0, Q4_0 kept", [g4.tensors[n].ggml_type for n in ("blk.0.attn_q.weight", "blk.0.ffn_up.weight", "blk.0.ffn_down.weight")] == [2, 2, 2])
    chk("repack 4bit: shrinks the file vs 8-bit", s4["bytes_out"] < s8["bytes_out"], f"4bit {s4['bytes_out']} vs 8bit {s8['bytes_out']}")
    chk("repack 4bit: re-quantized F32 within 4-bit error", np.max(np.abs(g4.read_tensor("blk.0.attn_q.weight").reshape(64, 128) - A)) < 0.3)
    g4.close()
    # mixed source (K-quants / BF16): K-quants already small are kept; odd-column BF16 falls back to F32
    rpm = tmpdir / "mixed.8bit.gguf"
    sm = repack_gguf(gp2, rpm, mode="reband", budget="8bit", keep_types=True, memguard=MemGuard(soft_mb=512, hard_mb=900, chunk_mb=1))
    gm = GGUFReader(rpm)
    chk("repack mixed: Q4_K / Q6_K kept verbatim (already under the 8-bit band)",
        gm.tensors["blk.0.ffn_gate.weight"].ggml_type == 12 and gm.tensors["blk.0.attn_v.weight"].ggml_type == 14
        and np.array_equal(gm.read_tensor("blk.0.ffn_gate.weight").ravel(), deq_q4_k(k4)))
    chk("repack mixed: BF16 with non-32 columns falls back to F32 (block quant needs 32|cols)", gm.tensors["token_embd.weight"].ggml_type == 0)
    gm.close()
    mf = write_modelfile(rp8, "mini8")
    chk("repack: Ollama Modelfile written next to the .gguf", mf.exists() and mf.read_text().strip() == f"FROM ./{rp8.name}")
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
