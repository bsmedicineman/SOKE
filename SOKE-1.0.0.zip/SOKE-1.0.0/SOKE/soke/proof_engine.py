"""
soke.proof_engine — the Math Truth Engine (MTE), stdlib only.

MFP LAW 0: "True" means PROVEN — or explicitly tagged otherwise.

Verification paths, in strict order of authority (MFP Phase 2):
  PATH 1  SYMBOLIC / DECISION PROCEDURE            -> TRUE | FALSE
          * propositional formulas: truth table (a decision procedure, <= 16 variables)
          * set identities over ∪ ∩ \\ ^c: translated to propositional form (Boolean-algebra
            free-variable theorem: an identity holds in every Boolean algebra iff it is a
            propositional tautology) -> truth table
          * polynomial identities over Q: both sides canonicalized to multivariate
            polynomial normal form with exact Fractions; equal normal forms <=> identity
          * closed arithmetic (no variables, +-*/^ integer powers): exact Fractions
          * finite structures (Z mod n is a group): exhaustive check — TRUE for that n
  PATH 3  COMPUTATIONAL CHECK                       -> EMPIRICALLY_TRUE | FALSE
          random rational + integer plug-ins (N cases, |error| < 1e-9, relative), with an
          active counterexample search. NEVER promoted to TRUE.
  (PATH 2, derivation from the store, lives in math_engine; PATH 4, cited authority, is a tag.)

Grammar (one line, ASCII):
  arithmetic: + - * / ^  ( )  numbers  identifiers  sqrt sin cos tan exp log abs
  relations : =  !=  <  <=  >  >=
  logic     : ~ (not)  & (and)  | (or)  -> (implies)  <-> (iff)   over propositional letters
  sets      : A | B (union) written  A u B ,  A n B (intersection),  A \\ B (difference),  A' (complement)
"""
from __future__ import annotations

import itertools
import math
import random
import re
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Optional

from .util import TOL

# ==========================================================================
# tokenizer / parser for arithmetic relations
# ==========================================================================
_TOKEN = re.compile(r"\s*(?:(?P<num>\d+\.?\d*(?:[eE][-+]?\d+)?)|(?P<id>[A-Za-z_][A-Za-z0-9_]*)|(?P<op><=|>=|!=|<->|->|[-+*/^()=<>,]))")
FUNCS = {"sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan, "exp": math.exp, "log": math.log,
         "ln": math.log, "abs": abs, "atan": math.atan, "sinh": math.sinh, "cosh": math.cosh, "tanh": math.tanh}
CONSTS = {"pi": math.pi, "e": math.e}
TRANSCENDENTAL = set(FUNCS) - {"abs"}


class ParseError(ValueError):
    pass


def tokenize(s: str) -> list[tuple[str, str]]:
    out = []
    pos = 0
    s = s.strip()
    while pos < len(s):
        m = _TOKEN.match(s, pos)
        if not m or m.end() == pos:
            raise ParseError(f"bad token at {pos}: {s[pos:pos + 10]!r}")
        pos = m.end()
        for k in ("num", "id", "op"):
            if m.group(k) is not None:
                out.append((k, m.group(k)))
                break
    return out


class Node:
    __slots__ = ("op", "args")

    def __init__(self, op: str, *args):
        self.op = op
        self.args = args

    def __repr__(self):
        return f"({self.op} {' '.join(map(repr, self.args))})" if self.args else self.op


class Parser:
    """Recursive descent: expr := sum ; sum := prod (('+'|'-') prod)* ; prod := pow (('*'|'/') pow)* ;
    pow := unary ('^' pow)? ; unary := '-' unary | atom ; atom := num | id | id '(' args ')' | '(' expr ')'."""

    def __init__(self, tokens: list[tuple[str, str]]):
        self.t = tokens
        self.i = 0

    def peek(self) -> Optional[tuple[str, str]]:
        return self.t[self.i] if self.i < len(self.t) else None

    def take(self, val: Optional[str] = None) -> tuple[str, str]:
        tok = self.peek()
        if tok is None or (val is not None and tok[1] != val):
            raise ParseError(f"expected {val!r} at token {self.i}")
        self.i += 1
        return tok

    def parse_relation(self) -> Node:
        lhs = self.parse_expr()
        tok = self.peek()
        if tok and tok[1] in ("=", "!=", "<", "<=", ">", ">="):
            self.take()
            rhs = self.parse_expr()
            if self.peek() is not None:
                raise ParseError("trailing tokens")
            return Node(tok[1], lhs, rhs)
        if self.peek() is not None:
            raise ParseError("trailing tokens")
        return lhs

    def parse_expr(self) -> Node:
        n = self.parse_prod()
        while self.peek() and self.peek()[1] in ("+", "-"):
            op = self.take()[1]
            n = Node(op, n, self.parse_prod())
        return n

    def parse_prod(self) -> Node:
        n = self.parse_pow()
        while self.peek() and self.peek()[1] in ("*", "/"):
            op = self.take()[1]
            n = Node(op, n, self.parse_pow())
        return n

    def parse_pow(self) -> Node:
        base = self.parse_unary()
        if self.peek() and self.peek()[1] == "^":
            self.take()
            return Node("^", base, self.parse_pow())
        return base

    def parse_unary(self) -> Node:
        if self.peek() and self.peek()[1] == "-":
            self.take()
            return Node("neg", self.parse_unary())
        if self.peek() and self.peek()[1] == "+":
            self.take()
            return self.parse_unary()
        return self.parse_atom()

    def parse_atom(self) -> Node:
        tok = self.take()
        kind, val = tok
        if kind == "num":
            return Node("num", val)
        if kind == "id":
            if self.peek() and self.peek()[1] == "(":
                self.take("(")
                args = [self.parse_expr()]
                while self.peek() and self.peek()[1] == ",":
                    self.take(",")
                    args.append(self.parse_expr())
                self.take(")")
                return Node("call", val, *args)
            return Node("var", val)
        if val == "(":
            n = self.parse_expr()
            self.take(")")
            return n
        raise ParseError(f"unexpected {val!r}")


def parse(s: str) -> Node:
    return Parser(tokenize(s)).parse_relation()


def variables(n: Node) -> set[str]:
    if n.op == "var":
        return {n.args[0]} if n.args[0] not in CONSTS else set()
    if n.op == "num":
        return set()
    if n.op == "call":
        return set().union(*[variables(a) for a in n.args[1:]]) if len(n.args) > 1 else set()
    return set().union(*[variables(a) for a in n.args]) if n.args else set()


def uses_transcendental(n: Node) -> bool:
    if n.op == "call":
        return n.args[0] in TRANSCENDENTAL or any(uses_transcendental(a) for a in n.args[1:])
    if n.op == "var":
        return n.args[0] in CONSTS
    if n.op == "num":
        return False
    return any(uses_transcendental(a) for a in n.args)


# ==========================================================================
# exact evaluation (Fractions) and float evaluation
# ==========================================================================
def eval_exact(n: Node, env: dict[str, Fraction]) -> Fraction:
    op = n.op
    if op == "num":
        return Fraction(n.args[0])
    if op == "var":
        if n.args[0] in env:
            return Fraction(env[n.args[0]])
        raise ValueError(f"unbound {n.args[0]}")
    if op == "neg":
        return -eval_exact(n.args[0], env)
    if op == "+":
        return eval_exact(n.args[0], env) + eval_exact(n.args[1], env)
    if op == "-":
        return eval_exact(n.args[0], env) - eval_exact(n.args[1], env)
    if op == "*":
        return eval_exact(n.args[0], env) * eval_exact(n.args[1], env)
    if op == "/":
        d = eval_exact(n.args[1], env)
        if d == 0:
            raise ZeroDivisionError("division by zero")
        return eval_exact(n.args[0], env) / d
    if op == "^":
        b = eval_exact(n.args[0], env)
        e = eval_exact(n.args[1], env)
        if e.denominator != 1:
            raise ValueError("non-integer exponent is not exact")
        return b ** int(e)
    if op == "call":
        if n.args[0] == "abs":
            return abs(eval_exact(n.args[1], env))
        raise ValueError("transcendental call is not exact")
    raise ValueError(f"cannot evaluate {op}")


def eval_float(n: Node, env: dict[str, float]) -> float:
    op = n.op
    if op == "num":
        return float(n.args[0])
    if op == "var":
        v = n.args[0]
        if v in env:
            return float(env[v])
        if v in CONSTS:
            return CONSTS[v]
        raise ValueError(f"unbound {v}")
    if op == "neg":
        return -eval_float(n.args[0], env)
    if op in ("+", "-", "*", "/", "^"):
        a, b = eval_float(n.args[0], env), eval_float(n.args[1], env)
        if op == "+":
            return a + b
        if op == "-":
            return a - b
        if op == "*":
            return a * b
        if op == "/":
            return a / b
        return a ** b
    if op == "call":
        f = FUNCS[n.args[0]]
        return f(*[eval_float(a, env) for a in n.args[1:]])
    raise ValueError(op)


# ==========================================================================
# polynomial normal form over Q  (decision procedure for polynomial identities)
# ==========================================================================
Poly = dict  # {monomial tuple (sorted (var, exp) pairs) : Fraction}


def _padd(a: Poly, b: Poly) -> Poly:
    out = dict(a)
    for k, v in b.items():
        out[k] = out.get(k, Fraction(0)) + v
        if out[k] == 0:
            del out[k]
    return out


def _pmul(a: Poly, b: Poly) -> Poly:
    out: Poly = {}
    for ka, va in a.items():
        for kb, vb in b.items():
            d = dict(ka)
            for var, e in kb:
                d[var] = d.get(var, 0) + e
            k = tuple(sorted(d.items()))
            out[k] = out.get(k, Fraction(0)) + va * vb
            if out[k] == 0:
                del out[k]
    return out


def _pscale(a: Poly, c: Fraction) -> Poly:
    return {k: v * c for k, v in a.items()} if c != 0 else {}


def to_poly(n: Node) -> Poly:
    """Raises ValueError when the expression is not a polynomial over Q."""
    op = n.op
    if op == "num":
        c = Fraction(n.args[0])
        return {(): c} if c != 0 else {}
    if op == "var":
        if n.args[0] in CONSTS:
            raise ValueError("transcendental constant")
        return {((n.args[0], 1),): Fraction(1)}
    if op == "neg":
        return _pscale(to_poly(n.args[0]), Fraction(-1))
    if op == "+":
        return _padd(to_poly(n.args[0]), to_poly(n.args[1]))
    if op == "-":
        return _padd(to_poly(n.args[0]), _pscale(to_poly(n.args[1]), Fraction(-1)))
    if op == "*":
        return _pmul(to_poly(n.args[0]), to_poly(n.args[1]))
    if op == "/":
        d = to_poly(n.args[1])
        if len(d) == 1 and () in d:
            return _pscale(to_poly(n.args[0]), 1 / d[()])
        raise ValueError("division by a non-constant")
    if op == "^":
        e = to_poly(n.args[1])
        if len(e) == 1 and () in e and e[()].denominator == 1 and e[()] >= 0:
            k = int(e[()])
            out: Poly = {(): Fraction(1)}
            b = to_poly(n.args[0])
            for _ in range(k):
                out = _pmul(out, b)
            return out
        if not e:
            return {(): Fraction(1)}
        raise ValueError("non-integer exponent")
    if op == "call" and n.args[0] == "abs":
        raise ValueError("abs is not polynomial")
    raise ValueError(f"not polynomial: {op}")


# ==========================================================================
# propositional logic — truth-table decision procedure
# ==========================================================================
_PTOK = re.compile(r"\s*(?:(?P<id>[A-Za-z_][A-Za-z0-9_]*)|(?P<op><->|->|[~&|()]))")


def _ptokens(s: str) -> list[str]:
    out = []
    pos = 0
    s = s.strip()
    while pos < len(s):
        m = _PTOK.match(s, pos)
        if not m or m.end() == pos:
            raise ParseError(f"bad propositional token at {pos}")
        pos = m.end()
        out.append(m.group("id") or m.group("op"))
    return out


class PropParser:
    """iff := imp ('<->' imp)* ; imp := or ('->' imp)? ; or := and ('|' and)* ; and := not ('&' not)* ;
    not := '~' not | atom ; atom := id | '(' iff ')'"""

    def __init__(self, toks: list[str]):
        self.t = toks
        self.i = 0

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else None

    def take(self, v=None):
        tok = self.peek()
        if tok is None or (v is not None and tok != v):
            raise ParseError(f"expected {v}")
        self.i += 1
        return tok

    def parse(self):
        n = self.iff()
        if self.peek() is not None:
            raise ParseError("trailing tokens")
        return n

    def iff(self):
        n = self.imp()
        while self.peek() == "<->":
            self.take()
            n = ("iff", n, self.imp())
        return n

    def imp(self):
        n = self.or_()
        if self.peek() == "->":
            self.take()
            return ("imp", n, self.imp())
        return n

    def or_(self):
        n = self.and_()
        while self.peek() == "|":
            self.take()
            n = ("or", n, self.and_())
        return n

    def and_(self):
        n = self.not_()
        while self.peek() == "&":
            self.take()
            n = ("and", n, self.not_())
        return n

    def not_(self):
        if self.peek() == "~":
            self.take()
            return ("not", self.not_())
        return self.atom()

    def atom(self):
        tok = self.take()
        if tok == "(":
            n = self.iff()
            self.take(")")
            return n
        if tok in ("~", "&", "|", "->", "<->", ")"):
            raise ParseError(f"unexpected {tok}")
        return ("var", tok)


def _peval(n, env: dict[str, bool]) -> bool:
    k = n[0]
    if k == "var":
        return env[n[1]]
    if k == "not":
        return not _peval(n[1], env)
    a = _peval(n[1], env)
    b = _peval(n[2], env)
    if k == "and":
        return a and b
    if k == "or":
        return a or b
    if k == "imp":
        return (not a) or b
    return a == b


def _pvars(n, acc: set):
    if n[0] == "var":
        acc.add(n[1])
    else:
        for c in n[1:]:
            _pvars(c, acc)
    return acc


def decide_propositional(formula: str, max_vars: int = 16) -> dict:
    tree = PropParser(_ptokens(formula)).parse()
    vs = sorted(_pvars(tree, set()))
    if len(vs) > max_vars:
        return {"status": "UNDECIDED", "reason": f"{len(vs)} variables > {max_vars}", "path": 1}
    true_rows = 0
    counter = None
    for bits in itertools.product((False, True), repeat=len(vs)):
        env = dict(zip(vs, bits))
        if _peval(tree, env):
            true_rows += 1
        elif counter is None:
            counter = env
    total = 2 ** len(vs)
    if true_rows == total:
        return {"status": "TRUE", "kind": "TAUTOLOGY", "rows": total, "path": 1}
    if true_rows == 0:
        return {"status": "FALSE", "kind": "CONTRADICTION", "rows": total, "path": 1}
    return {"status": "FALSE", "kind": "CONTINGENT", "rows": total, "counterexample": counter, "path": 1}


# ==========================================================================
# set identities -> propositional (Boolean algebra free-variable theorem)
# ==========================================================================
def set_to_prop(expr: str) -> str:
    s = expr
    s = re.sub(r"\bu\b", "|", s)      # union
    s = re.sub(r"\bn\b", "&", s)      # intersection
    s = s.replace("\\", "&~")         # A \ B == A & ~B  (difference)
    # postfix complement X' -> (~X): apply to identifiers and parenthesized groups
    s = re.sub(r"([A-Za-z_][A-Za-z0-9_]*)'", r"(~\1)", s)
    while re.search(r"\)'", s):
        # find the matching '(' for the ')' before the quote
        i = s.index(")'")
        depth = 0
        j = i
        while j >= 0:
            if s[j] == ")":
                depth += 1
            elif s[j] == "(":
                depth -= 1
                if depth == 0:
                    break
            j -= 1
        s = s[:j] + "(~" + s[j:i + 1] + ")" + s[i + 2:]
    return s


def decide_set_identity(lhs: str, rhs: str) -> dict:
    formula = f"({set_to_prop(lhs)}) <-> ({set_to_prop(rhs)})"
    r = decide_propositional(formula)
    r["translated"] = formula
    return r


# ==========================================================================
# finite structures
# ==========================================================================
def check_group_z_mod_n(n: int) -> dict:
    """Exhaustive: (Z_n, +) closure, associativity, identity, inverses."""
    els = range(n)
    for a in els:
        for b in els:
            if (a + b) % n not in els:
                return {"status": "FALSE", "reason": "closure"}
            for c in els:
                if ((a + b) % n + c) % n != (a + (b + c) % n) % n:
                    return {"status": "FALSE", "reason": "associativity"}
    if any((a + 0) % n != a for a in els):
        return {"status": "FALSE", "reason": "identity"}
    if any(all((a + b) % n != 0 for b in els) for a in els):
        return {"status": "FALSE", "reason": "inverse"}
    return {"status": "TRUE", "kind": f"group Z_{n}", "checks": n ** 3 + 2 * n, "path": 1}


def check_bijection(mapping: dict) -> dict:
    vals = list(mapping.values())
    inj = len(set(vals)) == len(vals)
    return {"status": "TRUE" if inj else "FALSE", "injective": inj, "image": sorted(set(vals)), "path": 1}


# ==========================================================================
# the verifier
# ==========================================================================
RELS = {"=": lambda a, b: a == b, "!=": lambda a, b: a != b, "<": lambda a, b: a < b, "<=": lambda a, b: a <= b,
        ">": lambda a, b: a > b, ">=": lambda a, b: a >= b}


@dataclass
class Verdict:
    status: str                    # TRUE | FALSE | EMPIRICALLY_TRUE | UNDECIDED
    path: int
    method: str
    detail: dict = field(default_factory=dict)

    @property
    def truth_symbol(self) -> str:
        return {"TRUE": "⊤", "FALSE": "⊥", "EMPIRICALLY_TRUE": "≈⊤", "UNDECIDED": "?"}.get(self.status, "?")

    def as_dict(self) -> dict:
        return {"status": self.status, "path": self.path, "method": self.method, "detail": self.detail}


class ProofEngine:
    def __init__(self, samples: int = 64, seed: int = 369, tol: float = TOL):
        self.samples = samples
        self.seed = seed
        self.tol = tol

    # ------------------------------------------------------------ dispatch
    def verify(self, statement: str) -> Verdict:
        s = statement.strip()
        try:
            if any(t in s for t in ("<->", "->", "~", "&", "|")) and "=" not in s and "<" not in s.replace("<->", "").replace("->", ""):
                r = decide_propositional(s)
                return Verdict(r["status"], 1, "truth_table", r)
            if re.search(r"\b[un]\b|'|\\", s) and "=" in s and not re.search(r"\d", s):
                lhs, rhs = s.split("=", 1)
                r = decide_set_identity(lhs.strip(), rhs.strip())
                return Verdict(r["status"], 1, "set_identity->truth_table", r)
            node = parse(s)
        except (ParseError, ValueError) as e:
            return Verdict("UNDECIDED", 0, "parse", {"error": str(e)})
        if node.op not in RELS:
            return Verdict("UNDECIDED", 0, "not_a_relation", {"expr": repr(node)})
        lhs, rhs = node.args
        vs = variables(lhs) | variables(rhs)
        # PATH 1a: closed arithmetic, exact
        if not vs and not uses_transcendental(node):
            try:
                a, b = eval_exact(lhs, {}), eval_exact(rhs, {})
                ok = RELS[node.op](a, b)
                return Verdict("TRUE" if ok else "FALSE", 1, "exact_rational", {"lhs": str(a), "rhs": str(b)})
            except ZeroDivisionError as e:
                return Verdict("FALSE", 1, "exact_rational", {"error": str(e)})
            except ValueError:
                pass
        # PATH 1b: polynomial identity normal form
        if node.op == "=":
            try:
                pl, pr = to_poly(lhs), to_poly(rhs)
                eq = _padd(pl, _pscale(pr, Fraction(-1)))
                if not eq:
                    return Verdict("TRUE", 1, "polynomial_normal_form", {"monomials": len(pl)})
                # a nonzero polynomial is not identically zero -> not an identity; exhibit a counterexample
                ce = self._poly_counterexample(eq, vs)
                return Verdict("FALSE", 1, "polynomial_normal_form", {"difference": _poly_str(eq), "counterexample": ce})
            except ValueError:
                pass
        # PATH 3: computational check with counterexample search
        return self._numeric(node, vs)

    def _poly_counterexample(self, p: Poly, vs: set[str]) -> Optional[dict]:
        rnd = random.Random(self.seed)
        names = sorted(vs)
        for _ in range(500):
            env = {v: Fraction(rnd.randint(-6, 6)) for v in names}
            val = Fraction(0)
            for mono, c in p.items():
                term = c
                for var, e in mono:
                    term *= env[var] ** e
                val += term
            if val != 0:
                return {k: str(v) for k, v in env.items()}
        return None

    def _numeric(self, node: Node, vs: set[str]) -> Verdict:
        rnd = random.Random(self.seed)
        names = sorted(vs)
        lhs, rhs = node.args
        checked = 0
        worst = 0.0
        for i in range(self.samples):
            if i < 8:
                env = {v: float(rnd.randint(1, 5)) for v in names}          # small integers first (the plug-in discipline)
            else:
                env = {v: rnd.uniform(-3.0, 3.0) if rnd.random() < 0.5 else rnd.uniform(0.1, 4.0) for v in names}
            try:
                a, b = eval_float(lhs, env), eval_float(rhs, env)
            except (ValueError, ZeroDivisionError, OverflowError):
                continue
            if not (math.isfinite(a) and math.isfinite(b)):
                continue
            checked += 1
            if node.op == "=":
                err = abs(a - b) / max(1.0, abs(a), abs(b))
                worst = max(worst, err)
                if err > self.tol:
                    return Verdict("FALSE", 3, "numeric_counterexample", {"env": env, "lhs": a, "rhs": b, "rel_err": err})
            else:
                if not RELS[node.op](a, b):
                    return Verdict("FALSE", 3, "numeric_counterexample", {"env": env, "lhs": a, "rhs": b})
        if checked < 2:
            return Verdict("UNDECIDED", 3, "numeric", {"checked": checked, "reason": "domain errors"})
        return Verdict("EMPIRICALLY_TRUE", 3, "numeric_sampling", {"checked": checked, "worst_rel_err": worst,
                                                                    "note": "never promoted to TRUE (MFP PATH 3)"})

    # --------------------------------------------------------- utilities
    def negation_of(self, statement: str) -> Optional[str]:
        s = statement.strip()
        for rel, neg in (("!=", "="), ("<=", ">"), (">=", "<"), ("=", "!="), ("<", ">="), (">", "<=")):
            if rel in s and "->" not in s and "<->" not in s:
                l, r = s.split(rel, 1)
                return f"{l.strip()} {neg} {r.strip()}"
        if any(t in s for t in ("<->", "->", "~", "&", "|")):
            return f"~({s})"
        return None


def _poly_str(p: Poly) -> str:
    parts = []
    for mono, c in sorted(p.items(), key=lambda kv: str(kv[0])):
        m = "*".join(f"{v}^{e}" if e > 1 else v for v, e in mono)
        parts.append(f"{c}" + (f"*{m}" if m else ""))
    return " + ".join(parts) if parts else "0"


# ==========================================================================
# self-checks
# ==========================================================================
def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("proof")
    pe = ProofEngine()
    v = pe.verify("(a + b)^2 = a^2 + 2*a*b + b^2")
    chk("polynomial identity PROVEN (normal form)", v.status == "TRUE" and v.path == 1, v.method)
    v = pe.verify("(a + b)^2 = a^2 + b^2")
    chk("false identity refuted with counterexample", v.status == "FALSE" and v.detail.get("counterexample"), str(v.detail.get("counterexample")))
    v = pe.verify("(x - 1)*(x + 1) = x^2 - 1")
    chk("difference of squares PROVEN", v.status == "TRUE")
    v = pe.verify("1/3 + 1/6 = 1/2")
    chk("closed rational arithmetic exact", v.status == "TRUE" and v.method == "exact_rational")
    v = pe.verify("2 + 2 = 5")
    chk("2+2=5 FALSE", v.status == "FALSE")
    v = pe.verify("1/0 = 0")
    chk("division by zero rejected", v.status == "FALSE")
    v = pe.verify("sin(x)^2 + cos(x)^2 = 1")
    chk("trig identity only EMPIRICALLY_TRUE (never TRUE)", v.status == "EMPIRICALLY_TRUE" and v.path == 3, f"checked {v.detail.get('checked')} worst {v.detail.get('worst_rel_err'):.1e}")
    v = pe.verify("exp(log(x)) = x")
    chk("exp/log identity EMPIRICALLY_TRUE", v.status == "EMPIRICALLY_TRUE")
    v = pe.verify("sin(x) = x")
    chk("sin(x)=x refuted numerically", v.status == "FALSE" and v.method == "numeric_counterexample")
    v = pe.verify("a*b/(a+b) = 1/(1/a + 1/b)")
    chk("harmonic-sum dual EMPIRICALLY_TRUE (rational function)", v.status == "EMPIRICALLY_TRUE")
    v = pe.verify("sqrt(a*b) <= (a + b)/2")
    chk("AM-GM without the a,b>=0 scope is refuted (negative legs)", v.status == "FALSE")
    v = pe.verify("sqrt(abs(a)*abs(b)) <= (abs(a) + abs(b))/2")
    chk("AM-GM scoped to magnitudes holds on samples", v.status == "EMPIRICALLY_TRUE")
    v = pe.verify("(p -> q) & p -> q")
    chk("modus ponens is a tautology", v.status == "TRUE" and v.detail["kind"] == "TAUTOLOGY")
    v = pe.verify("~(p & q) <-> (~p | ~q)")
    chk("De Morgan (propositional) tautology", v.status == "TRUE")
    v = pe.verify("p -> q")
    chk("contingent formula not a theorem", v.status == "FALSE" and v.detail["kind"] == "CONTINGENT")
    v = pe.verify("p & ~p")
    chk("contradiction detected", v.status == "FALSE" and v.detail["kind"] == "CONTRADICTION")
    v = pe.verify("(A u B)' = A' n B'")
    chk("De Morgan for sets via Boolean-algebra translation", v.status == "TRUE", v.detail.get("translated", ""))
    v = pe.verify("A n (B u C) = (A n B) u (A n C)")
    chk("set distributivity PROVEN", v.status == "TRUE")
    v = pe.verify("A \\ B = A n B'")
    chk("set difference definition", v.status == "TRUE")
    v = pe.verify("A u B = A n B")
    chk("false set identity refuted", v.status == "FALSE")
    g = check_group_z_mod_n(7)
    chk("Z_7 is a group (exhaustive)", g["status"] == "TRUE")
    chk("negation builder", pe.negation_of("a = b") == "a != b" and pe.negation_of("p -> q") == "~(p -> q)")
    v = pe.verify("hello world")
    chk("non-relation is UNDECIDED, not accepted", v.status == "UNDECIDED")
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
