"""
soke.memguard — the hard memory ceiling.

Operator requirement: the program NEVER loads an entire GGUF, and training +
conversion stay under 1 GB of resident memory. This module measures the
process RSS (Windows: psapi via ctypes; Linux: /proc/self/status) and exposes
budgets that every streaming loop consults before allocating.

Defaults: soft 768 MB (evict / shrink), hard 900 MB (abort the step, checkpoint,
log a SYS:memguard_trip event).
"""
from __future__ import annotations

import ctypes
import os
import sys
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

MB = 1024 * 1024


_WIN_STATE: dict = {"route": None, "warned": False, "tl_time": 0.0, "tl_val": 0, "tl_peak": 0}


def _win_pmc():
    """(WorkingSetSize, PeakWorkingSetSize) via psapi/kernel32 with explicit C signatures.

    The pseudo-handle from GetCurrentProcess is (HANDLE)-1; without argtypes ctypes would pass it as a
    32-bit int and the call fails silently (observed on the operator's 64-bit machine: RSS read as 0).
    """
    import ctypes.wintypes as wt

    class PMC(ctypes.Structure):
        _fields_ = [("cb", wt.DWORD), ("PageFaultCount", wt.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.GetCurrentProcess.restype = wt.HANDLE
    k32.GetCurrentProcess.argtypes = []
    h = k32.GetCurrentProcess()
    pmc = PMC()
    pmc.cb = ctypes.sizeof(PMC)
    routes = []
    try:                                                       # route 1: kernel32!K32GetProcessMemoryInfo (Win7+)
        fn = k32.K32GetProcessMemoryInfo
        routes.append(("k32", fn))
    except AttributeError:
        pass
    try:                                                       # route 2: psapi!GetProcessMemoryInfo
        psapi = ctypes.WinDLL("psapi", use_last_error=True)
        routes.append(("psapi", psapi.GetProcessMemoryInfo))
    except OSError:
        pass
    for name, fn in routes:
        fn.restype = wt.BOOL
        fn.argtypes = [wt.HANDLE, ctypes.POINTER(PMC), wt.DWORD]
        if fn(h, ctypes.byref(pmc), pmc.cb):
            _WIN_STATE["route"] = name
            return int(pmc.WorkingSetSize), int(pmc.PeakWorkingSetSize)
    return 0, 0


def _win_tasklist() -> int:
    """Route 3 (slow, throttled to once per second): parse `tasklist` for this PID's working set."""
    now = time.time()
    if now - _WIN_STATE["tl_time"] < 1.0:
        return _WIN_STATE["tl_val"]
    _WIN_STATE["tl_time"] = now
    try:
        import subprocess
        out = subprocess.run(["tasklist", "/FI", f"PID eq {os.getpid()}", "/FO", "CSV", "/NH"],
                             capture_output=True, text=True, timeout=5,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
        for line in out.splitlines():
            if line.startswith('"'):
                cols = [c.strip('"') for c in line.split('","')]
                mem = cols[-1].replace("K", "").replace(",", "").replace(".", "").replace("\xa0", "").strip()
                val = int(mem) * 1024
                _WIN_STATE["tl_val"] = val
                _WIN_STATE["tl_peak"] = max(_WIN_STATE["tl_peak"], val)
                _WIN_STATE["route"] = "tasklist"
                return val
    except Exception:
        pass
    return _WIN_STATE["tl_val"]


def _win_rss() -> tuple[int, int]:
    try:
        cur, peak = _win_pmc()
        if cur > 0:
            return cur, peak
    except Exception:
        pass
    v = _win_tasklist()
    return v, max(v, _WIN_STATE["tl_peak"])


def rss_bytes() -> int:
    """Resident set size of this process in bytes (0 if unmeasurable)."""
    try:
        if os.name == "nt":
            return _win_rss()[0]
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) * 1024
    except Exception:
        pass
    return 0


def peak_rss_bytes() -> int:
    try:
        if os.name == "nt":
            return _win_rss()[1]
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmHWM:"):
                    return int(line.split()[1]) * 1024
    except Exception:
        pass
    return 0


def rss_route() -> str:
    """Which probe answered (for the self-test artifact and the GUI gauge tooltip)."""
    if os.name == "nt":
        rss_bytes()
        return _WIN_STATE["route"] or "none"
    return "procfs"


class MemoryBudgetExceeded(RuntimeError):
    pass


@dataclass
class MemGuard:
    soft_mb: int = 768
    hard_mb: int = 900
    chunk_mb: int = 16                     # default streaming chunk for tensor conversion
    on_trip: Optional[Callable[[int], None]] = None
    trips: int = 0
    peak_seen: int = 0
    samples: list = field(default_factory=list)

    @property
    def soft(self) -> int:
        return self.soft_mb * MB

    @property
    def hard(self) -> int:
        return self.hard_mb * MB

    def sample(self) -> int:
        r = rss_bytes()
        if r > self.peak_seen:
            self.peak_seen = r
        if len(self.samples) < 4096:
            self.samples.append((time.time(), r))
        return r

    def check(self, where: str = "") -> int:
        """Sample RSS; raise MemoryBudgetExceeded above the hard cap."""
        r = self.sample()
        if r > self.hard:
            self.trips += 1
            if self.on_trip:
                try:
                    self.on_trip(r)
                except Exception:
                    pass
            raise MemoryBudgetExceeded(f"RSS {r / MB:.0f} MB > hard cap {self.hard_mb} MB at {where}")
        return r

    def over_soft(self) -> bool:
        return self.sample() > self.soft

    def chunk_bytes(self) -> int:
        """Streaming chunk size; halves while over the soft cap (minimum 1 MB)."""
        c = self.chunk_mb * MB
        r = self.sample()
        while r + 3 * c > self.soft and c > MB:
            c //= 2
        return c

    def headroom(self) -> int:
        return max(0, self.hard - self.sample())

    def status(self) -> dict:
        r = self.sample()
        return {"rss_mb": round(r / MB, 1), "peak_mb": round(max(self.peak_seen, peak_rss_bytes()) / MB, 1),
                "soft_mb": self.soft_mb, "hard_mb": self.hard_mb, "trips": self.trips}


class RSSMonitor(threading.Thread):
    """Background sampler: records peak RSS while a long job runs."""

    def __init__(self, guard: MemGuard, interval: float = 0.2):
        super().__init__(daemon=True)
        self.guard = guard
        self.interval = interval
        self._stop_evt = threading.Event()
        self.peak = 0

    def run(self) -> None:
        while not self._stop_evt.is_set():
            r = self.guard.sample()
            if r > self.peak:
                self.peak = r
            self._stop_evt.wait(self.interval)

    def stop(self) -> int:
        self._stop_evt.set()
        self.join(timeout=2)
        return self.peak


def estimate_model_bytes(n_params: int, adam: bool = True, f32: bool = True) -> int:
    """Parameters (+ Adam m,v) in bytes — used to refuse configs that cannot fit the budget."""
    per = 4 if f32 else 2
    mult = 3 if adam else 1
    return n_params * per * mult
