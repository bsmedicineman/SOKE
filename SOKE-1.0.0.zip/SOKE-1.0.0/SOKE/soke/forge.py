"""
soke.forge — build GGUF models from a template while harvesting weights from other GGUF models.

    inventory   -> the donor pool: every GGUF (Ollama blobs or a folder), its architecture and shape
    family      -> donors that share one signature (arch, n_embd, n_layer, n_ff, heads, vocab) can fill
                   the same slots byte-for-byte; anything else needs a (lossy, experimental) resize
    ForgeSpec   -> the template: per layer, which donor supplies attention / norms, which donor (or
                   blend) supplies each TOPIC expert, the always-on shared expert, the gate init
    SpecStore   -> serves the template as a live model to the inference engine WITHOUT writing a file,
                   so the trial-and-error loop can score thousands of variants
    assemble()  -> writes the runnable .gguf (llama.cpp / Ollama) — copies untouched donor tensors
                   byte-for-byte (exact), requantizes blended/novel tensors — plus the SFF sidecar

Output architectures (all VERIFIED against llama.cpp on synthetic models, tests/crosscheck_llama_cpp.py):
    qwen2moe  routed topic experts + ALWAYS-ON shared expert (the "math primary" layout)   [qwen2 donors]
    llama+moe Mixtral-style routed experts, no shared expert                                 [llama donors]
    dense     one trunk, every slot chosen per layer                                          [any family]
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Callable, Iterator, Optional

import numpy as np

from .gguf_rewrites import DEQUANT, GGML_TYPES, GGUFReader, quant_q8_0, write_gguf
from .llm_engine import LLM, LLMConfig, WeightStore, MB
from .memguard import MemGuard
from .rng import Rng
from .tokenizer import Tokenizer
from .util import sha256_8

# ==========================================================================
# donors
# ==========================================================================
@dataclass
class Donor:
    id: str
    label: str
    path: str
    arch: str
    sig: str
    hp: dict
    n_layer: int
    size: int
    types: dict                       # tensor role -> ggml type id (e.g. "attn_q": 12)
    tied: bool
    sha8: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def _hp(kv: dict, arch: str) -> dict:
    g = lambda k, d=None: kv.get(f"{arch}.{k}", d)
    return {"n_embd": int(g("embedding_length", 0)), "n_layer": int(g("block_count", 0)), "n_ff": int(g("feed_forward_length", 0)),
            "n_head": int(g("attention.head_count", 0)), "n_head_kv": int(g("attention.head_count_kv", g("attention.head_count", 0))),
            "n_vocab": int(g("vocab_size", len(kv.get("tokenizer.ggml.tokens", [])))), "rope_theta": float(g("rope.freq_base", 10000.0)),
            "rms_eps": float(g("attention.layer_norm_rms_epsilon", 1e-6)), "n_ctx": int(g("context_length", 2048)),
            "n_expert": int(g("expert_count", 0)), "n_expert_used": int(g("expert_used_count", 0)),
            "n_rot": int(g("rope.dimension_count", 0))}


def signature(arch: str, hp: dict) -> str:
    base = "qwen2" if arch in ("qwen2", "qwen2moe") else ("llama" if arch in ("llama", "mistral") else arch)
    return f"{base}:{hp['n_embd']}x{hp['n_layer']}:ff{hp['n_ff']}:h{hp['n_head']}/{hp['n_head_kv']}:v{hp['n_vocab']}"


def describe_gguf(path, label: Optional[str] = None, donor_id: Optional[str] = None) -> Donor:
    """Header-only read: architecture, shape, tensor types. Never touches the weights."""
    gr = GGUFReader(path)
    try:
        arch = str(gr.kv.get("general.architecture", "?"))
        hp = _hp(gr.kv, arch)
        types = {}
        for name, t in gr.tensors.items():
            if name.startswith("blk.0.") or not name.startswith("blk."):
                role = name.replace("blk.0.", "").replace(".weight", "").replace(".bias", "_bias")
                types[role] = t.ggml_type
        tied = "output.weight" not in gr.tensors
        size = gr.size
    finally:
        gr.close()
    with open(path, "rb") as f:
        head = f.read(1 << 20)
    sha8 = hashlib.sha256(head + str(size).encode()).hexdigest()[:8]
    return Donor(donor_id or sha8, label or Path(path).name, str(path), arch, signature(arch, hp), hp, hp["n_layer"], size, types, tied, sha8)


def inventory_ollama(models_dir=None) -> list[Donor]:
    """Every model Ollama has pulled: manifests -> GGUF blob -> header."""
    root = Path(models_dir or os.environ.get("OLLAMA_MODELS") or (Path(os.path.expanduser("~")) / ".ollama" / "models"))
    out: list[Donor] = []
    man = root / "manifests"
    if not man.exists():
        return out
    seen: set = set()
    for mf in sorted(man.rglob("*")):
        if not mf.is_file():
            continue
        try:
            m = json.loads(mf.read_text(encoding="utf-8"))
        except Exception:
            continue
        for layer in m.get("layers", []):
            if "model" not in str(layer.get("mediaType", "")):
                continue
            digest = str(layer.get("digest", "")).replace(":", "-")
            blob = root / "blobs" / digest
            if not blob.exists() or digest in seen:
                continue
            seen.add(digest)
            rel = mf.relative_to(man).parts
            label = "/".join(rel[-2:]) if len(rel) >= 2 else mf.name
            try:
                d = describe_gguf(blob, label=label, donor_id=f"D{len(out)}")
                out.append(d)
            except Exception as e:
                out.append(Donor(f"D{len(out)}", label, str(blob), "unreadable", "?", {}, 0, blob.stat().st_size, {}, True, _err_note(e)))
    return out


def _err_note(e: BaseException) -> str:
    """'err:<Type>: <message> @ <file>:<line>' for an unreadable file — the artifact, not just the type name."""
    import traceback
    tb = traceback.extract_tb(e.__traceback__)
    where = f" @ {Path(tb[-1].filename).name}:{tb[-1].lineno}" if tb else ""
    return f"err:{type(e).__name__}: {str(e)[:160]}{where}"


def _is_gguf_file(p: Path) -> bool:
    try:
        with open(p, "rb") as f:
            return f.read(4) == b"GGUF"
    except OSError:
        return False


def ollama_labels(models_dir) -> dict:
    """digest file name (sha256-<hex>) -> 'family/tag' from the manifests of an Ollama store; {} if none."""
    man = Path(models_dir) / "manifests"
    out: dict = {}
    if not man.exists():
        return out
    for mf in sorted(man.rglob("*")):
        if not mf.is_file():
            continue
        try:
            m = json.loads(mf.read_text(encoding="utf-8"))
        except Exception:
            continue
        for layer in m.get("layers", []):
            if "model" in str(layer.get("mediaType", "")):
                rel = mf.relative_to(man).parts
                out.setdefault(str(layer.get("digest", "")).replace(":", "-"), "/".join(rel[-2:]) if len(rel) >= 2 else mf.name)
    return out


def inventory_folder(folder) -> list[Donor]:
    """Every GGUF in a folder: *.gguf files (recursively) plus extension-less files that start with the GGUF magic —
    Ollama's blob store keeps models as blobs/sha256-<hex>. Blobs are labelled from the store's manifests when the
    folder is (inside) an Ollama store; other files by their name."""
    folder = Path(folder)
    labels = ollama_labels(folder.parent) if folder.name == "blobs" else ollama_labels(folder)
    paths: list[Path] = sorted(folder.rglob("*.gguf"))
    seen = {p.resolve() for p in paths}
    for p in sorted(folder.iterdir()) if folder.is_dir() else []:
        if p.is_file() and p.suffix == "" and p.resolve() not in seen and _is_gguf_file(p):
            paths.append(p); seen.add(p.resolve())
    if folder.name != "blobs" and (folder / "blobs").is_dir():                # an Ollama store root: include its blobs
        for p in sorted((folder / "blobs").iterdir()):
            if p.is_file() and p.suffix == "" and p.resolve() not in seen and _is_gguf_file(p):
                paths.append(p); seen.add(p.resolve())
    out: list[Donor] = []
    for p in paths:
        label = labels.get(p.name, p.stem if p.suffix else p.name[:19])
        try:
            out.append(describe_gguf(p, label=label, donor_id=f"D{len(out)}"))
        except Exception as e:
            out.append(Donor(f"D{len(out)}", label, str(p), "unreadable", "?", {}, 0, p.stat().st_size, {}, True, _err_note(e)))
    return out


DONOR_ARCHS = ("qwen2", "llama", "mistral")          # dense families the forge can harvest from


def donor_status(d: Donor) -> str:
    """'ok' | 'moe' (a mixture-of-experts file: chat/score works, harvesting its experts is not built) | 'arch' (unsupported)."""
    if d.arch in DONOR_ARCHS and int(d.hp.get("n_expert", 0) or 0) == 0:
        return "ok"
    if d.arch in ("qwen2moe",) or (d.arch in DONOR_ARCHS and int(d.hp.get("n_expert", 0) or 0) > 0):
        return "moe"
    return "arch"


def family_groups(donors: list[Donor]) -> dict[str, list[Donor]]:
    g: dict[str, list[Donor]] = {}
    for d in donors:
        if donor_status(d) == "ok":
            g.setdefault(d.sig, []).append(d)
    return g


# ==========================================================================
# the template
# ==========================================================================
OP_KINDS = ("copy", "blend", "task", "slerp", "zeros")


def op_copy(donor: str) -> dict:
    return {"kind": "copy", "donor": donor}


def op_blend(weights: dict) -> dict:
    return {"kind": "blend", "weights": dict(weights)}


def op_task(base: str, deltas: dict) -> dict:
    """task arithmetic: base + sum_i lambda_i * (donor_i - base)"""
    return {"kind": "task", "base": base, "deltas": dict(deltas)}


def op_slerp(a: str, b: str, t: float) -> dict:
    return {"kind": "slerp", "a": a, "b": b, "t": float(t)}


class ForgeSpec:
    """The template. A plain dict underneath (JSON round trip), with helpers and presets."""

    def __init__(self, d: dict):
        self.d = d

    # ---------------------------------------------------------------- access
    @property
    def arch_out(self) -> str:
        return self.d["arch_out"]

    @property
    def topics(self) -> list[str]:
        return list(self.d.get("topics", []))

    @property
    def layers(self) -> list[dict]:
        return self.d["layers"]

    @property
    def donors(self) -> dict:
        return self.d["donors"]

    @property
    def n_expert(self) -> int:
        return len(self.layers[0].get("experts", [])) if self.layers else 0

    def copy(self) -> "ForgeSpec":
        return ForgeSpec(json.loads(json.dumps(self.d)))

    def to_json(self) -> str:
        return json.dumps(self.d, indent=1)

    @staticmethod
    def from_json(s: str) -> "ForgeSpec":
        return ForgeSpec(json.loads(s))

    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps(self.d, sort_keys=True).encode()).hexdigest()[:12]

    def summary(self) -> str:
        L = self.layers
        ne = self.n_expert
        sh = sum(1 for l in L if l.get("shared"))
        return (f"{self.d.get('name', 'forge')}: {self.arch_out}, {len(L)} layers, {ne} routed experts"
                f"{' + shared (' + str(self.d.get('shared_topic')) + ')' if sh else ''}, topics {self.topics}, donors {list(self.donors)}")

    # ---------------------------------------------------------------- presets
    @staticmethod
    def preset(kind: str, donors: list[Donor], topics: list[str], base: Optional[str] = None, shared_topic: str = "math",
               n_used: int = 2, topic_donor: Optional[dict] = None, gate_init: str = "lexicon", seed: int = 0) -> "ForgeSpec":
        """
        kind: "math-always-on" (qwen2moe: shared expert + routed topics) | "all-routed" (routed only) |
              "dense" | "interleave" (dense, donors alternate by layer) | "stack" (dense, every layer twice — depth growth) |
              "random" (every slot a random donor; blends sprinkled in — the trial loop's starting soup)
        topic_donor: optional {topic: donor_id} — which donor seeds which topic expert (else round-robin)
        """
        if not donors:
            raise ValueError("no donors")
        sigs = {d.sig for d in donors}
        if len(sigs) != 1:
            raise ValueError(f"donors must share one family signature; got {sigs}")
        base = base or donors[0].id
        ids = [d.id for d in donors]
        family = donors[0]
        n_layer = family.n_layer
        rng = Rng(seed)
        dmap = {d.id: {"path": d.path, "label": d.label, "sig": d.sig, "sha8": d.sha8} for d in donors}
        is_qwen = family.arch in ("qwen2", "qwen2moe")
        d: dict = {"name": f"forge-{kind}", "kind": kind, "family": family.sig, "base_arch": family.arch, "donors": dmap, "base": base,
                   "topics": list(topics), "n_used": n_used, "shared_topic": None, "gate_init": gate_init, "gate_scale": 1.0,
                   "shexp_gain": 2.0, "quant_novel": "q8_0", "hp": family.hp, "layers": []}

        def seed_for(topic: str, i: int) -> str:
            if topic_donor and topic in topic_donor:
                return topic_donor[topic]
            return ids[i % len(ids)]

        if kind in ("math-always-on", "all-routed"):
            d["arch_out"] = "qwen2moe" if is_qwen else "llama"
            routed = [t for t in topics if not (kind == "math-always-on" and t == shared_topic)]
            if kind == "math-always-on":
                if not is_qwen:
                    raise ValueError("an always-on shared expert needs qwen2-family donors (llama.cpp's qwen2moe layout)")
                d["shared_topic"] = shared_topic
            if not routed:
                raise ValueError("need at least one routed topic")
            d["n_used"] = max(1, min(n_used, len(routed)))
            for l in range(n_layer):
                layer = {"src_layer": l, "attn": op_copy(base), "attn_norm": op_copy(base), "ffn_norm": op_copy(base),
                         "experts": [{"topic": t, "op": op_copy(seed_for(t, i))} for i, t in enumerate(routed)],
                         "gate": {"init": gate_init, "scale": 1.0}}
                if kind == "math-always-on":
                    layer["shared"] = {"topic": shared_topic, "op": op_copy(seed_for(shared_topic, 0)), "gain": 2.0}
                elif is_qwen:
                    # llama.cpp's qwen2moe layout always has a shared expert: make it silent and tiny (32 wide, zero weights)
                    layer["shared"] = {"topic": None, "op": {"kind": "zeros"}, "gain": 0.0, "ff": 32}
                d["layers"].append(layer)
        elif kind in ("dense", "interleave", "stack", "random"):
            d["arch_out"] = "qwen2" if is_qwen else "llama"
            order = list(range(n_layer)) if kind != "stack" else [i for i in range(n_layer) for _ in (0, 1)]
            for j, l in enumerate(order):
                if kind == "interleave":
                    who = ids[j % len(ids)]
                elif kind == "random":
                    who = ids[int(rng.integers(0, len(ids)))]
                else:
                    who = base
                ffn = op_copy(who)
                if kind == "random" and len(ids) > 1 and rng.random() < 0.3:
                    w = rng.random(len(ids)); w = w / w.sum()
                    ffn = op_blend({i: float(x) for i, x in zip(ids, w)})
                d["layers"].append({"src_layer": l, "attn": op_copy(who if kind != "random" else ids[int(rng.integers(0, len(ids)))]),
                                    "attn_norm": op_copy(who), "ffn_norm": op_copy(who), "ffn": ffn})
        else:
            raise ValueError(f"unknown preset {kind}")
        d["embed"] = op_copy(base)
        d["output"] = op_copy(base)
        d["output_norm"] = op_copy(base)
        return ForgeSpec(d)


# ==========================================================================
# serving the template as a model (no file written)
# ==========================================================================
class SpecStore(WeightStore):
    """WeightStore interface over a ForgeSpec: target tensor rows are resolved to donor rows / blends on demand."""

    def __init__(self, spec: ForgeSpec, memguard: Optional[MemGuard] = None, chunk_bytes: int = 48 * MB, resident: str = "stream"):
        self.spec = spec
        self.mg = memguard or MemGuard()
        self.chunk_bytes = chunk_bytes
        self._res = {}
        self.mode = "stream" if resident == "auto" else resident
        self.readers: dict[str, GGUFReader] = {}
        for did, info in spec.donors.items():
            self.readers[did] = GGUFReader(info["path"])
        self.base = spec.d["base"]
        self.base_kv = self.readers[self.base].kv
        self.hp = spec.d["hp"]
        self.computed: dict[str, np.ndarray] = {}
        self._layout()
        self.dequant_values = 0
        self.matmul_flops = 0.0
        self.path = None

    # ---------------------------------------------------------------- layout
    def _layout(self) -> None:
        sp, hp = self.spec, self.hp
        E, F = hp["n_embd"], hp["n_ff"]
        self.arch = sp.arch_out
        moe = self.arch in ("qwen2moe",) or (self.arch == "llama" and sp.n_expert > 0)
        self.moe = moe
        self.tensors: dict[str, tuple] = {}          # name -> (shape, ggml_type_hint)
        tmap: dict[str, dict] = {}                    # name -> slot description
        base_t = self.readers[self.base].tensors

        def add(name, shape, slot):
            self.tensors[name] = (tuple(shape), None)
            tmap[name] = slot

        add("token_embd.weight", base_t["token_embd.weight"].shape, {"op": sp.d["embed"], "src": "token_embd.weight"})
        add("output_norm.weight", (E,), {"op": sp.d["output_norm"], "src": "output_norm.weight"})
        out_src = "output.weight" if "output.weight" in base_t else "token_embd.weight"
        if moe or "output.weight" in base_t:
            add("output.weight", base_t[out_src].shape, {"op": sp.d["output"], "src": out_src})
        qkv_bias = "blk.0.attn_q.bias" in base_t
        self.qkv_bias = qkv_bias
        for i, layer in enumerate(sp.layers):
            s = layer["src_layer"]
            p, q = f"blk.{i}.", f"blk.{s}."
            for role in ("attn_q", "attn_k", "attn_v", "attn_output"):
                add(p + role + ".weight", base_t[q + role + ".weight"].shape, {"op": layer["attn"], "src": q + role + ".weight"})
                if qkv_bias and role != "attn_output":
                    add(p + role + ".bias", base_t[q + role + ".bias"].shape, {"op": layer["attn"], "src": q + role + ".bias"})
            add(p + "attn_norm.weight", (E,), {"op": layer["attn_norm"], "src": q + "attn_norm.weight"})
            add(p + "ffn_norm.weight", (E,), {"op": layer["ffn_norm"], "src": q + "ffn_norm.weight"})
            if not moe:
                for role in ("ffn_gate", "ffn_up", "ffn_down"):
                    add(p + role + ".weight", base_t[q + role + ".weight"].shape, {"op": layer["ffn"], "src": q + role + ".weight"})
            else:
                ne = len(layer["experts"])
                add(p + "ffn_gate_inp.weight", (ne, E), {"computed": "gate", "layer": i})
                add(p + "ffn_gate_exps.weight", (ne, F, E), {"experts": layer["experts"], "src_role": "ffn_gate", "src_layer": s})
                add(p + "ffn_up_exps.weight", (ne, F, E), {"experts": layer["experts"], "src_role": "ffn_up", "src_layer": s})
                add(p + "ffn_down_exps.weight", (ne, E, F), {"experts": layer["experts"], "src_role": "ffn_down", "src_layer": s})
                if layer.get("shared"):
                    sh = layer["shared"]
                    Fs = int(sh.get("ff", F))
                    add(p + "ffn_gate_inp_shexp.weight", (E,), {"computed": "shexp_gate", "layer": i})
                    add(p + "ffn_gate_shexp.weight", (Fs, E), {"op": sh["op"], "src": q + "ffn_gate.weight"})
                    add(p + "ffn_up_shexp.weight", (Fs, E), {"op": sh["op"], "src": q + "ffn_up.weight"})
                    add(p + "ffn_down_shexp.weight", (E, Fs), {"op": sh["op"], "src": q + "ffn_down.weight", "gain": float(sh.get("gain", 2.0))})
        self.tmap = tmap
        # kv of the target
        kv = {}
        kvt = {}
        a_in = self.spec.d["base_arch"]
        a_out = self.arch
        base_types = getattr(self.readers[self.base], "kv_types", {})
        for k, v in self.base_kv.items():
            if k.startswith(a_in + "."):
                nk = a_out + "." + k[len(a_in) + 1:]
                kv[nk] = v
                if k in base_types:
                    kvt[nk] = base_types[k]
            elif k.startswith("tokenizer.") or k in ("general.file_type", "general.quantization_version"):
                kv[k] = v
                if k in base_types:
                    kvt[k] = base_types[k]
        self._kv_types = kvt
        kv["general.architecture"] = a_out
        kv["general.name"] = sp.d.get("name", "soke-forge")
        kv[f"{a_out}.block_count"] = len(sp.layers)
        if moe:
            ne = sp.n_expert
            kv[f"{a_out}.expert_count"] = ne
            kv[f"{a_out}.expert_used_count"] = int(sp.d.get("n_used", 2))
            kv[f"{a_out}.expert_feed_forward_length"] = F
            kv[f"{a_out}.feed_forward_length"] = F        # llama-arch MoE sizes experts from this key
            if any(l.get("shared") for l in sp.layers):
                kv[f"{a_out}.expert_shared_feed_forward_length"] = int(sp.layers[0]["shared"].get("ff", F))
        kv["soke.forge.spec"] = sp.to_json()
        kv["soke.forge.version"] = "1.2.0"
        self._kv = kv

    @property
    def kv(self) -> dict:
        return self._kv

    def names(self) -> set:
        return set(self.tensors)

    def has(self, name: str) -> bool:
        return name in self.tensors

    def shape(self, name: str) -> tuple:
        return self.tensors[name][0]

    def close(self) -> None:
        for r in self.readers.values():
            r.close()
        self._res.clear()

    # ---------------------------------------------------------------- rows
    def _donor_rows(self, did: str, tname: str, r0: int, r1: int) -> np.ndarray:
        gr = self.readers[did]
        t = gr.tensors[tname]
        cols = t.shape[-1]
        _, bs, ts = GGML_TYPES[t.ggml_type]
        bpr = cols // bs * ts
        gr.f.seek(t.abs_offset + r0 * bpr)
        raw = gr._read((r1 - r0) * bpr)
        out = np.asarray(DEQUANT[t.ggml_type](raw), dtype=np.float32).reshape(r1 - r0, cols)
        self.dequant_values += out.size
        return out

    def _op_rows(self, op: dict, tname: str, r0: int, r1: int) -> np.ndarray:
        k = op["kind"]
        if k == "copy":
            return self._donor_rows(op["donor"], tname, r0, r1)
        if k == "blend":
            acc = None
            for did, w in op["weights"].items():
                x = self._donor_rows(did, tname, r0, r1) * float(w)
                acc = x if acc is None else acc + x
            return acc
        if k == "task":
            b = self._donor_rows(op["base"], tname, r0, r1)
            acc = b.copy()
            for did, lam in op["deltas"].items():
                acc += float(lam) * (self._donor_rows(did, tname, r0, r1) - b)
            return acc
        if k == "slerp":
            a = self._donor_rows(op["a"], tname, r0, r1)
            b = self._donor_rows(op["b"], tname, r0, r1)
            t = float(op["t"])
            na, nb = math.sqrt(float(np.sum(a * a))), math.sqrt(float(np.sum(b * b)))
            if na < 1e-12 or nb < 1e-12:
                return (1 - t) * a + t * b
            cosw = float(np.sum(a * b)) / (na * nb)
            cosw = max(-1.0, min(1.0, cosw))
            w = math.acos(cosw)
            if w < 1e-6:
                return (1 - t) * a + t * b
            return (math.sin((1 - t) * w) * a / na + math.sin(t * w) * b / nb) / math.sin(w) * ((1 - t) * na + t * nb)
        if k == "zeros":
            return np.zeros((r1 - r0, self.readers[self.base].tensors[tname].shape[-1]), dtype=np.float32)
        raise ValueError(f"unknown op {k}")

    def rows(self, name: str, r0: int, r1: int) -> np.ndarray:
        slot = self.tmap[name]
        if "computed" in slot:
            return self._computed(name)[r0:r1]
        if "experts" in slot:
            shape = self.tensors[name][0]
            per = int(shape[1])                                  # rows per expert (F for gate/up, E for down)
            cols = int(shape[2])
            out = np.empty((r1 - r0, cols), dtype=np.float32)
            pos = r0
            while pos < r1:
                e = pos // per
                e_end = min(r1, (e + 1) * per)
                op = slot["experts"][e]["op"]
                src = f"blk.{slot['src_layer']}.{slot['src_role']}.weight"
                out[pos - r0:e_end - r0] = self._op_rows(op, src, pos - e * per, e_end - e * per)
                pos = e_end
            return out
        if slot["op"]["kind"] == "zeros":
            return np.zeros((r1 - r0, self.tensors[name][0][-1]), dtype=np.float32)
        x = self._op_rows(slot["op"], slot["src"], r0, r1)
        if "gain" in slot:
            x = x * slot["gain"]
        return x

    def full(self, name: str) -> np.ndarray:
        hit = self._res.get(name)
        if hit is not None and hit[0] == "f32":
            return hit[1]
        slot = self.tmap[name]
        shape = self.tensors[name][0]
        if "computed" in slot:
            arr = self._computed(name)
        elif slot["op"]["kind"] == "zeros":
            arr = np.zeros(shape, dtype=np.float32)
        elif len(shape) == 1:
            did = slot["op"].get("donor") or slot["op"].get("base") or next(iter(slot["op"].get("weights", {self.base: 1})), self.base)
            src = slot["src"]
            if slot["op"]["kind"] == "copy":
                gr = self.readers[did]
                t = gr.tensors[src]
                gr.f.seek(t.abs_offset)
                _, bs, ts = GGML_TYPES[t.ggml_type]
                arr = np.asarray(DEQUANT[t.ggml_type](gr._read(t.n_elem // bs * ts)), dtype=np.float32).reshape(shape)
            else:
                arr = self._op_rows(slot["op"], src, 0, 1).reshape(shape) if False else self._vec_op(slot["op"], src, shape)
            if "gain" in slot:
                arr = arr * slot["gain"]
        else:
            arr = self.rows(name, 0, int(np.prod(shape[:-1]))).reshape(shape)
        self._res[name] = ("f32", arr)
        return arr

    def _vec_op(self, op: dict, src: str, shape) -> np.ndarray:
        def vec(did):
            gr = self.readers[did]; t = gr.tensors[src]; gr.f.seek(t.abs_offset)
            _, bs, ts = GGML_TYPES[t.ggml_type]
            return np.asarray(DEQUANT[t.ggml_type](gr._read(t.n_elem // bs * ts)), dtype=np.float32).reshape(shape)
        k = op["kind"]
        if k == "copy":
            return vec(op["donor"])
        if k == "blend":
            return sum(vec(d) * float(w) for d, w in op["weights"].items())
        if k == "task":
            b = vec(op["base"]); return b + sum(float(l) * (vec(d) - b) for d, l in op["deltas"].items())
        if k == "slerp":
            t = float(op["t"]); return (1 - t) * vec(op["a"]) + t * vec(op["b"])
        return np.zeros(shape, dtype=np.float32)

    # ---------------------------------------------------------------- computed tensors (gates)
    def _computed(self, name: str) -> np.ndarray:
        if name in self.computed:
            return self.computed[name]
        slot = self.tmap[name]
        li = slot["layer"]
        layer = self.spec.layers[li]
        E = self.hp["n_embd"]
        if slot["computed"] == "shexp_gate":
            # sigmoid(x . w) with |w| ~ 1e-3 stays at 0.5 (+-0.01); the shared expert's gain (2.0) restores unity.
            # NOT exactly zero: an all-zero gate vector makes llama.cpp's CPU path emit NaN (measured), our engine does not.
            arr = (Rng(f"shexp:{li}").normal(0, 1e-3, (1, E))).astype(np.float32)
            self.computed[name] = arr
            return arr
        # routed gate rows: one per expert
        ne = len(layer["experts"])
        init = layer.get("gate", {}).get("init", self.spec.d.get("gate_init", "lexicon"))
        scale = float(layer.get("gate", {}).get("scale", 1.0)) * float(self.spec.d.get("gate_scale", 1.0))
        rng = Rng(f"{self.spec.fingerprint()}:{li}")
        if init == "zeros":
            arr = np.zeros((ne, E), dtype=np.float32)
        elif init == "random":
            arr = rng.normal(0, 0.02, (ne, E)).astype(np.float32)
        else:
            arr = self._lexicon_gate([e["topic"] for e in layer["experts"]]) * scale
        # optional learned deltas (the trial loop's novel weights) stored in the spec
        delta = layer.get("gate", {}).get("delta")
        if delta:
            arr = arr + np.asarray(delta, dtype=np.float32).reshape(ne, E)
        self.computed[name] = arr.astype(np.float32)
        return self.computed[name]

    def _lexicon_gate(self, topics: list[str]) -> np.ndarray:
        """Gate row for a topic = unit-norm centroid of the base donor's token embeddings of the topic's lexicon."""
        key = "__lexgate__" + "|".join(topics)
        if key in self.computed:
            return self.computed[key]
        from .tower import DOMAINS
        tok = Tokenizer(self.base_kv)
        emb_name = "token_embd.weight"
        E = self.hp["n_embd"]
        rows = []
        for t in topics:
            words = next((d.lexicon for d in DOMAINS if d.name == t), [t])
            ids = []
            for w in words:
                ids.extend(tok.encode(" " + w, add_special=False, parse_special=False)[:2])
            ids = sorted(set(ids))
            if not ids:
                rows.append(np.zeros(E, dtype=np.float32)); continue
            v = np.mean(self._donor_rows(self.base, emb_name, 0, 0).reshape(0, E) if False else np.stack([self._donor_rows(self.base, emb_name, i, i + 1)[0] for i in ids]), axis=0)
            n = float(np.sqrt(np.sum(v * v)))
            rows.append(v / n if n > 0 else v)
        arr = np.stack(rows).astype(np.float32)
        # centre the rows so the gate discriminates between topics rather than measuring "wordness"
        arr = arr - np.mean(arr, axis=0, keepdims=True)
        nr = np.sqrt(np.sum(arr * arr, axis=1, keepdims=True)); nr[nr == 0] = 1
        arr = arr / nr
        self.computed[key] = arr
        return arr

    def embed(self, name: str, ids: np.ndarray) -> np.ndarray:
        res = self._res.get(name)
        if res is not None and res[0] == "f32":
            return res[1][ids]
        out = np.empty((len(ids), self.hp["n_embd"]), dtype=np.float32)
        cache = self.__dict__.setdefault("_emb_cache", {})
        for i, tid in enumerate(ids):
            tid = int(tid)
            row = cache.get(tid)
            if row is None:
                row = self.rows(name, tid, tid + 1)[0]
                if len(cache) < 4096:
                    cache[tid] = row
            out[i] = row
        return out

    def make_resident(self, name: str) -> None:
        if name in self._res:
            return
        shape = self.tensors[name][0]
        rows = int(np.prod(shape[:-1]))
        self._res[name] = ("f32", self.rows(name, 0, rows).reshape(shape))
        self.mg.check(f"resident {name}")

    def matmul_T(self, x: np.ndarray, name: str) -> np.ndarray:
        shape = self.tensors[name][0]
        out_dim, in_dim = int(np.prod(shape[:-1])), shape[-1]
        assert x.shape[-1] == in_dim, f"{name}: x has {x.shape[-1]} features, W has {in_dim}"
        self.matmul_flops += 2.0 * x.shape[0] * in_dim * out_dim
        res = self._res.get(name)
        if res is None and self.mode == "f32":
            self.make_resident(name); res = self._res.get(name)
        if res is not None and res[0] == "f32":
            return x @ res[1].reshape(out_dim, in_dim).T
        y = np.empty((x.shape[0], out_dim), dtype=np.float32)
        step = max(1, self.chunk_bytes // (in_dim * 4))
        for r0 in range(0, out_dim, step):
            r1 = min(out_dim, r0 + step)
            y[:, r0:r1] = x @ self.rows(name, r0, r1).T
        return y

    # ---------------------------------------------------------------- export helpers
    def slot_exact_type(self, name: str) -> Optional[int]:
        """The GGML type this tensor can be copied in byte-for-byte (all sources same type, pure copy ops), else None."""
        slot = self.tmap[name]
        if "computed" in slot or "gain" in slot:
            return None
        if "experts" in slot:
            types = set()
            for e in slot["experts"]:
                if e["op"]["kind"] != "copy":
                    return None
                types.add(self.readers[e["op"]["donor"]].tensors[f"blk.{slot['src_layer']}.{slot['src_role']}.weight"].ggml_type)
            return types.pop() if len(types) == 1 else None
        if slot["op"]["kind"] != "copy":
            return None
        return self.readers[slot["op"]["donor"]].tensors[slot["src"]].ggml_type


# ==========================================================================
# export: write the runnable GGUF (+ SFF sidecar)
# ==========================================================================
def _raw_iter(gr: GGUFReader, tname: str, chunk: int) -> Iterator[bytes]:
    for _, raw in gr.iter_raw(tname, chunk):
        yield raw


def assemble(spec: ForgeSpec, out_path, memguard: Optional[MemGuard] = None, progress: Optional[Callable] = None,
             sidecar: bool = True, ledger=None, novel_quant: Optional[str] = None, behavior=None, clone_consent: Optional[dict] = None,
             clone_teeth: Optional[list] = None) -> dict:
    """Write the model described by `spec` to `out_path` (.gguf). Copies are exact; novel tensors are requantized.
    A behavior profile (soke.behavior.BehaviorProfile) is written as GGUF metadata + streamed helix teeth in the
    .sff sidecar — never as weights (behavior map, L2 / LAW_E). Clone metadata is written only if clone_consent['store']."""
    mg = memguard or MemGuard()
    store = SpecStore(spec, mg)
    novel = (novel_quant or spec.d.get("quant_novel", "q8_0")).lower()
    t0 = time.time()
    stats = {"tensors": 0, "exact": 0, "novel": 0, "bytes": 0, "lineage": []}
    tensors = []
    names = list(store.tensors)

    def gen_exact(name, gtype):
        slot = store.tmap[name]
        if "experts" in slot:
            src = f"blk.{slot['src_layer']}.{slot['src_role']}.weight"
            for e in slot["experts"]:
                gr = store.readers[e["op"]["donor"]]
                yield from _raw_iter(gr, src, 8 * MB)
        else:
            gr = store.readers[slot["op"]["donor"]]
            yield from _raw_iter(gr, slot["src"], 8 * MB)

    def gen_novel(name, shape, qt):
        rows_total = int(np.prod(shape[:-1])) if len(shape) > 1 else 1
        cols = shape[-1]
        if len(shape) == 1:
            arr = store.full(name).reshape(1, -1)
            yield arr.astype(np.float32).tobytes()
            return
        step = max(1, (16 * MB) // (cols * 4))
        for r0 in range(0, rows_total, step):
            r1 = min(rows_total, r0 + step)
            blk = store.rows(name, r0, r1)
            if qt == "q8_0":
                yield quant_q8_0(blk)
            elif qt == "f16":
                yield blk.astype(np.float16).tobytes()
            else:
                yield blk.astype(np.float32).tobytes()
            mg.check(f"assemble {name}")

    for i, name in enumerate(names):
        shape = store.tensors[name][0]
        dims = tuple(reversed(shape))
        n_elem = int(np.prod(shape))
        et = store.slot_exact_type(name)
        if et is not None:
            _, bs, ts = GGML_TYPES[et]
            n_bytes = n_elem // bs * ts
            tensors.append((name, dims, et, gen_exact(name, et), n_bytes))
            stats["exact"] += 1
            src_desc = store.tmap[name]
            stats["lineage"].append({"tensor": name, "exact": True, "from": src_desc.get("src") or src_desc.get("src_role"),
                                     "donors": [e["op"]["donor"] for e in src_desc["experts"]] if "experts" in src_desc else [src_desc["op"]["donor"]]})
        else:
            qt = novel
            if len(shape) == 1 or shape[-1] % 32 != 0 or name.endswith("ffn_gate_inp.weight") or name.endswith("shexp.weight") and shape == (store.hp["n_embd"],):
                qt = "f32"
            gt = {"q8_0": 8, "f16": 1, "f32": 0}[qt]
            _, bs, ts = GGML_TYPES[gt]
            n_bytes = n_elem // bs * ts
            tensors.append((name, dims, gt, gen_novel(name, shape, qt), n_bytes))
            stats["novel"] += 1
            stats["lineage"].append({"tensor": name, "exact": False, "quant": qt, "slot": {k: v for k, v in store.tmap[name].items() if k != "experts"} | ({"experts": [e["op"] for e in store.tmap[name]["experts"]]} if "experts" in store.tmap[name] else {})})
        stats["tensors"] += 1
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    kv = dict(store.kv)
    kv_types = dict(store._kv_types) if store._kv_types else {}
    if behavior is not None:
        from .behavior import assert_no_conditioning_in_weights, gguf_metadata
        assert_no_conditioning_in_weights([t[0] for t in tensors])       # refusal: conditioning is never a tensor
        for k, v in gguf_metadata(behavior, consent=clone_consent).items():
            kv[k] = v                                                    # enc_val infers str->8 and list[float]->float32 array
        stats["behavior"] = behavior.to_dict()
        stats["behavior"]["pillars"] = kv.get("soke.behavior.pillars")

    def prog_wrap():
        for j, t in enumerate(tensors):
            if progress:
                progress({"i": j + 1, "n": len(tensors), "tensor": t[0], "rss_mb": mg.status()["rss_mb"], "elapsed": time.time() - t0})
            yield t

    written = write_gguf(out_path, kv, prog_wrap(), kv_types=kv_types or None)
    stats["bytes"] = written
    stats["elapsed_s"] = round(time.time() - t0, 1)
    stats["peak_rss_mb"] = mg.status()["peak_mb"]
    stats["path"] = str(out_path)
    if sidecar:
        stats["sidecar"] = write_sidecar(spec, out_path.with_suffix(".sff"), stats, ledger=ledger, behavior=behavior,
                                         clone_teeth=clone_teeth, clone_consent=clone_consent)
    store.close()
    return stats


def write_sidecar(spec: ForgeSpec, path, stats: dict, ledger=None, behavior=None, clone_teeth=None, clone_consent=None) -> str:
    """The SFF sidecar: the template, the lineage of every tensor, the donor hashes, the trial ledger — not the weights.
    Since 1.3.0 it also STREAMS the behavioral component as ACTG helix teeth (emotion / logic / behavior, and — only
    with consent — the clone's psychology teeth). Do not dump C into weights; stream the helix (behavior map, L1)."""
    from .sff import SFFWriter
    meta = {"model_id": spec.d.get("name", "forge"), "source": {"kind": "forge", "family": spec.d.get("family"), "gguf": stats.get("path")},
            "arch": {"family": "forge-sidecar", "arch_out": spec.arch_out, "spec": spec.d},
            "notes": "SOKE forge sidecar: template + lineage for the .gguf of the same name; weights live in the .gguf"}
    if behavior is not None:
        meta["behavior"] = behavior.to_dict()
    w = SFFWriter(Path(path), file_kind=3, meta=meta, model_id=spec.d.get("name", "forge"))
    model_node = w.add_lineage_node(6, f"forge:{spec.d.get('name', 'forge')}")
    for did, info in spec.donors.items():
        n = w.add_lineage_node(3, f"donor:{did}:{info.get('label')}:{info.get('sha8')}")
        w.add_lineage_edge(n, model_node, 17)
    for row in stats.get("lineage", []):
        w.add_exp(1, row)
    if behavior is not None:
        from .behavior import HELICES
        teeth_total = 0
        for hname, spec_h in HELICES.items():
            if hname == "logic" and not behavior.logic_enabled:
                continue
            for reg, text in spec_h["teeth"]():
                w.add_exp(2, {"helix": hname, "domain": spec_h["domain"], "register": reg, "text": text, "face_gear_window": spec_h["face_gear_window"]})
                teeth_total += 1
        # clone psychology/emotion teeth only with consent (a helix is not consent)
        if clone_teeth and clone_consent and clone_consent.get("store"):
            for reg, text in clone_teeth:
                w.add_exp(2, {"helix": "psychology", "domain": "level_15_psychology", "register": reg, "text": text})
                teeth_total += 1
        stats["helix_teeth"] = teeth_total
    if ledger is not None:
        w.set_ledger_bytes(ledger.export_bytes())
    w.commit()
    w.close()
    return str(path)


def write_modelfile(gguf_path, name: str) -> Path:
    """name.Modelfile beside the .gguf so `ollama create name -f name.Modelfile` registers the forged model."""
    gguf_path = Path(gguf_path).resolve()
    mf = gguf_path.with_name(f"{name}.Modelfile")
    frm = f'"{gguf_path}"' if " " in str(gguf_path) else str(gguf_path)
    mf.write_text(f"# SOKE forge - BS Medicineman / Knight Industries\nFROM {frm}\nPARAMETER temperature 0.7\n", encoding="utf-8")
    return mf


# ==========================================================================
# self-test: synthetic family -> presets -> live evaluation -> export -> reload equality
# ==========================================================================
def _synthetic_family(tmpdir: Path, n_donors: int = 3, arch: str = "qwen2", E: int = 32, L: int = 2, H: int = 4, HKV: int = 2, F: int = 64, V: int = 96) -> list[Donor]:
    from .gguf_rewrites import quant_q8_0 as q8
    tmpdir = Path(tmpdir)
    tmpdir.mkdir(parents=True, exist_ok=True)
    donors = []
    for k in range(n_donors):
        rng = Rng(100 + k)
        from .tower import DOMAINS
        lex = []
        for dname in ("math", "language", "science"):
            lex.extend("\u0120" + w for w in next(d.lexicon for d in DOMAINS if d.name == dname)[:12])
        tokens = (lex + [f"t{i}" for i in range(V)])[:V]
        kv = {"general.architecture": arch, "general.name": f"donor{k}", f"{arch}.block_count": L, f"{arch}.context_length": 64,
              f"{arch}.embedding_length": E, f"{arch}.feed_forward_length": F, f"{arch}.attention.head_count": H,
              f"{arch}.attention.head_count_kv": HKV, f"{arch}.rope.freq_base": 10000.0, f"{arch}.attention.layer_norm_rms_epsilon": 1e-5,
              f"{arch}.rope.dimension_count": E // H, f"{arch}.vocab_size": V, "tokenizer.ggml.model": "gpt2", "tokenizer.ggml.pre": "default",
              "tokenizer.ggml.tokens": tokens, "tokenizer.ggml.token_type": [1] * V, "tokenizer.ggml.merges": [],
              "tokenizer.ggml.bos_token_id": 0, "tokenizer.ggml.eos_token_id": 1}
        D = E // H
        W = {"token_embd.weight": rng.normal(0, 0.1, (V, E)), "output_norm.weight": 1 + rng.normal(0, 0.05, (E,))}
        for l in range(L):
            p = f"blk.{l}."
            W[p + "attn_norm.weight"] = 1 + rng.normal(0, 0.05, (E,)); W[p + "ffn_norm.weight"] = 1 + rng.normal(0, 0.05, (E,))
            W[p + "attn_q.weight"] = rng.normal(0, 0.1, (H * D, E)); W[p + "attn_k.weight"] = rng.normal(0, 0.1, (HKV * D, E)); W[p + "attn_v.weight"] = rng.normal(0, 0.1, (HKV * D, E))
            W[p + "attn_output.weight"] = rng.normal(0, 0.1, (E, H * D))
            if arch == "qwen2":
                W[p + "attn_q.bias"] = rng.normal(0, 0.05, (H * D,)); W[p + "attn_k.bias"] = rng.normal(0, 0.05, (HKV * D,)); W[p + "attn_v.bias"] = rng.normal(0, 0.05, (HKV * D,))
            W[p + "ffn_gate.weight"] = rng.normal(0, 0.1, (F, E)); W[p + "ffn_up.weight"] = rng.normal(0, 0.1, (F, E)); W[p + "ffn_down.weight"] = rng.normal(0, 0.1, (E, F))
        tl = []
        for name, arr in W.items():
            arr = arr.astype(np.float32)
            dims = tuple(reversed(arr.shape))
            if arr.ndim == 2 and arr.shape[1] % 32 == 0 and "embd" not in name and k % 2 == 0:
                raw = q8(arr); tl.append((name, dims, 8, iter([raw]), len(raw)))
            else:
                raw = arr.tobytes(); tl.append((name, dims, 0, iter([raw]), len(raw)))
        p = tmpdir / f"donor{k}.gguf"
        write_gguf(p, kv, tl)
        donors.append(describe_gguf(p, label=f"donor{k}", donor_id=f"D{k}"))
    return donors


def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    chk = chk or Check("forge")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_forge_"))
    donors = _synthetic_family(tmpdir, 3)
    inv = inventory_folder(tmpdir)
    chk("inventory reads headers only (3 donors, one family)", len(inv) == 3 and len(family_groups(inv)) == 1 and inv[0].hp["n_embd"] == 32, str(family_groups(inv).keys()))
    # an Ollama-style blob store: extension-less blobs sniffed by magic, labelled from manifests, non-model blobs skipped
    store = tmpdir / "store"; blobs = store / "blobs"; blobs.mkdir(parents=True, exist_ok=True)
    for k, tag in ((0, "registry.ollama.ai/library/qwen-test/0.5b"), (1, "hf.co/someone/Draft-GGUF/Q4_K_M")):
        data = Path(donors[k].path).read_bytes(); h = hashlib.sha256(data).hexdigest()
        (blobs / f"sha256-{h}").write_bytes(data)
        mf = store / "manifests" / Path(tag); mf.parent.mkdir(parents=True, exist_ok=True)
        mf.write_text(json.dumps({"layers": [{"mediaType": "application/vnd.ollama.image.model", "digest": f"sha256:{h}"},
                                             {"mediaType": "application/vnd.ollama.image.license", "digest": "sha256:0"}]}), encoding="utf-8")
    (blobs / "sha256-0").write_bytes(b"license text, not a model")
    inv2 = inventory_folder(blobs)
    labels = sorted(d.label for d in inv2)
    chk("blob store scan: 2 GGUF blobs found by magic, labelled from manifests, license blob skipped",
        labels == ["Draft-GGUF/Q4_K_M", "qwen-test/0.5b"] and len(family_groups(inv2)) == 1, str(labels))
    chk("manifest route agrees with the blob scan", sorted(d.label for d in inventory_ollama(store)) == labels)
    topics = ["math", "language", "science"]
    ids = [3, 17, 42, 5, 9, 60, 2, 33, 8, 1]
    # 1. math-always-on preset over the live store == the same model reloaded from the exported GGUF
    sp = ForgeSpec.preset("math-always-on", donors, topics, shared_topic="math", n_used=2, topic_donor={"language": "D1", "science": "D2", "math": "D0"})
    chk("preset: qwen2moe with shared math expert, 2 routed experts", sp.arch_out == "qwen2moe" and sp.n_expert == 2 and sp.layers[0]["shared"]["topic"] == "math", sp.summary())
    live = LLM(store=SpecStore(sp))
    lg_live = live.logits(live.hidden(np.asarray(ids)))
    out = assemble(sp, tmpdir / "forged.gguf", sidecar=True)
    chk("export: every copied tensor byte-exact, gates + gained shared-down novel", out["exact"] > 0 and out["novel"] >= 2 * 2 + 0, f"exact {out['exact']} novel {out['novel']} bytes {out['bytes']}")
    re = LLM(tmpdir / "forged.gguf", resident="f32")
    lg_re = re.logits(re.hidden(np.asarray(ids)))
    chk("reloaded GGUF == live template model (max |dlogit| < 1e-2)", np.max(np.abs(lg_re - lg_live)) < 1e-2, f"{np.max(np.abs(lg_re - lg_live)):.2e}")
    chk("routed experts actually route (top-2 over 2 experts) and shared expert gain restores unity", re.cfg.has_shexp and re.cfg.n_expert_used == 2)
    chk("sidecar written with lineage", Path(out["sidecar"]).exists())
    dm = describe_gguf(tmpdir / "forged.gguf")
    chk("a forged MoE file is inventoried as chat-only, never as a dense donor", donor_status(dm) == "moe" and dm.sig == donors[0].sig and not family_groups([dm]),
        f"{dm.arch} n_expert {dm.hp.get('n_expert')} status {donor_status(dm)}")
    mfp = write_modelfile(tmpdir / "forged.gguf", "forged")
    chk("Modelfile beside the export points at the absolute .gguf path", mfp.exists() and str((tmpdir / "forged.gguf").resolve()) in mfp.read_text(encoding="utf-8"))
    # behavior conditioning: metadata + helix on export, never a weight; clone withheld without consent
    from .behavior import CLIMATES
    bo = assemble(sp, tmpdir / "beh.gguf", behavior=CLIMATES["seeking"], sidecar=True)
    grb = GGUFReader(tmpdir / "beh.gguf")
    kv = grb.kv; tnames = set(grb.tensors); grb.close()
    chk("behavior export writes soke.emotion.* metadata (modulate_not_govern)", kv.get("soke.emotion.policy") == "modulate_not_govern" and "soke.emotion.C" in kv)
    chk("behavior export writes soke.logic.* metadata (veto_and_shape_not_erase)", kv.get("soke.logic.policy") == "veto_and_shape_not_erase")
    chk("refusal holds: no conditioning tensor in the weight stream", not any(n.startswith("soke.emotion") or n.startswith("soke.logic") or n.startswith("soke.clone") for n in tnames))
    chk("behavior helix teeth streamed into the .sff sidecar", bo.get("helix_teeth", 0) >= 12)
    # the .gguf still loads + runs in SOKE's own engine unchanged (metadata is inert to the forward pass)
    mb = LLM(tmpdir / "beh.gguf", resident="f32"); nllb = mb.nll(ids)["nll"]; mb.close()
    chk("behavior-conditioned .gguf still loads and scores (metadata is inert to inference)", np.isfinite(nllb))
    # clone metadata gated by consent
    from .clone_battery import CloneBattery
    cbp = CloneBattery(user_id="u"); cbp.set_consent(store=True)
    it = cbp.next_item()
    for _ in range(6):
        if it is None: break
        cbp.answer(response="warm", intensity=5); it = cbp.next_item()
    prof = cbp.build_profile(); prof.name = "clone"
    a_no = assemble(sp, tmpdir / "clone_no.gguf", behavior=prof, clone_consent={"store": False}, sidecar=False)
    g1 = GGUFReader(tmpdir / "clone_no.gguf"); has_no = "soke.clone.user_id" in g1.kv; g1.close()
    a_yes = assemble(sp, tmpdir / "clone_yes.gguf", behavior=prof, clone_consent={"store": True}, sidecar=False)
    g2 = GGUFReader(tmpdir / "clone_yes.gguf"); has_yes = "soke.clone.user_id" in g2.kv; g2.close()
    chk("clone metadata withheld without consent, written with consent", (not has_no) and has_yes)
    re.close(); live.close()
    # 2. ops: blend of identical donors == copy; task arithmetic with lambda=1 == donor; slerp endpoints
    st = SpecStore(sp)
    a = st._op_rows(op_copy("D1"), "blk.0.ffn_up.weight", 0, 8)
    b = st._op_rows(op_blend({"D1": 0.5, "D1": 0.5}) if False else op_blend({"D1": 1.0}), "blk.0.ffn_up.weight", 0, 8)
    chk("blend with one donor == copy", np.array_equal(a, b))
    c = st._op_rows(op_task("D0", {"D1": 1.0}), "blk.0.ffn_up.weight", 0, 8)
    chk("task arithmetic lambda=1 == the delta donor", np.max(np.abs(c - a)) < 1e-6)
    d0 = st._op_rows(op_slerp("D0", "D1", 0.0), "blk.0.ffn_up.weight", 0, 8)
    d1 = st._op_rows(op_slerp("D0", "D1", 1.0), "blk.0.ffn_up.weight", 0, 8)
    chk("slerp endpoints", np.max(np.abs(d1 - a)) < 1e-5 and np.max(np.abs(d0 - st._op_rows(op_copy("D0"), "blk.0.ffn_up.weight", 0, 8))) < 1e-5)
    g = st.full("blk.0.ffn_gate_inp.weight")
    chk("lexicon gate: one unit row per routed topic, rows differ", g.shape == (2, 32) and abs(float(np.sum(g[0] ** 2)) - 1) < 1e-4 and np.max(np.abs(g[0] - g[1])) > 1e-3)
    st.close()
    # 3. dense presets: interleave and stack (depth growth) export + reload
    for kind, nl in (("interleave", 2), ("stack", 4), ("random", 2)):
        spd = ForgeSpec.preset(kind, donors, topics)
        o = assemble(spd, tmpdir / f"{kind}.gguf", sidecar=False)
        m = LLM(tmpdir / f"{kind}.gguf", resident="f32")
        chk(f"dense preset {kind}: {nl} layers, exported and runs", m.cfg.n_layer == nl and np.isfinite(m.nll(ids)["nll"]), f"exact {o['exact']} novel {o['novel']}")
        m.close()
    # 4. all-routed llama-family preset (Mixtral layout)
    ldon = _synthetic_family(tmpdir / "ll", 2, arch="llama")
    spl = ForgeSpec.preset("all-routed", ldon, ["math", "language"], n_used=1)
    o = assemble(spl, tmpdir / "llama-moe.gguf", sidecar=False)
    m = LLM(tmpdir / "llama-moe.gguf", resident="f32")
    chk("llama-family all-routed preset exports a Mixtral-style MoE", m.cfg.arch == "llama" and m.cfg.n_expert == 2 and np.isfinite(m.nll(ids)["nll"]))
    m.close()
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
