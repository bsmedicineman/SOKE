"""
soke.kernels — computation ROUTES for the model core, and the route table the
Self-Healing loop (SOP) benchmarks and switches.

A route is one of several numerically equivalent implementations of an op. The
heal engine times candidates (>= 3 runs), checks equivalence on the same inputs
(max |Δ| within tolerance), and adopts a route only when it is faster by more than
the margin AND passes the KL / logit-divergence gate on the live model. Routes are
never applied silently: adoption is a ledger event and a META.routes entry.
"""
from __future__ import annotations

import time
from typing import Callable

import numpy as np

from .rng import Rng

# ---------------------------------------------------------------- softmax routes
def softmax_naive(x: np.ndarray, axis: int = -1) -> np.ndarray:
    e = np.exp(x)
    return e / np.sum(e, axis=axis, keepdims=True)


def softmax_lse(x: np.ndarray, axis: int = -1) -> np.ndarray:
    """L-gauge transport: subtract the running max (log-sum-exp trick), the stable route."""
    m = np.max(x, axis=axis, keepdims=True)
    e = np.exp(x - m)
    return e / np.sum(e, axis=axis, keepdims=True)


def softmax_chunked(x: np.ndarray, axis: int = -1, chunk: int = 64) -> np.ndarray:
    """Online softmax: two passes over chunks with a running max (flash-style)."""
    if axis != -1 and axis != x.ndim - 1:
        x = np.moveaxis(x, axis, -1)
    n = x.shape[-1]
    m = np.full(x.shape[:-1] + (1,), -np.inf, dtype=x.dtype)
    s = np.zeros(x.shape[:-1] + (1,), dtype=x.dtype)
    for i in range(0, n, chunk):
        blk = x[..., i:i + chunk]
        bm = np.max(blk, axis=-1, keepdims=True)
        nm = np.maximum(m, bm)
        s = s * np.exp(m - nm) + np.sum(np.exp(blk - nm), axis=-1, keepdims=True)
        m = nm
    out = np.exp(x - m) / s
    return out


def logsumexp(x: np.ndarray, axis: int = -1) -> np.ndarray:
    m = np.max(x, axis=axis, keepdims=True)
    return (m + np.log(np.sum(np.exp(x - m), axis=axis, keepdims=True))).squeeze(axis)


# ---------------------------------------------------------------- matmul routes
def matmul_dot(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return a @ b


def matmul_blocked(a: np.ndarray, b: np.ndarray, block: int = 256) -> np.ndarray:
    """Row-blocked product (bounded temporary memory for tall inputs)."""
    if a.ndim != 2 or a.shape[0] <= block:
        return a @ b
    out = np.empty((a.shape[0], b.shape[1]), dtype=np.result_type(a, b))
    for i in range(0, a.shape[0], block):
        out[i:i + block] = a[i:i + block] @ b
    return out


# ---------------------------------------------------------------- attention routes
def attention_full(q: np.ndarray, k: np.ndarray, v: np.ndarray, scale: float, mask: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    s = (q @ np.swapaxes(k, -1, -2)) * scale + mask
    p = softmax_lse(s)
    return p @ v, p


def attention_chunked(q: np.ndarray, k: np.ndarray, v: np.ndarray, scale: float, mask: np.ndarray, qchunk: int = 32) -> tuple[np.ndarray, np.ndarray]:
    """Query-blocked attention (bounded score memory); returns the same probabilities for the backward pass."""
    T = q.shape[-2]
    out = np.empty_like(q)
    p_all = np.empty(q.shape[:-1] + (k.shape[-2],), dtype=q.dtype)
    for i in range(0, T, qchunk):
        s = (q[..., i:i + qchunk, :] @ np.swapaxes(k, -1, -2)) * scale + mask[..., i:i + qchunk, :]
        p = softmax_lse(s)
        p_all[..., i:i + qchunk, :] = p
        out[..., i:i + qchunk, :] = p @ v
    return out, p_all


ROUTES: dict[str, dict[str, Callable]] = {
    "softmax": {"lse": softmax_lse, "naive": softmax_naive, "chunked": softmax_chunked},
    "matmul": {"dot": matmul_dot, "blocked": matmul_blocked},
    "attention": {"full": attention_full, "chunked": attention_chunked},
}
DEFAULT_ROUTES = {"softmax": "lse", "matmul": "dot", "attention": "full"}
ACTIVE = dict(DEFAULT_ROUTES)


def get(op: str) -> Callable:
    return ROUTES[op][ACTIVE[op]]


def set_route(op: str, name: str) -> None:
    if name not in ROUTES[op]:
        raise KeyError(f"unknown route {op}:{name}")
    ACTIVE[op] = name


def stress_args(op: str, args: tuple) -> tuple:
    """Numerical-stability probe inputs (large magnitudes) for a route audit."""
    if op == "softmax":
        return (np.asarray(args[0]) * 400.0,) + tuple(args[1:])
    if op == "attention":
        q, k, v, scale, mask = args
        return (q * 40.0, k * 40.0, v, scale, mask)
    return args


def benchmark(op: str, args: tuple, runs: int = 3, tol: float = 1e-5) -> list[dict]:
    """Time every route of `op` on the same inputs; equivalence against the active route; stability probe."""
    ref = None
    rows = []
    sargs = stress_args(op, args)
    for name, fn in ROUTES[op].items():
        times = []
        out = None
        for _ in range(runs):
            t0 = time.perf_counter()
            out = fn(*args)
            times.append(time.perf_counter() - t0)
        val = out[0] if isinstance(out, tuple) else out
        if name == ACTIVE[op]:
            ref = val
        with np.errstate(all="ignore"):
            sv = fn(*sargs)
        sv = sv[0] if isinstance(sv, tuple) else sv
        stable = bool(np.all(np.isfinite(sv)))
        rows.append({"route": name, "median_s": sorted(times)[len(times) // 2], "min_s": min(times), "_val": val, "stable": stable})
    for r in rows:
        r["max_abs_delta"] = float(np.max(np.abs(r["_val"] - ref))) if ref is not None and r["_val"].shape == ref.shape else float("inf")
        r["equivalent"] = r["max_abs_delta"] <= tol and r["stable"]
        del r["_val"]
    return rows


def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("kernels")
    rng = Rng(2)
    x = rng.normal(0, 3, (4, 8, 200)).astype(np.float64)
    a, b, c = softmax_naive(x), softmax_lse(x), softmax_chunked(x)
    chk("softmax routes agree", np.allclose(a, b, atol=1e-12) and np.allclose(b, c, atol=1e-12))
    big = np.array([[1000.0, 1001.0]])
    with np.errstate(all="ignore"):
        naive_big = softmax_naive(big)
    chk("naive softmax overflows, lse route survives", not np.all(np.isfinite(naive_big)) and np.allclose(softmax_lse(big), [[1 / (1 + np.e), np.e / (1 + np.e)]]))
    chk("logsumexp", abs(logsumexp(np.array([0.0, 0.0])) - np.log(2)) < 1e-12)
    A = rng.normal(0, 1, (600, 32))
    B = rng.normal(0, 1, (32, 16))
    chk("blocked matmul == dot", np.allclose(matmul_blocked(A, B, 100), A @ B))
    q = rng.normal(0, 1, (2, 2, 40, 8))
    mask = np.triu(np.full((40, 40), -np.inf), 1)
    o1, p1 = attention_full(q, q, q, 0.35, mask)
    o2, p2 = attention_chunked(q, q, q, 0.35, mask, 16)
    chk("chunked attention == full", np.allclose(o1, o2) and np.allclose(p1, p2))
    rows = benchmark("softmax", (x,), runs=3)
    naive = next(r for r in rows if r["route"] == "naive")
    chk("benchmark: naive softmax fails the stability probe, others equivalent", (not naive["stable"]) and all(r["equivalent"] for r in rows if r["route"] != "naive") and len(rows) == 3)
    set_route("softmax", "chunked")
    chk("route switch", get("softmax") is softmax_chunked)
    set_route("softmax", "lse")
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
