"""
soke.frame_engine — the Orthometric Frame System (OFS).

Implements Orthometric Mathematics v1.0 (BS Medicineman / Knight Industries):
  D1 Frame F = <alpha ⟂ beta>, size sigma^2 = alpha*beta, shape tau = beta/alpha
  D2 Gauge  = strictly monotone bijection on (0, inf): Q(x)=x^2, R(x)=1/x, L(x)=ln x,
              T(theta)=tan(theta/2); readings only through a declared gauge
  D3 Unit gauge normal form: sigma = 1 -> beta = 1/alpha; leg swap = Z2; X*Y = 1
  T1 One-figure invariant AM*HM = GM^2
  T2 Gauge Transport: a (+)_g b = g^-1(g(a) + g(b))
  The five operations: quadrature sum, harmonic sum, gnomon product, leg swap,
  orthogonal solve; registers R, Q, T, L, H; spread & quadrance; AGM engine;
  Lill-Horner shot; Third Law operation counting with eviction condition.

Standing nulls honoured (never re-entered as wins): Carlyle vs quadratic formula
= TIE; deferred-division T-register vs rotation matrix = TIE; orthometric frame
*weights* inside a neural net = NULL (SEPHIRA test epsilon). Frames are used here
for storage encoding, verification and op-count accounting only.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from decimal import Decimal, getcontext
from fractions import Fraction
from typing import Callable, Iterable, Optional, Sequence

from .util import Check, TOL

# --------------------------------------------------------------------------
# D2 — Gauges
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class Gauge:
    name: str
    fwd: Callable[[float], float]
    inv: Callable[[float], float]
    kind: int            # SFF register_kind code: 0=R 1=Q 2=T 3=L 4=H 5=LIN
    additive_for: str    # which dominant op becomes addition

    def transport(self, a: float, b: float) -> float:
        """T2: a (+)_g b = g^-1(g(a) + g(b))."""
        return self.inv(self.fwd(a) + self.fwd(b))

    def reduce(self, values: Iterable[float]) -> float:
        acc = 0.0
        n = 0
        for v in values:
            acc += self.fwd(v)
            n += 1
        if n == 0:
            raise ValueError("empty transport")
        return self.inv(acc)


def _safe_inv(x: float) -> float:
    if x == 0:
        return math.inf
    return 1.0 / x


GAUGE_R = Gauge("R", _safe_inv, _safe_inv, 0, "division in reciprocal structure")
GAUGE_Q = Gauge("Q", lambda x: x * x, math.sqrt, 1, "square root inside accumulation")
GAUGE_T = Gauge("T", lambda th: math.tan(th / 2.0), lambda t: 2.0 * math.atan(t), 2, "rotation composition")
GAUGE_L = Gauge("L", math.log, math.exp, 3, "multiplication chain")
GAUGE_H = Gauge("H", lambda x: x, lambda x: x, 4, "spatial attitude (braid)")
GAUGE_LIN = Gauge("LIN", lambda x: x, lambda x: x, 5, "steel-man baseline (raw line, never an answer)")
GAUGES = {g.name: g for g in (GAUGE_R, GAUGE_Q, GAUGE_T, GAUGE_L, GAUGE_H, GAUGE_LIN)}
KIND_TO_GAUGE = {g.kind: g for g in GAUGES.values()}
# ACTG tooth type -> gauge, per the data-recording spec (A=Q, C=R, T=T, G=L)
ACTG_GAUGE = {"A": GAUGE_Q, "C": GAUGE_R, "T": GAUGE_T, "G": GAUGE_L}


def select_gauge(dominant_op: str) -> Gauge:
    """Gauge-selection table (Third Law): the gauge that makes the dominant op additive."""
    key = dominant_op.lower()
    if "root" in key or "sqrt" in key or "rms" in key or "energy" in key:
        return GAUGE_Q
    if "div" in key or "parallel" in key or "recip" in key or "harmonic" in key:
        return GAUGE_R
    if "rot" in key or "angle" in key or "compos" in key or "cycl" in key:
        return GAUGE_T
    if "mul" in key or "product" in key or "exp" in key or "growth" in key or "prob" in key:
        return GAUGE_L
    if "attitude" in key or "quaternion" in key or "braid" in key:
        return GAUGE_H
    return GAUGE_LIN


# --------------------------------------------------------------------------
# D1/D3 — Frames
# --------------------------------------------------------------------------
@dataclass
class Frame:
    alpha: float
    beta: float
    gauge: Gauge = GAUGE_LIN
    meta: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.alpha <= 0 or self.beta <= 0:
            raise ValueError("frame legs must be positive magnitudes (D1)")

    @property
    def sigma2(self) -> float:      # size
        return self.alpha * self.beta

    @property
    def sigma(self) -> float:
        return math.sqrt(self.alpha * self.beta)

    @property
    def tau(self) -> float:         # shape
        return self.beta / self.alpha

    def unit(self) -> "Frame":
        """D3: normalize sigma = 1 -> (alpha/sigma, 1/(alpha/sigma))."""
        a = self.alpha / self.sigma
        return Frame(a, 1.0 / a, self.gauge, dict(self.meta))

    def swap(self) -> "Frame":
        """Leg swap — the exact Z2 (alpha -> 1/alpha in unit gauge)."""
        return Frame(self.beta, self.alpha, self.gauge, dict(self.meta))

    def read(self, gauge: Optional[Gauge] = None) -> float:
        """Boundary read-out of the size through a declared gauge (never raw unless LIN declared)."""
        g = gauge or self.gauge
        return g.fwd(self.sigma)

    @staticmethod
    def from_value(x: float, gauge: Gauge = GAUGE_LIN) -> "Frame":
        """Unit-gauge frame carrying magnitude x as its size: (x, 1/x) is the reciprocal pair
        of D3 scaled so that alpha*beta = x^2... we keep sigma = x, alpha = x, beta = x^-1 * x^2 = x.
        For storage we use alpha = |x|, beta = 1/|x| (unit size) with sigma re-read via gauge."""
        x = abs(float(x))
        if x == 0:
            raise ValueError("zero has no frame; use the zero flag")
        return Frame(x, 1.0 / x, gauge)

    # ---- the five operations (algebraic shadows; constructions documented in the spec)
    def qsum(self, other: "Frame") -> "Frame":
        """⊕ quadrature sum on sizes (Q-gauge addition); shapes carried as geometric mean."""
        s = GAUGE_Q.transport(self.sigma, other.sigma)
        tau = math.sqrt(self.tau * other.tau)
        return _frame_from_sigma_tau(s, tau, GAUGE_Q)

    def hsum(self, other: "Frame") -> "Frame":
        """⊞ harmonic sum on sizes (R-gauge addition)."""
        s = GAUGE_R.transport(self.sigma, other.sigma)
        tau = math.sqrt(self.tau * other.tau)
        return _frame_from_sigma_tau(s, tau, GAUGE_R)

    def gnomon(self, other: "Frame") -> "Frame":
        """⊗ gnomon product: sizes multiply; shapes compose by one Möbius step in the T-gauge."""
        s = self.sigma * other.sigma
        t1 = math.tan(math.atan(self.tau) / 2.0)
        t2 = math.tan(math.atan(other.tau) / 2.0)
        t3 = tcompose(t1, t2)
        tau = math.tan(2.0 * math.atan(t3)) if abs(t3) < 1e12 else 1e12
        tau = abs(tau) if tau != 0 else 1e-12
        return _frame_from_sigma_tau(s, tau, GAUGE_T)


def _frame_from_sigma_tau(sigma: float, tau: float, gauge: Gauge) -> Frame:
    # sigma^2 = a*b, tau = b/a  ->  a = sigma/sqrt(tau), b = sigma*sqrt(tau)
    r = math.sqrt(tau)
    return Frame(sigma / r, sigma * r, gauge)


# --------------------------------------------------------------------------
# T1 — one-figure invariant and the three means
# --------------------------------------------------------------------------
def am(a: float, b: float) -> float:
    return (a + b) / 2.0


def gm(a: float, b: float) -> float:
    return math.sqrt(a * b)


def hm(a: float, b: float) -> float:
    return 2.0 * a * b / (a + b)


def canon_conjugate(a: float, b: float) -> float:
    """Reciprocal dual of a^2 + b^2 = c^2:  1/a^2 + 1/b^2 = 1/h,  h = a^2 b^2 / (a^2 + b^2)."""
    return (a * a * b * b) / (a * a + b * b)


# --------------------------------------------------------------------------
# Registers
# --------------------------------------------------------------------------
def qsum(a: float, b: float) -> float:
    return math.sqrt(a * a + b * b)


def hsum(a: float, b: float) -> float:
    return a * b / (a + b)


def tcompose(t1: float, t2: float) -> float:
    """T-register composition t3 = (t1 + t2) / (1 - t1 t2); pole handled by the cot branch."""
    d = 1.0 - t1 * t2
    if abs(d) < 1e-300:
        return math.inf
    return (t1 + t2) / d


def cotcompose(c1: float, c2: float) -> float:
    """Cotangent-branch dual: c3 = (c1 c2 - 1) / (c1 + c2)."""
    return (c1 * c2 - 1.0) / (c1 + c2)


def t_readout(t: float) -> tuple[float, float]:
    """cos = (1 - t^2)/(1 + t^2), sin = 2t/(1 + t^2)."""
    tt = t * t
    return (1.0 - tt) / (1.0 + tt), 2.0 * t / (1.0 + tt)


def spread(u: Sequence[int], v: Sequence[int]) -> Fraction:
    """Rational spread s = (u x v)^2 / (Q(u) Q(v)) — exact over the rationals."""
    cx = u[0] * v[1] - u[1] * v[0]
    return Fraction(cx * cx, (u[0] ** 2 + u[1] ** 2) * (v[0] ** 2 + v[1] ** 2))


def quadrance(u: Sequence[int], v: Sequence[int]) -> int:
    return (u[0] - v[0]) ** 2 + (u[1] - v[1]) ** 2


def qmul(p: Sequence[float], q: Sequence[float]) -> tuple[float, float, float, float]:
    """H-register braid: quaternion product (16M + 12A = 28 ops)."""
    w1, x1, y1, z1 = p
    w2, x2, y2, z2 = q
    return (w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
            w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
            w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
            w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2)


def q2m(q: Sequence[float]) -> list[list[float]]:
    w, x, y, z = q
    return [[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]]


def mmul3(A: list[list[float]], B: list[list[float]]) -> list[list[float]]:
    return [[sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def axang(ax: Sequence[float], th: float) -> tuple[float, float, float, float]:
    n = math.sqrt(sum(a * a for a in ax))
    ax = [a / n for a in ax]
    s = math.sin(th / 2.0)
    return (math.cos(th / 2.0), ax[0] * s, ax[1] * s, ax[2] * s)


# --------------------------------------------------------------------------
# 6.3 — Lill / Horner
# --------------------------------------------------------------------------
def horner(co: Sequence[float], x: float) -> float:
    b = co[0]
    for a in co[1:]:
        b = a + x * b
    return b


def derivative_coeffs(co: Sequence[float]) -> list[float]:
    n = len(co) - 1
    return [co[i] * (n - i) for i in range(n)]


def lill_shot(co: Sequence[float], x0: float, tol: float = 1e-15, max_iter: int = 100) -> tuple[float, int]:
    """Right-angle shot: rational Newton on Horner ladders (branch-free, no radicals)."""
    dco = derivative_coeffs(co)
    x = float(x0)
    for it in range(1, max_iter + 1):
        px = horner(co, x)
        dpx = horner(dco, x)
        if dpx == 0:
            break
        xn = x - px / dpx
        if abs(xn - x) < tol:
            return xn, it
        x = xn
    return x, max_iter


def bisect_root(co: Sequence[float], lo: float, hi: float, n: int = 80) -> float:
    flo = horner(co, lo)
    for _ in range(n):
        mid = (lo + hi) / 2.0
        fm = horner(co, mid)
        if (fm < 0) == (flo < 0):
            lo, flo = mid, fm
        else:
            hi = mid
    return (lo + hi) / 2.0


# --------------------------------------------------------------------------
# 7.1 — AGM engine (decimal, arbitrary precision, stdlib)
# --------------------------------------------------------------------------
def agm_pi(digits: int = 60) -> tuple[Decimal, int]:
    """Brent–Salamin: rectangle (AM) + Thales perpendicular (GM), iterated. Returns (pi, iterations)."""
    getcontext().prec = digits + 10
    a = Decimal(1)
    b = Decimal(1) / Decimal(2).sqrt()
    t = Decimal("0.25")
    p = Decimal(1)
    it = 0
    eps = Decimal(10) ** (-(digits + 2))
    for _ in range(60):
        an = (a + b) / 2
        b = (a * b).sqrt()
        t = t - p * (a - an) ** 2
        p = 2 * p
        it += 1
        if abs(a - an) < eps:
            a = an
            break
        a = an
    pi = (a + b) ** 2 / (4 * t)
    return +pi, it


def agm_ln(x: float | Decimal, digits: int = 60) -> tuple[Decimal, int]:
    """ln x via the AGM (Borwein): ln x ≈ pi / (2 AGM(1, 4/s)) − m ln 2, s = x·2^m."""
    getcontext().prec = digits + 15
    X = Decimal(x)
    p_bits = int(digits * 3.3219281) + 20
    m = p_bits // 2 + 8
    s = X * (Decimal(2) ** m)
    a = Decimal(1)
    b = Decimal(4) / s
    it = 0
    eps = Decimal(10) ** (-(digits + 5))
    while abs(a - b) > eps and it < 200:
        a, b = (a + b) / 2, (a * b).sqrt()
        it += 1
    pi, _ = agm_pi(digits)
    ln2 = _ln2_series(digits)
    return +(pi / (2 * a) - m * ln2), it


def _ln2_series(digits: int) -> Decimal:
    """ln 2 = 2 atanh(1/3) — the steel-man series (kept only to anchor the AGM)."""
    getcontext().prec = digits + 15
    u = Decimal(1) / Decimal(3)
    term = u
    total = Decimal(0)
    k = 1
    eps = Decimal(10) ** (-(digits + 10))
    while term > eps:
        total += term / k
        term = term * u * u
        k += 2
    return 2 * total


PI_100 = ("3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679")
LN10_40 = "2.302585092994045684017991454684364207601101488628"


# --------------------------------------------------------------------------
# Section 7 — the Third Law: op counting with an explicit cost model
# --------------------------------------------------------------------------
DEFAULT_COST_MODEL = {"add": 1.0, "mul": 1.0, "div": 4.0, "sqrt": 4.0, "transcendental": 20.0}


class OpCounter:
    def __init__(self):
        self.add = 0
        self.mul = 0
        self.div = 0
        self.sqrt = 0
        self.transcendental = 0

    def weighted(self, cost: dict = DEFAULT_COST_MODEL) -> float:
        return (self.add * cost["add"] + self.mul * cost["mul"] + self.div * cost["div"]
                + self.sqrt * cost["sqrt"] + self.transcendental * cost["transcendental"])

    def raw(self) -> int:
        return self.add + self.mul + self.div + self.sqrt + self.transcendental

    def as_dict(self) -> dict:
        return {"add": self.add, "mul": self.mul, "div": self.div, "sqrt": self.sqrt,
                "transcendental": self.transcendental}


def third_law_verdict(baseline_raw: float, ortho_raw: float, threshold: float = 1.0 / 3.0) -> tuple[str, float]:
    """Returns (status, cut_fraction). Eviction condition: cut < 33.3% -> TIE/NULL, never a win."""
    if baseline_raw <= 0:
        return "BOUNDARY", 0.0
    cut = (baseline_raw - ortho_raw) / baseline_raw
    if cut >= threshold:
        return "VERIFIED", cut
    if cut > 0:
        return "TIE", cut
    return "NULL", cut


def certified_rows() -> list[dict]:
    """
    Executed Third-Law rows (raw counts). Rows with libm-range baselines are tagged DERIVED,
    exactly as the treatise does; the two ties of Section 8 are recorded as ties.
    """
    rows = []
    # Row 1: planar rotation composition — normalized one-number T form vs rotation matrix
    rows.append(_row("planar_rotation_composition", baseline=6, ortho=4, note="4M+2A vs 1M+1D+2A (normalized T form; deferred-division form is a TIE)"))
    # Row 2: spatial attitude composition
    rows.append(_row("spatial_attitude_composition", baseline=45, ortho=28, note="3x3 matrix 27M+18A vs H-register 16M+12A"))
    # Row 4: series–parallel network (weighted, div=4): counted live
    c, f = _network_counts()
    rows.append(_row("series_parallel_network_12", baseline=c.weighted(), ortho=f.weighted(),
                     note=f"classical A{c.add} D{c.div} vs frame A{f.add} D{f.div} (weighted div=4)"))
    # Row 6: real cubic root — Lill shot iterations vs Cardano (2 cube roots + branches): counted as calls
    x, it = lill_shot([1, 0, -1, -1], 1.5)
    rows.append(_row("real_cubic_root_lill_shot", baseline=3 * 20, ortho=it * (3 + 2 + 1 + 4),
                     note=f"3 libm calls (trig route, 20 each) vs {it} rational Newton iterations", status_override="DERIVED"))
    # Ties (Section 8) recorded explicitly
    rows.append({"pipeline": "carlyle_circle_vs_quadratic_formula", "baseline_ops": 0, "ortho_ops": 0,
                 "cut_pct": 0.0, "status": "TIE", "note": "identical flop count once coordinates are computed"})
    rows.append({"pipeline": "deferred_division_T_vs_rotation_matrix", "baseline_ops": 6, "ortho_ops": 6,
                 "cut_pct": 0.0, "status": "TIE", "note": "4M+2A on both sides; the 33.3% cut needs the normalized form"})
    return rows


def _row(name: str, baseline: float, ortho: float, note: str = "", status_override: Optional[str] = None) -> dict:
    status, cut = third_law_verdict(baseline, ortho)
    if status_override and status == "VERIFIED":
        status = status_override
    return {"pipeline": name, "baseline_ops": baseline, "ortho_ops": ortho,
            "cut_pct": round(cut * 100.0, 2), "status": status, "note": note}


def _network_counts() -> tuple[OpCounter, OpCounter]:
    import random
    rnd = random.Random(3)
    R = [rnd.uniform(10, 100) for _ in range(12)]
    c = OpCounter()

    def par_classical(rs):
        inv = 0.0
        for r in rs:
            inv += 1.0 / r
            c.div += 1
        c.add += len(rs) - 1
        c.div += 1
        return 1.0 / inv

    blocks = [par_classical(R[i:i + 4]) for i in (0, 4, 8)]
    series = blocks[0] + blocks[1] + blocks[2]
    c.add += 2
    f = OpCounter()
    G = [1.0 / r for r in R]           # creation legs, amortized across sweeps
    fb = []
    for i in (0, 4, 8):
        g = G[i] + G[i + 1] + G[i + 2] + G[i + 3]
        f.add += 3
        fb.append(1.0 / g)
        f.div += 1
    fser = fb[0] + fb[1] + fb[2]
    f.add += 2
    assert abs(series - fser) < 1e-9
    return c, f


# --------------------------------------------------------------------------
# Verification suite — every load-bearing relation, two routes each
# --------------------------------------------------------------------------
def verify_suite(chk: Optional[Check] = None, high_precision_digits: int = 60) -> Check:
    chk = chk or Check("frame_engine")
    # 1. canon conjugates
    h = canon_conjugate(3, 4)
    chk("canon 3-4-5 conjugate", abs(1 / 9 + 1 / 16 - 1 / h) < 1e-12, f"h={h}")
    h2 = canon_conjugate(5, 12)
    chk("canon 5-12-13 conjugate", abs(1 / 25 + 1 / 144 - 1 / h2) < 1e-12, f"h={h2:.6f}")
    # 2. one-figure invariant + dual
    chk("AM*HM=GM^2 (3,4)", abs(am(3, 4) * hm(3, 4) - gm(3, 4) ** 2) < 1e-12)
    chk("AM*HM=GM^2 (1,9)", abs(am(1, 9) * hm(1, 9) - 9.0) < 1e-12)
    chk("HM dual of AM (3,4)", abs(hm(3, 4) - 1.0 / am(1 / 3, 1 / 4)) < 1e-12)
    chk("HM dual of AM (1,9)", abs(hm(1, 9) - 1.0 / am(1.0, 1 / 9)) < 1e-12)
    # 3. transport
    chk("R-conjugacy 1/(3 hsum 4)=1/3+1/4", abs(1.0 / hsum(3, 4) - (1 / 3 + 1 / 4)) < 1e-15)
    chk("R-conjugacy (2,2)", abs(1.0 / hsum(2, 2) - 1.0) < 1e-15)
    chk("Q-associativity (2+3)+6", abs(qsum(qsum(2, 3), 6) - 7.0) < 1e-12)
    chk("Q-sum second route", abs(qsum(qsum(2, 3), 6) - math.sqrt(4 + 9 + 36)) < 1e-15)
    alt = 1.0 / math.sqrt(1 / 9 + 1 / 16)
    chk("altitude gauge 3-4 legs", abs(alt - 2.4) < 1e-12)
    chk("T2 transport Q == qsum", abs(GAUGE_Q.transport(3, 4) - 5.0) < 1e-12)
    chk("T2 transport R == hsum", abs(GAUGE_R.transport(3, 6) - 2.0) < 1e-12)
    chk("T2 transport L == product", abs(GAUGE_L.transport(3, 4) - 12.0) < 1e-9)
    chk("T2 commutative (L)", abs(GAUGE_L.transport(3, 4) - GAUGE_L.transport(4, 3)) < 1e-12)
    chk("T2 associative (R)", abs(GAUGE_R.transport(GAUGE_R.transport(2, 3), 4) - GAUGE_R.transport(2, GAUGE_R.transport(3, 4))) < 1e-12)
    # 4. T-register
    d = math.radians
    chk("T-compose 30+60 -> unity", abs(tcompose(math.tan(d(15)), math.tan(d(30))) - 1.0) < 1e-12)
    chk("T-compose 40+50 -> unity", abs(tcompose(math.tan(d(20)), math.tan(d(25))) - 1.0) < 1e-12)
    chk("T-compose 30+40", abs(tcompose(math.tan(d(15)), math.tan(d(20))) - math.tan(d(35))) < 1e-12)
    chk("cot-branch dual 60+60", abs(cotcompose(1 / math.tan(d(30)), 1 / math.tan(d(30))) - 1 / math.tan(d(60))) < 1e-12)
    chk("cot-branch dual 90+90", abs(cotcompose(1 / math.tan(d(45)), 1 / math.tan(d(45)))) < 1e-15)
    c70, s70 = t_readout(math.tan(d(35)))
    chk("T-readout cos70", abs(c70 - math.cos(d(70))) < 1e-15)
    chk("T-readout sin70", abs(s70 - math.sin(d(70))) < 1e-15)
    import random
    rnd = random.Random(7)
    angles = [rnd.uniform(-0.001, 0.001) for _ in range(100000)]
    tacc = 0.0
    for a in angles:
        tacc = tcompose(tacc, math.tan(a / 2.0))
    ref = math.tan(sum(angles) / 2.0)
    chk("T-chain drift n=100000", abs(tacc - ref) < 1e-9, f"|d|={abs(tacc - ref):.2e}")
    # 5. spread
    s = spread((3, 4), (5, 12))
    chk("spread (3,4)x(5,12) exact", s == Fraction(256, 4225), f"s={s}")
    chk("spread second route 1-cos^2", s == 1 - Fraction(63 * 63, 65 * 65))
    chk("co-spread sums to unity", s + spread((3, 4), (-12, 5)) == 1)
    chk("spread (1,0)x(1,1)", spread((1, 0), (1, 1)) == Fraction(1, 2))
    # 6. H-register
    qa, qb = axang([1, 2, 3], 0.7), axang([-2, 1, 0.5], 1.3)
    M1, M2 = mmul3(q2m(qa), q2m(qb)), q2m(qmul(qa, qb))
    err = max(abs(M1[i][j] - M2[i][j]) for i in range(3) for j in range(3))
    chk("H-register = matrix compose", err < 1e-12, f"max err {err:.2e}; 28 vs 45 ops -> 37.8% cut")
    # 7. network
    c, f = _network_counts()
    chk("R-register network counts", (c.add, c.div, f.add, f.div) == (11, 15, 11, 3), f"A{c.add}D{c.div} vs A{f.add}D{f.div}")
    chk("R-register weighted cut >= 1/3", (c.weighted() - f.weighted()) / c.weighted() >= 1 / 3, f"{c.weighted():.0f} vs {f.weighted():.0f}")
    # 8. Lill
    chk("Lill path = Horner p(1)", horner([1, 0, -1, -1], 1.0) == -1.0)
    x, it = lill_shot([1, 0, -1, -1], 1.5)
    chk("Lill-shot root of x^3-x-1", abs(horner([1, 0, -1, -1], x)) < 1e-12, f"x*={x:.15f} it={it}")
    chk("Lill firing angle", abs(math.tan(math.atan(x)) - x) < 1e-15)
    chk("cubic root second route (bisection)", abs(bisect_root([1, 0, -1, -1], 1.0, 2.0) - x) < 1e-12)
    # 9. AGM (decimal, stdlib)
    pi, its = agm_pi(high_precision_digits)
    chk(f"Brent-Salamin pi to {high_precision_digits} digits", str(pi)[:high_precision_digits + 1] == PI_100[:high_precision_digits + 1], f"iterations={its}")
    ln10, agm_it = agm_ln(10, high_precision_digits)
    chk("AGM ln(10) to 40 digits", str(ln10)[:41] == LN10_40[:41], f"AGM iterations={agm_it}")
    # 10. quadrance reciprocal dual
    for xv in (3.7, 0.21):
        v1, v2 = (1 / xv) ** 2, 1 / (xv ** 2)
        chk(f"Q(1/x) = 1/Q(x) x={xv}", abs(v1 - v2) / v2 < 1e-15)
    # 11. frames
    F = Frame(4, 1)
    chk("frame size/shape", abs(F.sigma2 - 4) < 1e-12 and abs(F.tau - 0.25) < 1e-12)
    U = F.unit()
    chk("unit gauge normal form beta=1/alpha", abs(U.alpha * U.beta - 1.0) < 1e-12)
    chk("leg swap is Z2", abs(U.swap().swap().alpha - U.alpha) < 1e-15)
    chk("frame qsum sizes", abs(Frame(3, 3).qsum(Frame(4, 4)).sigma - 5.0) < 1e-12)
    chk("frame hsum sizes", abs(Frame(3, 3).hsum(Frame(6, 6)).sigma - 2.0) < 1e-12)
    chk("frame gnomon sizes multiply", abs(Frame(2, 2).gnomon(Frame(3, 3)).sigma - 6.0) < 1e-9)
    # 12. Third Law verdicts
    st, cut = third_law_verdict(45, 28)
    chk("third law 28 vs 45 VERIFIED", st == "VERIFIED" and abs(cut - 17 / 45) < 1e-12)
    st2, _ = third_law_verdict(6, 6)
    chk("third law tie is NULL/TIE never win", st2 in ("TIE", "NULL"))
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
