"""
soke.forge_loop — the forge's learning: trial and error over the template, judged only by measured performance.

No slot is ranked up front. The loop proposes a change to the template (swap a donor into a slot, blend two
donors, extrapolate past them, re-seed a gate, add or drop an expert, duplicate or drop a layer, re-source a
layer, rescale the always-on expert ...), scores the candidate on the probe corpus with the real forward pass,
and keeps it only if the training probes improve. Everything else is a null — kept on record, never softened.

    ratchet     : the current template only ever gets better on the training probes
    hold-out    : a second probe set is scored but never optimised; if three accepted trials in a row make it
                  worse the loop steps back to the best hold-out template (the over-fit guard)
    priority    : an optional topic that may not get worse by more than `tol_priority` (default: math, 2 %)
    speed       : probes are scored in one packed batch per layer (every donor tensor dequantized once);
                  a change at layer k re-runs only layers >= the nearest cached boundary below k

The score is plain negative log-likelihood per token (nats). Lower is better; the loop reports it per topic.
"""
from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from .forge import ForgeSpec, SpecStore, assemble, op_blend, op_copy, op_task
from .llm_engine import LLM
from .memguard import MemGuard
from .rng import Rng
from .tokenizer import Tokenizer
from .tower import route_text
from .util import expand_corpus, iso_now


# ==========================================================================
# probes
# ==========================================================================
@dataclass
class Probes:
    topics: list[str]
    train: dict                      # topic -> list[list[int]]
    holdout: dict
    n_tokens: int = 0

    def flat(self, which: str) -> tuple[list, list]:
        src = self.train if which == "train" else self.holdout
        seqs, owners = [], []
        for t in self.topics:
            for s in src.get(t, []):
                seqs.append(s); owners.append(t)
        return seqs, owners


def build_probes(sources, tokenizer: Tokenizer, topics: list[str], per_topic: int = 6, holdout_per_topic: int = 2,
                 chunk_chars: int = 1200, max_tokens: int = 192, seed: int = 0, progress: Optional[Callable] = None) -> Probes:
    """Text chunks from files/folders, routed to topics by the knowledge tower's lexicon router, tokenized by the
    donor family's tokenizer. Unrouted chunks feed a topic named 'general' if it is in `topics`."""
    from .memory_engine import iter_file_text
    files, rep = expand_corpus(sources)
    rng = Rng(seed)
    buckets: dict[str, list[list[int]]] = {t: [] for t in topics}
    want = per_topic + holdout_per_topic
    total_needed = want * len(topics)
    n_seen = 0
    for f in files:
        try:
            for text in iter_file_text(f, chunk_bytes=64 * 1024):
                for i in range(0, len(text), chunk_chars):
                    piece = text[i:i + chunk_chars].strip()
                    if len(piece) < chunk_chars // 3:
                        continue
                    routed = route_text(piece, top=1)
                    topic = routed[0][0] if routed and routed[0][1] > 0.5 else "general"
                    if topic not in buckets:
                        continue
                    if len(buckets[topic]) >= want * 3:
                        continue
                    ids = tokenizer.encode(piece, add_special=False, parse_special=False)[:max_tokens]
                    if len(ids) >= 16:
                        buckets[topic].append(ids)
                        n_seen += 1
                    if progress and n_seen % 25 == 0:
                        progress({"chunks": n_seen, "per_topic": {t: len(v) for t, v in buckets.items()}})
            if all(len(v) >= want * 3 for v in buckets.values()):
                break
        except Exception:
            continue
    train, hold = {}, {}
    n_tok = 0
    for t in topics:
        lst = buckets[t]
        idx = list(rng.permutation(len(lst))) if lst else []
        pick = [lst[i] for i in idx[:want]]
        train[t] = pick[:per_topic]
        hold[t] = pick[per_topic:per_topic + holdout_per_topic]
        n_tok += sum(len(s) for s in train[t]) + sum(len(s) for s in hold[t])
    return Probes(topics=list(topics), train=train, holdout=hold, n_tokens=n_tok)


# ==========================================================================
# scoring with boundary caches
# ==========================================================================
class Scorer:
    SNAP_BUDGET = 128 * 2 ** 20      # bytes of cached boundary hidden states per probe set

    def __init__(self, probes: Probes, memguard: Optional[MemGuard] = None, cache_every: int = 4):
        self.p = probes
        self.mg = memguard or MemGuard()
        self.cache_every = cache_every
        self.snaps: dict[str, dict] = {"train": {}, "holdout": {}}     # which -> {layer: packed hidden}
        self.seqs = {w: self.p.flat(w) for w in ("train", "holdout")}
        self.evals = 0
        self.seconds = 0.0

    def _boundaries(self, n_layer: int, n_tokens: int = 0, n_embd: int = 0) -> set:
        """Layer indices whose input hidden state is cached. The spacing widens when a pack is so long that
        cache_every snapshots would exceed SNAP_BUDGET (each snapshot is n_tokens x n_embd f32)."""
        every = self.cache_every
        if n_tokens and n_embd:
            per_snap = n_tokens * n_embd * 4
            max_snaps = max(1, self.SNAP_BUDGET // per_snap)
            every = max(every, -(-n_layer // max_snaps))
        return {b for b in range(0, n_layer, every)}

    def score(self, spec: ForgeSpec, which: str = "train", changed_from: Optional[int] = None, keep_snaps: bool = False) -> dict:
        """Per-topic and total NLL. changed_from = lowest layer index that differs from the spec whose snapshots are
        cached; None = full pass. keep_snaps = refresh the boundary cache from this pass (call for accepted specs)."""
        seqs, owners = self.seqs[which]
        if not seqs:
            return {"total": float("nan"), "topics": {}, "tokens": 0}
        t0 = time.time()
        model = LLM(store=SpecStore(spec, self.mg), memguard=self.mg)
        n_layer = model.cfg.n_layer
        bounds = self._boundaries(n_layer, sum(len(x) for x in seqs), model.cfg.n_embd)
        cache = self.snaps[which]
        layer_from, h0 = 0, None
        if changed_from is not None and cache:
            usable = [b for b in cache if b <= changed_from and b in bounds]
            if usable:
                layer_from = max(usable)
                h0 = cache[layer_from]
        new_snaps: dict = {}
        r = model.nll_batch(seqs, layer_from=layer_from, h0=h0, snap_at=bounds if keep_snaps else None, snaps=new_snaps if keep_snaps else None)
        model.close()
        if keep_snaps:
            merged = {b: h for b, h in cache.items() if b < layer_from}
            merged.update(new_snaps)
            self.snaps[which] = merged
        per_topic: dict[str, list] = {}
        for nll, t in zip(r["per_seq"], owners):
            per_topic.setdefault(t, []).append(nll)
        topics = {t: float(np.mean(v)) for t, v in per_topic.items()}
        self.evals += 1
        self.seconds += time.time() - t0
        return {"total": float(r["nll"]), "topics": topics, "tokens": r["tokens"], "seconds": round(time.time() - t0, 1), "layer_from": layer_from}


# ==========================================================================
# the loop
# ==========================================================================
OPERATORS = ["swap_attn", "swap_expert", "blend_expert", "task_attn", "swap_shared", "gate_scale", "gate_reinit",
             "shexp_gain", "swap_topics", "swap_layer_src", "add_expert", "drop_expert", "dup_layer", "drop_layer", "extrapolate"]
DEFAULT_OP_WEIGHTS = {"swap_attn": 2, "swap_expert": 3, "blend_expert": 3, "task_attn": 2, "swap_shared": 1, "gate_scale": 1,
                      "gate_reinit": 1, "shexp_gain": 1, "swap_topics": 1, "swap_layer_src": 1, "add_expert": 0.5, "drop_expert": 0.5,
                      "dup_layer": 0.5, "drop_layer": 0.5, "extrapolate": 1}


@dataclass
class Trial:
    n: int
    op: str
    desc: str
    changed_from: int
    before: float
    after: float
    accepted: bool
    holdout: Optional[float] = None
    seconds: float = 0.0
    topics: dict = field(default_factory=dict)


class ForgeTrainer:
    def __init__(self, spec: ForgeSpec, probes: Probes, memguard: Optional[MemGuard] = None, ledger=None, research_db=None,
                 on_event: Optional[Callable] = None, priority_topic: Optional[str] = "math", tol_priority: float = 0.02,
                 min_gain: float = 0.001, seed: int = 0, op_weights: Optional[dict] = None, cache_every: int = 4,
                 allow_ops: Optional[list] = None, save_dir: Optional[Path] = None, behavior=None):
        self.spec = spec
        self.best_holdout_spec = spec
        self.probes = probes
        self.mg = memguard or MemGuard()
        self.ledger = ledger
        self.db = research_db
        self.on_event = on_event
        self.priority = priority_topic if priority_topic in probes.topics else None
        self.tol_priority = tol_priority
        self.base_min_gain = min_gain
        self.min_gain = min_gain
        self.rng = Rng(seed)
        self.base_weights = dict(DEFAULT_OP_WEIGHTS)
        if op_weights:
            self.base_weights.update(op_weights)
        if allow_ops is not None:
            self.base_weights = {k: (v if k in allow_ops else 0.0) for k, v in self.base_weights.items()}
        self.behavior = behavior                                    # a soke.behavior.BehaviorProfile or None
        self.weights = self._behavior_weights()
        self.scorer = Scorer(probes, self.mg, cache_every=cache_every)
        self.trials: list[Trial] = []
        self.score: Optional[dict] = None
        self.hold: Optional[dict] = None
        self.best_hold_total = float("inf")
        self.hold_worse_streak = 0
        self.stop = False
        self.save_dir = Path(save_dir) if save_dir else None
        self.op_stats: dict[str, dict] = {k: {"tried": 0, "won": 0} for k in self.weights}
        # behavioral instrumentation (03/07): counts the map keeps honest
        self.proof_vetoes = 0            # P = ⊥ / ⊥⊥ dropped a candidate
        self.macro_blocked = 0           # P = ? refused to promote a grow move
        self.emo_overrides_blocked = 0   # a lawful-accept guard would-be trip (must stay 0)
        self.veto_bypass = 0             # accept without the priority veto check (must stay 0)
        self.reg_log: list = []          # per-accepted-trial regularizer snapshots
        self._apply_behavior_bar()

    # ------------------------------------------------------------ behavior
    def _behavior_weights(self) -> dict:
        """Operator weights tilted by the chemical mix (PARSE). Emotion re-weights the PROPOSAL only."""
        w = dict(self.base_weights)
        if self.behavior is None:
            return w
        mult = self.behavior.op_weight_multipliers()
        return {k: float(v) * float(mult.get(k, 1.0)) for k, v in w.items()}

    def _apply_behavior_bar(self) -> None:
        """The Z/GABA veto may only TIGHTEN the accept bar (min_gain up), never loosen it. Enforced by
        behavior.check_accept_lawful; emotion may not set TARGET_LOSS."""
        if self.behavior is None:
            return
        from .behavior import check_accept_lawful
        k = self.behavior.knobs()
        applied = self.base_min_gain * float(k["min_gain_mult"])
        check_accept_lawful(self.behavior, self.base_min_gain, applied, self.tol_priority, self.tol_priority)
        self.min_gain = applied

    def _focus_topic(self) -> Optional[str]:
        """NE vigilance: aim the next proposal at the worst-scoring topic (threat token). Returns a topic or None."""
        if self.behavior is None or not self.score or not self.score.get("topics"):
            return None
        if self.behavior.knobs()["focus_worst"] < 0.4:
            return None
        return max(self.score["topics"], key=self.score["topics"].get)

    # ---------------------------------------------------------------- events
    def emit(self, kind: str, payload: dict) -> None:
        if self.on_event:
            try:
                self.on_event(kind, payload)
            except Exception:
                pass
        if self.ledger is not None:
            try:
                self.ledger.append("FORGE", kind, payload, domain="parametric")
            except Exception:
                pass

    # ---------------------------------------------------------------- baseline
    def baseline(self) -> dict:
        self.score = self.scorer.score(self.spec, "train", None, keep_snaps=True)
        self.hold = self.scorer.score(self.spec, "holdout", None, keep_snaps=True)
        self.best_hold_total = self.hold["total"]
        self.emit("baseline", {"train": self.score, "holdout": self.hold, "spec": self.spec.summary()})
        self._save()
        return self.score

    # ---------------------------------------------------------------- proposals
    def _donors(self) -> list[str]:
        return list(self.spec.donors)

    def _other(self, current: Optional[str]) -> str:
        ds = [d for d in self._donors() if d != current]
        return ds[int(self.rng.integers(0, len(ds)))] if ds else (current or self._donors()[0])

    def _pick_expert(self, layer) -> int:
        """NE focus: if a worst-topic focus is set and this layer has that expert, target it; else random."""
        experts = layer["experts"]
        foc = getattr(self, "_focus", None)
        if foc:
            for i, e in enumerate(experts):
                if e.get("topic") == foc:
                    return i
        return int(self.rng.integers(0, len(experts)))

    def propose(self) -> tuple[ForgeSpec, int, str, str]:
        """Returns (candidate, changed_from_layer, operator, description)."""
        sp = self.spec.copy()
        L = sp.layers
        n = len(L)
        moe = bool(L[0].get("experts"))
        ops = [k for k, w in self.weights.items() if w > 0]
        w = np.array([self.weights[k] for k in ops], dtype=np.float64)
        for _ in range(20):
            op = ops[int(self.rng.choice(len(ops), p=w / w.sum()))]
            li = int(self.rng.integers(0, n))
            layer = L[li]
            if op == "swap_attn":
                cur = layer["attn"].get("donor")
                new = self._other(cur)
                layer["attn"] = op_copy(new)
                return sp, li, op, f"layer {li}: attention <- {new}"
            if op == "swap_expert" and moe:
                ei = self._pick_expert(layer)
                e = layer["experts"][ei]
                cur = e["op"].get("donor")
                new = self._other(cur)
                e["op"] = op_copy(new)
                return sp, li, op, f"layer {li}: expert '{e['topic']}' <- {new}"
            if op == "blend_expert" and moe:
                ei = self._pick_expert(layer)
                e = layer["experts"][ei]
                o = e["op"]
                if o["kind"] == "blend":
                    ws = dict(o["weights"])
                    k = list(ws)[int(self.rng.integers(0, len(ws)))]
                    ws[k] = float(ws[k] + self.rng.normal(0, 0.15))
                    tot = sum(ws.values()) or 1.0
                    ws = {kk: float(v / tot) for kk, v in ws.items()}
                else:
                    a = o.get("donor", self._donors()[0]); b = self._other(a)
                    t = float(self.rng.uniform(0.2, 0.8))
                    ws = {a: 1 - t, b: t}
                e["op"] = op_blend(ws)
                return sp, li, op, f"layer {li}: expert '{e['topic']}' blend {json.dumps({k: round(v, 2) for k, v in ws.items()})}"
            if op == "task_attn":
                base = layer["attn"].get("donor") or layer["attn"].get("base") or self._donors()[0]
                other = self._other(base)
                lam = float(self.rng.uniform(0.2, 1.0))
                layer["attn"] = op_task(base, {other: lam})
                return sp, li, op, f"layer {li}: attention = {base} + {lam:.2f}*({other} - {base})"
            if op == "extrapolate" and moe:
                ei = self._pick_expert(layer)
                e = layer["experts"][ei]
                a = e["op"].get("donor") or e["op"].get("base") or self._donors()[0]
                other = self._other(a)
                lam = float(self.rng.uniform(1.05, 1.6)) * (1 if self.rng.random() < 0.7 else -0.5)
                e["op"] = op_task(a, {other: lam})
                return sp, li, op, f"layer {li}: expert '{e['topic']}' = {a} + {lam:.2f}*({other} - {a})  [beyond the donors]"
            if op == "swap_shared" and layer.get("shared") and layer["shared"].get("topic"):
                cur = layer["shared"]["op"].get("donor")
                new = self._other(cur)
                if self.rng.random() < 0.5:
                    layer["shared"]["op"] = op_copy(new); desc = f"layer {li}: shared '{layer['shared']['topic']}' <- {new}"
                else:
                    t = float(self.rng.uniform(0.3, 0.7)); layer["shared"]["op"] = op_blend({cur or new: 1 - t, new: t}); desc = f"layer {li}: shared blend t={t:.2f} with {new}"
                return sp, li, op, desc
            if op == "gate_scale" and moe:
                g = layer.setdefault("gate", {"init": sp.d.get("gate_init", "lexicon"), "scale": 1.0})
                g["scale"] = float(g.get("scale", 1.0) * math.exp(self.rng.normal(0, 0.5)))
                return sp, li, op, f"layer {li}: gate scale -> {g['scale']:.2f}"
            if op == "gate_reinit" and moe:
                g = layer.setdefault("gate", {"init": "lexicon", "scale": 1.0})
                g["init"] = ["lexicon", "random", "zeros"][int(self.rng.integers(0, 3))]
                return sp, li, op, f"layer {li}: gate init -> {g['init']}"
            if op == "shexp_gain" and layer.get("shared") and layer["shared"].get("topic"):
                layer["shared"]["gain"] = float(layer["shared"].get("gain", 2.0) * math.exp(self.rng.normal(0, 0.3)))
                return sp, li, op, f"layer {li}: shared gain -> {layer['shared']['gain']:.2f}"
            if op == "swap_topics" and moe and len(layer["experts"]) > 1:
                i, j = self.rng.choice(len(layer["experts"]), size=2, replace=False)
                a, b = layer["experts"][int(i)], layer["experts"][int(j)]
                a["op"], b["op"] = b["op"], a["op"]
                return sp, li, op, f"layer {li}: swap experts '{a['topic']}' <-> '{b['topic']}'"
            if op == "swap_layer_src" and n > 1:
                src = int(layer.get("src_layer", li))
                new = src + (1 if self.rng.random() < 0.5 else -1)
                new = max(0, min(int(sp.d["hp"]["n_layer"]) - 1, new))
                if new == src:
                    continue
                layer["src_layer"] = new
                return sp, li, op, f"layer {li}: source layer {src} -> {new}"
            if op == "add_expert" and moe and len(layer["experts"]) < 8:
                from .tower import DOMAINS
                used = {e["topic"] for e in layer["experts"]}
                cands = [d.name for d in DOMAINS if d.name not in used]
                topic = cands[int(self.rng.integers(0, len(cands)))] if cands else f"extra{len(layer['experts'])}"
                donor = self._donors()[int(self.rng.integers(0, len(self._donors())))]
                for lay in L:                                   # the expert count is global (every layer)
                    lay["experts"].append({"topic": topic, "op": op_copy(donor)})
                return sp, 0, op, f"all layers: + expert '{topic}' <- {donor}  (grow)"
            if op == "drop_expert" and moe and len(layer["experts"]) > max(1, int(sp.d.get("n_used", 1))):
                ei = int(self.rng.integers(0, len(layer["experts"])))
                topic = layer["experts"][ei]["topic"]
                for lay in L:
                    if ei < len(lay["experts"]):
                        del lay["experts"][ei]
                sp.d["n_used"] = min(int(sp.d.get("n_used", 1)), len(L[0]["experts"]))
                return sp, 0, op, f"all layers: - expert '{topic}'  (heal)"
            if op == "dup_layer" and n < 2 * int(sp.d["hp"]["n_layer"]):
                L.insert(li + 1, json.loads(json.dumps(layer)))
                return sp, li + 1, op, f"duplicate layer {li} (depth {n} -> {n + 1})  (grow)"
            if op == "drop_layer" and n > 2:
                del L[li]
                return sp, li, op, f"drop layer {li} (depth {n} -> {n - 1})  (heal)"
        # nothing applicable: a no-op swap of attention on layer 0
        L[0]["attn"] = op_copy(self._other(L[0]["attn"].get("donor")))
        return sp, 0, "swap_attn", "layer 0: attention swapped (fallback)"

    # ---------------------------------------------------------------- trial
    def trial(self) -> Trial:
        if self.score is None:
            self.baseline()
        self._focus = self._focus_topic()                          # NE vigilance aims the next proposal
        cand, changed_from, op, desc = self.propose()
        t0 = time.time()
        self.op_stats.setdefault(op, {"tried": 0, "won": 0})["tried"] += 1
        try:
            sc = self.scorer.score(cand, "train", changed_from, keep_snaps=False)
        except Exception as e:
            tr = Trial(len(self.trials) + 1, op, desc + f"  [ERROR {type(e).__name__}: {e}]", changed_from, self.score["total"], float("nan"), False, seconds=time.time() - t0)
            self.trials.append(tr)
            self.emit("trial", tr.__dict__)
            return tr
        before, after = self.score["total"], sc["total"]
        gain = before - after
        finite = bool(np.isfinite(after))
        # --- logic pillar: the P proof-state gate (veto_and_shape_not_erase). It may only VETO or SHAPE.
        pstate = "TT"
        if self.behavior is not None and self.behavior.logic_enabled:
            from .behavior import proof_state
            pstate = proof_state(before, after, self.score["topics"], sc["topics"], op, finite, self.priority, self.tol_priority)
            if pstate == "BOTBOT":                                 # contradiction: freeze + rollback + audit
                self.proof_vetoes += 1
                desc += "  [P=⊥⊥ freeze+rollback]"
                self.emit("proof_veto", {"state": "BOTBOT", "op": op, "desc": desc})
            elif pstate == "Q" and op in getattr(self.behavior, "GROW_OPS", ()):
                self.macro_blocked += 1                            # ? -> do not promote to a macro act
                desc += "  [P=? macro not promoted]"
        # --- logic gate result: ⊥⊥ vetoes; ? refuses to promote a grow move; ⊤/⊥ leave the task test to decide.
        grow_ops = getattr(self.behavior, "GROW_OPS", ()) if self.behavior is not None else ()
        logic_ok = (pstate != "BOTBOT") and not (pstate == "Q" and op in grow_ops)
        # --- SELECT: task loss is the closer (Z/W). Emotion never enters this test.
        ok = finite and gain >= self.min_gain and logic_ok
        if ok and self.priority and self.priority in sc["topics"] and self.priority in self.score["topics"]:
            if sc["topics"][self.priority] > self.score["topics"][self.priority] * (1 + self.tol_priority):
                ok = False
                desc += f"  [priority '{self.priority}' would worsen]"
        elif ok and self.priority and self.priority in self.probes.topics and self.priority not in sc["topics"]:
            self.veto_bypass += 1                                  # accept-without-veto: must never happen
        hold_total = None
        if ok:
            # accept: refresh caches with the candidate, score hold-out, over-fit guard
            self.spec = cand
            self.score = self.scorer.score(cand, "train", changed_from, keep_snaps=True)
            self.hold = self.scorer.score(cand, "holdout", changed_from, keep_snaps=True)
            hold_total = self.hold["total"]
            if hold_total < self.best_hold_total - 1e-9:
                self.best_hold_total = hold_total
                self.best_holdout_spec = cand
                self.hold_worse_streak = 0
            else:
                self.hold_worse_streak += 1
            self.op_stats[op]["won"] += 1
            if self.behavior is not None:
                snap = {"trial": len(self.trials) + 1, "reg": self.behavior.regularizers(self.veto_bypass),
                        "happiness": self.behavior.happiness_mix(), "hire": self.behavior.hire_test()}
                self.reg_log.append(snap)
                if snap["reg"]["L_veto_bypass"] != 0:
                    raise ValueError("refusal: L_veto_bypass != 0 (SELECT was closed without the veto)")
            self._save()
        tr = Trial(len(self.trials) + 1, op, desc, changed_from, before, after, bool(ok), hold_total, round(time.time() - t0, 1), sc["topics"])
        self.trials.append(tr)
        self.emit("trial", tr.__dict__)
        if self.db is not None:
            try:
                self.db.log_experiment(lock="FORGE", family=op, hypothesis=desc, config={"changed_from": changed_from}, loss_before=before,
                                       loss_after=after, v_control=0.0, v_candidate=float(after - before) if np.isfinite(after) else 0.0,
                                       stable=bool(np.isfinite(after)), success=bool(ok), insights="forge trial")
            except Exception:
                pass
        if self.hold_worse_streak >= 3:
            self.emit("overfit_guard", {"streak": self.hold_worse_streak, "best_holdout": self.best_hold_total})
            self.spec = self.best_holdout_spec
            self.score = self.scorer.score(self.spec, "train", None, keep_snaps=True)
            self.hold = self.scorer.score(self.spec, "holdout", None, keep_snaps=True)
            self.hold_worse_streak = 0
        return tr

    def run(self, max_trials: int = 50, time_budget_s: Optional[float] = None) -> dict:
        t0 = time.time()
        if self.score is None:
            self.baseline()
        for _ in range(max_trials):
            if self.stop or (time_budget_s and time.time() - t0 > time_budget_s):
                break
            self.trial()
        return self.report()

    def report(self) -> dict:
        acc = [t for t in self.trials if t.accepted]
        rep = {"trials": len(self.trials), "accepted": len(acc), "nulls": len(self.trials) - len(acc), "train": self.score, "holdout": self.hold,
               "best_holdout": self.best_hold_total, "ops": self.op_stats, "evals": self.scorer.evals, "eval_seconds": round(self.scorer.seconds, 1),
               "spec": self.spec.summary()}
        if self.behavior is not None:
            rep["behavior"] = {"name": self.behavior.name, "min_gain_base": self.base_min_gain, "min_gain_applied": self.min_gain,
                               "proof_vetoes": self.proof_vetoes, "macro_blocked": self.macro_blocked,
                               "emo_overrides_blocked": self.emo_overrides_blocked, "veto_bypass": self.veto_bypass,
                               "happiness_mix": self.behavior.happiness_mix(), "last_reg": (self.reg_log[-1]["reg"] if self.reg_log else None)}
        return rep

    def _save(self) -> None:
        if not self.save_dir:
            return
        self.save_dir.mkdir(parents=True, exist_ok=True)
        (self.save_dir / "spec_best.json").write_text(self.spec.to_json(), encoding="utf-8")
        (self.save_dir / "spec_best_holdout.json").write_text(self.best_holdout_spec.to_json(), encoding="utf-8")
        st = {"t": iso_now(), "train": self.score, "holdout": self.hold, "trials": len(self.trials), "ops": self.op_stats}
        if self.behavior is not None:
            st["emo_coord"] = self.behavior.S_e; st["emo_chem"] = self.behavior.C; st["logic_coord"] = self.behavior.S_l
            st["happiness_mix"] = self.behavior.happiness_mix()
            st["proof_vetoes"] = self.proof_vetoes; st["emo_overrides_blocked"] = self.emo_overrides_blocked
            st["macro_blocked"] = self.macro_blocked; st["veto_bypass"] = self.veto_bypass
        (self.save_dir / "state.json").write_text(json.dumps(st, indent=1, default=str), encoding="utf-8")

    def export(self, out_path, use_holdout_best: bool = True, progress=None, clone_consent=None, clone_teeth=None) -> dict:
        spec = self.best_holdout_spec if use_holdout_best else self.spec
        return assemble(spec, out_path, memguard=self.mg, progress=progress, ledger=self.ledger,
                        behavior=self.behavior, clone_consent=clone_consent, clone_teeth=clone_teeth)


# ==========================================================================
# self-test
# ==========================================================================
def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    from .forge import _synthetic_family
    chk = chk or Check("forge_loop")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_floop_"))
    donors = _synthetic_family(tmpdir, 3)
    topics = ["math", "language"]
    # probes: token sequences from the synthetic vocab (the loop only needs ids); make 'math' text come from donor-1-like ids
    rng = Rng(3)
    V = 96
    probes = Probes(topics=topics, train={t: [list(rng.integers(0, V, 24)) for _ in range(3)] for t in topics},
                    holdout={t: [list(rng.integers(0, V, 24)) for _ in range(1)] for t in topics})
    probes.n_tokens = 24 * 8
    sp = ForgeSpec.preset("math-always-on", donors, topics + ["science"], shared_topic="math", n_used=2, topic_donor={"math": "D0", "language": "D1", "science": "D2"})
    tr = ForgeTrainer(sp, probes, priority_topic="math", min_gain=0.0, seed=1, cache_every=1, save_dir=tmpdir / "run")
    b = tr.baseline()
    chk("baseline scores every topic", set(b["topics"]) == set(topics) and np.isfinite(b["total"]), str(b))
    # partial recompute equals a full pass (cache correctness)
    cand, cf, op, desc = tr.propose()
    full = tr.scorer.score(cand, "train", None, keep_snaps=False)["total"]
    part = tr.scorer.score(cand, "train", cf, keep_snaps=False)["total"]
    chk("candidate scored from a cached boundary == full pass", abs(full - part) < 1e-5, f"{full:.6f} vs {part:.6f} (changed_from {cf}, op {op})")
    rep = tr.run(max_trials=12)
    chk("12 trials run; every trial recorded with a verdict", rep["trials"] == 12 and all(isinstance(t.accepted, bool) for t in tr.trials), f"accepted {rep['accepted']} nulls {rep['nulls']}")
    chk("ratchet: the current template never scored worse than the baseline", tr.score["total"] <= b["total"] + 1e-9, f"{b['total']:.5f} -> {tr.score['total']:.5f}")
    chk("spec checkpoints written", (tmpdir / "run" / "spec_best.json").exists() and (tmpdir / "run" / "state.json").exists())
    # export the best template and confirm the exported file reproduces its score
    out = tr.export(tmpdir / "best.gguf", use_holdout_best=False)
    m = LLM(tmpdir / "best.gguf", resident="f32")
    seqs, _ = probes.flat("train")
    re_total = m.nll_batch(seqs)["nll"]
    m.close()
    chk("exported GGUF reproduces the template's training score (|d| < 2e-2 after Q8 requant)", abs(re_total - tr.score["total"]) < 2e-2, f"{re_total:.5f} vs {tr.score['total']:.5f}")
    # operators: growth and heal produce loadable templates
    tr2 = ForgeTrainer(sp, probes, allow_ops=["dup_layer", "add_expert", "drop_layer", "drop_expert"], min_gain=-1.0, seed=2, cache_every=1)
    tr2.baseline()
    ops_seen = set()
    for _ in range(8):
        t = tr2.trial(); ops_seen.add(t.op)
    chk("grow/heal operators all applicable and scored", ops_seen >= {"dup_layer", "add_expert"} and all(np.isfinite(t.after) for t in tr2.trials), str(sorted(ops_seen)))
    # --- behavioral conditioning (modulate-not-govern): a climate tilts the proposal and tightens the bar,
    #     never loosens it; the run reports the veto counts and a happiness mix.
    from .behavior import CLIMATES
    trb = ForgeTrainer(sp, probes, priority_topic="math", min_gain=0.001, seed=4, cache_every=1, behavior=CLIMATES["scarcity"])
    chk("high-CORT climate tightens the accept bar (min_gain up, never down)", trb.min_gain >= trb.base_min_gain and trb.min_gain > 0.001 - 1e-12,
        f"base {trb.base_min_gain} -> applied {trb.min_gain}")
    chk("high-CORT climate zeroes the grow-op weights (heal-first)", trb.weights.get("add_expert", 0.0) == 0.0 and trb.weights.get("dup_layer", 0.0) == 0.0)
    repb = trb.run(max_trials=8)
    chk("behavior run reports veto counts and a happiness mix; veto_bypass stays 0", repb["behavior"]["veto_bypass"] == 0 and "happiness_mix" in repb["behavior"],
        str(repb["behavior"]))
    chk("no grow op was ever tried under the high-CORT climate", all(t.op not in ("add_expert", "dup_layer") for t in trb.trials), str(sorted({t.op for t in trb.trials})))
    # a focus climate (NE high) still keeps SELECT lawful and never bypasses the priority veto
    trf = ForgeTrainer(sp, probes, priority_topic="math", min_gain=0.0, seed=5, cache_every=1, behavior=CLIMATES["focus"])
    trf.run(max_trials=6)
    chk("focus climate: priority veto never bypassed (L_veto_bypass == 0)", trf.veto_bypass == 0)
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
