"""
soke.gui_connectome — the Connectome tab: build a neuron+synapse graph, keep it in SFF, push a signal
through it, find pathways, and train a readout policy on the motor output. A point-and-click face for
soke.connectome_engine. The connectome is the SCAFFOLD; SOKE's policy learns on top.

Four pages:
    1 Build     synthetic / your CSV / neuPrint (male-cns:v1.0) -> a connectome, saved inside an .sff
    2 Simulate  inject sensory neurons, run N ticks, read the descending (motor) neurons
    3 Pathways  the strongest synapse chains from an input group to an output group
    4 Policy    train a readout (linear or MLP) on the motor output — the "learn on top" step
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import theme as _T
BG = _T.PAPER
OK = _T.OK
WARN = _T.WARN
BAD = _T.BAD
DIM = _T.DIM
SLATE = _T.SLATE
MONO = _T.MONO


class ConnectomeTab:
    def __init__(self, app, frame: ttk.Frame):
        self.app = app
        self.f = frame
        self.cnx = None                                  # a connectome_engine.Connectome once built/loaded
        self.policy = None
        self.cnx_dir = self.app.root_dir / "connectome"
        self._build()

    # ------------------------------------------------------------- layout
    def _build(self) -> None:
        nb = ttk.Notebook(self.f)
        nb.pack(fill="both", expand=True, padx=6, pady=6)
        self.nb = nb
        self.p_build, self.p_sim, self.p_path, self.p_policy, self.p_concepts = (ttk.Frame(nb) for _ in range(5))
        for fr, n in ((self.p_build, "1 Build"), (self.p_sim, "2 Simulate"),
                      (self.p_path, "3 Pathways"), (self.p_policy, "4 Policy"), (self.p_concepts, "5 Concepts")):
            nb.add(fr, text=n)
        self.cg = None                                    # a concept_graph.ConceptGraph once built
        self._build_build(); self._build_sim(); self._build_path(); self._build_policy(); self._build_concepts()

    def _text(self, parent, height=14):
        t = tk.Text(parent, wrap="word", height=height, bg=_T.PAPER_HI, fg=_T.INK, font=MONO,
                    bd=2, relief="sunken", padx=8, pady=6)
        t.pack(fill="both", expand=True, padx=6, pady=6)
        return t

    def _say(self, box, s: str, clear: bool = True) -> None:
        if clear:
            box.delete("1.0", "end")
        box.insert("end", s)
        box.see("end")

    def _need_cnx(self) -> bool:
        if self.cnx is None:
            messagebox.showinfo("SOKE", "Build or load a connectome first (page 1 Build).")
            return False
        return True

    # ---- 1 build ---------------------------------------------------------
    def _build_build(self) -> None:
        t = self.p_build
        tk.Label(t, text="A connectome is a map of neurons (nodes) and synapses (edges). Build one three ways, then it is "
                         "stored inside an .sff — paged and checksummed. The wiring is the scaffold; SOKE learns on top.",
                 bg=BG, fg=SLATE, font=_T.font(8), anchor="w", justify="left", wraplength=1120).pack(fill="x", padx=8, pady=(8, 2))

        # synthetic
        syn = tk.LabelFrame(t, text=" synthetic — a made-up brain of any size (to test the machinery) ", bg=BG, fg=SLATE, font=_T.font(8, True))
        syn.pack(fill="x", padx=8, pady=4)
        row = tk.Frame(syn, bg=BG); row.pack(fill="x", padx=4, pady=2)
        self.v_nodes = tk.StringVar(value="50000"); self.v_deg = tk.StringVar(value="12"); self.v_seed = tk.StringVar(value="0")
        for lab, var, w in (("neurons", self.v_nodes, 9), ("avg synapses/neuron", self.v_deg, 5), ("seed", self.v_seed, 5)):
            tk.Label(row, text=lab, bg=BG, fg=DIM).pack(side="left", padx=(6, 2))
            ttk.Entry(row, textvariable=var, width=w).pack(side="left")
        ttk.Button(row, text="Build synthetic", style="Accent.TButton", command=self._build_synth).pack(side="left", padx=10)

        # csv / sff
        io = tk.LabelFrame(t, text=" your own data ", bg=BG, fg=SLATE, font=_T.font(8, True))
        io.pack(fill="x", padx=8, pady=4)
        row2 = tk.Frame(io, bg=BG); row2.pack(fill="x", padx=4, pady=2)
        ttk.Button(row2, text="Ingest edge-list CSV…", command=self._ingest_csv).pack(side="left")
        tk.Label(row2, text="(columns: bodyId_pre, bodyId_post, weight [, type_pre, type_post])", bg=BG, fg=DIM).pack(side="left", padx=6)
        row2b = tk.Frame(io, bg=BG); row2b.pack(fill="x", padx=4, pady=2)
        ttk.Button(row2b, text="Load a connectome .sff…", command=self._load_sff).pack(side="left")
        ttk.Button(row2b, text="Save current → .sff…", command=self._save_sff).pack(side="left", padx=6)

        # neuprint
        npf = tk.LabelFrame(t, text=" neuPrint (real fly-brain slice — needs neuprint-python + your token, runs on THIS machine) ", bg=BG, fg=SLATE, font=_T.font(8, True))
        npf.pack(fill="x", padx=8, pady=4)
        row3 = tk.Frame(npf, bg=BG); row3.pack(fill="x", padx=4, pady=2)
        self.v_ds = tk.StringVar(value="male-cns:v1.0"); self.v_types = tk.StringVar(value="DN.*"); self.v_token = tk.StringVar(value="")
        tk.Label(row3, text="dataset", bg=BG, fg=DIM).pack(side="left", padx=(6, 2)); ttk.Entry(row3, textvariable=self.v_ds, width=16).pack(side="left")
        tk.Label(row3, text="type regex", bg=BG, fg=DIM).pack(side="left", padx=(8, 2)); ttk.Entry(row3, textvariable=self.v_types, width=10).pack(side="left")
        tk.Label(row3, text="token", bg=BG, fg=DIM).pack(side="left", padx=(8, 2)); ttk.Entry(row3, textvariable=self.v_token, width=22, show="•").pack(side="left")
        ttk.Button(row3, text="Pull from neuPrint", command=self._pull_neuprint).pack(side="left", padx=10)

        self.b_info = self._text(t, height=12)
        self._say(self.b_info, "No connectome yet. Build a synthetic one, ingest a CSV, load an .sff, or pull from neuPrint.")

    def _build_synth(self) -> None:
        try:
            n = int(self.v_nodes.get()); d = int(self.v_deg.get()); s = int(self.v_seed.get())
        except ValueError:
            messagebox.showerror("SOKE", "neurons / degree / seed must be whole numbers"); return
        self._say(self.b_info, f"building a synthetic connectome: {n:,} neurons, ~{d} synapses each…")

        def job():
            from .connectome_engine import Connectome
            return Connectome.synthetic(n_nodes=n, avg_degree=d, seed=s)

        def done(c):
            self.cnx = c
            self._say(self.b_info, c.describe())
            self._refresh_taps()
            self.app.status_var.set(f"connectome: {c.n:,} neurons, {c.n_edges:,} synapses")
        self.app.run_job("connectome build", job, done)

    def _ingest_csv(self) -> None:
        p = filedialog.askopenfilename(title="Edge-list CSV", filetypes=[("CSV", "*.csv"), ("All", "*.*")])
        if not p:
            return
        self._say(self.b_info, f"reading {Path(p).name}…")

        def job():
            from .connectome_engine import Connectome
            return Connectome.from_csv(p)

        def done(c):
            self.cnx = c; self._say(self.b_info, c.describe()); self._refresh_taps()
        self.app.run_job("connectome ingest", job, done)

    def _load_sff(self) -> None:
        p = filedialog.askopenfilename(title="Connectome .sff", filetypes=[("SFF", "*.sff"), ("All", "*.*")])
        if not p:
            return

        def job():
            from .connectome_engine import Connectome
            return Connectome.from_sff(p)

        def done(c):
            self.cnx = c; self._say(self.b_info, c.describe()); self._refresh_taps()
            try:
                self.app.imports.add_model(p)
            except Exception:
                pass
        self.app.run_job("connectome load", job, done)

    def _save_sff(self) -> None:
        if not self._need_cnx():
            return
        self.cnx_dir.mkdir(parents=True, exist_ok=True)
        p = filedialog.asksaveasfilename(title="Save connectome", defaultextension=".sff",
                                         initialdir=str(self.cnx_dir), initialfile=f"{self.cnx.name}.sff")
        if not p:
            return

        def job():
            return self.cnx.to_sff(p, memguard=self.app.mg)

        def done(st):
            self._say(self.b_info, self.cnx.describe() + f"\n\nsaved -> {p}  ({st['bytes']/1e6:.1f} MB)")
            try:
                self.app.imports.add_model(p)
            except Exception:
                pass
        self.app.run_job("connectome save", job, done)

    def _pull_neuprint(self) -> None:
        ds = self.v_ds.get().strip(); ty = self.v_types.get().strip(); tok = self.v_token.get().strip()
        self._say(self.b_info, f"pulling {ds} (types {ty}) from neuPrint… this runs on your machine and needs neuprint-python + your token.")

        def job():
            from .connectome_engine import Connectome
            return Connectome.from_neuprint(dataset=ds, token=tok, type_regex=ty)

        def done(c):
            self.cnx = c; self._say(self.b_info, c.describe()); self._refresh_taps()

        def err(e):
            self._say(self.b_info, f"neuPrint pull could not run:\n  {type(e).__name__}: {e}\n\n"
                                   "Install it on this machine (pip install neuprint-python) and paste your token, "
                                   "or export an edge list and use 'Ingest edge-list CSV' instead.")
        self.app.run_job("connectome neuprint", job, done, on_error=err)

    # ---- 2 simulate ------------------------------------------------------
    def _build_sim(self) -> None:
        t = self.p_sim
        tk.Label(t, text="Inject a signal at the input (sensory) neurons, let it flow along the synapses for a few ticks, and "
                         "read what arrives at the output (descending / motor) neurons.", bg=BG, fg=SLATE, font=_T.font(8),
                 anchor="w", justify="left", wraplength=1120).pack(fill="x", padx=8, pady=(8, 2))
        row = tk.Frame(t, bg=BG); row.pack(fill="x", padx=8, pady=4)
        self.v_in = tk.StringVar(value="SEN.*"); self.v_out = tk.StringVar(value="DN.*")
        self.v_ticks = tk.StringVar(value="8"); self.v_fan = tk.StringVar(value="64"); self.v_decay = tk.StringVar(value="0.8")
        for lab, var, w in (("input type", self.v_in, 10), ("output type", self.v_out, 10),
                            ("ticks", self.v_ticks, 5), ("inject #", self.v_fan, 6), ("decay", self.v_decay, 5)):
            tk.Label(row, text=lab, bg=BG, fg=DIM).pack(side="left", padx=(6, 2))
            ttk.Entry(row, textvariable=var, width=w).pack(side="left")
        ttk.Button(row, text="Run signal", style="Accent.TButton", command=self._run_sim).pack(side="left", padx=10)
        self.s_out = self._text(t)
        self._say(self.s_out, "Build a connectome (page 1), then run a signal here.")

    def _run_sim(self) -> None:
        if not self._need_cnx():
            return
        try:
            ticks = int(self.v_ticks.get()); fan = int(self.v_fan.get()); decay = float(self.v_decay.get())
        except ValueError:
            messagebox.showerror("SOKE", "ticks / inject # must be whole numbers, decay a number"); return
        in_re, out_re = self.v_in.get().strip(), self.v_out.get().strip()

        def job():
            import numpy as np
            src = self.cnx.group(in_re); out = self.cnx.group(out_re)
            if src.size == 0:
                return {"err": f"no input neurons match {in_re!r}"}
            vals = np.ones(min(src.size, fan), dtype=np.float32)
            read = self.cnx.simulate(src[:fan], vals, ticks=ticks, readout_idx=out, decay=decay, memguard=self.app.mg)
            order = np.argsort(-np.abs(read))[:20]
            return {"src": int(min(src.size, fan)), "in": in_re, "out_n": int(out.size), "out": out_re,
                    "mean": float(np.mean(np.abs(read))) if read.size else 0.0,
                    "top": [(int(out[i]), float(read[i])) for i in order] if out.size else []}

        def done(r):
            if "err" in r:
                self._say(self.s_out, r["err"]); return
            lines = [f"injected {r['src']} {r['in']} neurons → read {r['out_n']} {r['out']} neurons over the run.",
                     f"mean |activity| at the readout = {r['mean']:.4f}", "", "strongest motor outputs:"]
            lines += [f"  neuron {nid:<8} {val:+.4f}" for nid, val in r["top"]]
            self._say(self.s_out, "\n".join(lines))
        self.app.run_job("connectome sim", job, done)

    # ---- 3 pathways ------------------------------------------------------
    def _build_path(self) -> None:
        t = self.p_path
        tk.Label(t, text="The strongest synapse chains from an input group to an output group. A stronger synapse is a "
                         "cheaper hop, so a low-cost route is a high-strength pathway.", bg=BG, fg=SLATE, font=_T.font(8),
                 anchor="w", justify="left", wraplength=1120).pack(fill="x", padx=8, pady=(8, 2))
        row = tk.Frame(t, bg=BG); row.pack(fill="x", padx=8, pady=4)
        self.v_pin = tk.StringVar(value="SEN.*"); self.v_pout = tk.StringVar(value="DN.*")
        self.v_k = tk.StringVar(value="8"); self.v_hops = tk.StringVar(value="8")
        for lab, var, w in (("from type", self.v_pin, 10), ("to type", self.v_pout, 10), ("routes", self.v_k, 5), ("max hops", self.v_hops, 5)):
            tk.Label(row, text=lab, bg=BG, fg=DIM).pack(side="left", padx=(6, 2))
            ttk.Entry(row, textvariable=var, width=w).pack(side="left")
        ttk.Button(row, text="Find pathways", style="Accent.TButton", command=self._find_paths).pack(side="left", padx=10)
        self.p_out = self._text(t)
        self._say(self.p_out, "Build a connectome (page 1), then trace pathways here.")

    def _find_paths(self) -> None:
        if not self._need_cnx():
            return
        try:
            k = int(self.v_k.get()); hops = int(self.v_hops.get())
        except ValueError:
            messagebox.showerror("SOKE", "routes / max hops must be whole numbers"); return
        pin, pout = self.v_pin.get().strip(), self.v_pout.get().strip()

        def job():
            src = self.cnx.group(pin); dst = self.cnx.group(pout)
            return {"routes": self.cnx.pathways(src, dst, k=k, max_hops=hops), "pin": pin, "pout": pout,
                    "ns": int(src.size), "nd": int(dst.size)}

        def done(r):
            if not r["routes"]:
                self._say(self.p_out, f"no route from {r['pin']} ({r['ns']} neurons) to {r['pout']} ({r['nd']} neurons) "
                                      f"within {hops} hops."); return
            lines = [f"{len(r['routes'])} route(s) {r['pin']} → {r['pout']} (cost = Σ 1/synapse-weight, cheapest first):", ""]
            for path, cost in r["routes"]:
                lines.append(f"  cost {cost:.4f}  {len(path)-1} hop(s):  " + " → ".join(str(p) for p in path))
            self._say(self.p_out, "\n".join(lines))
        self.app.run_job("connectome pathways", job, done)

    # ---- 4 policy --------------------------------------------------------
    def _build_policy(self) -> None:
        t = self.p_policy
        tk.Label(t, text="The 'learn on top' step. SOKE stimulates each sensory group, reads the motor output, and trains a "
                         "readout to tell the groups apart from that output alone. The connectome is the wiring; THIS is the "
                         "part that learns. Linear = a fitted line; MLP = a small network that can learn nonlinear splits.",
                 bg=BG, fg=SLATE, font=_T.font(8), anchor="w", justify="left", wraplength=1120).pack(fill="x", padx=8, pady=(8, 2))
        row = tk.Frame(t, bg=BG); row.pack(fill="x", padx=8, pady=4)
        self.v_kind = tk.StringVar(value="mlp")
        ttk.Radiobutton(row, text="MLP (nonlinear)", value="mlp", variable=self.v_kind).pack(side="left")
        ttk.Radiobutton(row, text="Linear", value="linear", variable=self.v_kind).pack(side="left", padx=(6, 12))
        self.v_groups = tk.StringVar(value="4"); self.v_per = tk.StringVar(value="20"); self.v_pticks = tk.StringVar(value="6")
        for lab, var, w in (("sensory groups", self.v_groups, 4), ("samples/group", self.v_per, 4), ("ticks", self.v_pticks, 4)):
            tk.Label(row, text=lab, bg=BG, fg=DIM).pack(side="left", padx=(6, 2))
            ttk.Entry(row, textvariable=var, width=w).pack(side="left")
        ttk.Button(row, text="Train readout policy", style="Accent.TButton", command=self._train_policy).pack(side="left", padx=10)
        self.pol_out = self._text(t)
        self._say(self.pol_out, "Build a connectome (page 1), then train a readout here.")

    def _train_policy(self) -> None:
        if not self._need_cnx():
            return
        try:
            ng = int(self.v_groups.get()); per = int(self.v_per.get()); ticks = int(self.v_pticks.get())
        except ValueError:
            messagebox.showerror("SOKE", "groups / samples / ticks must be whole numbers"); return
        kind = self.v_kind.get()
        self._say(self.pol_out, f"stimulating {ng} sensory groups × {per} samples, reading motor output, training a {kind} readout…")

        def job():
            import numpy as np
            from .connectome_engine import MLPPolicy, LinearReadout, _one_hot
            c = self.cnx
            dn = c.descending()
            sen = c.sensory()
            if dn.size == 0 or sen.size < ng * 4:
                return {"err": f"need descending neurons and at least {ng*4} sensory neurons "
                               f"(have DN={dn.size}, SEN={sen.size}). Try a bigger connectome or fewer groups."}
            gsz = max(4, sen.size // ng)
            jit = __import__("soke.rng", fromlist=["Rng"]).Rng(7)
            X, y = [], []
            for g in range(ng):
                grp = sen[g * gsz:(g + 1) * gsz]
                if grp.size == 0:
                    continue
                for _ in range(per):
                    vals = (1.0 + 0.1 * jit.normal(0, 1, size=grp.size)).astype(np.float32)
                    X.append(c.simulate(grp, vals, ticks=ticks, readout_idx=dn, memguard=self.app.mg)); y.append(g)
            X = np.asarray(X, dtype=np.float64); y = np.asarray(y, dtype=np.int64)
            labels = [f"group{g}" for g in range(ng)]
            if kind == "mlp":
                pol = MLPPolicy(dn.size, n_hidden=16, n_out=ng, labels=labels, seed=1).fit_supervised(X, y, epochs=500, lr=0.3)
                acc = pol.accuracy(X, y)
            else:
                ro = LinearReadout().fit(X, _one_hot(y, ng), labels=labels)
                pred = np.array([ro.predict(x.astype(np.float32)).argmax() for x in X])
                acc = float((pred == y).mean()); pol = ro
            return {"acc": float(acc), "kind": kind, "dn": int(dn.size), "n": int(X.shape[0]), "ng": ng, "pol": pol}

        def done(r):
            if "err" in r:
                self._say(self.pol_out, r["err"]); return
            self.policy = r["pol"]
            verdict = ("the readout tells the groups apart from motor output alone."
                       if r["acc"] >= 0.9 else "the readout only partly separates them — try the MLP, more ticks, or a denser graph.")
            self._say(self.pol_out,
                      f"trained a {r['kind'].upper()} readout on {r['n']} samples of {r['dn']}-neuron motor output "
                      f"({r['ng']} sensory groups).\n\n  accuracy = {r['acc']*100:.1f}%\n\n{verdict}\n\n"
                      "This is SOKE learning ON TOP of the connectome scaffold — the same readout takes text features, "
                      "game state or sensor values in place of the sensory stimulus.")
        self.app.run_job("connectome policy", job, done)

    # ---- 5 concepts (the expandable concept graph) -----------------------
    def _build_concepts(self) -> None:
        t = self.p_concepts
        tk.Label(t, text="The EXPANDABLE concept graph. Each concept (a topic / knowledge unit) gets a number of ROUTES sized "
                         "to its complexity — a simple idea gets 1, a complex one up to 50 — through a Tree-of-Life motif that "
                         "stacks into more 'worlds' (more vessels) as it grows. Build one here and it becomes the connectome the "
                         "other pages simulate, trace and train on.", bg=BG, fg=SLATE, font=_T.font(8), anchor="w",
                 justify="left", wraplength=1120).pack(fill="x", padx=8, pady=(8, 2))
        src = tk.LabelFrame(t, text=" size the concepts ", bg=BG, fg=SLATE, font=_T.font(8, True)); src.pack(fill="x", padx=8, pady=4)
        row = tk.Frame(src, bg=BG); row.pack(fill="x", padx=4, pady=2)
        ttk.Button(row, text="Auto-size from imported text", style="Accent.TButton", command=self._cpt_auto).pack(side="left")
        tk.Label(row, text="(each imported .txt/.md becomes a concept, sized by its own entropy)", bg=BG, fg=DIM).pack(side="left", padx=6)
        row2 = tk.Frame(src, bg=BG); row2.pack(fill="x", padx=4, pady=2)
        tk.Label(row2, text="or type concepts:", bg=BG, fg=DIM).pack(side="left")
        self.v_concepts = tk.StringVar(value="arithmetic:0.05, language:0.9, music:0.4, physics:0.5")
        ttk.Entry(row2, textvariable=self.v_concepts, width=64).pack(side="left", padx=4)
        tk.Label(row2, text="max routes", bg=BG, fg=DIM).pack(side="left", padx=(8, 2))
        self.v_hi = tk.StringVar(value="50"); ttk.Entry(row2, textvariable=self.v_hi, width=5).pack(side="left")
        ttk.Button(row2, text="Build", style="Accent.TButton", command=self._cpt_build).pack(side="left", padx=8)
        grow = tk.LabelFrame(t, text=" grow / prune at the significant steps ", bg=BG, fg=SLATE, font=_T.font(8, True)); grow.pack(fill="x", padx=8, pady=4)
        row3 = tk.Frame(grow, bg=BG); row3.pack(fill="x", padx=4, pady=2)
        tk.Label(row3, text="concept", bg=BG, fg=DIM).pack(side="left", padx=(6, 2))
        self.v_cname = tk.StringVar(value="language"); ttk.Entry(row3, textvariable=self.v_cname, width=16).pack(side="left")
        tk.Label(row3, text="routes ±", bg=BG, fg=DIM).pack(side="left", padx=(8, 2))
        self.v_camt = tk.StringVar(value="8"); ttk.Entry(row3, textvariable=self.v_camt, width=5).pack(side="left")
        ttk.Button(row3, text="Grow", command=lambda: self._cpt_grow(+1)).pack(side="left", padx=(8, 2))
        ttk.Button(row3, text="Prune", command=lambda: self._cpt_grow(-1)).pack(side="left")
        ttk.Button(row3, text="Save graph → .sff…", command=self._cpt_save).pack(side="left", padx=14)
        self.cpt_out = self._text(t)
        self._say(self.cpt_out, "Build a concept graph. It compiles to a connectome — pages 2–4 then run on it.")

    def _cpt_from_entry(self):
        spec = {}
        for item in self.v_concepts.get().split(","):
            if ":" in item:
                n, v = item.split(":", 1)
                try:
                    spec[n.strip()] = float(v)
                except ValueError:
                    pass
        return spec

    def _cpt_hi(self):
        try:
            return int(self.v_hi.get())
        except ValueError:
            return 50

    def _cpt_show(self, cg):
        self.cg = cg
        self.cnx = cg.build()                              # the concept graph IS the connectome now
        self._say(self.cpt_out, cg.describe() + "\n\nThis graph is now loaded as the connectome — go to Simulate / Pathways / "
                                "Policy to run on it. Grow or prune a concept above to change its routes.")
        self._refresh_taps()

    def _cpt_build(self) -> None:
        spec = self._cpt_from_entry()
        if not spec:
            messagebox.showinfo("SOKE", "Type concepts as name:complexity, e.g. language:0.9"); return
        hi = self._cpt_hi()

        def job():
            from .concept_graph import ConceptGraph
            return ConceptGraph.from_complexities(spec, hi=hi)
        self.app.run_job("concept build", job, self._cpt_show)

    def _cpt_auto(self) -> None:
        files = [f for f in getattr(self.app.imports, "files", []) if str(f).lower().endswith((".txt", ".md"))]
        if not files:
            self._say(self.cpt_out, "No imported text files yet. Use the Import tab (or Knowledge → Load sample corpus) to add "
                                    ".txt/.md files, then Auto-size."); return
        hi = self._cpt_hi()

        def job():
            from .concept_graph import ConceptGraph
            texts = {}
            for f in files:
                try:
                    texts[Path(f).stem] = Path(f).read_text(encoding="utf-8", errors="replace")
                except Exception:
                    continue
            return ConceptGraph.auto_size_from_texts(texts, hi=hi)
        self.app.run_job("concept auto-size", job, self._cpt_show)

    def _cpt_grow(self, sign: int) -> None:
        if self.cg is None:
            messagebox.showinfo("SOKE", "Build a concept graph first."); return
        name = self.v_cname.get().strip()
        if name not in self.cg.routes:
            messagebox.showinfo("SOKE", f"'{name}' is not one of: {', '.join(self.cg.routes)}"); return
        try:
            amt = int(self.v_camt.get())
        except ValueError:
            amt = 1
        self.cg.grow(name, sign * amt)
        self._cpt_show(self.cg)

    def _cpt_save(self) -> None:
        if self.cg is None:
            messagebox.showinfo("SOKE", "Build a concept graph first."); return
        self.cnx_dir.mkdir(parents=True, exist_ok=True)
        p = filedialog.asksaveasfilename(title="Save concept graph", defaultextension=".sff",
                                         initialdir=str(self.cnx_dir), initialfile="concepts.sff")
        if not p:
            return

        def job():
            return self.cg.to_sff(p, memguard=self.app.mg)

        def done(st):
            self._say(self.cpt_out, self.cg.describe() + f"\n\nsaved -> {p}  ({st['bytes']/1e6:.1f} MB)")
            try:
                self.app.imports.add_model(p)
            except Exception:
                pass
        self.app.run_job("concept save", job, done)

    # ---- shared ----------------------------------------------------------
    def _refresh_taps(self) -> None:
        if self.cnx is None:
            return
        try:
            self.v_in.set("SEN.*"); self.v_out.set("DN.*"); self.v_pin.set("SEN.*"); self.v_pout.set("DN.*")
        except Exception:
            pass
