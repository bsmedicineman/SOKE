"""
soke.actg_parser — the ACTG strand language and the ACTG -> frame parser.

Strand grammar (SOKE-ACTG v1):
    strand  := tooth (WS tooth)*
    tooth   := BASE '[' domain (':' ident)? ']' payload? ('~' tooth)?
    payload := '{' text '}'            (a literal '}' inside text is written '\\}')
    BASE    := 'A' | 'C' | 'T' | 'G'   (Axiom, Concept, Technique, Grounding)

    A[math:peano]{0 is a natural number} ~ T[math:induction]{P(0) & (P(n)->P(n+1)) => forall n P(n)}

'~' binds a tooth to its complementary partner. Legal pairs (META.pairing_rules,
default SOKE layout): A-T, C-G, A-C, T-G; A-G and C-T are rejected at parse time —
the strand cannot physically carry an illegal pairing (DNA-polymerase discipline).

ACTG -> frames: a numeric payload becomes a real frame in the domain's default
register gauge; a text payload becomes the unity square (1,1) carrying the record
as metadata — no magnitude is invented for text (the DeepAI draft hashed text into
pseudo-floats; that is not a measurement and is not done here).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from .frame_engine import GAUGE_LIN, GAUGES, Frame, KIND_TO_GAUGE
from .teeth import LEGAL_PAIRS, ToothRecord, pair_legal
from .tower import BY_NAME, domain_id, domain_name

_TOK = re.compile(r"""
    (?P<ws>\s+)
  | (?P<base>[ACTG])\[(?P<domain>[a-zA-Z_][a-zA-Z0-9_]*)(?::(?P<ident>[^\]\s]+))?\]
  | (?P<payload>\{(?:\\\}|[^}])*\})
  | (?P<tie>~)
""", re.X)
_NUM = re.compile(r"^\s*([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)\s*([A-Za-z/^0-9\-]*)\s*$")
REG_CODE = {"R": 0, "Q": 1, "T": 2, "L": 3, "H": 4, "LIN": 5}


class ACTGError(ValueError):
    pass


@dataclass
class Tooth:
    base: str
    domain: str
    ident: str = ""
    text: str = ""
    partner: Optional["Tooth"] = None

    def to_record(self, pair_ref: int = 0xFFFFFFFF) -> ToothRecord:
        d = BY_NAME.get(domain_name(domain_id(self.domain)))
        gauge = 5
        if d and d.registers:
            gauge = REG_CODE.get(d.registers[0], 5)
        flags = 0
        if _NUM.match(self.text or ""):
            flags |= 4
        if self.partner is None:
            flags |= 1          # PAIRED_PENDING
        return ToothRecord(self.base, domain_id(self.domain), self.ident, self.text, gauge, flags, pair_ref)


def parse_strand(src: str, legal: Optional[set] = None) -> list[Tooth]:
    legal = legal or LEGAL_PAIRS
    teeth: list[Tooth] = []
    pos = 0
    pending_tie = False
    n = len(src)
    while pos < n:
        m = _TOK.match(src, pos)
        if not m:
            raise ACTGError(f"syntax error at {pos}: {src[pos:pos + 20]!r}")
        pos = m.end()
        if m.group("ws"):
            continue
        if m.group("tie"):
            if not teeth:
                raise ACTGError("'~' with no left tooth")
            pending_tie = True
            continue
        if m.group("payload"):
            if not teeth:
                raise ACTGError("payload with no tooth")
            if teeth[-1].text:
                raise ACTGError("two payloads on one tooth")
            teeth[-1].text = m.group("payload")[1:-1].replace("\\}", "}")
            continue
        base, dom, ident = m.group("base"), m.group("domain"), m.group("ident") or ""
        try:
            domain_id(dom)
        except KeyError:
            raise ACTGError(f"unknown domain {dom!r}")
        t = Tooth(base, dom, ident)
        if pending_tie:
            left = teeth[-1]
            if not pair_legal(left.base, base, legal):
                raise ACTGError(f"illegal pairing {left.base}-{base} ({left.domain}:{left.ident} ~ {dom}:{ident})")
            left.partner = t
            t.partner = left
            pending_tie = False
        teeth.append(t)
    if pending_tie:
        raise ACTGError("dangling '~'")
    return teeth


def strand_to_records(teeth: list[Tooth]) -> list[ToothRecord]:
    """Records in strand order; partner links become pair_ref indexes (into this list)."""
    idx = {id(t): i for i, t in enumerate(teeth)}
    out = []
    for t in teeth:
        ref = idx[id(t.partner)] if t.partner is not None else 0xFFFFFFFF
        out.append(t.to_record(ref))
    return out


def records_to_strand(records: list[ToothRecord]) -> str:
    parts = []
    seen_pairs = set()
    i = 0
    while i < len(records):
        r = records[i]
        s = _fmt(r)
        if r.pair_ref != 0xFFFFFFFF and r.pair_ref == i + 1 and i + 1 < len(records) and records[i + 1].pair_ref == i:
            s += " ~ " + _fmt(records[i + 1])
            i += 2
        else:
            i += 1
        parts.append(s)
    return "\n".join(parts)


def _fmt(r: ToothRecord) -> str:
    head = f"{r.base}[{domain_name(r.domain)}" + (f":{r.ident}" if r.ident else "") + "]"
    if r.text:
        head += "{" + r.text.replace("}", "\\}") + "}"
    return head


def record_to_frame(r: ToothRecord) -> Frame:
    gauge = KIND_TO_GAUGE.get(r.gauge, GAUGE_LIN)
    m = _NUM.match(r.text or "")
    if m:
        v = float(m.group(1))
        if v != 0:
            f = Frame.from_value(v, gauge)
            f.meta.update({"base": r.base, "domain": domain_name(r.domain), "ident": r.ident, "unit": m.group(2), "numeric": True,
                           "sign": -1 if v < 0 else 1})
            return f
    f = Frame(1.0, 1.0, gauge)
    f.meta.update({"base": r.base, "domain": domain_name(r.domain), "ident": r.ident, "numeric": False, "text": r.text})
    return f


def actg_to_frames(src: str) -> list[Frame]:
    return [record_to_frame(r) for r in strand_to_records(parse_strand(src))]


# --------------------------------------------------------------------------
# base classification for free text (INFERRED heuristic, tagged as such in flags)
# --------------------------------------------------------------------------
_AX = re.compile(r"\b(axiom|theorem|lemma|law of|definition|postulate|principle|for all|forall|iff|if and only if|conjecture)\b|[=≡]|∀|∃", re.I)
_TE = re.compile(r"\b(step \d|first,|then,|procedure|algorithm|method|how to|compute|apply|def |return |import |function|protocol|cmd_|\[.*:.*\])", re.I)
_GR = re.compile(r"\d+(\.\d+)?\s*(%|hz|khz|mhz|ms|kg|m/s|°|deg|km|mm|cm|nm|ev|volts?|amps?|joules?|seconds?|years?)\b|\b(measured|observed|data|sample|result|experiment|recorded)\b", re.I)


def classify_base(text: str) -> str:
    t = text[:4000]
    sa = len(_AX.findall(t))
    st = len(_TE.findall(t))
    sg = len(_GR.findall(t))
    best = max(("A", sa), ("T", st), ("G", sg), key=lambda kv: kv[1])
    if best[1] == 0:
        return "C"
    return best[0]


def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("actg")
    s = "A[math:peano]{0 is a natural number} ~ T[math:induction]{P(0) & (P(n)->P(n+1)) => forall n P(n)} G[physics:g]{9.81 m/s^2} C[music:fifth]{3:2 ratio}"
    teeth = parse_strand(s)
    chk("parse 4 teeth", len(teeth) == 4 and teeth[0].partner is teeth[1] and teeth[2].partner is None)
    recs = strand_to_records(teeth)
    chk("pair refs", recs[0].pair_ref == 1 and recs[1].pair_ref == 0 and recs[2].pair_ref == 0xFFFFFFFF)
    chk("PAIRED_PENDING flag on unpaired", (recs[2].flags & 1) == 1 and (recs[0].flags & 1) == 0)
    back = records_to_strand(recs)
    chk("strand round trip", strand_to_records(parse_strand(back))[1].text == recs[1].text and "~" in back)
    fr = actg_to_frames(s)
    chk("numeric payload -> real frame (unit gauge)", fr[2].meta["numeric"] and abs(fr[2].alpha - 9.81) < 1e-12 and abs(fr[2].alpha * fr[2].beta - 1) < 1e-12)
    chk("text payload -> unity square, no invented magnitude", not fr[0].meta["numeric"] and fr[0].alpha == 1.0 and fr[0].beta == 1.0)
    chk("physics tooth carries T register gauge", fr[2].gauge.name == "T")
    try:
        parse_strand("A[math:x] ~ G[physics:y]")
        chk("illegal A-G pairing rejected", False)
    except ACTGError as e:
        chk("illegal A-G pairing rejected", "illegal pairing" in str(e))
    try:
        parse_strand("A[nonsense:x]")
        chk("unknown domain rejected", False)
    except ACTGError:
        chk("unknown domain rejected", True)
    chk("escaped brace in payload", parse_strand(r"C[language:b]{a \} b}")[0].text == "a } b")
    chk("classify axiom text", classify_base("Theorem: for all n, n + 0 = n") == "A")
    chk("classify technique text", classify_base("Step 1: compute the mean. Then, apply the filter. def run():") == "T")
    chk("classify grounding text", classify_base("measured 440 Hz at 20 °C; the data sample") == "G")
    chk("classify concept default", classify_base("the sky is wide") == "C")
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
