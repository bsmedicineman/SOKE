"""
soke.gui — the SOKE Windows program (Tk, stdlib) — early-Windows-95 chrome, cream/olive/green skin.

Tabs: Home | Help | Build & Train | Import GGUF | Inspect SFF | Knowledge | Generate | Ledger & Self-test
Every long job runs on a worker thread and reports through a queue; the window
never blocks. The memory gauge in the header is the live RSS against the hard cap.
"""
from __future__ import annotations

import json
import os
import queue
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import Callable, Optional

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import SOKE_NAME, SOKE_LONG, SOKE_VERSION, AUTHOR, MOTTO
from .memguard import MemGuard, rss_bytes
from .util import app_log, data_root, expand_corpus, human_bytes

MB = 1024 * 1024
from . import theme as _T
BG = _T.PAPER
FG = _T.INK
ACC = _T.ACCENT
WARN = _T.WARN
OK = _T.OK
BAD = _T.BAD
SLATE = _T.SLATE
DIM = _T.DIM
INK = _T.INK
FACE = _T.FACE
PAPER_HI = _T.PAPER_HI
MONO = _T.MONO


class ImportStore:
    """Every file imported / staged in any tab, shared across the whole program. Tabs register sources here
    (corpus files, converted .sff, ingested books) so 'imported files are available in all sections'."""

    def __init__(self, app):
        self.app = app
        self.files: list[str] = []          # corpus / text sources
        self.models: list[str] = []         # .gguf / .sff models
        self.listeners: list = []           # callables notified on change

    def add_files(self, paths) -> int:
        n = 0
        for p in paths:
            p = str(p)
            if p not in self.files:
                self.files.append(p); n += 1
        if n:
            self._notify()
        return n

    def add_model(self, path) -> None:
        path = str(path)
        if path not in self.models:
            self.models.append(path); self._notify()

    def subscribe(self, cb) -> None:
        self.listeners.append(cb)

    def _notify(self) -> None:
        for cb in list(self.listeners):
            try:
                cb()
            except Exception:
                pass


class Job(threading.Thread):
    def __init__(self, app: "App", name: str, fn: Callable, on_done: Optional[Callable] = None,
                 on_error: Optional[Callable] = None, quiet: bool = False):
        super().__init__(daemon=True)
        self.app = app
        self.jname = name
        self.fn = fn
        self.on_done = on_done
        self.on_error = on_error
        self.quiet = quiet

    def run(self) -> None:
        if not self.quiet:
            self.app.q.put(("status", f"{self.jname}: running"))
        try:
            res = self.fn()
            self.app.q.put(("done", (self.jname, res, self.on_done, self.quiet)))
        except Exception as e:
            self.app.q.put(("log", f"[{self.jname}] ERROR {type(e).__name__}: {e}\n{traceback.format_exc()}"))
            self.app.q.put(("status", f"{self.jname}: failed — {type(e).__name__}: {str(e)[:120]}"))
            if self.on_error:
                self.app.q.put(("error", (self.on_error, e)))


class LossChart(tk.Canvas):
    def __init__(self, master, **kw):
        super().__init__(master, bg=PAPER_HI, highlightthickness=0, **kw)
        self.train: list[tuple[int, float]] = []
        self.val: list[tuple[int, float]] = []
        self.floor: Optional[float] = None
        self.bind("<Configure>", lambda e: self.redraw())

    def add_train(self, step: int, loss: float) -> None:
        self.train.append((step, loss))
        if len(self.train) > 4000:
            self.train = self.train[-4000:]

    def add_val(self, step: int, loss: float) -> None:
        self.val.append((step, loss))

    def redraw(self) -> None:
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 20 or h < 20:
            return
        pts = self.train[-1500:]
        if len(pts) < 2:
            self.create_text(w // 2, h // 2, text="loss curve appears here", fill=DIM, font=MONO)
            return
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts] + [v[1] for v in self.val if v[0] >= xs[0]]
        if self.floor:
            ys.append(self.floor)
        x0, x1 = min(xs), max(xs)
        y0, y1 = min(ys), max(ys)
        if y1 - y0 < 1e-6:
            y1 = y0 + 1e-6
        pad = 28

        def X(s):
            return pad + (s - x0) / max(1, x1 - x0) * (w - 2 * pad)

        def Y(v):
            return h - pad - (v - y0) / (y1 - y0) * (h - 2 * pad)

        for k in range(5):
            v = y0 + (y1 - y0) * k / 4
            self.create_line(pad, Y(v), w - pad, Y(v), fill="#b9b6a2")
            self.create_text(4, Y(v), text=f"{v:.2f}", anchor="w", fill=DIM, font=("Consolas", 8))
        self.create_line(*[c for s, v in pts for c in (X(s), Y(v))], fill=ACC, width=1)
        if self.floor and y0 <= self.floor <= y1:
            self.create_line(pad, Y(self.floor), w - pad, Y(self.floor), fill=WARN, dash=(4, 3))
            self.create_text(w - pad, Y(self.floor) - 8, text=f"bigram floor {self.floor:.2f}", anchor="e", fill=WARN, font=("Consolas", 8))
        for s, v in self.val:
            if x0 <= s <= x1:
                self.create_oval(X(s) - 3, Y(v) - 3, X(s) + 3, Y(v) + 3, fill=OK, outline="")
        self.create_text(w - pad, pad - 12, text=f"step {xs[-1]}  train {pts[-1][1]:.4f}" + (f"  val {self.val[-1][1]:.4f}" if self.val else ""),
                         anchor="e", fill=FG, font=MONO)


class App(tk.Tk):
    def __init__(self, root: Optional[Path] = None):
        super().__init__()
        self.title(f"{SOKE_NAME} {SOKE_VERSION} — {SOKE_LONG}")
        self.geometry("1180x760")
        self.minsize(960, 620)
        self.configure(bg=BG)
        self.root_dir = Path(root or data_root())
        self.root_dir.mkdir(parents=True, exist_ok=True)
        self.q: queue.Queue = queue.Queue()
        self.mg = MemGuard()
        self.orb = None
        self._style()
        self._build()
        self.after(100, self._poll)
        self.after(1000, self._tick)
        self.log(f"{SOKE_NAME} {SOKE_VERSION} — {AUTHOR} — {MOTTO}")
        self.log(f"data root: {self.root_dir}")
        app_log(f"start {SOKE_NAME} {SOKE_VERSION} python {sys.version.split()[0]} root {self.root_dir}", self.root_dir)
        self.after(600, self._first_start_check)

    # ------------------------------------------------------------- style
    def _style(self) -> None:
        self.pal = _T.apply(self)

    def _build(self) -> None:
        # shared store of imported / staged files, available to every tab
        self.imports = ImportStore(self)
        head = tk.Frame(self, bg=SLATE, bd=2, relief="raised")
        head.pack(fill="x", padx=6, pady=(6, 0))
        tk.Label(head, text=f" {SOKE_NAME} ", bg=SLATE, fg=ACC, font=_T.font(16, True)).pack(side="left", padx=(4, 0), pady=2)
        tk.Label(head, text=f"{SOKE_LONG} · {AUTHOR}", bg=SLATE, fg="#e7e4d2", font=_T.font(8)).pack(side="left", padx=6)
        self.mem_var = tk.StringVar(value="RSS —")
        tk.Label(head, textvariable=self.mem_var, bg=SLATE, fg="#cfe0a8", font=MONO).pack(side="right", padx=(0, 6))
        self.mem_bar = ttk.Progressbar(head, length=140, maximum=self.mg.hard_mb)
        self.mem_bar.pack(side="right", padx=6, pady=4)
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=6, pady=6)
        self.tab_home = ttk.Frame(self.nb)
        self.tab_import = ttk.Frame(self.nb)
        self.tab_forge = ttk.Frame(self.nb)
        self.tab_help = ttk.Frame(self.nb)
        self.tab_train = ttk.Frame(self.nb)
        self.tab_inspect = ttk.Frame(self.nb)
        self.tab_know = ttk.Frame(self.nb)
        self.tab_gen = ttk.Frame(self.nb)
        self.tab_connectome = ttk.Frame(self.nb)
        self.tab_mind = ttk.Frame(self.nb)
        self.tab_ledger = ttk.Frame(self.nb)
        for t, n in ((self.tab_home, "  Home  "), (self.tab_import, " Import "), (self.tab_forge, "  Forge  "),
                     (self.tab_know, "Knowledge"), (self.tab_train, "Build && Train"), (self.tab_inspect, "Inspect SFF"),
                     (self.tab_gen, "Generate"), (self.tab_connectome, "Connectome"), (self.tab_mind, "Mind"), (self.tab_ledger, "Ledger && Self-test"), (self.tab_help, "  Help  ")):
            self.nb.add(t, text=n)
        from .gui_home import HomeTab
        from .gui_help import HELP_TEXT
        from .gui_forge import ForgeTab
        from .gui_connectome import ConnectomeTab
        from .gui_mind import MindTab
        self.home = HomeTab(self, self.tab_home)
        self.forge = ForgeTab(self, self.tab_forge)
        self.connectome = ConnectomeTab(self, self.tab_connectome)
        self.mind = MindTab(self, self.tab_mind)
        helpbox = tk.Text(self.tab_help, wrap="word", padx=14, pady=10)
        _T.sunken_text(helpbox)
        helpbox.configure(font=_T.font(9))
        helpbox.pack(fill="both", expand=True, padx=6, pady=6)
        helpbox.insert("end", HELP_TEXT)
        helpbox.config(state="disabled")
        self._build_train()
        self._build_import()
        self._build_inspect()
        self._build_know()
        self._build_gen()
        self._build_ledger()
        bottom = tk.Frame(self, bg=BG)
        bottom.pack(fill="both", padx=6, pady=(0, 6))
        self.status_var = tk.StringVar(value="ready")
        tk.Label(bottom, textvariable=self.status_var, bg=FACE, fg=INK, anchor="w", bd=2, relief="sunken", font=_T.font(8)).pack(fill="x")
        self.logbox = tk.Text(bottom, height=4, wrap="word", font=MONO)
        _T.sunken_text(self.logbox)
        self.logbox.pack(fill="both", expand=True)

    def run_job(self, name: str, fn: Callable, on_done: Optional[Callable] = None, on_error: Optional[Callable] = None,
                quiet: bool = False) -> None:
        Job(self, name, fn, on_done, on_error, quiet).start()

    def _entry(self, parent, label, var, width=10, row=0, col=0):
        tk.Label(parent, text=label, bg=BG, fg=DIM).grid(row=row, column=col, sticky="e", padx=(8, 2), pady=2)
        e = ttk.Entry(parent, textvariable=var, width=width)
        e.grid(row=row, column=col + 1, sticky="w", padx=(0, 6), pady=2)
        return e

    # ---------------------------------------------------------- tab train
    def _build_train(self) -> None:
        t = self.tab_train
        left = tk.Frame(t, bg=BG)
        left.pack(side="left", fill="y", padx=6, pady=6)
        tk.Label(left, text="Corpus files (streamed, never loaded whole)", bg=BG, fg=ACC).pack(anchor="w")
        self.corpus_list = tk.Listbox(left, height=7, width=52, bg=PAPER_HI, fg=FG, selectbackground=SLATE)
        self.corpus_list.pack()
        b = tk.Frame(left, bg=BG)
        b.pack(anchor="w", pady=2)
        ttk.Button(b, text="Add files", command=self._add_corpus).pack(side="left")
        ttk.Button(b, text="Add folder", command=self._add_corpus_dir).pack(side="left", padx=4)
        ttk.Button(b, text="Remove", command=lambda: [self.corpus_list.delete(i) for i in reversed(self.corpus_list.curselection())]).pack(side="left")
        cfg = tk.LabelFrame(left, text="Model (SOKE-LM)", bg=BG, fg=ACC)
        cfg.pack(fill="x", pady=6)
        self.v_model_id = tk.StringVar(value="soke-v001")
        self.v_dmodel = tk.StringVar(value="128")
        self.v_layers = tk.StringVar(value="3")
        self.v_heads = tk.StringVar(value="4")
        self.v_dff = tk.StringVar(value="512")
        self.v_ctx = tk.StringVar(value="128")
        self.v_experts = tk.StringVar(value="math,language,science,technology,culture,art,behavior,philosophy")
        self.v_dexp = tk.StringVar(value="256")
        self._entry(cfg, "model id", self.v_model_id, 18, 0, 0)
        self._entry(cfg, "d_model", self.v_dmodel, 6, 0, 2)
        self._entry(cfg, "layers", self.v_layers, 6, 1, 0)
        self._entry(cfg, "heads", self.v_heads, 6, 1, 2)
        self._entry(cfg, "d_ff", self.v_dff, 6, 2, 0)
        self._entry(cfg, "ctx", self.v_ctx, 6, 2, 2)
        self._entry(cfg, "d_expert", self.v_dexp, 6, 3, 0)
        tk.Label(cfg, text="experts (tower domains)", bg=BG, fg=DIM).grid(row=4, column=0, sticky="e", padx=(8, 2))
        ttk.Entry(cfg, textvariable=self.v_experts, width=40).grid(row=4, column=1, columnspan=3, sticky="w", pady=2)
        tr = tk.LabelFrame(left, text="Descent (ALM) / loops", bg=BG, fg=ACC)
        tr.pack(fill="x", pady=6)
        self.v_lr = tk.StringVar(value="0.003")
        self.v_batch = tk.StringVar(value="16")
        self.v_steps = tk.StringVar(value="100")
        self.v_cycles = tk.StringVar(value="20")
        self.v_target = tk.StringVar(value="0.001")
        self.v_heal_every = tk.StringVar(value="3")
        self.v_grow_max = tk.StringVar(value="3")
        self.v_scoped = tk.BooleanVar(value=False)
        self._entry(tr, "lr", self.v_lr, 8, 0, 0)
        self._entry(tr, "batch", self.v_batch, 6, 0, 2)
        self._entry(tr, "steps/cycle", self.v_steps, 6, 1, 0)
        self._entry(tr, "cycles", self.v_cycles, 6, 1, 2)
        self._entry(tr, "target loss", self.v_target, 8, 2, 0)
        self._entry(tr, "heal every", self.v_heal_every, 6, 2, 2)
        self._entry(tr, "grow max", self.v_grow_max, 6, 3, 0)
        ttk.Checkbutton(tr, text="scoped corpus (LAW C: 0.001 claimable)", variable=self.v_scoped).grid(row=3, column=2, columnspan=2, sticky="w")
        bb = tk.Frame(left, bg=BG)
        bb.pack(anchor="w", pady=4)
        ttk.Button(bb, text="Bootstrap + Train", style="Accent.TButton", command=self._start_train).pack(side="left")
        ttk.Button(bb, text="Stop", command=self._stop_train).pack(side="left", padx=4)
        ttk.Button(bb, text="Grow (width)", command=lambda: self._grow("width")).pack(side="left")
        ttk.Button(bb, text="Heal sweep", command=self._heal).pack(side="left", padx=4)
        ttk.Button(bb, text="Finalize", command=self._finalize).pack(side="left")
        rt = tk.LabelFrame(left, text=" real-time testing (adjust live, even mid-run) ", bg=BG, fg=SLATE, font=_T.font(8, True))
        rt.pack(fill="x", pady=(6, 0))
        r1 = tk.Frame(rt, bg=BG); r1.pack(fill="x", padx=4, pady=2)
        tk.Label(r1, text="test intensity", bg=BG, fg=DIM).pack(side="left")
        self.v_intensity = tk.StringVar(value="Normal")
        _ci = ttk.Combobox(r1, textvariable=self.v_intensity, values=["Light (fast, frequent checks)", "Normal", "Deep (slow, thorough)", "Continuous (check every few steps)"], width=32, state="readonly")
        _ci.set("Normal"); _ci.pack(side="left", padx=4); _ci.bind("<<ComboboxSelected>>", lambda e: self._set_test_intensity())
        ttk.Button(r1, text="Test now", command=self._test_now).pack(side="left", padx=6)
        self.v_testprompt = tk.StringVar(value="The theorem")
        ttk.Entry(r1, textvariable=self.v_testprompt, width=22).pack(side="left")
        self.lbl_rt = tk.Label(rt, text="Intensity sets how often and how hard the model is checked while it learns; change it any time. "
                                       "'Test now' generates a sample and reports the latest validation loss.", bg=BG, fg=DIM, wraplength=430, justify="left", font=_T.font(8))
        self.lbl_rt.pack(fill="x", padx=4, pady=(0, 2))
        right = tk.Frame(t, bg=BG)
        right.pack(side="left", fill="both", expand=True, padx=6, pady=6)
        self.chart = LossChart(right, height=300)
        self.chart.pack(fill="both", expand=True)
        self.train_info = tk.Text(right, height=12, bg=PAPER_HI, fg=FG, font=MONO, wrap="word")
        self.train_info.pack(fill="x", pady=(6, 0))

    def _add_corpus(self) -> None:
        for f in filedialog.askopenfilenames(title="Corpus files", filetypes=[("Text-like", "*.txt *.md *.py *.json *.csv *.docx *.html *.log"), ("All", "*.*")]):
            self.corpus_list.insert("end", f)

    def _add_corpus_dir(self) -> None:
        d = filedialog.askdirectory(title="Corpus folder (walked recursively; text-like files only)")
        if d:
            self.corpus_list.insert("end", d)
            files, rep = expand_corpus([d])
            self.log(f"folder {d}: {len(files)} text-like files ({human_bytes(rep['bytes'])}), skipped {rep['skipped_binary'] + rep['skipped_ext'] + rep['skipped_empty']}")

    def _corpus(self) -> list[str]:
        return list(self.corpus_list.get(0, "end"))

    _INTENSITY = {"Light": 25, "Normal": 100, "Deep": 400, "Continuous": 8}

    def _set_test_intensity(self) -> None:
        key = self.v_intensity.get().split(" ")[0]
        steps = self._INTENSITY.get(key, 100)
        self.v_steps.set(str(steps))
        if self.orb is not None and getattr(self.orb, "cfg", None) is not None:
            try:
                self.orb.cfg.steps_per_cycle = steps            # takes effect on the next cycle — checks get more/less frequent live
                self.log(f"[test] intensity {key}: {steps} steps between checks (applied to the running model)")
            except Exception:
                pass
        self.status_var.set(f"test intensity: {key} ({steps} steps/check)")

    def _test_now(self) -> None:
        if self.orb is None or getattr(self.orb, "model", None) is None:
            self.status_var.set("no model training yet — start a run first"); return
        prompt = self.v_testprompt.get()

        def job():
            m = self.orb.model
            try:
                txt = m.generate(prompt, max_new=48, temperature=0.7)
            except Exception as e:
                txt = f"(generate unavailable: {e})"
            val = None
            try:
                val = self.orb.loss.floors.get("val") if getattr(self.orb, "loss", None) else None
            except Exception:
                pass
            step = getattr(m, "step", "?")
            return step, txt, val

        def done(res):
            step, txt, val = res
            self.train_info.insert("end", f"[test @ step {step}] {prompt!r} -> {txt!r}\n")
            self.train_info.see("end")
        self.run_job("test now", job, done)

    def _run_cfg(self):
        from .orchestrator import RunConfig
        from .model_engine import ModelConfig
        from .loss_engine import TrainConfig
        mc = ModelConfig(d_model=int(self.v_dmodel.get()), n_heads=int(self.v_heads.get()), n_layers=int(self.v_layers.get()),
                         d_ff=int(self.v_dff.get()), ctx=int(self.v_ctx.get()),
                         experts=[e.strip() for e in self.v_experts.get().split(",") if e.strip()], d_expert=int(self.v_dexp.get()))
        tc = TrainConfig(lr=float(self.v_lr.get()), batch=int(self.v_batch.get()), target_loss=float(self.v_target.get()), scoped=self.v_scoped.get())
        return RunConfig(model=mc, train=tc, steps_per_cycle=int(self.v_steps.get()), max_cycles=int(self.v_cycles.get()),
                         heal_every=int(self.v_heal_every.get()), grow_max=int(self.v_grow_max.get()))

    def _ensure_orb(self):
        from .orchestrator import Orchestrator
        corpus = self._corpus()
        if not corpus:
            raise ValueError("add at least one corpus file")
        if self.orb is None or self.orb.model_id != self.v_model_id.get():
            self.orb = Orchestrator(self.root_dir, model_id=self.v_model_id.get(), corpus=corpus, cfg=self._run_cfg(),
                                    on_event=self._orb_event, memguard=self.mg)
        else:
            self.orb.corpus, self.orb.corpus_report = expand_corpus(corpus)
        return self.orb

    def _orb_event(self, kind: str, payload: dict) -> None:
        self.q.put(("orb", (kind, payload)))

    def _start_train(self) -> None:
        try:
            orb = self._ensure_orb()
        except Exception as e:
            messagebox.showerror("SOKE", str(e))
            return
        orb._stop.clear()

        def job():
            if orb.model is None:
                orb.bootstrap()
            if orb.loss is None:
                orb.learn()
            else:
                orb.loss.stop = False
            return orb.run()

        Job(self, "train", job).start()

    def _stop_train(self) -> None:
        if self.orb:
            self.orb.stop()
            self.log("stop requested (finishes the current step, checkpoints on the next ratchet)")

    def _grow(self, axis: str) -> None:
        if not self.orb or self.orb.loss is None:
            messagebox.showinfo("SOKE", "bootstrap + train first")
            return
        Job(self, f"grow:{axis}", lambda: self.orb.grow(axis)).start()

    def _heal(self) -> None:
        if not self.orb or self.orb.loss is None:
            messagebox.showinfo("SOKE", "bootstrap + train first")
            return
        Job(self, "heal", lambda: self.orb.heal_sweep()).start()

    def _finalize(self) -> None:
        if not self.orb or self.orb.loss is None:
            messagebox.showinfo("SOKE", "bootstrap + train first")
            return
        Job(self, "finalize", lambda: self.orb.finalize()).start()

    # --------------------------------------------------------- tab import
    def _build_import(self) -> None:
        t = self.tab_import
        top = tk.Frame(t, bg=BG)
        top.pack(fill="x", padx=6, pady=6)
        self.v_gguf = tk.StringVar()
        self.v_sff_out = tk.StringVar()
        self.v_budget = tk.StringVar(value="8bit")
        self.v_keep = tk.BooleanVar(value=True)
        self.v_mode = tk.StringVar(value="exact")
        self.v_out = tk.StringVar(value="sff")
        ttk.Button(top, text="Choose .gguf", command=self._pick_gguf).pack(side="left")
        ttk.Entry(top, textvariable=self.v_gguf, width=52).pack(side="left", padx=4)
        ttk.Button(top, text="Convert (streamed, <1 GB)", style="Accent.TButton", command=self._convert).pack(side="left", padx=10)
        opt = tk.Frame(t, bg=BG)
        opt.pack(fill="x", padx=6)
        ttk.Radiobutton(opt, text="Exact — every weight kept as-is (recommended)", value="exact", variable=self.v_mode).pack(side="left")
        ttk.Radiobutton(opt, text="Re-band (lossy, error recorded) into", value="reband", variable=self.v_mode).pack(side="left", padx=(16, 2))
        for b in ("f32", "f16", "8bit", "4bit"):
            ttk.Radiobutton(opt, text=b, value=b, variable=self.v_budget).pack(side="left")
        ttk.Checkbutton(opt, text="keep source band", variable=self.v_keep).pack(side="left", padx=(8, 0))
        opt2 = tk.Frame(t, bg=BG)
        opt2.pack(fill="x", padx=6, pady=(2, 0))
        tk.Label(opt2, text="Save as:", bg=BG, fg=SLATE, font=_T.font(8, True)).pack(side="left")
        ttk.Radiobutton(opt2, text=".sff (SOKE)", value="sff", variable=self.v_out).pack(side="left", padx=(6, 2))
        ttk.Radiobutton(opt2, text=".gguf (for Ollama / LM Studio)", value="gguf", variable=self.v_out).pack(side="left", padx=2)
        ttk.Radiobutton(opt2, text="both", value="both", variable=self.v_out).pack(side="left", padx=2)
        tk.Label(opt2, text="— .gguf output also writes a Modelfile:  ollama create <name> -f <name>.Modelfile",
                 bg=BG, fg=DIM, font=_T.font(8)).pack(side="left", padx=(8, 0))
        self.imp_prog = ttk.Progressbar(t, maximum=100)
        self.imp_prog.pack(fill="x", padx=6)
        cols = ("tensor", "type", "shape", "pages", "status", "rss")
        self.imp_tree = ttk.Treeview(t, columns=cols, show="headings", height=18)
        for c, w in zip(cols, (420, 70, 160, 70, 90, 80)):
            self.imp_tree.heading(c, text=c)
            self.imp_tree.column(c, width=w, anchor="w")
        self.imp_tree.pack(fill="both", expand=True, padx=6, pady=6)
        self.imp_info = tk.Label(t, text="", bg=BG, fg=OK, font=MONO, anchor="w", justify="left", wraplength=1120)
        self.imp_info.pack(fill="x", padx=6)
        shared = tk.LabelFrame(t, text=" shared imports — available in every tab (corpus, books, models) ", bg=BG, fg=SLATE, font=_T.font(8, True))
        shared.pack(fill="x", padx=6, pady=(6, 4))
        rowb = tk.Frame(shared, bg=BG); rowb.pack(fill="x", padx=4, pady=2)
        ttk.Button(rowb, text="Add files (text / PDF / ebooks / models)", command=self._import_add_files).pack(side="left")
        ttk.Button(rowb, text="Add a folder", command=self._import_add_folder).pack(side="left", padx=4)
        ttk.Button(rowb, text="Load sample corpus", command=self._load_samples).pack(side="left", padx=4)
        self.imp_shared = tk.Label(shared, text="nothing shared yet", bg=BG, fg=DIM, anchor="w", justify="left", wraplength=1120, font=_T.font(8))
        self.imp_shared.pack(fill="x", padx=4, pady=(0, 2))
        self.imports.subscribe(self._refresh_shared)

    def _refresh_shared(self) -> None:
        nf, nm = len(self.imports.files), len(self.imports.models)
        names = [Path(x).name for x in (self.imports.files + self.imports.models)[:16]]
        self.imp_shared.config(text=f"{nf} file(s), {nm} model(s): " + ", ".join(names) + (" …" if nf + nm > 16 else ""))

    def _import_add_files(self) -> None:
        fs = filedialog.askopenfilenames(title="Files to share across all tabs")
        if fs:
            n = self.imports.add_files([f for f in fs if not str(f).lower().endswith((".gguf", ".sff"))])
            for f in fs:
                if str(f).lower().endswith((".gguf", ".sff")):
                    self.imports.add_model(f)
            self.status_var.set(f"added {len(fs)} file(s) to shared imports")

    def _import_add_folder(self) -> None:
        d = filedialog.askdirectory(title="Folder to share (text / PDFs / ebooks)")
        if d:
            files, rep = expand_corpus([d])
            self.imports.add_files([str(f) for f in files])
            self.status_var.set(f"shared {rep.get('kept', 0)} file(s) from the folder")

    def _pick_gguf(self) -> None:
        f = filedialog.askopenfilename(title="GGUF model", filetypes=[("GGUF", "*.gguf"), ("All", "*.*")])
        if f:
            self.v_gguf.set(f)
            self.v_sff_out.set(str(Path(f).with_suffix(".sff")))

    def _convert(self) -> None:
        src = self.v_gguf.get().strip()
        if not src or not Path(src).exists():
            messagebox.showerror("SOKE", "choose a .gguf file")
            return
        budget = self.v_budget.get()
        keep = self.v_keep.get()
        mode = self.v_mode.get()
        out_kind = self.v_out.get()                  # "sff" | "gguf" | "both"
        out_sff = Path(src).with_suffix(".sff")
        tag = budget if mode == "reband" else "repack"
        out_gguf = Path(src).with_name(f"{Path(src).stem}.{tag}.gguf")   # never overwrite the source .gguf
        self.imp_tree.delete(*self.imp_tree.get_children())
        self.imp_prog["value"] = 0

        def job():
            from .gguf_rewrites import (convert_gguf_to_sff, GGUFReader, explain_conversion,
                                        repack_gguf, explain_repack, write_modelfile)
            from .ledger import Ledger
            gr = GGUFReader(src)
            self.q.put(("log", f"GGUF: {json.dumps(gr.summary(), default=str)}"))
            gr.close()
            led = Ledger(self.root_dir / "ledger" / "events.jsonl")
            made, texts, st = [], [], None
            if out_kind in ("sff", "both"):
                st = convert_gguf_to_sff(Path(src), out_sff, budget=budget, memguard=self.mg, ledger=led, keep_types=keep, mode=mode,
                                         progress=lambda d: self.q.put(("import", d)))
                texts.append(explain_conversion(st, Path(src), out_sff)); made.append(str(out_sff))
            if out_kind in ("gguf", "both"):
                sg = repack_gguf(Path(src), out_gguf, budget=budget, mode=mode, keep_types=keep, memguard=self.mg, ledger=led,
                                 progress=lambda d: self.q.put(("import", d)))
                mf = write_modelfile(out_gguf)
                texts.append(explain_repack(sg, Path(src), out_gguf) + f"\n  Modelfile: {mf.name}"); made.append(str(out_gguf))
                st = st or sg
            return st, "\n\n".join(texts), made

        def done(res):
            st, text, made = res
            self.imp_info.config(text=text)
            self.log(text)
            self.imp_prog["value"] = 100
            self.imports.add_model(src)              # the source gguf and every output are now shared with every tab
            for m in made:
                self.imports.add_model(m)

        Job(self, "convert", job, done).start()

    # -------------------------------------------------------- tab inspect
    def _build_inspect(self) -> None:
        t = self.tab_inspect
        top = tk.Frame(t, bg=BG)
        top.pack(fill="x", padx=6, pady=6)
        self.v_sff = tk.StringVar()
        ttk.Button(top, text="Open .sff", command=self._pick_sff).pack(side="left")
        ttk.Entry(top, textvariable=self.v_sff, width=60).pack(side="left", padx=4)
        ttk.Button(top, text="Summary", command=lambda: self._inspect("summary")).pack(side="left", padx=2)
        ttk.Button(top, text="Tensors", command=lambda: self._inspect("tensors")).pack(side="left", padx=2)
        ttk.Button(top, text="Patches", command=lambda: self._inspect("patches")).pack(side="left", padx=2)
        ttk.Button(top, text="Lineage", command=lambda: self._inspect("lineage")).pack(side="left", padx=2)
        ttk.Button(top, text="Third-Law table", command=lambda: self._inspect("opt")).pack(side="left", padx=2)
        ttk.Button(top, text="Ledger", command=lambda: self._inspect("ledger")).pack(side="left", padx=2)
        ttk.Button(top, text="Verify (deep)", command=lambda: self._inspect("verify")).pack(side="left", padx=2)
        ttk.Button(top, text="Compact", command=self._compact).pack(side="left", padx=2)
        self.insp = tk.Text(t, bg=PAPER_HI, fg=FG, font=MONO, wrap="none")
        self.insp.pack(fill="both", expand=True, padx=6, pady=6)

    def _pick_sff(self) -> None:
        f = filedialog.askopenfilename(title="SFF model", filetypes=[("SFF", "*.sff"), ("All", "*.*")])
        if f:
            self.v_sff.set(f)
            self._inspect("summary")

    def _inspect(self, what: str) -> None:
        p = self.v_sff.get().strip()
        if not p:
            return

        def job():
            from .sff import SFFReader
            rd = SFFReader(p)
            lines = []
            if what == "summary":
                lines.append(json.dumps(rd.summary(), indent=1, default=str))
                lines.append("META: " + json.dumps({k: v for k, v in rd.meta.items() if k not in ("source", "arch")}, indent=1, default=str)[:4000])
                arch = rd.meta.get("arch", {})
                lines.append("ARCH: " + json.dumps({k: v for k, v in arch.items() if k != "tensor_order"}, indent=1, default=str)[:3000])
            elif what == "tensors":
                lines.append(f"{'tensor':<48} {'shape':<22} {'src':>4} {'pages':>7} {'status':<9} {'err_base':>10} {'err_chosen':>10}")
                for ti in rd.tensors.values():
                    lines.append(f"{ti.name[:48]:<48} {str(ti.shape):<22} {ti.dtype_orig:>4} {ti.page_count:>7} {ti.status:<9} {ti.err_base:>10.2e} {ti.err_chosen:>10.2e}")
            elif what == "patches":
                for pt in rd.patches()[-400:]:
                    lines.append(f"patch {pt['patch_id']:5d} helix {pt['helix']:4d} idx {pt['index']:5d} {pt['old_page']:8d} -> {pt['new_page']:8d} {pt['kind']:<10} {pt['note']}")
            elif what == "lineage":
                nodes, edges = rd.lineage()
                for n in nodes[-300:]:
                    lines.append(f"node {n['node_id']:5d} {n['kind']:<10} {n['label']}")
                for e in edges[-300:]:
                    lines.append(f"edge {e['src']:5d} -> {e['dst']:5d} {e['op']}")
            elif what == "opt":
                lines.append("Third Law of storage — per tensor: baseline (linear band) mse vs chosen gauge mse; cut < 33.3% is a TIE, never a win")
                for r in rd.opt_rows()[-600:]:
                    lines.append(f"{r['pipeline'][:60]:<60} base {r['baseline_ops']:.3e} chosen {r['ortho_ops']:.3e} cut {r['cut_pct']:6.1f}% {r['status']:<9} {r['note']}")
            elif what == "ledger":
                for r in rd.ledger_records()[-300:]:
                    lines.append(f"{r.get('seq', '?'):>5} {r.get('iso', '')} {r.get('protocol', ''):<4} {r.get('domain', ''):<12} {r.get('event', '')} {json.dumps(r.get('payload'), default=str)[:140]}")
            elif what == "verify":
                lines.append(json.dumps(rd.verify(deep=True), indent=1))
            rd.close()
            return "\n".join(lines)

        Job(self, f"inspect:{what}", job, lambda s: (self.insp.delete("1.0", "end"), self.insp.insert("end", s))).start()

    def _compact(self) -> None:
        p = self.v_sff.get().strip()
        if not p:
            return
        out = str(Path(p).with_name(Path(p).stem + "-compact.sff"))

        def job():
            from .sff import compact
            return compact(Path(p), Path(out))

        Job(self, "compact", job, lambda r: self.log(f"compacted -> {out}: {r}")).start()

    # ------------------------------------------------------- tab knowledge
    def _build_know(self) -> None:
        t = self.tab_know
        top = tk.Frame(t, bg=BG)
        top.pack(fill="x", padx=6, pady=6)
        self.v_know = tk.StringVar(value=str(self.root_dir / "knowledge.sff"))
        ttk.Entry(top, textvariable=self.v_know, width=50).pack(side="left")
        ttk.Button(top, text="Ingest files", command=self._ingest).pack(side="left", padx=4)
        ttk.Button(top, text="Ingest books / PDFs (folder)", style="Accent.TButton", command=self._ingest_books).pack(side="left", padx=4)
        ttk.Button(top, text="Load sample corpus", command=self._load_samples).pack(side="left", padx=4)
        ttk.Button(top, text="Boot math (MFP stages 0-7)", command=self._boot_math).pack(side="left", padx=4)
        ttk.Button(top, text="Stats", command=self._know_stats).pack(side="left", padx=4)
        tk.Label(t, text="Point 'Ingest books' at a folder of PDFs / ePub / HTML (your ebooks: math, science, religion, art, philosophy). "
                        "SOKE converts them to text, reads them into the knowledge tower, routes each passage to a topic, and reports the "
                        "topic mix as a behavior + expert prior. The Home advisor can then help wire that into a build. (No OCR: image-only "
                        "scans yield little.)", bg=BG, fg=DIM, wraplength=1120, justify="left").pack(anchor="w", padx=8)
        q = tk.Frame(t, bg=BG)
        q.pack(fill="x", padx=6)
        self.v_query = tk.StringVar()
        tk.Label(q, text="seek (O(log N) index → face gear)", bg=BG, fg=DIM).pack(side="left")
        ttk.Entry(q, textvariable=self.v_query, width=50).pack(side="left", padx=4)
        ttk.Button(q, text="Seek", command=self._seek).pack(side="left")
        self.v_domain = tk.StringVar(value="math")
        tk.Label(q, text="ride domain", bg=BG, fg=DIM).pack(side="left", padx=(12, 2))
        ttk.Entry(q, textvariable=self.v_domain, width=14).pack(side="left")
        ttk.Button(q, text="Ride 20", command=self._ride).pack(side="left", padx=4)
        s = tk.Frame(t, bg=BG)
        s.pack(fill="x", padx=6, pady=4)
        tk.Label(s, text="ACTG strand", bg=BG, fg=DIM).pack(side="left")
        self.v_strand = tk.StringVar(value="A[math:peano]{0 is a natural number} ~ T[math:induction]{P(0) & (P(n)->P(n+1)) => forall n P(n)}")
        ttk.Entry(s, textvariable=self.v_strand, width=90).pack(side="left", padx=4)
        ttk.Button(s, text="Parse + record", command=self._strand).pack(side="left")
        self.know = tk.Text(t, bg=PAPER_HI, fg=FG, font=MONO, wrap="word")
        self.know.pack(fill="both", expand=True, padx=6, pady=6)

    def _mem(self):
        from .memory_engine import HelicalMemory
        from .ledger import Ledger
        return HelicalMemory(Path(self.v_know.get()), ledger=Ledger(self.root_dir / "ledger" / "events.jsonl"), memguard=self.mg)

    def _ingest(self) -> None:
        files = filedialog.askopenfilenames(title="Files to ingest")
        if not files:
            return

        def job():
            mem = self._mem()
            out = [mem.ingest_file(Path(f), progress=lambda d: self.q.put(("status", f"ingest {d['file']}: {d['chunks']} chunks"))) for f in files]
            st = mem.stats()
            mem.close()
            return json.dumps(out, indent=1, default=str) + "\n" + json.dumps(st, indent=1, default=str)

        Job(self, "ingest", job, lambda s: self._know_out(s)).start()

    def _samples_dir(self):
        return Path(__file__).resolve().parent.parent / "samples" / "corpus"

    def _load_samples(self) -> None:
        d = self._samples_dir()
        files = [str(p) for p in sorted(d.glob("*.txt"))] if d.exists() else []
        if not files:
            self._know_out("No sample corpus shipped with this copy."); return
        n = self.imports.add_files(files)
        self._know_out(f"Loaded {n} sample corpus file(s) into the shared imports (available in every tab):\n" + "\n".join("  " + Path(f).name for f in files)
                       + "\n\nThey are editable text — open them in " + str(d) + " and change them, then re-import.")
        self.status_var.set(f"sample corpus loaded ({len(files)} files)")

    def _ingest_books(self) -> None:
        folder = filedialog.askdirectory(title="Folder of PDFs / ebooks to read")
        if not folder:
            return
        self.status_var.set("reading books…")

        def job():
            from .tower import route_text, domain_name
            from .memory_engine import iter_file_text
            files, rep = expand_corpus([folder])
            books = [f for f in files if str(f).lower().endswith((".pdf", ".epub", ".htm", ".html", ".xhtml", ".txt", ".md", ".docx"))]
            mem = self._mem()
            topic_tokens, ingested, empties, total_chars = {}, [], [], 0
            for f in books:
                got = 0
                try:
                    for chunk in iter_file_text(Path(f), chunk_bytes=200000):
                        got += len(chunk); total_chars += len(chunk)
                        for i in range(0, len(chunk), 1500):
                            piece = chunk[i:i + 1500]
                            r = route_text(piece, top=1)
                            topic = r[0][0] if r and r[0][1] > 0.5 else "general"
                            topic_tokens[topic] = topic_tokens.get(topic, 0) + len(piece.split())
                except Exception as e:
                    empties.append(f"{Path(f).name}: {type(e).__name__}")
                    continue
                if got < 40:
                    empties.append(f"{Path(f).name}: no extractable text (scanned/DRM?)")
                    continue
                try:
                    mem.ingest_file(Path(f))
                    ingested.append(str(f))
                except Exception as e:
                    empties.append(f"{Path(f).name}: ingest {type(e).__name__}")
            st = mem.stats(); mem.close()
            self.imports.add_files(ingested)
            return {"ingested": ingested, "empties": empties, "topics": topic_tokens, "chars": total_chars, "stats": st}

        def done(res):
            top = sorted(res["topics"].items(), key=lambda kv: -kv[1])
            tot = sum(res["topics"].values()) or 1
            lines = [f"Read {len(res['ingested'])} book(s), {res['chars']:,} characters of text into the knowledge tower."]
            if res["empties"]:
                lines.append("Skipped (no text — likely scanned images or an unsupported filter; SOKE does not OCR):")
                lines += ["   " + e for e in res["empties"][:12]]
            lines.append("")
            lines.append("Topic mix (this is the knowledge + behavior prior the material implies):")
            for t2, w in top[:12]:
                lines.append(f"   {t2:<14} {100*w/tot:5.1f}%   {'#'*int(40*w/tot)}")
            experts = [t2 for t2, _ in top if t2 != 'general'][:8]
            lines.append("")
            lines.append("Suggested topic experts for a Forge template built on this material:")
            lines.append("   " + ", ".join(experts))
            lines.append("")
            lines.append("The books are now in the shared imports, so 'Generate probes' (Home / Forge) will draw on them, and the")
            lines.append("Home advisor can help wire these experts into a build. Knowledge store: " + json.dumps(res["stats"]))
            self._know_out("\n".join(lines))
            self.status_var.set(f"ingested {len(res['ingested'])} books")

        self.run_job("ingest books", job, done)

    def _boot_math(self) -> None:
        def job():
            from .math_engine import MathEngine
            from .ledger import Ledger
            me = MathEngine(self.root_dir / "math_graph.json", ledger=Ledger(self.root_dir / "ledger" / "events.jsonl"))
            rep = me.boot()
            me.dump()
            mem = self._mem()
            mem.staging.extend(me.to_teeth())
            cons = mem.consolidate()
            mem.close()
            lines = []
            for r in rep:
                lines.append(f"stage {r['stage']} {'OK ' if r.get('ok') else 'FAIL'} {r['title']}")
                for row in r.get("rows", []):
                    lines.append(f"    {row['status']:<17} {row['kind']:<11} {row['statement'][:90]}  ({row['method']})")
            lines.append(json.dumps(me.stats()) + "\nteeth -> knowledge: " + json.dumps(cons))
            return "\n".join(lines)

        Job(self, "boot-math", job, self._know_out).start()

    def _know_stats(self) -> None:
        def job():
            mem = self._mem()
            st = mem.stats()
            mem.close()
            return json.dumps(st, indent=1, default=str)
        Job(self, "know-stats", job, self._know_out).start()

    def _seek(self) -> None:
        qtext = self.v_query.get().strip()
        if not qtext:
            return

        def job():
            from .tower import domain_name
            mem = self._mem()
            hits = mem.seek(qtext, limit=12)
            mem.close()
            if not hits:
                return "no hits"
            return "\n".join(f"[{sc}] {rec.base} {domain_name(rec.domain)}:{rec.ident}  {rec.text[:300]!r}" for _, _, _, sc, rec in hits)

        Job(self, "seek", job, self._know_out).start()

    def _ride(self) -> None:
        dom = self.v_domain.get().strip()

        def job():
            mem = self._mem()
            g = mem.gear(dom, window=20)
            recs = list(g.ride(20))
            mem.close()
            return f"face gear on helix:{dom} — {len(recs)} records (one page window)\n" + "\n".join(f"{r.base} {r.ident:<24} {r.text[:200]!r}" for r in recs)

        Job(self, "ride", job, self._know_out).start()

    def _strand(self) -> None:
        src = self.v_strand.get()

        def job():
            from .actg_parser import parse_strand, strand_to_records, record_to_frame
            recs = strand_to_records(parse_strand(src))
            mem = self._mem()
            mem.staging.extend(recs)
            cons = mem.consolidate()
            mem.close()
            lines = [f"{r.base} domain {r.domain} ident {r.ident} pair {r.pair_ref if r.pair_ref != 0xFFFFFFFF else '-'} flags {r.flags}  frame {record_to_frame(r).meta}" for r in recs]
            lines.append("recorded: " + json.dumps(cons))
            return "\n".join(lines)

        Job(self, "strand", job, self._know_out).start()

    def _know_out(self, s: str) -> None:
        self.know.delete("1.0", "end")
        self.know.insert("end", s)

    # ------------------------------------------------------- tab generate
    def _build_gen(self) -> None:
        t = self.tab_gen
        top = tk.Frame(t, bg=BG)
        top.pack(fill="x", padx=6, pady=6)
        self.v_gen_model = tk.StringVar()
        ttk.Button(top, text="Model .sff", command=lambda: self.v_gen_model.set(filedialog.askopenfilename(filetypes=[("SFF", "*.sff")]) or self.v_gen_model.get())).pack(side="left")
        ttk.Entry(top, textvariable=self.v_gen_model, width=50).pack(side="left", padx=4)
        self.v_gen_max = tk.StringVar(value="200")
        self.v_gen_temp = tk.StringVar(value="0.8")
        tk.Label(top, text="max bytes", bg=BG, fg=DIM).pack(side="left")
        ttk.Entry(top, textvariable=self.v_gen_max, width=6).pack(side="left", padx=4)
        tk.Label(top, text="temp", bg=BG, fg=DIM).pack(side="left")
        ttk.Entry(top, textvariable=self.v_gen_temp, width=6).pack(side="left", padx=4)
        ttk.Button(top, text="Generate (streaming experts)", style="Accent.TButton", command=self._generate).pack(side="left", padx=8)
        self.gen_prompt = tk.Text(t, height=5, bg=PAPER_HI, fg=FG, font=MONO)
        self.gen_prompt.pack(fill="x", padx=6)
        self.gen_prompt.insert("end", "the chord and the melody")
        self.gen_out = tk.Text(t, bg=PAPER_HI, fg=FG, font=MONO, wrap="word")
        self.gen_out.pack(fill="both", expand=True, padx=6, pady=6)

    def _generate(self) -> None:
        p = self.v_gen_model.get().strip() or (str(self.orb.model_path) if self.orb else "")
        if not p:
            messagebox.showinfo("SOKE", "choose a model .sff")
            return
        prompt = self.gen_prompt.get("1.0", "end").strip()
        mx, temp = int(self.v_gen_max.get()), float(self.v_gen_temp.get())

        def job():
            from .model_engine import StreamingModel
            sm = StreamingModel(p)
            out, info = sm.generate(prompt.encode("utf-8"), max_new=mx, temperature=temp)
            sm.close()
            return prompt + out.decode("utf-8", errors="replace") + "\n\n" + json.dumps(info)

        Job(self, "generate", job, lambda s: (self.gen_out.delete("1.0", "end"), self.gen_out.insert("end", s))).start()

    # ---------------------------------------------------------- tab ledger
    def _build_ledger(self) -> None:
        t = self.tab_ledger
        top = tk.Frame(t, bg=BG)
        top.pack(fill="x", padx=6, pady=6)
        ttk.Button(top, text="Run self-test (quick)", command=lambda: self._selftest(True)).pack(side="left")
        ttk.Button(top, text="Run self-test (full)", style="Accent.TButton", command=lambda: self._selftest(False)).pack(side="left", padx=4)
        ttk.Button(top, text="Ledger tail", command=self._ledger_tail).pack(side="left", padx=4)
        ttk.Button(top, text="Verify chain", command=self._ledger_verify).pack(side="left", padx=4)
        ttk.Button(top, text="Research DB", command=self._research).pack(side="left", padx=4)
        ttk.Button(top, text="Frame calculus (35+ rows)", command=self._frames).pack(side="left", padx=4)
        self.ledger_box = tk.Text(t, bg=PAPER_HI, fg=FG, font=MONO, wrap="none")
        self.ledger_box.pack(fill="both", expand=True, padx=6, pady=6)

    def _selftest(self, quick: bool) -> None:
        def job():
            import io
            from .selftest import run
            buf = io.StringIO()
            ok, summary = run(quick=quick, verbose=True, out=buf)
            return buf.getvalue()
        Job(self, "selftest", job, self._ledger_out).start()

    def _ledger_tail(self) -> None:
        def job():
            from .ledger import Ledger
            led = Ledger(self.root_dir / "ledger" / "events.jsonl")
            return "\n".join(f"{r['seq']:>5} {r['iso']} {r['protocol']:<4} {r['domain']:<12} {r['event']:<22} {json.dumps(r['payload'], default=str)[:150]}" for r in led.tail(200))
        Job(self, "ledger", job, self._ledger_out).start()

    def _ledger_verify(self) -> None:
        def job():
            from .ledger import Ledger
            led = Ledger(self.root_dir / "ledger" / "events.jsonl")
            ok, n, bad = led.verify_chain()
            return f"ledger chain {'OK' if ok else 'BROKEN at seq ' + str(bad)} — {n} records, head {led.head[:16]}…"
        Job(self, "verify-chain", job, self._ledger_out).start()

    def _research(self) -> None:
        def job():
            from .meta_optimizer import ResearchDB
            db = ResearchDB(self.root_dir / "research.db")
            ex = db.experiments(100)
            ms = db.milestones()
            db.close()
            lines = ["EXPERIMENTS (control-arm trials)"]
            for e in ex:
                lines.append(f"{e['id']:4d} {e['lock']:<20} {e['family']:<18} vC {e['v_control'] or 0:+.4f} vK {e['v_candidate'] or 0:+.4f} {'WIN' if e['success'] else 'null'}")
            lines.append("\nMILESTONES (ratchet)")
            for m in ms:
                lines.append(f"step {m['step']:6d} params {m['params']:9d} train {m['train_loss']:.4f} val {m['val_loss']:.4f} {m['note']}")
            return "\n".join(lines)
        Job(self, "research", job, self._ledger_out).start()

    def _frames(self) -> None:
        def job():
            from .frame_engine import verify_suite, certified_rows
            rep = verify_suite().report()
            rows = "\n".join(f"{r['pipeline']:<40} base {r['baseline_ops']:>8} ortho {r['ortho_ops']:>8} cut {r['cut_pct']:6.1f}% {r['status']:<9} {r['note']}" for r in certified_rows())
            return rep + "\n\nTHIRD LAW — certified rows (ties declared as ties):\n" + rows
        Job(self, "frames", job, self._ledger_out).start()

    def _ledger_out(self, s: str) -> None:
        self.ledger_box.delete("1.0", "end")
        self.ledger_box.insert("end", s)

    # ------------------------------------------------------------- events
    def log(self, s: str) -> None:
        self.logbox.insert("end", s + "\n")
        self.logbox.see("end")

    def _poll(self) -> None:
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "log":
                    self.log(payload)
                elif kind == "status":
                    self.status_var.set(payload)
                elif kind == "done":
                    name, res, cb, quiet = payload
                    if not quiet:
                        self.status_var.set(f"{name}: done")
                    if cb:
                        try:
                            cb(res)
                        except Exception as e:
                            self.log(f"[{name}] callback error: {e}\n{traceback.format_exc()}")
                    elif res is not None and not quiet:
                        self.log(f"[{name}] {json.dumps(res, default=str)[:600]}")
                elif kind == "error":
                    cb, err = payload
                    try:
                        cb(err)
                    except Exception as e:
                        self.log(f"error callback failed: {e}")
                elif kind == "home":
                    self.home.on_home_event(*payload)
                elif kind == "import":
                    d = payload
                    self.imp_tree.insert("", "end", values=(d.get("tensor", ""), d.get("type") or d.get("out_type", ""), "",
                                                            d.get("pages", ""), d.get("status") or d.get("kind", ""),
                                                            f"{d.get('rss_mb', 0):.0f} MB"))
                    self.imp_tree.see(self.imp_tree.get_children()[-1])
                    self.imp_prog["value"] = 100.0 * d.get("i", 0) / max(1, d.get("n", 1))
                    self.status_var.set(f"convert {d.get('i', 0)}/{d.get('n', 0)} — RSS {d.get('rss_mb', 0):.0f} MB — {d.get('elapsed', 0):.0f}s")
                elif kind == "orb":
                    self._orb_ui(*payload)
                elif kind == "forge":
                    self._forge_ui(*payload)
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _forge_ui(self, kind: str, p) -> None:
        try:
            if kind == "export":
                self.forge.on_export_event(p)
            elif kind == "token":
                self.forge.on_token(p)
            else:
                self.forge.on_event(kind, p)
        except Exception as e:
            self.log(f"[forge] {e}")

    def _orb_ui(self, kind: str, p: dict) -> None:
        # training events render on the Build & Train tab (chart + train_info); Home is the advisor console
        if kind == "step":
            self.chart.add_train(p["step"], p["loss"])
            if p["step"] % 5 == 0:
                self.chart.redraw()
            if p["step"] % 20 == 0:
                self.status_var.set(f"step {p['step']}  loss {p['loss']:.4f}  lr {p['lr']:.2e}  gn {p['gn']:.2f}")
        elif kind == "cycle":
            self.chart.add_val(self.orb.model.step if self.orb and self.orb.model else 0, p["val_loss"])
            if self.orb and self.orb.loss and self.orb.loss.floors:
                self.chart.floor = self.orb.loss.floors.get("bigram")
            self.chart.redraw()
            t = p.get("trials", [])
            self.train_info.insert("end", f"cycle {p.get('cycle', '?')}: train {p['train_loss']:.4f} val {p['val_loss']:.4f} lock {p['lock']} vel {p['velocity']:+.4f} noise {p['noise']:.3f} gap {p['gap']:+.3f} rare-tax {p['rare_tax']:.2f} best {p['best_val']:.4f} floor {p['floor']['status']}\n")
            for tr in t:
                self.train_info.insert("end", f"    trial {tr['family']:<16} vC {tr['v_control']:+.4f} vK {tr['v_candidate']:+.4f} -> {'ADOPT' if tr['success'] else 'null'}\n")
            self.train_info.see("end")
        elif kind in ("grow", "heal", "checkpoint", "finalize", "run_end", "bootstrap", "learn", "ingest", "corpus"):
            if kind != "ingest":
                self.train_info.insert("end", f"[{kind}] {json.dumps(p, default=str)[:500]}\n")
                self.train_info.see("end")
            self.log(f"[{kind}] {json.dumps(p, default=str)[:300]}")

    def _first_start_check(self) -> None:
        """First window start after an install or update: report the shortcut repair and run the quick
        self-test in the background; the one-line verdict goes to the window log and soke_data/logs/soke.log."""
        marker = self.root_dir / "installed_version.txt"
        try:
            seen = marker.read_text(encoding="utf-8").strip()
        except OSError:
            seen = ""
        logp = self.root_dir / "logs" / "soke.log"
        try:
            tail = logp.read_text(encoding="utf-8", errors="replace").splitlines()[-40:]
            for ln in tail:
                if "shortcuts:" in ln:
                    self.log(ln.split("] ", 1)[-1])
                    break
        except OSError:
            pass
        if seen == SOKE_VERSION:
            return
        self.log(f"first start of {SOKE_VERSION}: running the quick self-test in the background…")

        def job():
            import io
            from .selftest import run
            from .memguard import rss_route
            buf = io.StringIO()
            ok, summary = run(quick=True, verbose=True, out=buf)
            text = buf.getvalue()
            verdict = text.strip().splitlines()[-1] if text.strip() else "no output"
            return ok, verdict, summary, rss_route(), text

        def done(res):
            ok, verdict, summary, route, text = res
            line = f"self-test on this machine: {verdict} · RSS probe route={route}"
            self.log(line)
            app_log(line, self.root_dir)
            if not ok:
                bad = [f"{k}: {v['passed']}/{v['total']}" for k, v in summary.get("per_suite", {}).items() if v["passed"] != v["total"]]
                app_log("self-test failures: " + ", ".join(bad), self.root_dir)
                app_log("self-test transcript:\n" + text, self.root_dir)
                self.log("failures: " + ", ".join(bad) + " — the transcript is in soke_data\\logs\\soke.log")
            try:
                marker.write_text(SOKE_VERSION, encoding="utf-8")
            except OSError:
                pass

        self.run_job("first-start self-test", job, done, quiet=True)

    def _tick(self) -> None:
        r = rss_bytes() / MB
        self.mem_var.set(f"RSS {r:.0f} MB / cap {self.mg.hard_mb} MB")
        self.mem_bar["value"] = min(r, self.mg.hard_mb)
        self.after(1000, self._tick)


def main(root: Optional[str] = None) -> None:
    app = App(Path(root) if root else None)
    app.mainloop()


if __name__ == "__main__":
    main()
