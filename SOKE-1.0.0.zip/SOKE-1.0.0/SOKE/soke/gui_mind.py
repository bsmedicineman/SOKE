"""
soke.gui_mind — the Mind tab: the live 4-D thought/emotion engine (Transcendence) running beneath the model.

Pick a temperament (the Forge/Behavior chemistry), watch the 4-D state (Nature / Nurture / Ego / Meaning),
the seven core affects, and the reward/punishment budget (tokens = room to think, RAM headroom) EVOLVE as you
feed it situations. Load a gguf and it speaks with the emotional feed live — fear sharpens, joy broadens, and
the token budget governs how much it may say. Emotion may bid; it may not close.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import theme as _T
BG = _T.PAPER
OK = _T.OK
WARN = _T.WARN
BAD = _T.BAD
DIM = _T.DIM
SLATE = _T.SLATE
MONO = _T.MONO

CLIMATE_LIST = ["neutral", "seeking", "daring", "care", "joy", "focus", "equanimity", "scarcity"]


def _bar(v: float, w: int = 24) -> str:
    v = max(0.0, min(1.0, float(v)))
    n = int(round(v * w))
    return "█" * n + "·" * (w - n)


class MindTab:
    def __init__(self, app, frame: ttk.Frame):
        self.app = app
        self.f = frame
        self.eng = None                                  # a mind_engine.MindEngine once a temperament is loaded
        self.advisor = None                              # an optional loaded LLM for emotional speech
        self._build()

    def _build(self) -> None:
        t = self.f
        tk.Label(t, text="The live 4-D thought/emotion engine (from your book \"Transcendence\"). It runs BENEATH the model: a "
                         "state S = (Nature, Nurture, Ego, Meaning) sits in an attractor basin, the seven core affects are its "
                         "weather, and a reward/punishment budget (tokens = room to think, RAM headroom) is its digital "
                         "chemistry. Feed it situations and watch it evolve — this is not a blanket behavior, it is a response "
                         "system that reacts to what happens. Emotion may bid; it may not close.",
                 bg=BG, fg=SLATE, font=_T.font(8), anchor="w", justify="left", wraplength=1120).pack(fill="x", padx=8, pady=(8, 2))

        top = tk.Frame(t, bg=BG); top.pack(fill="x", padx=8, pady=4)
        tk.Label(top, text="temperament (from Forge/Behavior chemistry)", bg=BG, fg=DIM).pack(side="left", padx=(4, 4))
        self.v_climate = tk.StringVar(value="daring")
        ttk.Combobox(top, textvariable=self.v_climate, values=CLIMATE_LIST, width=14, state="readonly").pack(side="left")
        ttk.Button(top, text="Load temperament", style="Accent.TButton", command=self._load).pack(side="left", padx=8)
        ttk.Button(top, text="Reset to baseline", command=self._reset).pack(side="left")

        feed = tk.LabelFrame(t, text=" feed a situation (the evolving response) ", bg=BG, fg=SLATE, font=_T.font(8, True))
        feed.pack(fill="x", padx=8, pady=4)
        row = tk.Frame(feed, bg=BG); row.pack(fill="x", padx=4, pady=2)
        self.v_val = tk.StringVar(value="-0.8"); self.v_ar = tk.StringVar(value="0.8"); self.v_aff = tk.StringVar(value="(auto)")
        tk.Label(row, text="valence -1..+1", bg=BG, fg=DIM).pack(side="left", padx=(4, 2)); ttk.Entry(row, textvariable=self.v_val, width=6).pack(side="left")
        tk.Label(row, text="arousal 0..1", bg=BG, fg=DIM).pack(side="left", padx=(8, 2)); ttk.Entry(row, textvariable=self.v_ar, width=6).pack(side="left")
        tk.Label(row, text="affect", bg=BG, fg=DIM).pack(side="left", padx=(8, 2))
        ttk.Combobox(row, textvariable=self.v_aff, values=["(auto)", "joy", "sadness", "fear", "anger", "surprise", "disgust", "contempt"],
                     width=10, state="readonly").pack(side="left")
        ttk.Button(row, text="Feel it", style="Accent.TButton", command=self._feel).pack(side="left", padx=10)
        row2 = tk.Frame(feed, bg=BG); row2.pack(fill="x", padx=4, pady=2)
        tk.Label(row2, text="or a feed:", bg=BG, fg=DIM).pack(side="left")
        self.v_seq = tk.StringVar(value="-0.9:0.9, +0.8:0.5, -0.6:0.7, +0.9:0.4")
        ttk.Entry(row2, textvariable=self.v_seq, width=52).pack(side="left", padx=4)
        ttk.Button(row2, text="Run feed", command=self._run_feed).pack(side="left", padx=6)

        speak = tk.LabelFrame(t, text=" let it speak with the emotional feed (optional — loads a gguf) ", bg=BG, fg=SLATE, font=_T.font(8, True))
        speak.pack(fill="x", padx=8, pady=4)
        r3 = tk.Frame(speak, bg=BG); r3.pack(fill="x", padx=4, pady=2)
        ttk.Button(r3, text="Choose .gguf…", command=self._pick).pack(side="left")
        self.v_gguf = tk.StringVar(); ttk.Entry(r3, textvariable=self.v_gguf, width=40).pack(side="left", padx=4)
        self.v_prompt = tk.StringVar(value="How are you feeling right now?")
        ttk.Entry(r3, textvariable=self.v_prompt, width=30).pack(side="left", padx=4)
        ttk.Button(r3, text="Speak", command=self._speak).pack(side="left", padx=6)

        self.disp = tk.Text(t, wrap="word", height=20, bg=_T.PAPER_HI, fg=_T.INK, font=MONO, bd=2, relief="sunken", padx=8, pady=6)
        self.disp.pack(fill="both", expand=True, padx=8, pady=6)
        self._say("Load a temperament to bring the mind online.")

    def _say(self, s: str) -> None:
        self.disp.delete("1.0", "end"); self.disp.insert("end", s)

    # ---- engine ----------------------------------------------------------
    def _load(self) -> None:
        from .mind_engine import MindEngine
        from .behavior import CLIMATES, BehaviorProfile
        prof = CLIMATES.get(self.v_climate.get()) or BehaviorProfile()
        self.eng = MindEngine.from_behavior(prof)
        self._refresh(f"temperament '{self.v_climate.get()}' online.")

    def _reset(self) -> None:
        if self.eng is None:
            return
        self.eng.state.S = self.eng.state.baseline.copy()
        self.eng.state.affect[:] = 0.0
        self.eng.state.tokens = self.eng.base_tokens
        self.eng.state.ram_headroom = 1.0
        self._refresh("reset to the baseline basin.")

    def _need(self) -> bool:
        if self.eng is None:
            messagebox.showinfo("SOKE", "Load a temperament first."); return False
        return True

    def _feel(self) -> None:
        if not self._need():
            return
        try:
            v = float(self.v_val.get()); ar = float(self.v_ar.get())
        except ValueError:
            messagebox.showerror("SOKE", "valence and arousal must be numbers"); return
        aff = None if self.v_aff.get() == "(auto)" else self.v_aff.get()
        self.eng.step(v, ar, aff)
        self._refresh(f"situation felt: valence {v:+.2f}, arousal {ar:.2f}.")

    def _run_feed(self) -> None:
        if not self._need():
            return
        seq = []
        for item in self.v_seq.get().split(","):
            item = item.strip()
            if not item:
                continue
            try:
                if ":" in item:
                    a, b = item.split(":", 1); seq.append((float(a), float(b)))
                else:
                    seq.append((float(item), 0.6))
            except ValueError:
                continue
        lines = ["feed (the evolving response):"]
        for i, (v, ar) in enumerate(seq):
            s = self.eng.step(v, ar)
            lines.append(f"  [{i+1}] v={v:+.2f} a={ar:.2f} -> {s['mood']['dominant']:<9} "
                         f"tokens {s['tokens']:.0f}  ram×{s['ram_headroom']:.2f}")
        self._refresh("\n".join(lines))

    def _pick(self) -> None:
        p = filedialog.askopenfilename(title="Model", filetypes=[("GGUF", "*.gguf"), ("All", "*.*")])
        if p:
            self.v_gguf.set(p)

    def _speak(self) -> None:
        if not self._need():
            return
        path = self.v_gguf.get().strip()
        if not path or not Path(path).exists():
            messagebox.showinfo("SOKE", "Choose a .gguf for it to speak with."); return
        prompt = self.v_prompt.get().strip()

        def job():
            from .llm_engine import LLM
            from .connectome_engine import Connectome  # noqa: F401 (keeps engines importable together)
            if self.advisor is None or getattr(self.advisor, "path", None) != path:
                self.advisor = LLM(path, memguard=self.app.mg, resident="stream")
                self.advisor.path = path
            self.eng.state.tokens = self.eng.base_tokens
            txt, info = self.advisor.generate(prompt, max_new=96, temperature=0.8, controller=self.eng)
            return txt, info

        def done(res):
            txt, info = res
            s = self.eng.snapshot()
            self._refresh(f"it spoke ({info['tokens']} tokens; the emotional budget governs the length):\n\n  {txt}\n\n"
                          f"mood while speaking: {s['mood']['dominant']} (temp×{s['mood']['temp_scale']:.2f}), "
                          f"tokens left {s['tokens']:.0f}")

        def err(e):
            self._refresh(f"could not speak: {type(e).__name__}: {e}\n(a dense llama/qwen2 .gguf works; MoE files are chat-only.)")
        self._say("thinking, with the emotional feed live…")
        self.app.run_job("mind speak", job, done, on_error=err)

    # ---- display ---------------------------------------------------------
    def _refresh(self, note: str = "") -> None:
        if self.eng is None:
            self._say(note or "no temperament loaded."); return
        s = self.eng.snapshot()
        S = s["S"]
        lines = [note, ""] if note else []
        lines.append(f"temperament '{self.eng.name}':  reward_gain {self.eng.reward_gain:.2f}   "
                     f"threat_gain {self.eng.threat_gain:.2f}   basin_stiffness {self.eng.stiffness:.2f}")
        lines.append("")
        lines.append("4-D STATE  (the book's coordinate — the attractor basin the self returns to)")
        for axis, label in (("x_nature", "Nature   X"), ("y_nurture", "Nurture  Y"),
                            ("z_regulation", "Ego/Reg  Z"), ("w_meaning", "Meaning  W")):
            lines.append(f"  {label}  {_bar(S[axis])}  {S[axis]:.2f}")
        lines.append(f"  Nature*Nurture trade-off (1/x=y) error: {s['reciprocal_error']:.3f}")
        lines.append("")
        lines.append("SEVEN CORE AFFECTS  (the weather — the seven attractors of the substrate)")
        aff = s["affect"]
        for a in ("joy", "sadness", "fear", "anger", "surprise", "disgust", "contempt"):
            val = aff.get(a, 0.0)
            lines.append(f"  {a:<9} {_bar(val, 18)}  {val:.2f}")
        m = s["mood"]
        lines.append("")
        lines.append(f"MOOD: {m['dominant']}   peakedness temp×{m['temp_scale']:.2f}   valence {m['valence']:+.2f}")
        lines.append("")
        lines.append("DIGITAL CHEMISTRY  (reward / punishment — the neuro-path the model is on)")
        lines.append(f"  tokens (room to think)  {_bar(min(1.0, s['tokens']/max(1.0, self.eng.base_tokens*1.5)))}  {s['tokens']:.0f}")
        lines.append(f"  RAM headroom            {_bar((s['ram_headroom']-0.5)/1.0)}  ×{s['ram_headroom']:.2f}")
        self._say("\n".join(lines))
