"""
soke.theme — the SOKE look: an early-Windows-95 chrome (beveled raised buttons, sunken fields, chunky
title strips, a low-resolution bitmap feel) tinted with the cracked cream / olive / vivid-green palette of
the operator's cover art. One place so every tab matches; `apply(root)` styles ttk and returns the palette.

Colors are read off the cover image: bone/cream paper, warm grey Win95 face, slate scales-of-justice ink,
and the acid-green logo stroke as the single accent.
"""
from __future__ import annotations

import os

# -- palette ----------------------------------------------------------------
PAPER = "#d7d4c0"        # cream/bone background (the cracked field)
PAPER_HI = "#e7e4d2"     # lighter paper (sunken field interior)
FACE = "#c8c5b4"         # Win95 control face, warmed toward the cream
FACE_HI = "#f2f0e4"      # bevel highlight (top-left)
FACE_SH = "#7d7b6b"      # bevel shadow (bottom-right)
FACE_DK = "#a9a693"      # pressed / darker face
INK = "#1b1c17"          # near-black text / cracks
SLATE = "#565a4d"        # muted olive-slate (the scales)
DIM = "#6c6f5e"          # secondary text
ACCENT = "#7fb23a"       # acid green (the logo stroke)
ACCENT_DK = "#5d8a27"    # darker green (pressed accent)
OK = "#4f7a2a"           # success green
WARN = "#b07d1e"         # amber
BAD = "#9c3b2f"          # brick red
LINK = "#3d5a86"         # classic hyperlink blue

# legacy names some modules import (kept pointing at the new palette so nothing breaks visually)
BG = PAPER
FG = INK

def font(size: int = 8, bold: bool = False):
    """MS Sans Serif on Windows for the authentic low-res feel; Tahoma / DejaVu elsewhere."""
    fam = "MS Sans Serif" if os.name == "nt" else "DejaVu Sans"
    return (fam, size, "bold") if bold else (fam, size)

MONO = ("Courier New", 9) if os.name == "nt" else ("DejaVu Sans Mono", 9)


def apply(root) -> dict:
    """Style ttk + the root to the SOKE Win95 look. Returns the palette dict for direct tk widgets."""
    from tkinter import ttk
    root.configure(bg=PAPER)
    try:
        root.option_add("*background", PAPER)
        root.option_add("*Font", font(8))
    except Exception:
        pass
    st = ttk.Style(root)
    try:
        st.theme_use("clam")           # clam takes bevel colors; we push it toward classic Win95
    except Exception:
        pass
    F = font(8)
    st.configure(".", background=PAPER, foreground=INK, fieldbackground=PAPER_HI, font=F,
                 bordercolor=FACE_SH, lightcolor=FACE_HI, darkcolor=FACE_SH, focuscolor=SLATE)
    # notebook = tabbed folder look
    st.configure("TNotebook", background=FACE, borderwidth=2, tabmargins=(2, 2, 2, 0))
    st.configure("TNotebook.Tab", background=FACE, foreground=INK, padding=(10, 3), borderwidth=2,
                 lightcolor=FACE_HI, darkcolor=FACE_SH, font=F)
    st.map("TNotebook.Tab", background=[("selected", PAPER_HI)], foreground=[("selected", INK)],
           expand=[("selected", (1, 1, 1, 0))])
    # raised beveled buttons
    st.configure("TButton", background=FACE, foreground=INK, borderwidth=2, relief="raised",
                 lightcolor=FACE_HI, darkcolor=FACE_SH, padding=(8, 2), font=F, focusthickness=1, focuscolor=INK)
    st.map("TButton", background=[("active", FACE), ("pressed", FACE_DK)], relief=[("pressed", "sunken")])
    st.configure("Accent.TButton", background=ACCENT, foreground=INK, lightcolor="#a6d16a", darkcolor=ACCENT_DK)
    st.map("Accent.TButton", background=[("active", ACCENT), ("pressed", ACCENT_DK)], relief=[("pressed", "sunken")])
    # sunken entries / combos / lists
    st.configure("TEntry", fieldbackground=PAPER_HI, foreground=INK, borderwidth=2, relief="sunken", insertcolor=INK)
    st.configure("TCombobox", fieldbackground=PAPER_HI, foreground=INK, background=FACE, borderwidth=2, arrowcolor=INK, relief="sunken")
    st.map("TCombobox", fieldbackground=[("readonly", PAPER_HI)], foreground=[("readonly", INK)],
           selectbackground=[("readonly", PAPER_HI)], selectforeground=[("readonly", INK)])
    st.configure("TCheckbutton", background=PAPER, foreground=INK, focuscolor=SLATE, font=F)
    st.map("TCheckbutton", background=[("active", PAPER)])
    st.configure("TRadiobutton", background=PAPER, foreground=INK, focuscolor=SLATE, font=F)
    st.map("TRadiobutton", background=[("active", PAPER)])
    st.configure("TLabel", background=PAPER, foreground=INK, font=F)
    st.configure("TLabelframe", background=PAPER, foreground=SLATE, borderwidth=2, relief="groove", lightcolor=FACE_HI, darkcolor=FACE_SH)
    st.configure("TLabelframe.Label", background=PAPER, foreground=SLATE, font=font(8, True))
    st.configure("TFrame", background=PAPER)
    st.configure("TScale", background=PAPER, troughcolor=PAPER_HI, borderwidth=1)
    # treeview = a Win95 list/detail control
    st.configure("Treeview", background=PAPER_HI, fieldbackground=PAPER_HI, foreground=INK, rowheight=19,
                 borderwidth=2, relief="sunken", font=F)
    st.configure("Treeview.Heading", background=FACE, foreground=INK, relief="raised", borderwidth=2, font=F)
    st.map("Treeview", background=[("selected", SLATE)], foreground=[("selected", "#f2f0e4")])
    st.configure("Horizontal.TProgressbar", background=ACCENT, troughcolor=PAPER_HI, borderwidth=2, lightcolor="#a6d16a", darkcolor=ACCENT_DK)
    st.configure("Vertical.TScrollbar", background=FACE, troughcolor=PAPER_HI, borderwidth=2, arrowcolor=INK)
    st.configure("Horizontal.TScrollbar", background=FACE, troughcolor=PAPER_HI, borderwidth=2, arrowcolor=INK)
    # combobox dropdown list colors
    try:
        root.option_add("*TCombobox*Listbox.background", PAPER_HI)
        root.option_add("*TCombobox*Listbox.foreground", INK)
        root.option_add("*TCombobox*Listbox.selectBackground", SLATE)
        root.option_add("*TCombobox*Listbox.selectForeground", "#f2f0e4")
        root.option_add("*TCombobox*Listbox.font", F)
    except Exception:
        pass
    return palette()


def palette() -> dict:
    return {"PAPER": PAPER, "PAPER_HI": PAPER_HI, "FACE": FACE, "FACE_HI": FACE_HI, "FACE_SH": FACE_SH,
            "FACE_DK": FACE_DK, "INK": INK, "SLATE": SLATE, "DIM": DIM, "ACCENT": ACCENT, "ACCENT_DK": ACCENT_DK,
            "OK": OK, "WARN": WARN, "BAD": BAD, "LINK": LINK, "BG": PAPER, "FG": INK, "MONO": MONO}


def bevel(widget, kind: str = "raised") -> None:
    """Give a plain tk widget a Win95 2-px bevel."""
    try:
        widget.configure(relief=kind, borderwidth=2, highlightthickness=0)
    except Exception:
        pass


def sunken_text(widget) -> None:
    try:
        widget.configure(bg=PAPER_HI, fg=INK, relief="sunken", borderwidth=2, insertbackground=INK,
                         highlightthickness=0, selectbackground=SLATE, selectforeground="#f2f0e4")
    except Exception:
        pass
