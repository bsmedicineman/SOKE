"""
soke.math_engine — the Mathematical Foundation Layer (MFL / MFP v1.0).

A derivation GRAPH, not a database of facts: axioms at the root, everything else
hangs off verified results. Every node carries a mechanical status:
  TRUE (PATH 1 decision procedure)  | FALSE | EMPIRICALLY_TRUE (PATH 3, never promoted)
  | ACCEPTED (PATH 4 cited, unverified here) | UNVERIFIED | CONJECTURE | OPEN
The consistency sweep runs after every insertion: a statement and its negation are
never both TRUE (X·Y = 1 maintained by the store itself).

MFP:BOOT seeds stages 0–7 in dependency order and gates each stage on the previous.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

from .proof_engine import ProofEngine, Verdict, check_group_z_mod_n
from .util import atomic_write_json, iso_now, read_json

KINDS = ("axiom", "definition", "theorem", "lemma", "conjecture", "computation", "open_problem", "fallacy")


@dataclass
class MathNode:
    node_id: str
    kind: str
    statement: str
    status: str = "UNVERIFIED"
    proof: Optional[dict] = None
    dependencies: list = field(default_factory=list)
    domain: list = field(default_factory=lambda: ["math"])
    stage: int = -1
    falsify_attempts: int = 0
    source: str = "builder"
    created: str = field(default_factory=iso_now)

    def hash(self) -> str:
        return hashlib.sha256(f"{self.kind}:{self.statement}:{json.dumps(self.proof, sort_keys=True, default=str)}".encode()).hexdigest()


class MathEngine:
    def __init__(self, path: Optional[Path] = None, ledger=None):
        self.path = Path(path) if path else None
        self.ledger = ledger
        self.nodes: dict[str, MathNode] = {}
        self.children: dict[str, list[str]] = {}
        self.pe = ProofEngine()
        self.contradictions: list[dict] = []
        self.boot_report: list[dict] = []
        if self.path and self.path.exists():
            self.load(self.path)

    # ---------------------------------------------------------------- ids
    @staticmethod
    def make_id(kind: str, statement: str) -> str:
        return "M-" + hashlib.sha256(f"{kind}|{statement.strip()}".encode()).hexdigest()[:10]

    def _log(self, event: str, payload: dict) -> None:
        if self.ledger is not None:
            self.ledger.append("MFP", event, payload, domain="math")

    # ------------------------------------------------------------ inserts
    def add_axiom(self, statement: str, domain: Optional[list] = None, stage: int = -1) -> MathNode:
        nid = self.make_id("axiom", statement)
        node = MathNode(nid, "axiom", statement, "TRUE", {"path": 0, "method": "axiom"}, [], domain or ["math"], stage)
        return self._store(node)

    def add_definition(self, statement: str, domain: Optional[list] = None, stage: int = -1) -> MathNode:
        nid = self.make_id("definition", statement)
        node = MathNode(nid, "definition", statement, "DEFINITION", {"path": 0, "method": "definition"}, [], domain or ["math"], stage)
        return self._store(node)

    def add_statement(self, statement: str, kind: str = "theorem", deps: Optional[list] = None,
                      domain: Optional[list] = None, stage: int = -1, source: str = "builder") -> MathNode:
        """[MFP:PARSE] + [MFP:VERIFY] + [MFP:STORE] + [MFP:CONSISTENCY_SWEEP]."""
        nid = self.make_id(kind, statement)
        if nid in self.nodes:
            return self.nodes[nid]
        v = self.pe.verify(statement)
        status = v.status
        if kind == "conjecture":
            status = "CONJECTURE" if v.status in ("EMPIRICALLY_TRUE", "UNDECIDED") else v.status
        if kind == "open_problem":
            status = "OPEN"
        node = MathNode(nid, kind, statement, status, v.as_dict(), list(deps or []), domain or ["math"], stage, source=source)
        node.falsify_attempts = int(v.detail.get("checked", v.detail.get("rows", 0)) or 0)
        return self._store(node)

    def accept_cited(self, statement: str, source: str, domain: Optional[list] = None) -> MathNode:
        """PATH 4: cited authority — ACCEPTED, tagged external/unverified-here, counted not trusted."""
        nid = self.make_id("theorem", statement)
        node = MathNode(nid, "theorem", statement, "ACCEPTED", {"path": 4, "method": "cited", "source": source}, [], domain or ["math"], source=source)
        return self._store(node)

    def _store(self, node: MathNode) -> MathNode:
        self.nodes[node.node_id] = node
        for d in node.dependencies:
            self.children.setdefault(d, []).append(node.node_id)
        self.consistency_sweep(node)
        self._log("store", {"id": node.node_id, "kind": node.kind, "status": node.status, "stmt": node.statement[:120]})
        return node

    # -------------------------------------------------------- consistency
    def consistency_sweep(self, node: MathNode) -> Optional[dict]:
        """[MFP:CONSISTENCY_SWEEP]: never store a statement and its negation both TRUE."""
        if node.status not in ("TRUE", "EMPIRICALLY_TRUE", "ACCEPTED"):
            return None
        neg = self.pe.negation_of(node.statement)
        if not neg:
            return None
        for other in self.nodes.values():
            if other.node_id == node.node_id or other.status not in ("TRUE", "EMPIRICALLY_TRUE", "ACCEPTED"):
                continue
            if _norm(other.statement) == _norm(neg):
                # both cannot stand; the one with the weaker authority is demoted; smaller blast radius re-verified first
                weaker = other if _authority(other) < _authority(node) else node
                weaker.status = "CONTRADICTION"
                rec = {"a": node.node_id, "b": other.node_id, "demoted": weaker.node_id, "statement": node.statement, "negation": neg}
                self.contradictions.append(rec)
                self._log("contradiction", rec)
                return rec
        return None

    def blast_radius(self, node_id: str) -> list[str]:
        out: list[str] = []
        stack = list(self.children.get(node_id, []))
        while stack:
            n = stack.pop()
            if n not in out:
                out.append(n)
                stack.extend(self.children.get(n, []))
        return out

    def reverify(self, node_id: str) -> Verdict:
        node = self.nodes[node_id]
        if node.kind in ("axiom", "definition"):
            return Verdict(node.status, 0, node.kind)
        v = self.pe.verify(node.statement)
        node.status = v.status
        node.proof = v.as_dict()
        return v

    # --------------------------------------------------------------- query
    def query_graph(self, concept: str, limit: int = 10) -> list[MathNode]:
        c = concept.lower()
        hits = [n for n in self.nodes.values() if c in n.statement.lower() or c in " ".join(n.domain).lower()]
        return hits[:limit]

    def derive(self, target: str) -> Optional[MathNode]:
        """[MFP:DERIVE] PATH 2: is the target already in the store (or its normal form)? Returns the node."""
        nid_t = self.make_id("theorem", target)
        if nid_t in self.nodes:
            return self.nodes[nid_t]
        for n in self.nodes.values():
            if _norm(n.statement) == _norm(target) and n.status in ("TRUE", "EMPIRICALLY_TRUE", "DEFINITION", "ACCEPTED"):
                return n
        return None

    def stats(self) -> dict:
        by = {}
        for n in self.nodes.values():
            by[n.status] = by.get(n.status, 0) + 1
        return {"nodes": len(self.nodes), "by_status": by, "contradictions": len(self.contradictions),
                "edges": sum(len(v) for v in self.children.values())}

    # ------------------------------------------------------------ persist
    def dump(self, path: Optional[Path] = None) -> None:
        path = Path(path or self.path)
        atomic_write_json(path, {"nodes": [asdict(n) for n in self.nodes.values()], "children": self.children,
                                 "contradictions": self.contradictions, "boot_report": self.boot_report})

    def load(self, path: Path) -> None:
        raw = read_json(path, {})
        self.nodes = {n["node_id"]: MathNode(**n) for n in raw.get("nodes", [])}
        self.children = raw.get("children", {})
        self.contradictions = raw.get("contradictions", [])
        self.boot_report = raw.get("boot_report", [])

    # ---------------------------------------------------------------- boot
    def boot(self) -> list[dict]:
        """[MFP:BOOT] stages 0–7; each stage gates the next (a FALSE at stage k halts the boot)."""
        stages = [
            (0, "propositional logic", [
                ("axiom", "p -> p"), ("theorem", "(p -> q) & p -> q"), ("theorem", "(p -> q) & ~q -> ~p"),
                ("theorem", "~(p & q) <-> (~p | ~q)"), ("theorem", "~(p | q) <-> (~p & ~q)"),
                ("theorem", "(p -> q) & (q -> r) -> (p -> r)"), ("theorem", "p | ~p"), ("fallacy", "(p -> q) & q -> p")]),
            (1, "Peano arithmetic (computations from the axioms)", [
                ("axiom", "0 is a natural number; S(n) is a natural number; 0 != S(n); S(n) = S(m) -> n = m; induction"),
                ("computation", "1 + 1 = 2"), ("computation", "2 + 2 = 4"), ("computation", "3 * 4 = 12"), ("fallacy", "2 + 2 = 5")]),
            (2, "arithmetic laws (polynomial normal form)", [
                ("theorem", "a + b = b + a"), ("theorem", "a * b = b * a"), ("theorem", "(a + b) + c = a + (b + c)"),
                ("theorem", "a * (b + c) = a * b + a * c"), ("theorem", "a + 0 = a"), ("theorem", "a * 1 = a"),
                ("theorem", "(a + b)^2 = a^2 + 2*a*b + b^2"), ("theorem", "(a - b) * (a + b) = a^2 - b^2"),
                ("theorem", "(a + b)^3 = a^3 + 3*a^2*b + 3*a*b^2 + b^3")]),
            (3, "set theory (Boolean algebra decision procedure)", [
                ("theorem", "(A u B)' = A' n B'"), ("theorem", "(A n B)' = A' u B'"), ("theorem", "A n (B u C) = (A n B) u (A n C)"),
                ("theorem", "A u (B n C) = (A u B) n (A u C)"), ("theorem", "A \\ B = A n B'"), ("fallacy", "A u B = A n B")]),
            (4, "relations and functions", [
                ("definition", "a function f: X -> Y is injective iff f(a) = f(b) -> a = b"),
                ("computation", "the map {0:1, 1:2, 2:0} on Z_3 is a bijection")]),
            (5, "real numbers and limits (numeric, EMPIRICALLY_TRUE only)", [
                ("theorem", "sqrt(x)^2 = x"), ("theorem", "exp(log(x)) = x"), ("theorem", "sin(x)^2 + cos(x)^2 = 1"),
                ("theorem", "exp(a + b) = exp(a) * exp(b)"), ("theorem", "log(a * b) = log(a) + log(b)"),
                ("conjecture", "sqrt(2) * sqrt(2) = 2"), ("fallacy", "sin(x) = x")]),
            (6, "algebraic structures (groups)", [
                ("computation", "Z_7 under addition is a group"), ("computation", "Z_12 under addition is a group")]),
            (7, "probability and the L-gauge (softmax / log-sum-exp)", [
                ("theorem", "exp(a) / (exp(a) + exp(b)) + exp(b) / (exp(a) + exp(b)) = 1"),
                ("theorem", "log(exp(a) + exp(b)) = a + log(1 + exp(b - a))"),
                ("theorem", "a * b / (a + b) = 1 / (1/a + 1/b)"),
                ("theorem", "(a + b) / 2 * (2 * a * b / (a + b)) = a * b")]),
        ]
        report = []
        prev_ok = True
        for stage, title, items in stages:
            if not prev_ok:
                report.append({"stage": stage, "title": title, "gated": "HALTED (previous stage failed)"})
                continue
            rows = []
            ok = True
            for kind, stmt in items:
                if kind == "axiom":
                    node = self.add_axiom(stmt, stage=stage)
                elif kind == "definition":
                    node = self.add_definition(stmt, stage=stage)
                elif kind == "computation" and "group" in stmt:
                    n = int(stmt.split("_")[1].split()[0])
                    r = check_group_z_mod_n(n)
                    node = MathNode(self.make_id("computation", stmt), "computation", stmt, r["status"], {"path": 1, "method": "exhaustive", **r}, [], ["math"], stage)
                    self._store(node)
                elif kind == "computation" and "bijection" in stmt:
                    from .proof_engine import check_bijection
                    r = check_bijection({0: 1, 1: 2, 2: 0})
                    node = MathNode(self.make_id("computation", stmt), "computation", stmt, r["status"], {"path": 1, "method": "finite_map", **r}, [], ["math"], stage)
                    self._store(node)
                elif kind == "fallacy":
                    node = self.add_statement(stmt, "fallacy", stage=stage)
                    node.status = "REFUTED" if node.proof and node.proof.get("status") == "FALSE" else node.status
                else:
                    node = self.add_statement(stmt, kind, stage=stage)
                expected_false = kind == "fallacy"
                got_false = node.status in ("FALSE", "REFUTED")
                good = (got_false if expected_false else node.status in ("TRUE", "EMPIRICALLY_TRUE", "DEFINITION", "CONJECTURE"))
                ok = ok and good
                rows.append({"kind": kind, "statement": stmt, "status": node.status, "method": (node.proof or {}).get("method"), "ok": good})
            report.append({"stage": stage, "title": title, "ok": ok, "rows": rows})
            prev_ok = ok
        self.boot_report = report
        self._log("boot", {"stages_ok": [r.get("ok") for r in report]})
        return report

    def to_teeth(self) -> list:
        """Export the graph as ACTG records for the math helix (A axiom, C definition, T technique, G computation)."""
        from .teeth import ToothRecord
        from .tower import domain_id
        base_of = {"axiom": "A", "definition": "C", "theorem": "T", "lemma": "T", "computation": "G", "conjecture": "C",
                   "open_problem": "C", "fallacy": "G"}
        out = []
        for n in self.nodes.values():
            text = f"[{n.status}] {n.statement}"
            out.append(ToothRecord(base_of.get(n.kind, "C"), domain_id("math"), n.node_id, text, 5, 2 if n.status == "TRUE" else 0))
        return out


def _norm(s: str) -> str:
    return "".join(s.split()).lower()


def _authority(n: MathNode) -> int:
    return {"TRUE": 3, "DEFINITION": 3, "EMPIRICALLY_TRUE": 2, "ACCEPTED": 1}.get(n.status, 0)


def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    from .ledger import NullLedger
    chk = chk or Check("math_engine")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_math_"))
    me = MathEngine(tmpdir / "math_graph.json", ledger=NullLedger())
    rep = me.boot()
    chk("boot stages 0-7 all pass", all(r.get("ok") for r in rep), str([(r["stage"], r.get("ok")) for r in rep]))
    st = me.stats()
    chk("graph populated", st["nodes"] >= 40, str(st))
    chk("PATH 1 vs PATH 3 kept apart", any(n.status == "TRUE" and n.stage == 2 for n in me.nodes.values())
        and all(n.status != "TRUE" for n in me.nodes.values() if n.stage == 5 and n.kind == "theorem"))
    chk("fallacies REFUTED", all(n.status == "REFUTED" for n in me.nodes.values() if n.kind == "fallacy"))
    # consistency sweep: insert a negation of a TRUE statement
    a = me.add_statement("x + 0 = x")
    b = me.add_statement("x + 0 != x")
    chk("negation refuted, no contradiction stored", a.status == "TRUE" and b.status == "FALSE" and not me.contradictions)
    # a cited claim that contradicts a proven one gets demoted, not the proof
    c = me.accept_cited("a * 1 != a", source="bogus-paper")
    chk("cited contradiction demoted by sweep, proof kept", c.status == "CONTRADICTION" and me.nodes[me.make_id("theorem", "a * 1 = a")].status == "TRUE" and len(me.contradictions) == 1)
    me.add_statement("(a+b)^2 = a^2 + 2*a*b + b^2", deps=[a.node_id])
    chk("blast radius follows dependency edges", len(me.blast_radius(a.node_id)) == 1)
    chk("PATH 2 derive from store", me.derive("a + b = b + a") is not None and me.derive("zzz = 1") is None)
    me.dump()
    me2 = MathEngine(tmpdir / "math_graph.json")
    chk("dump/load round trip", me2.stats()["nodes"] == me.stats()["nodes"])
    teeth = me.to_teeth()
    chk("export to ACTG teeth", len(teeth) == len(me.nodes) and any(t.base == "A" for t in teeth) and any(t.base == "G" for t in teeth))
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
