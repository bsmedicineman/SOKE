"""
soke.orchestrator — the Orchestrator & Research Brain (ORB): one state store,
one ledger, six engines, three loops.

    PHASE 1 Bootstrap : MFP boot (math graph) -> knowledge SFF (math teeth) -> genesis model SFF
    PHASE 2 Learn     : ingest corpus into helical memory; the model trains on the byte stream
    PHASE 3 Optimize  : ALM cycles (diagnose/hypothesize/trial/ratchet) + SOP sweeps
    PHASE 4 Expand    : EFP growth on CAP_LOCK (width/depth/expert), gated by equivalence
    PHASE 5 Converge  : declared floor or scoped target -> freeze, final heal, requant band,
                        compact, sign

    FUSION LOOP:  while not done:  learn -> heal -> tune -> (grow) -> heal -> checkpoint -> log

state.json (single source of truth): model_id, model_path, params, best_loss, target_loss,
hyper_history, growth_history, audit_log, phase, step, floors, last_check.
"""
from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from . import SOKE_VERSION, AUTHOR
from .expansion_engine import ExpansionEngine
from .heal_engine import HealEngine
from .ledger import Ledger
from .loss_engine import LossEngine, TrainConfig
from .math_engine import MathEngine
from .memguard import MemGuard, MemoryBudgetExceeded
from .memory_engine import HelicalMemory
from .meta_optimizer import MetaOptimizer, ResearchDB
from .model_engine import ByteStream, ModelConfig, SokeLM
from .util import atomic_write_json, data_root, iso_now, read_json, expand_corpus


@dataclass
class RunConfig:
    model: ModelConfig = field(default_factory=ModelConfig)
    train: TrainConfig = field(default_factory=TrainConfig)
    steps_per_cycle: int = 100
    max_cycles: int = 20
    heal_every: int = 3
    grow_max: int = 3
    ingest_corpus: bool = True
    final_budget: str = "8bit"
    expert_default_fe: int = 256

    def to_dict(self) -> dict:
        return {"model": self.model.to_dict(), "train": self.train.to_dict(), "steps_per_cycle": self.steps_per_cycle,
                "max_cycles": self.max_cycles, "heal_every": self.heal_every, "grow_max": self.grow_max,
                "ingest_corpus": self.ingest_corpus, "final_budget": self.final_budget}


class Orchestrator:
    def __init__(self, root: Optional[Path] = None, model_id: str = "soke-v001", corpus: Optional[list] = None,
                 cfg: Optional[RunConfig] = None, on_event: Optional[Callable[[str, dict], None]] = None,
                 memguard: Optional[MemGuard] = None):
        self.root = Path(root or data_root())
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "models").mkdir(exist_ok=True)
        (self.root / "ledger").mkdir(exist_ok=True)
        self.model_id = model_id
        self.cfg = cfg or RunConfig()
        self.corpus, self.corpus_report = expand_corpus(corpus or [])      # files and/or folders (recursive)
        self.on_event = on_event
        self.mg = memguard or MemGuard()
        self.ledger = Ledger(self.root / "ledger" / "events.jsonl")
        self.db = ResearchDB(self.root / "research.db")
        self.meta = MetaOptimizer(self.db)
        self.math = MathEngine(self.root / "math_graph.json", ledger=self.ledger)
        self.memory: Optional[HelicalMemory] = None
        self.model: Optional[SokeLM] = None
        self.stream: Optional[ByteStream] = None
        self.loss: Optional[LossEngine] = None
        self.heal = HealEngine(ledger=self.ledger)
        self.expand = ExpansionEngine(ledger=self.ledger)
        self.state_path = self.root / "state.json"
        self.state = read_json(self.state_path, None) or self._fresh_state()
        self.model_path = self.root / "models" / f"{model_id}.sff"
        self._stop = threading.Event()
        self.cycle_log: list[dict] = []

    # ------------------------------------------------------------- state
    def _fresh_state(self) -> dict:
        return {"model_id": self.model_id, "model_path": str(self.root / "models" / f"{self.model_id}.sff"), "params": 0,
                "best_loss": None, "target_loss": self.cfg.train.target_loss, "phase": "INIT", "step": 0,
                "hyper_history": [], "growth_history": [], "audit_log": [], "floors": {}, "last_check": None,
                "created": iso_now(), "soke": SOKE_VERSION, "author": AUTHOR}

    def save_state(self) -> None:
        self.state["last_check"] = iso_now()
        self.state["ledger_head"] = self.ledger.head
        atomic_write_json(self.state_path, self.state)

    def emit(self, kind: str, payload: dict) -> None:
        if self.on_event:
            try:
                self.on_event(kind, payload)
            except Exception:
                pass

    def stop(self) -> None:
        self._stop.set()
        if self.loss is not None:
            self.loss.stop = True

    # --------------------------------------------------------- bootstrap
    def bootstrap(self) -> dict:
        self.state["phase"] = "BOOTSTRAP"
        rep = {}
        # MFP boot
        if not self.math.nodes:
            boot = self.math.boot()
            self.math.dump()
            rep["math_boot"] = [(r["stage"], r.get("ok")) for r in boot]
            self.state["audit_log"].append({"t": iso_now(), "event": "mfp_boot", "ok": all(r.get("ok") for r in boot)})
        # knowledge memory with the math teeth
        self.memory = HelicalMemory(self.root / "knowledge.sff", ledger=self.ledger, memguard=self.mg)
        if self.memory.stats()["records"] == 0:
            for t in self.math.to_teeth():
                self.memory.staging.append(t)
            rep["math_teeth"] = self.memory.consolidate()
        # genesis model
        if self.model_path.exists():
            self.model = SokeLM.load_sff(self.model_path)
            rep["model"] = "loaded"
        else:
            self.model = SokeLM(self.cfg.model, seed=self.cfg.train.seed)
            self.model.save_sff(self.model_path, "create", ledger=self.ledger, note="genesis", state={"phase": "genesis"})
            rep["model"] = "genesis"
            self.ledger.append("ORB", "genesis", {"model_id": self.model_id, "params": self.model.n_params(),
                                                  "config": self.cfg.model.to_dict()}, domain="parametric")
        self.state["params"] = self.model.n_params()
        self.state["step"] = self.model.step
        self.save_state()
        self.emit("bootstrap", rep)
        return rep

    # ------------------------------------------------------------- learn
    def learn(self, corpus: Optional[list] = None) -> dict:
        self.state["phase"] = "LEARN"
        if corpus:
            self.corpus, self.corpus_report = expand_corpus(corpus)
        if not self.corpus:
            raise ValueError("no corpus files given (folders are walked recursively; only text-like files count): "
                             f"{self.corpus_report}")
        rep = {"ingested": [], "corpus": {**self.corpus_report, "files": len(self.corpus)}}
        self.emit("corpus", rep["corpus"])
        if self.cfg.ingest_corpus and self.memory is not None:
            for p in self.corpus:
                try:
                    rep["ingested"].append(self.memory.ingest_file(p, progress=lambda d: self.emit("ingest", d)))
                except Exception as e:
                    rep["ingested"].append({"file": str(p), "error": str(e)})
        self.stream = ByteStream(self.corpus, seed=self.cfg.train.seed)
        self.loss = LossEngine(self.model, self.stream, self.cfg.train, ledger=self.ledger, meta=self.meta,
                               memguard=self.mg, research_db=self.db, on_step=lambda r: self.emit("step", r))
        self.state["floors"] = self.loss.entropy_floors()
        self.save_state()
        self.emit("learn", rep)
        return rep

    # ------------------------------------------------------ checkpointing
    def checkpoint(self, keyframe: bool) -> dict:
        st = {"phase": self.state["phase"], "best_loss": self.loss.best_val if self.loss else None,
              "train_cfg": self.cfg.train.to_dict()}
        r = self.model.save_sff(self.model_path, "append", keyframe=keyframe, ledger=self.ledger,
                                note=f"step {self.model.step}", state=st)
        self.state["step"] = self.model.step
        self.state["params"] = self.model.n_params()
        self.save_state()
        self.emit("checkpoint", {**r, "step": self.model.step})
        return r

    def _eval_batches(self, n: int = 3) -> list:
        return [self.stream.batch(min(8, self.cfg.train.batch), self.model.cfg.ctx, val=True)[:2] for _ in range(n)]

    def domain_losses(self) -> dict:
        """Per-expert (domain) mean NLL on val batches — the fork-tension probe."""
        out: dict[str, list] = {d: [] for d in self.model.cfg.experts}
        for ids, tgt in self._eval_batches(2):
            res = self.model.forward(ids, tgt, cache=True)
            nll = res["per_token_nll"].reshape(-1)
            k = res["_cache"]["caches"][-1]["kidx"].reshape(-1)
            for e, d in enumerate(self.model.cfg.experts):
                sel = k == e
                if sel.any():
                    out[d].append(float(np.mean(nll[sel])))
        return {d: float(np.mean(v)) for d, v in out.items() if v}

    # -------------------------------------------------------------- grow
    def grow(self, axis: Optional[str] = None, detail: Optional[dict] = None) -> dict:
        self.state["phase"] = "EXPAND"
        batches = self._eval_batches(2)
        if axis is None:
            n_grown = len(self.state["growth_history"])
            axis = ["width", "expert_width", "depth"][n_grown % 3]
        detail = detail or {}
        if axis == "width":
            detail.setdefault("layer", int(np.argmax([float(np.sqrt(np.sum(np.square(self.model.p[f"blk.{l}.w2"], dtype=np.float64)))) for l in range(self.model.cfg.n_layers)])))
            detail.setdefault("add", max(16, self.model.cfg.d_ff // 2))
        rec = self.expand.grow(self.model, axis, batches, detail, optimizer=self.loss.opt if self.loss else None)
        entry = {"t": iso_now(), "axis": axis, "params_before": rec.params_before, "params_after": rec.params_after,
                 "passed": rec.passed, "max_abs_delta": rec.equivalence_max_abs, "detail": {k: v for k, v in rec.detail.items() if k != "rows"}}
        self.state["growth_history"].append(entry)
        if rec.passed:
            self.model.save_sff(self.model_path, "append", keyframe=True, ledger=self.ledger, note=f"step {self.model.step} grow:{axis}")
            self.expand.record_capacity(rec.params_after, self.loss.best_val if self.loss else float("nan"))
            self.loss.stalled_cycles = 0
            self.loss.failed_families = {}
        self.emit("grow", entry)
        self.save_state()
        return entry

    # -------------------------------------------------------------- heal
    def heal_sweep(self, requant: Optional[str] = None) -> dict:
        batches = self._eval_batches(3)
        rep = self.heal.sweep(self.model, batches, sff_path=self.model_path if requant else None, requant_budget=requant)
        self.state["audit_log"].append({"t": iso_now(), "event": "heal", "routes": rep.get("routes_adopted"),
                                        "prune": len(rep.get("prune", [])), "requant": (rep.get("requant") or {}).get("passed")})
        self.emit("heal", rep)
        self.save_state()
        return rep

    # -------------------------------------------------------- fusion loop
    def run(self, cycles: Optional[int] = None) -> dict:
        """learn -> heal -> tune -> (grow) -> heal -> checkpoint -> log, until done or stopped."""
        if self.model is None:
            self.bootstrap()
        if self.loss is None:
            self.learn()
        self.state["phase"] = "OPTIMIZE"
        cycles = cycles or self.cfg.max_cycles
        done_reason = ""
        t0 = time.time()
        try:
            for ci in range(cycles):
                if self._stop.is_set():
                    done_reason = "stopped"
                    break
                cyc = self.loss.run_cycle(self.cfg.steps_per_cycle, checkpoint=self.checkpoint)
                cyc["cycle"] = ci
                self.cycle_log.append(cyc)
                self.state["best_loss"] = self.loss.best_val
                self.state["hyper_history"].append({"step": self.model.step, "lr": self.cfg.train.lr, "batch": self.cfg.train.batch,
                                                    "wd": self.cfg.train.wd, "lock": cyc["lock"], "val": cyc["val_loss"]})
                self.emit("cycle", cyc)
                # interlock: scoped target / floor
                fs = cyc["floor"]["status"]
                if fs == "SCOPED_TARGET_REACHED":
                    done_reason = fs
                    break
                # EFP on capacity lock (bounded growth events)
                if cyc["lock"] == "CAP_LOCK" and len(self.state["growth_history"]) < self.cfg.grow_max:
                    before = self.domain_losses()
                    forks = self.expand.detect_fork(self.state.get("domain_losses", before), before)
                    if forks and forks[0]["domain"] not in self.model.cfg.experts:
                        self.grow("expert", {"domain": forks[0]["domain"]})
                    else:
                        self.grow()
                    self.state["domain_losses"] = before
                    self.state["phase"] = "OPTIMIZE"
                # SOP sweep every k cycles
                if (ci + 1) % self.cfg.heal_every == 0:
                    self.heal_sweep()
                if self.model.step >= self.cfg.train.max_steps:
                    done_reason = "max_steps"
                    break
            else:
                done_reason = "max_cycles"
        except MemoryBudgetExceeded as e:
            done_reason = f"memguard: {e}"
            self.ledger.append("SYS", "memguard_trip", {"error": str(e)}, domain="sys")
        self.save_state()
        rep = {"reason": done_reason, "cycles": len(self.cycle_log), "step": self.model.step, "best_val": self.loss.best_val,
               "params": self.model.n_params(), "elapsed_s": round(time.time() - t0, 1), "rss": self.mg.status()}
        self.ledger.append("ORB", "run_end", rep, domain="parametric")
        self.emit("run_end", rep)
        return rep

    # ----------------------------------------------------------- converge
    def finalize(self, budget: Optional[str] = None, compact_file: bool = True) -> dict:
        """Freeze -> final heal (with the storage band requant, validated) -> compact -> sign."""
        from .sff import compact, SFFReader
        self.state["phase"] = "CONVERGE"
        budget = budget or self.cfg.final_budget
        # precision ladder: the requested band first; if the KL gate rejects it, climb to the next safer band
        ladder = ["4bit", "8bit", "f16"]
        start = ladder.index(budget) if budget in ladder else 1
        rep = {"bands_tried": []}
        for band in ladder[start:]:
            rep["heal"] = self.heal_sweep(requant=band)
            rq = rep["heal"].get("requant") or {}
            rep["bands_tried"].append({"band": band, "passed": rq.get("passed"), "kl": rq.get("kl")})
            if rq.get("passed"):
                rep["band"] = band
                break
        else:
            rep["band"] = "f32"      # nothing passed: the F32 pages stay (nulls are deliverables)
        final = self.root / "models" / f"{self.model_id}-final.sff"
        if compact_file:
            rep["compact"] = compact(self.model_path, final)
        else:
            import shutil
            shutil.copy2(self.model_path, final)
        rd = SFFReader(final)
        rep["verify"] = rd.verify(deep=True)
        rep["summary"] = rd.summary()
        rd.close()
        self.state["final_model"] = str(final)
        self.state["phase"] = "FROZEN"
        self.ledger.append("ORB", "finalize", {"final": str(final), "budget": budget, "verify_ok": rep["verify"]["ok"]}, domain="parametric")
        self.save_state()
        self.emit("finalize", rep)
        return rep

    def close(self) -> None:
        try:
            self.db.close()
        except Exception:
            pass
        if self.memory is not None:
            self.memory.close()


def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    from .sff import SFFReader
    chk = chk or Check("orchestrator")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_orb_"))
    corpus = tmpdir / "corpus.txt"
    corpus.write_bytes((b"the chord and the melody in harmony. " * 150 + b"prove the theorem by induction on n. " * 150
                        + b"the electron and the magnetic field. " * 150) * 2)
    cfg = RunConfig(model=ModelConfig(d_model=32, n_heads=4, n_layers=2, d_ff=64, ctx=32, experts=["math", "music", "physics"], d_expert=32),
                    train=TrainConfig(lr=3e-3, batch=8, warmup=10, trial_steps=10, window=20, stall_cycles_before_cap=1),
                    steps_per_cycle=30, max_cycles=4, heal_every=2, grow_max=1)
    events = []
    orb = Orchestrator(tmpdir / "data", model_id="t1", corpus=[corpus], cfg=cfg, on_event=lambda k, p: events.append(k),
                       memguard=MemGuard(soft_mb=700, hard_mb=950))
    b = orb.bootstrap()
    chk("bootstrap: math boot + knowledge + genesis model", b["model"] == "genesis" and all(ok for _, ok in b["math_boot"]) and orb.memory.stats()["records"] > 30, str(b.get("math_teeth")))
    l = orb.learn()
    chk("learn: corpus ingested into helices + stream ready", l["ingested"][0]["chunks"] > 0 and orb.stream is not None)
    r = orb.run()
    chk("fusion loop ran cycles and ended", r["cycles"] >= 1 and r["reason"] in ("max_cycles", "max_steps"), str(r))
    chk("state.json persisted", read_json(orb.state_path)["step"] == orb.model.step and read_json(orb.state_path)["best_loss"] is not None)
    chk("events emitted (step/cycle/checkpoint)", "cycle" in events and "checkpoint" in events and "step" in events)
    # force a growth + heal + finalize
    g = orb.grow("width", {"layer": 0, "add": 16})
    chk("grow: gated growth committed to SFF", g["passed"] and orb.state["growth_history"][-1]["params_after"] > orb.state["growth_history"][-1]["params_before"])
    h = orb.heal_sweep()
    chk("heal sweep audited routes", "routes" in h)
    f = orb.finalize(budget="8bit")
    chk("finalize: precision ladder picks a band that passes the KL gate, compacted, verified", f["verify"]["ok"] and f["band"] in ("8bit", "f16") and Path(orb.state["final_model"]).exists(), f"band={f['band']} tried={f['bands_tried']}")
    rd = SFFReader(orb.state["final_model"])
    chk("final SFF carries ledger + lineage + patches + opt rows", len(rd.ledger_records()) > 10 and rd.patch_count > 0 and len(rd.lineage()[0]) > 3)
    ok, n, bad = orb.ledger.verify_chain()
    chk("ledger hash chain + HMAC verify", ok and n > 20, f"{n} records")
    rd.close()
    m2 = SokeLM.load_sff(orb.state["final_model"])
    chk("final model reloads with grown shape", m2.cfg.d_ff == orb.model.cfg.d_ff and m2.n_params() == orb.model.n_params())
    orb.close()
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
