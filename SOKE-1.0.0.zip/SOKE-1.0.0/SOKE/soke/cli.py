"""
soke.cli — command line for everything the GUI does.

  soke_main.py                       -> GUI
  soke_main.py selftest [--quick]
  soke_main.py train  --corpus a.txt b.md ... [--model-id X] [--cycles N] [--steps N] [--d-model 128 ...]
  soke_main.py convert model.gguf [--out model.sff] [--mode exact|reband] [--budget 8bit|4bit|f16|f32]
  soke_main.py inspect model.sff [--tensors] [--patches] [--lineage] [--opt] [--ledger] [--verify]
  soke_main.py generate model.sff --prompt "..." [--max 200] [--temp 0.8]
  soke_main.py ingest --files ... [--knowledge knowledge.sff]
  soke_main.py seek "query" [--knowledge knowledge.sff]
  soke_main.py boot-math
  soke_main.py heal model.sff --corpus ... [--requant 8bit]
  soke_main.py grow model.sff --corpus ... --axis width|depth|expert|expert_width [--domain music]
  soke_main.py finalize --model-id X [--budget 8bit]
  soke_main.py rollback model.sff --to-step N
  soke_main.py compact model.sff --out compact.sff
  soke_main.py status
  soke_main.py settings [--model-dir DIR] [--export-dir DIR]
  soke_main.py forge-inventory [--folder DIR | --ollama]
  soke_main.py forge-build --donors a.gguf b.gguf | ollama-name ... [--preset math-always-on] [--topics math,language,...]
                 [--shared math] [--n-used 2] [--gate lexicon] --out template.json
  soke_main.py forge-run template.json --corpus DIR|files ... [--trials 40] [--minutes 60] [--priority math] [--tol 2]
                 [--min-gain 0.001] [--per-topic 6] [--holdout 2] [--tokens 192] [--ops a,b,c] [--save-dir DIR] [--export model.gguf]
  soke_main.py forge-export template.json --out model.gguf [--no-sidecar]     (a bare name saves into the export folder)
  soke_main.py chat model.gguf --prompt "..." [--max 48] [--temp 0.7] [--resident auto|stream|q8|f32]
  soke_main.py score model.gguf (--text "..." | --file f.txt) [--max-tokens 512]
  soke_main.py behavior [--list] [--climate seeking|equanimity|...] [--no-logic] [--out profile.json]
  soke_main.py clone [--user you] [--session MICRO|STANDARD|DEEP] [--out clone_profile.json]   (interactive battery)
  soke_main.py ingest-books <folder>                          (read PDFs/ebooks to text, report the topic mix)
  soke_main.py tandem [--route "..."] [--out tandem.json]      (optional math-driver knowledge-tree scaffold)
  soke_main.py forge-run ... [--behavior profile.json]   /   forge-export ... [--behavior profile.json] [--clone-consent]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import SOKE_NAME, SOKE_VERSION, AUTHOR, MOTTO
from .util import data_root, expand_corpus, human_bytes


def _p(obj) -> None:
    print(json.dumps(obj, indent=1, default=str))


def cmd_selftest(a):
    from .selftest import run
    ok, summary = run(quick=a.quick, verbose=not a.summary)
    return 0 if ok else 1


def cmd_train(a):
    from .orchestrator import Orchestrator, RunConfig
    from .model_engine import ModelConfig
    from .loss_engine import TrainConfig
    experts = [e.strip() for e in a.experts.split(",")] if a.experts else None
    mc = ModelConfig(d_model=a.d_model, n_heads=a.heads, n_layers=a.layers, d_ff=a.d_ff or 4 * a.d_model, ctx=a.ctx,
                     experts=experts or ModelConfig().experts, d_expert=a.d_expert or 2 * a.d_model)
    tc = TrainConfig(lr=a.lr, batch=a.batch, target_loss=a.target, scoped=a.scoped)
    cfg = RunConfig(model=mc, train=tc, steps_per_cycle=a.steps, max_cycles=a.cycles, heal_every=a.heal_every, grow_max=a.grow_max)
    last = {"step": 0}

    def on_event(kind, payload):
        if kind == "step" and payload["step"] % 20 == 0:
            print(f"  step {payload['step']:6d} loss {payload['loss']:.4f} lr {payload['lr']:.2e} gn {payload['gn']:.2f}")
        elif kind == "cycle":
            print(f"[cycle] train {payload['train_loss']:.4f} val {payload['val_loss']:.4f} lock {payload['lock']} best {payload['best_val']:.4f} floor {payload['floor']['status']}")
            for t in payload.get("trials", []):
                print(f"   trial {t['family']:<16} vC {t['v_control']:+.4f} vK {t['v_candidate']:+.4f} -> {'ADOPT' if t['success'] else 'reject'}")
        elif kind in ("grow", "heal", "checkpoint", "finalize", "run_end", "bootstrap", "learn", "corpus"):
            print(f"[{kind}] {json.dumps(payload, default=str)[:400]}")

    orb = Orchestrator(a.root, model_id=a.model_id, corpus=a.corpus, cfg=cfg, on_event=on_event)
    print(f"{SOKE_NAME} {SOKE_VERSION} — {AUTHOR}\nmodel {a.model_id}: {orb.model_path}")
    orb.bootstrap()
    orb.learn()
    rep = orb.run()
    if a.finalize:
        rep["finalize"] = orb.finalize()
    orb.close()
    _p(rep)
    return 0


def cmd_convert(a):
    from .gguf_rewrites import (convert_gguf_to_sff, GGUFReader, explain_conversion,
                                repack_gguf, explain_repack, write_modelfile)
    from .memguard import MemGuard
    from .ledger import Ledger
    src = Path(a.gguf)
    gr = GGUFReader(src)
    _p(gr.summary())
    gr.close()
    mg = MemGuard(soft_mb=a.soft_mb, hard_mb=a.hard_mb)
    led = Ledger(Path(a.root or data_root()) / "ledger" / "events.jsonl")
    mode = "reband" if (a.rebands or a.mode == "reband") else "exact"
    to = getattr(a, "to", "sff")

    def prog(d):
        print(f"  [{d.get('i', 0):4d}/{d.get('n', 0)}] {d.get('tensor', '')[:48]:<48} "
              f"{(d.get('type') or d.get('out_type', '')):<6} {d.get('status') or d.get('kind', ''):<8} rss {d.get('rss_mb', 0):.0f} MB")

    if to in ("sff", "both"):
        out = Path(a.out) if (a.out and a.out.endswith(".sff")) else src.with_suffix(".sff")
        st = convert_gguf_to_sff(src, out, budget=a.budget, memguard=mg, ledger=led, progress=prog, keep_types=not a.rebands, mode=mode)
        _p(st)
        print(explain_conversion(st, src, out))
    if to in ("gguf", "both"):
        tag = a.budget if mode == "reband" else "repack"
        out_g = Path(a.out) if (a.out and a.out.endswith(".gguf")) else src.with_name(f"{src.stem}.{tag}.gguf")
        sg = repack_gguf(src, out_g, budget=a.budget, mode=mode, keep_types=not a.rebands, memguard=mg, ledger=led, progress=prog)
        mf = write_modelfile(out_g)
        _p(sg)
        print(explain_repack(sg, src, out_g))
        print(f"  Modelfile: {mf}")
    return 0


def cmd_inspect(a):
    from .sff import SFFReader
    rd = SFFReader(a.sff)
    _p(rd.summary())
    if a.meta:
        _p({k: (v if len(json.dumps(v, default=str)) < 2000 else "<large>") for k, v in rd.meta.items()})
    if a.tensors:
        for t in rd.tensors.values():
            print(f"  {t.name:<48} {str(t.shape):<20} src {t.dtype_orig:<4} pages {t.page_count:6d} {t.status:<9} err_base {t.err_base:.2e} err {t.err_chosen:.2e}")
    if a.helices:
        for h in rd.helices.values():
            print(f"  helix {h.helix_id:4d} {h.name:<40} domain {h.domain_id:3d} kind {h.kind} pages {h.page_count} frames {h.frame_count}")
    if a.patches:
        for p in rd.patches()[-a.limit:]:
            print(f"  patch {p['patch_id']:5d} helix {p['helix']:4d} idx {p['index']:5d} {p['old_page']:7d}->{p['new_page']:7d} {p['kind']:<10} {p['note']}")
    if a.lineage:
        nodes, edges = rd.lineage()
        for n in nodes[-a.limit:]:
            print(f"  node {n['node_id']:5d} {n['kind']:<10} {n['label']}")
        for e in edges[-a.limit:]:
            print(f"  edge {e['src']:5d}->{e['dst']:5d} {e['op']}")
    if a.opt:
        for r in rd.opt_rows()[-a.limit:]:
            print(f"  {r['pipeline'][:56]:<56} base {r['baseline_ops']:.3e} ortho {r['ortho_ops']:.3e} cut {r['cut_pct']:6.1f}% {r['status']:<9} {r['note']}")
    if a.ledger:
        for r in rd.ledger_records()[-a.limit:]:
            print(f"  {r.get('seq', '?'):>5} {r.get('iso', '')} {r.get('protocol', ''):<4} {r.get('domain', ''):<12} {r.get('event', '')} {json.dumps(r.get('payload'), default=str)[:120]}")
    if a.experiments:
        for e in rd.experiments()[-a.limit:]:
            print(f"  exp {e['exp_id']:4d} type {e['exp_type']} {json.dumps(e['payload'], default=str)[:160]}")
    if a.verify:
        _p(rd.verify(deep=True))
    rd.close()
    return 0


def cmd_generate(a):
    from .model_engine import StreamingModel
    sm = StreamingModel(a.sff, expert_cache=a.expert_cache or None)
    out, info = sm.generate(a.prompt.encode("utf-8"), max_new=a.max, temperature=a.temp, top_k=a.top_k, seed=a.seed)
    print(a.prompt + out.decode("utf-8", errors="replace"))
    _p(info)
    sm.close()
    return 0


def cmd_ingest(a):
    from .memory_engine import HelicalMemory
    from .ledger import Ledger
    root = Path(a.root or data_root())
    mem = HelicalMemory(Path(a.knowledge) if a.knowledge else root / "knowledge.sff", ledger=Ledger(root / "ledger" / "events.jsonl"))
    files, rep = expand_corpus(a.files)
    _p(rep)
    for f in files:
        _p(mem.ingest_file(Path(f), domain=a.domain))
    _p(mem.stats())
    mem.close()
    return 0


def cmd_seek(a):
    from .memory_engine import HelicalMemory
    root = Path(a.root or data_root())
    mem = HelicalMemory(Path(a.knowledge) if a.knowledge else root / "knowledge.sff")
    for hid, pidx, off, score, rec in mem.seek(a.query, limit=a.limit):
        from .tower import domain_name
        print(f"  [{score}] {rec.base} {domain_name(rec.domain)}:{rec.ident}  {rec.text[:160]!r}")
    mem.close()
    return 0


def cmd_boot_math(a):
    from .math_engine import MathEngine
    root = Path(a.root or data_root())
    me = MathEngine(root / "math_graph.json")
    rep = me.boot()
    me.dump()
    for r in rep:
        print(f"stage {r['stage']} {'OK ' if r.get('ok') else 'FAIL'} {r['title']}")
        for row in r.get("rows", []):
            print(f"    {row['status']:<17} {row['kind']:<11} {row['statement'][:80]}  ({row['method']})")
    _p(me.stats())
    return 0


def cmd_heal(a):
    from .model_engine import SokeLM, ByteStream
    from .heal_engine import HealEngine
    from .ledger import Ledger
    root = Path(a.root or data_root())
    m = SokeLM.load_sff(a.sff)
    bs = ByteStream(expand_corpus(a.corpus)[0])
    batches = [bs.batch(8, m.cfg.ctx, val=True)[:2] for _ in range(3)]
    he = HealEngine(ledger=Ledger(root / "ledger" / "events.jsonl"))
    rep = he.sweep(m, batches, sff_path=Path(a.sff) if a.requant else None, requant_budget=a.requant)
    _p(rep)
    return 0


def cmd_grow(a):
    from .model_engine import SokeLM, ByteStream
    from .expansion_engine import ExpansionEngine
    from .ledger import Ledger
    root = Path(a.root or data_root())
    m = SokeLM.load_sff(a.sff)
    bs = ByteStream(expand_corpus(a.corpus)[0])
    batches = [bs.batch(4, m.cfg.ctx)[:2] for _ in range(2)]
    eng = ExpansionEngine(ledger=Ledger(root / "ledger" / "events.jsonl"))
    detail = {}
    if a.domain:
        detail["domain"] = a.domain
    if a.layer is not None:
        detail["layer"] = a.layer
    if a.add:
        detail["add"] = a.add
    rec = eng.grow(m, a.axis, batches, detail)
    _p(rec.__dict__)
    if rec.passed:
        _p(m.save_sff(a.sff, "append", keyframe=True, note=f"step {m.step} grow:{a.axis}"))
    return 0 if rec.passed else 1


def cmd_finalize(a):
    from .orchestrator import Orchestrator
    orb = Orchestrator(a.root, model_id=a.model_id, corpus=a.corpus)
    orb.bootstrap()
    orb.learn()
    _p(orb.finalize(budget=a.budget))
    orb.close()
    return 0


def cmd_rollback(a):
    from .model_engine import SokeLM
    m = SokeLM.load_sff(a.sff)
    _p(m.rollback_sff(a.sff, to_step=a.to_step))
    return 0


def cmd_compact(a):
    from .sff import compact
    _p(compact(Path(a.sff), Path(a.out)))
    return 0


def cmd_status(a):
    from .util import read_json
    from .ledger import Ledger
    root = Path(a.root or data_root())
    st = read_json(root / "state.json", {})
    out = dict(st) if st else {"status": "no state.json yet", "root": str(root)}
    lpath = root / "ledger" / "events.jsonl"
    if lpath.exists():                       # tamper check of the data root's ledger (hash chain + HMAC)
        ok, n, bad = Ledger(lpath).verify_chain()
        out["ledger"] = {"path": str(lpath), "records": n, "chain_ok": ok, "first_bad_seq": bad}
    _p(out)
    return 0 if out.get("ledger", {}).get("chain_ok", True) else 3


# ------------------------------------------------------------------ forge
def _forge_donors(names, ollama_dir=None):
    """Resolve --donors entries: .gguf paths, folders of .gguf files, or Ollama model names (substring match)."""
    from .forge import describe_gguf, donor_status, inventory_folder, inventory_ollama
    from .util import load_settings
    out, inv = [], None
    for n in names:
        pth = Path(n)
        if pth.is_file():
            d = describe_gguf(pth, label=pth.stem if pth.suffix else pth.name[:19], donor_id=f"D{len(out)}")
            if donor_status(d) != "ok":
                raise SystemExit(f"{n}: {d.arch} with {d.hp.get('n_expert', 0)} experts — not a donor family the forge can harvest")
            out.append(d)
        elif pth.is_dir():
            for d in inventory_folder(pth):
                if donor_status(d) == "ok":
                    d.id = f"D{len(out)}"; out.append(d)
        else:
            if inv is None:
                inv = inventory_ollama(ollama_dir) or inventory_folder(load_settings()["model_dir"])
            hits = [d for d in inv if n.lower() in d.label.lower() and donor_status(d) == "ok"]
            if not hits:
                raise SystemExit(f"no Ollama model matches '{n}' (have: {', '.join(d.label for d in inv) or 'none'})")
            for d in hits:
                d.id = f"D{len(out)}"; out.append(d)
    return out


def _out_path(out: str, root) -> Path:
    """A bare file name lands in the settings' export folder (Ollama's blob store by default); a path is used as given."""
    from .util import load_settings
    p = Path(out)
    if p.parent == Path("."):
        p = Path(load_settings(root)["export_dir"]) / p
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def cmd_settings(a):
    from .util import load_settings, save_settings
    root = Path(a.root or data_root())
    d = load_settings(root)
    changed = False
    for k in ("model_dir", "export_dir"):
        v = getattr(a, k)
        if v:
            d[k] = str(Path(v)); changed = True
    if changed:
        save_settings(d, root)
    _p({"settings": str(root / "settings.json"), **d})
    return 0


def cmd_forge_inventory(a):
    from .forge import family_groups, inventory_folder, inventory_ollama
    from .util import load_settings
    if a.ollama:
        donors = inventory_ollama(a.ollama_dir)
    else:
        folder = a.folder or load_settings(a.root or data_root())["model_dir"]
        print(f"scanning {folder}")
        donors = inventory_folder(folder)
    groups = family_groups(donors)
    print(f"{len(donors)} models, {len(groups)} usable families")
    for sig, ds in sorted(groups.items(), key=lambda kv: -len(kv[1])):
        print(f"  family {sig}")
        for d in ds:
            print(f"     {d.id:<4} {d.label:<40} {d.arch:<8} {human_bytes(d.size):>9}  {d.path}")
    from .forge import donor_status
    for d in donors:
        st = donor_status(d)
        if st == "arch":
            print(f"  skipped {d.label} ({d.arch}: not a forge family yet)")
        elif st == "moe":
            print(f"  chat-only {d.label} ({d.arch}, {d.hp.get('n_expert')} experts: mixture-of-experts files are not harvested yet)")
    if a.json:
        Path(a.json).parent.mkdir(parents=True, exist_ok=True)
        Path(a.json).write_text(json.dumps([d.to_dict() for d in donors], indent=1), encoding="utf-8")
    return 0


def cmd_forge_build(a):
    from .forge import ForgeSpec
    donors = _forge_donors(a.donors, a.ollama_dir)
    topics = [t.strip() for t in a.topics.split(",") if t.strip()]
    sp = ForgeSpec.preset(a.preset, donors, topics, shared_topic=a.shared, n_used=a.n_used, gate_init=a.gate, seed=a.seed)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(sp.to_json(), encoding="utf-8")
    print(sp.summary()); print(f"fingerprint {sp.fingerprint()} -> {a.out}")
    return 0


def _forge_events(kind, p):
    if kind == "baseline":
        tr, ho = p["train"], p["holdout"]
        print(f"[start] train {tr['total']:.4f}  " + "  ".join(f"{k} {v:.3f}" for k, v in tr["topics"].items()) + f"  | hold-out {ho['total']:.4f}")
    elif kind == "trial":
        print(f"[trial {p['n']:3d}] {p['op']:<14} {p['desc'][:60]:<60} {p['before']:.4f} -> {p['after']:.4f}  "
              f"{'KEPT' if p['accepted'] else 'null'}" + (f"  hold-out {p['holdout']:.4f}" if p.get('holdout') is not None else "") + f"  {p.get('seconds', 0):.0f}s")
    elif kind == "overfit_guard":
        print(f"[guard] hold-out worsened {p['streak']}x: back to the best hold-out template ({p['best_holdout']:.4f})")


def cmd_forge_run(a):
    from .forge import ForgeSpec
    from .forge_loop import ForgeTrainer, build_probes
    from .gguf_rewrites import GGUFReader
    from .ledger import Ledger
    from .memguard import MemGuard
    from .meta_optimizer import ResearchDB
    from .tokenizer import Tokenizer
    root = Path(a.root or data_root())
    sp = ForgeSpec.from_json(Path(a.spec).read_text(encoding="utf-8"))
    gr = GGUFReader(sp.donors[sp.d["base"]]["path"]); tok = Tokenizer(gr.kv); gr.close()
    topics = list(sp.topics) + (["general"] if "general" not in sp.topics else [])
    probes = build_probes(a.corpus, tok, topics, per_topic=a.per_topic, holdout_per_topic=a.holdout, max_tokens=a.tokens)
    counts = {t: (len(probes.train.get(t, [])), len(probes.holdout.get(t, []))) for t in topics}
    print(f"probes: {probes.n_tokens} tokens, per topic (train, hold-out) {counts}")
    ops = [o.strip() for o in a.ops.split(",")] if a.ops else None
    save_dir = Path(a.save_dir) if a.save_dir else root / "forge" / sp.d.get("name", "forge")
    behavior, clone_consent, clone_teeth = _load_behavior(getattr(a, "behavior", None), getattr(a, "clone_consent", False))
    if behavior is not None:
        print(f"behavior: climate '{behavior.name}', logic pillar {'on' if behavior.logic_enabled else 'off'}, "
              f"min_gain x{behavior.knobs()['min_gain_mult']:.2f}, heal_first={behavior.knobs()['heal_first']}")
    tr = ForgeTrainer(sp, probes, memguard=MemGuard(soft_mb=a.soft_mb, hard_mb=a.hard_mb), ledger=Ledger(root / "ledger" / "events.jsonl"),
                      research_db=ResearchDB(root / "research.db"), on_event=_forge_events, priority_topic=a.priority or None,
                      tol_priority=a.tol / 100.0, min_gain=a.min_gain, seed=a.seed, allow_ops=ops, save_dir=save_dir, behavior=behavior)
    rep = tr.run(max_trials=a.trials, time_budget_s=a.minutes * 60)
    print(f"done: {rep['accepted']} kept, {rep['nulls']} nulls, train {rep['train']['total']:.4f}, hold-out {rep['holdout']['total']:.4f}, "
          f"best hold-out {rep['best_holdout']:.4f}, {rep['evals']} evaluations in {rep['eval_seconds']} s; templates in {save_dir}")
    if a.export:
        from .forge import write_modelfile
        out = _out_path(a.export, root)
        st = tr.export(out, use_holdout_best=not a.current, clone_consent=clone_consent, clone_teeth=clone_teeth)
        mf = write_modelfile(out, out.stem)
        print(f"exported {out}: {human_bytes(st['bytes'])}, {st['exact']} exact + {st['novel']} novel tensors, peak {st['peak_rss_mb']:.0f} MB, sidecar {st.get('sidecar')}")
        print(f"register with Ollama:  ollama create {out.stem} -f \"{mf}\"")
    return 0


def cmd_forge_export(a):
    from .forge import ForgeSpec, assemble
    from .ledger import Ledger
    from .memguard import MemGuard
    root = Path(a.root or data_root())
    from .forge import write_modelfile
    sp = ForgeSpec.from_json(Path(a.spec).read_text(encoding="utf-8"))
    out = _out_path(a.out, root)
    behavior, clone_consent, clone_teeth = _load_behavior(getattr(a, "behavior", None), getattr(a, "clone_consent", False))
    st = assemble(sp, out, memguard=MemGuard(soft_mb=a.soft_mb, hard_mb=a.hard_mb), sidecar=not a.no_sidecar, ledger=Ledger(root / "ledger" / "events.jsonl"),
                  behavior=behavior, clone_consent=clone_consent, clone_teeth=clone_teeth,
                  progress=(lambda d: print(f"  {d['i']}/{d['n']} {d['tensor']}  RSS {d['rss_mb']:.0f} MB", end="\r")) if sys.stdout.isatty() else None)
    mf = write_modelfile(out, out.stem)
    print(f"written {out}: {human_bytes(st['bytes'])}, {st['exact']} tensors byte-exact, {st['novel']} novel/requantized, {st['elapsed_s']} s, "
          f"peak {st['peak_rss_mb']:.0f} MB" + (f", sidecar {st['sidecar']}" if st.get("sidecar") else ""))
    print(f"register with Ollama:  ollama create {out.stem} -f \"{mf}\"")
    return 0


def cmd_chat(a):
    from .llm_engine import LLM
    from .memguard import MemGuard
    m = LLM(a.gguf, memguard=MemGuard(soft_mb=a.soft_mb, hard_mb=a.hard_mb), resident=a.resident)
    txt, info = m.generate(a.prompt, max_new=a.max, temperature=a.temp, top_k=a.top_k, seed=a.seed, chat=not a.raw,
                           on_token=lambda s: print(s, end="", flush=True))
    m.close()
    print(f"\n[{info['tokens']} tokens, {info['seconds']} s, {info.get('tok_per_s')} tok/s, weights {info['resident_mode']}, RSS {info['rss_mb']} MB]")
    return 0


def cmd_score(a):
    from .llm_engine import LLM
    from .memguard import MemGuard
    text = a.text if a.text is not None else Path(a.file).read_text(encoding="utf-8", errors="replace")
    m = LLM(a.gguf, memguard=MemGuard(soft_mb=a.soft_mb, hard_mb=a.hard_mb), resident=a.resident)
    r = m.score_text(text, max_tokens=a.max_tokens)
    m.close()
    _p({"tokens": r["tokens"], "nll_per_token": r["nll"], "bits_per_token": r["bits_per_token"]})
    return 0


def cmd_behavior(a):
    from .behavior import CLIMATES, CLIMATES as _C, BehaviorProfile, C_NAMES
    if a.list or not a.climate:
        print("climates (each MODULATES the forge — it may bid, never close SELECT):")
        for name, prof in CLIMATES.items():
            k = prof.knobs()
            print(f"  {name:12s} min_gain x{k['min_gain_mult']:.2f}  heal_first={k['heal_first']}  happiness={prof.happiness_mix()}")
        if not a.climate:
            return 0
    prof = CLIMATES.get(a.climate)
    if prof is None:
        raise SystemExit(f"unknown climate {a.climate!r}; try --list")
    prof.logic_enabled = not a.no_logic
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(prof.to_json(), encoding="utf-8")
        print(f"wrote {a.out}")
    _p(prof.to_dict())
    return 0


def cmd_clone(a):
    """The Digital Psychoanalyst battery, at the terminal. One item at a time; SKIP/PASS/LATER/EDIT/STOP/RAW."""
    from .clone_battery import CloneBattery
    root = Path(a.root or data_root())
    cb = CloneBattery(user_id=a.user, session=a.session)
    c = cb.contract()
    print("\n" + c["script"] + "\n")
    print("Tokens you can type as an answer: " + ", ".join(c["tokens"]) + "\n")
    def ask(q):
        try:
            return input(q).strip()
        except EOFError:
            return "STOP"
    store = ask("Consent 1/4 - store answers in helix + GGUF metadata? [y/N] ").lower().startswith("y")
    adapters = ask("Consent 2/4 - allow emotion-conditioning adapters? [y/N] ").lower().startswith("y")
    forks = ask("Consent 3/4 - allow later forks by other users? [y/N] ").lower().startswith("y")
    red = ask("Consent 4/4 - hard-red topics to never ask (comma list, blank for none): ")
    cb.set_consent(store=store, adapters=adapters, forks=forks, hard_red=red.split(",") if red else [])
    while True:
        it = cb.next_item()
        if it is None:
            break
        print("\n" + cb.prompt(it))
        raw = ask("> ")
        tok = raw.upper() if raw.upper() in ("SKIP", "PASS", "LATER", "STOP", "RAW") else None
        if tok in ("SKIP", "PASS", "LATER", "STOP"):
            res = cb.answer(token=tok)
            if res.get("stopped"):
                break
            if res.get("offer_stop"):
                if ask("Three skips - type STOP to end, or Enter to continue: ").upper() == "STOP":
                    cb.answer(token="STOP"); break
            continue
        inten = 0.0
        if it.cue_type in ("word", "question", "climate") or it.battery in ("A", "C"):
            iv = ask("  intensity 0-10 (blank=0): ")
            try:
                inten = float(iv)
            except ValueError:
                inten = 0.0
        pick = ""
        if it.battery == "H":
            pick = ask("  pick LOGIC/FEELING/BRAID/VETO: ")
        neg = ask("  negative-pole feeling (blank to skip): ") if it.battery == "E" else ""
        res = cb.answer(response=raw, intensity=inten, pick=pick, invert_response=neg)
        if res.get("mimic"):
            print("  " + res["mimic"])
    end = cb.end_script()
    _p(end)
    out = a.out or str(root / "forge" / f"clone_{a.user}.json")
    ex = cb.export(out, name=f"clone:{a.user}")
    print(f"wrote {ex['path']} ({ex['committed']} committed answers; consent.store={ex['consent_store']})")
    print("attach it to a forge with:  soke forge-export <spec> --out model.gguf --behavior " + out + (" --clone-consent" if store else ""))
    return 0


def _load_behavior(path, clone_consent=False):
    if not path:
        return None, None, None
    from .behavior import BehaviorProfile
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    prof = BehaviorProfile.from_dict(d.get("profile", d))       # accepts a bare profile or a clone_profile.json
    teeth = None
    if "rows" in d:                                             # a clone_profile.json also carries the teeth
        from .clone_battery import Row, CloneBattery
        cb = CloneBattery.__new__(CloneBattery)
        cb.rows = [Row(**{k: r.get(k) for k in Row.__dataclass_fields__}) for r in d["rows"]]
        teeth = cb.helix_teeth()
    consent = {"store": bool(clone_consent)} if clone_consent else {"store": False}
    return prof, consent, teeth


def cmd_ingest_books(a):
    from .tower import route_text
    from .memory_engine import iter_file_text
    from .util import expand_corpus
    from pathlib import Path as _P
    files, rep = expand_corpus([a.folder])
    books = [f for f in files if str(f).lower().endswith((".pdf", ".epub", ".htm", ".html", ".xhtml", ".txt", ".md", ".docx"))]
    topics, chars, empties = {}, 0, []
    for f in books:
        got = 0
        try:
            for chunk in iter_file_text(_P(f), chunk_bytes=200000):
                got += len(chunk); chars += len(chunk)
                for i in range(0, len(chunk), 1500):
                    piece = chunk[i:i + 1500]
                    r = route_text(piece, top=1)
                    tp = r[0][0] if r and r[0][1] > 0.5 else "general"
                    topics[tp] = topics.get(tp, 0) + len(piece.split())
        except Exception as e:
            empties.append(f"{_P(f).name}: {type(e).__name__}"); continue
        if got < 40:
            empties.append(f"{_P(f).name}: no extractable text (scanned/DRM?)")
    print(f"read {len(books)} book(s), {chars:,} chars")
    tot = sum(topics.values()) or 1
    for tp, w in sorted(topics.items(), key=lambda kv: -kv[1]):
        print(f"  {tp:<14} {100*w/tot:5.1f}%")
    if empties:
        print("skipped (no text — SOKE does not OCR):")
        for e in empties[:20]:
            print("   " + e)
    print("suggested topic experts: " + ", ".join(t for t, _ in sorted(topics.items(), key=lambda kv: -kv[1]) if t != "general")[:8] if topics else "(none)")
    return 0


def cmd_tandem(a):
    from .tandem import TandemSpec
    if a.spec and Path(a.spec).exists():
        sp = TandemSpec.from_json(Path(a.spec).read_text(encoding="utf-8"))
    else:
        sp = TandemSpec.scaffold(a.name or "tandem", extra_topics=[t.strip() for t in (a.topics or "").split(",") if t.strip()])
    print(sp.describe())
    if a.route:
        print(f"\nroute {a.route!r} -> {' / '.join(sp.route(a.route))}")
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(sp.to_json(), encoding="utf-8"); print(f"scaffold -> {a.out}")
    return 0


def cmd_connectome(a):
    from .connectome_engine import Connectome
    from .memguard import MemGuard
    import numpy as np
    mg = MemGuard(soft_mb=getattr(a, "soft_mb", 768), hard_mb=getattr(a, "hard_mb", 900))
    act = a.action
    if act == "synth":
        c = Connectome.synthetic(n_nodes=a.nodes, avg_degree=a.degree, seed=a.seed)
        out = a.out or "connectome.sff"
        st = c.to_sff(out, memguard=mg)
        print(c.describe()); print(f"\nstored -> {out}  ({st['bytes']/1e6:.1f} MB)")
    elif act == "ingest":
        c = Connectome.from_csv(a.edges)
        out = a.out or (Path(a.edges).with_suffix(".sff"))
        st = c.to_sff(out, memguard=mg)
        print(c.describe()); print(f"\nstored -> {out}  ({st['bytes']/1e6:.1f} MB)")
    elif act == "neuprint":
        c = Connectome.from_neuprint(dataset=a.dataset, token=a.token, type_regex=a.types, max_nodes=a.max_nodes)
        out = a.out or "connectome.sff"
        st = c.to_sff(out, memguard=mg)
        print(c.describe()); print(f"\nstored -> {out}  ({st['bytes']/1e6:.1f} MB)")
    elif act == "info":
        c = Connectome.from_sff(a.sff)
        print(c.describe())
    elif act == "sim":
        c = Connectome.from_sff(a.sff)
        src = c.group(a.in_type) if a.in_type else c.sensory()
        out = c.group(a.out_type) if a.out_type else c.descending()
        if src.size == 0:
            print(f"no input neurons match {a.in_type!r}"); return 1
        vals = np.ones(min(src.size, a.fan), dtype=np.float32)
        read = c.simulate(src[:a.fan], vals, ticks=a.ticks, readout_idx=out, decay=a.decay, memguard=mg)
        order = np.argsort(-np.abs(read))[:10]
        print(c.describe())
        print(f"\nsimulated {a.ticks} ticks: injected {min(src.size, a.fan)} {a.in_type or 'SEN.*'} neurons -> "
              f"read {out.size} {a.out_type or 'DN.*'} neurons")
        print(f"  peak activity |mean|={float(np.mean(np.abs(read))):.4f}  top outputs: " +
              ", ".join(f"n{int(out[i])}={float(read[i]):+.3f}" for i in order if out.size))
    elif act == "pathways":
        c = Connectome.from_sff(a.sff)
        src = c.group(a.in_type) if a.in_type else c.sensory()
        dst = c.group(a.out_type) if a.out_type else c.descending()
        routes = c.pathways(src, dst, k=a.k, max_hops=a.max_hops)
        if not routes:
            print(f"no route from {a.in_type or 'SEN.*'} to {a.out_type or 'DN.*'} within {a.max_hops} hops"); return 0
        print(f"{len(routes)} route(s) {a.in_type or 'SEN.*'} -> {a.out_type or 'DN.*'} (cost = sum 1/synapse-weight):")
        for path, cost in routes:
            print(f"  cost {cost:.4f}  hops {len(path)-1}: " + " -> ".join(str(p) for p in path))
    else:
        print("connectome action must be one of: synth, ingest, neuprint, info, sim, pathways"); return 2
    return 0


def cmd_concept(a):
    from .concept_graph import ConceptGraph, paths_for, text_complexity
    from .memguard import MemGuard
    mg = MemGuard(soft_mb=getattr(a, "soft_mb", 768), hard_mb=getattr(a, "hard_mb", 900))
    act = a.action
    if act == "routes":
        if a.text and Path(a.text).exists():
            c = text_complexity(Path(a.text).read_text(encoding="utf-8", errors="replace"))
            print(f"{Path(a.text).name}: complexity {c:.3f} -> {paths_for(c, hi=a.hi)} routes")
        else:
            comp = float(a.complexity)
            print(f"complexity {comp:.3f} -> {paths_for(comp, hi=a.hi)} routes")
        return 0
    if act == "auto":
        folder = Path(a.texts)
        texts = {p.stem: p.read_text(encoding="utf-8", errors="replace") for p in sorted(folder.glob("*.txt"))}
        if not texts:
            print(f"no .txt files in {folder}"); return 1
        cg = ConceptGraph.auto_size_from_texts(texts, hi=a.hi)
    elif act == "build":
        spec = {}
        for item in (a.concepts or "").split(","):
            if ":" in item:
                n, v = item.split(":", 1); spec[n.strip()] = float(v)
        if not spec:
            print("give --concepts \"math:0.05,language:0.9\""); return 2
        cg = ConceptGraph.from_complexities(spec, hi=a.hi)
    else:
        print("concept-graph action must be one of: build, auto, routes"); return 2
    print(cg.describe())
    if a.out:
        st = cg.to_sff(a.out, memguard=mg)
        print(f"\nstored -> {a.out}  ({st['bytes']/1e6:.1f} MB, {st['n_nodes']:,} vessels)")
    return 0


def cmd_jev(a):
    from .jev_engine import JEVEngine
    jev = JEVEngine(tol=float(a.tol))
    act = a.action
    if act == "route":
        n = int(a.options)
        print(f"a query with {n} option(s), open_language={a.language}: routes down the "
              f"{JEVEngine.route(n, a.language).upper()} pillar "
              f"({'JEV decision — cheap, no autoregression' if JEVEngine.route(n, a.language)=='right' else 'language + emotion'})")
        return 0
    if act == "decide":
        # a build decision: keep improving on this path, change strategy, grow, or hold
        cands = [
            {"name": "add a second same-family donor", "op": "swap_layer_src", "before": 1.0, "after": 1.0 - (0.30 if a.single_donor else 0.05), "finite": True},
            {"name": "change operators / raise intensity", "op": "swap_expert", "before": 1.0, "after": 1.0 - (0.15 if a.stalling else 0.05), "finite": True},
            {"name": "grow a topic expert", "op": "add_expert", "before": 1.0, "after": 0.97, "finite": True},
            {"name": "hold (keep the current template)", "op": "hold", "before": 1.0, "after": 1.0, "finite": True},
        ]
        d = jev.decide(cands)
        print("JEV logic route (right pillar — a decision, not language):")
        for name, sc in sorted(d.scores.items(), key=lambda kv: -kv[1]):
            print(f"  {name:<40} score {sc:+.2f}   {d.verdicts.get(name,'')}")
        print(f"\n  -> {'DO' if d.committed else 'DEFER'}: {d.choice}   verdict {d.verdict}")
        print(f"     {d.reason}")
        return 0
    print("jev action must be one of: decide, route"); return 2


def cmd_mind(a):
    from .mind_engine import MindEngine, CORE7, AXES
    from .behavior import CLIMATES, BehaviorProfile
    prof = CLIMATES.get(a.climate) or BehaviorProfile()
    eng = MindEngine.from_behavior(prof, base_tokens=float(a.tokens))
    print(f"temperament '{a.climate}': reward_gain {eng.reward_gain:.2f}  threat_gain {eng.threat_gain:.2f}  "
          f"basin_stiffness {eng.stiffness:.2f}  (from the Forge/Behavior chemistry)")
    print("baseline:", eng.snapshot())
    act = a.action
    if act == "state":
        return 0
    if act == "feel":
        snap = eng.step(float(a.valence), float(a.arousal), a.affect)
        print("after the situation:", snap)
        return 0
    if act == "run":
        seq = []
        for item in (a.seq or "").split(","):
            item = item.strip()
            if not item:
                continue
            if ":" in item:
                v, ar = item.split(":", 1); seq.append((float(v), float(ar)))
            else:
                seq.append((float(item), 0.6))
        if not seq:
            print("give --seq 'valence:arousal,...' e.g. '-0.9:0.9,+0.8:0.5,-0.5:0.7'"); return 2
        print("\nsituational feed (the evolving response, not a blanket behavior):")
        for i, (v, ar) in enumerate(seq):
            s = eng.step(v, ar)
            dom = s["mood"]["dominant"]; tokens = s["tokens"]; ram = s["ram_headroom"]
            xs = " ".join(f"{AXES[k].split('_')[0]}={s['S'][AXES[k]]}" for k in range(4))
            print(f"  [{i+1}] situation v={v:+.2f} a={ar:.2f} -> {dom:<9} {xs}  tokens {tokens:.0f}  ram×{ram:.2f}")
        return 0
    print("mind action must be one of: state, feel, run"); return 2


def cmd_gui(a):
    from .gui import main as gui_main
    from .util import app_log
    import os
    if os.name == "nt":
        # an install updated in place repairs its own desktop icon / Start-Menu entry on start-up
        try:
            from .winshortcut import ensure_shortcuts
            rep = ensure_shortcuts(Path(__file__).resolve().parent.parent)
            app_log(f"shortcuts: {rep}", a.root)
        except Exception as e:
            app_log(f"shortcuts: failed {type(e).__name__}: {e}", a.root)
    gui_main(root=a.root)
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="soke_main.py", description=f"{SOKE_NAME} {SOKE_VERSION} — {AUTHOR} — {MOTTO}")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--root", default=argparse.SUPPRESS, help="data root (default %%SOKE_HOME%% or <install>\\soke_data)")
    p.add_argument("--root", default=None, help="data root (default %%SOKE_HOME%% or <install>\\soke_data)")
    sub = p.add_subparsers(dest="cmd")
    s = sub.add_parser("selftest", parents=[common])
    s.add_argument("--quick", action="store_true")
    s.add_argument("--summary", action="store_true")
    s.set_defaults(f=cmd_selftest)
    s = sub.add_parser("train", parents=[common])
    s.add_argument("--corpus", nargs="+", required=True)
    s.add_argument("--model-id", default="soke-v001")
    s.add_argument("--cycles", type=int, default=20)
    s.add_argument("--steps", type=int, default=100)
    s.add_argument("--d-model", type=int, default=128)
    s.add_argument("--heads", type=int, default=4)
    s.add_argument("--layers", type=int, default=3)
    s.add_argument("--d-ff", type=int, default=0)
    s.add_argument("--ctx", type=int, default=128)
    s.add_argument("--experts", default="")
    s.add_argument("--d-expert", type=int, default=0)
    s.add_argument("--lr", type=float, default=3e-3)
    s.add_argument("--batch", type=int, default=16)
    s.add_argument("--target", type=float, default=0.001)
    s.add_argument("--scoped", action="store_true")
    s.add_argument("--heal-every", type=int, default=3)
    s.add_argument("--grow-max", type=int, default=3)
    s.add_argument("--finalize", action="store_true")
    s.set_defaults(f=cmd_train)
    s = sub.add_parser("convert", parents=[common])
    s.add_argument("gguf")
    s.add_argument("--out", default=None)
    s.add_argument("--mode", default="exact", choices=["exact", "reband"], help="exact (default): every weight kept as-is; reband: Third-Law storage contest into --budget (lossy, errors recorded)")
    s.add_argument("--budget", default="8bit", choices=["f32", "f16", "8bit", "4bit"], help="storage band for --mode reband")
    s.add_argument("--rebands", action="store_true", help="reband and force every source type into --budget (ignores the source band)")
    s.add_argument("--to", default="sff", choices=["sff", "gguf", "both"], help="output format: .sff (SOKE, default), .gguf (for Ollama/LM Studio, writes a Modelfile too), or both")
    s.add_argument("--soft-mb", type=int, default=768)
    s.add_argument("--hard-mb", type=int, default=900)
    s.set_defaults(f=cmd_convert)
    s = sub.add_parser("inspect", parents=[common])
    s.add_argument("sff")
    for flag in ("meta", "tensors", "helices", "patches", "lineage", "opt", "ledger", "experiments", "verify"):
        s.add_argument(f"--{flag}", action="store_true")
    s.add_argument("--limit", type=int, default=40)
    s.set_defaults(f=cmd_inspect)
    s = sub.add_parser("generate", parents=[common])
    s.add_argument("sff")
    s.add_argument("--prompt", required=True)
    s.add_argument("--max", type=int, default=200)
    s.add_argument("--temp", type=float, default=0.8)
    s.add_argument("--top-k", type=int, default=40)
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--expert-cache", type=int, default=0)
    s.set_defaults(f=cmd_generate)
    s = sub.add_parser("ingest", parents=[common])
    s.add_argument("--files", nargs="+", required=True)
    s.add_argument("--knowledge", default=None)
    s.add_argument("--domain", default=None)
    s.set_defaults(f=cmd_ingest)
    s = sub.add_parser("seek", parents=[common])
    s.add_argument("query")
    s.add_argument("--knowledge", default=None)
    s.add_argument("--limit", type=int, default=8)
    s.set_defaults(f=cmd_seek)
    s = sub.add_parser("boot-math", parents=[common])
    s.set_defaults(f=cmd_boot_math)
    s = sub.add_parser("heal", parents=[common])
    s.add_argument("sff")
    s.add_argument("--corpus", nargs="+", required=True)
    s.add_argument("--requant", default=None, choices=[None, "f16", "8bit", "4bit"])
    s.set_defaults(f=cmd_heal)
    s = sub.add_parser("grow", parents=[common])
    s.add_argument("sff")
    s.add_argument("--corpus", nargs="+", required=True)
    s.add_argument("--axis", required=True, choices=["width", "depth", "expert", "expert_width"])
    s.add_argument("--domain", default=None)
    s.add_argument("--layer", type=int, default=None)
    s.add_argument("--add", type=int, default=0)
    s.set_defaults(f=cmd_grow)
    s = sub.add_parser("finalize", parents=[common])
    s.add_argument("--model-id", default="soke-v001")
    s.add_argument("--corpus", nargs="+", required=True)
    s.add_argument("--budget", default="8bit")
    s.set_defaults(f=cmd_finalize)
    s = sub.add_parser("rollback", parents=[common])
    s.add_argument("sff")
    s.add_argument("--to-step", type=int, default=None)
    s.set_defaults(f=cmd_rollback)
    s = sub.add_parser("compact", parents=[common])
    s.add_argument("sff")
    s.add_argument("--out", required=True)
    s.set_defaults(f=cmd_compact)
    s = sub.add_parser("status", parents=[common])
    s.set_defaults(f=cmd_status)
    mem = argparse.ArgumentParser(add_help=False)
    mem.add_argument("--soft-mb", type=int, default=768)
    mem.add_argument("--hard-mb", type=int, default=900)
    s = sub.add_parser("settings", parents=[common], help="show or set the model folder (scan) and export folder (save)")
    s.add_argument("--model-dir", default=None)
    s.add_argument("--export-dir", default=None)
    s.set_defaults(f=cmd_settings)
    s = sub.add_parser("forge-inventory", parents=[common], help="list the GGUF models the forge can harvest (the settings' model folder by default)")
    s.add_argument("--ollama", action="store_true", help="use Ollama's manifests instead of scanning the folder")
    s.add_argument("--ollama-dir", default=None, help="Ollama models directory for --ollama (default %%OLLAMA_MODELS%% or ~/.ollama/models)")
    s.add_argument("--folder", default=None, help="scan this folder instead of the settings' model folder")
    s.add_argument("--json", default=None, help="also write the inventory to this file")
    s.set_defaults(f=cmd_forge_inventory)
    s = sub.add_parser("forge-build", parents=[common], help="write a template (ForgeSpec JSON) from a preset")
    s.add_argument("--donors", nargs="+", required=True, help=".gguf files, folders, or Ollama model names")
    s.add_argument("--ollama-dir", default=None)
    s.add_argument("--preset", default="math-always-on", choices=["math-always-on", "all-routed", "dense", "interleave", "stack", "random"])
    s.add_argument("--topics", default="math,language,science,technology")
    s.add_argument("--shared", default="math", help="the always-on expert's topic")
    s.add_argument("--n-used", type=int, default=2, help="routed experts used per token")
    s.add_argument("--gate", default="lexicon", choices=["lexicon", "random", "zeros"])
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--out", required=True)
    s.set_defaults(f=cmd_forge_build)
    s = sub.add_parser("behavior", parents=[common], help="show behavioral climates or write a behavior profile (the fine-tuning layer)")
    s.add_argument("--list", action="store_true")
    s.add_argument("--climate", default=None)
    s.add_argument("--no-logic", action="store_true", help="disable the logic (proof-state) pillar")
    s.add_argument("--out", default=None)
    s.set_defaults(f=cmd_behavior)
    s = sub.add_parser("clone", parents=[common], help="Digital Psychoanalyst battery -> a personality-conditioned profile (consent-gated)")
    s.add_argument("--user", default="you")
    s.add_argument("--session", default="STANDARD", choices=["MICRO", "STANDARD", "DEEP"])
    s.add_argument("--out", default=None)
    s.set_defaults(f=cmd_clone)
    s = sub.add_parser("ingest-books", parents=[common], help="read a folder of PDFs/ebooks into text and report the topic mix (no OCR)")
    s.add_argument("folder")
    s.set_defaults(f=cmd_ingest_books)
    s = sub.add_parser("tandem", parents=[common], help="OPTIONAL scaffold: a math driver over a tree of per-branch gguf models")
    s.add_argument("--spec", default=None, help="load an existing tandem_spec.json instead of scaffolding")
    s.add_argument("--name", default="tandem")
    s.add_argument("--topics", default="", help="extra top-level branch topics, comma-separated")
    s.add_argument("--route", default=None, help="print which branch a test prompt routes to")
    s.add_argument("--out", default=None, help="write the scaffold JSON")
    s.set_defaults(f=cmd_tandem)
    s = sub.add_parser("jev", parents=[common], help="the JEV decision engine (logic/right pillar): scores build moves and closes them with the logic proof-state, no language")
    s.add_argument("action", choices=["decide", "route"])
    s.add_argument("--single-donor", action="store_true", help="decide: flag that donors don't share a family (favors adding one)")
    s.add_argument("--stalling", action="store_true", help="decide: flag that the build has stalled")
    s.add_argument("--options", type=int, default=3, help="route: number of options")
    s.add_argument("--language", action="store_true", help="route: the query is open language")
    s.add_argument("--tol", type=float, default=0.02)
    s.set_defaults(f=cmd_jev)
    s = sub.add_parser("mind", parents=[common], help="the live 4D thought/emotion engine (Transcendence): reward/punishment + evolving affect that modulates the model")
    s.add_argument("action", choices=["state", "feel", "run"])
    s.add_argument("--climate", default="neutral", help="temperament from the Forge/Behavior climates (neutral, seeking, daring, care, scarcity, joy, focus, equanimity)")
    s.add_argument("--valence", default="0.0", help="feel: situation valence -1..+1")
    s.add_argument("--arousal", default="0.6", help="feel: situation arousal 0..1")
    s.add_argument("--affect", default=None, help="feel: force an affect (joy/sadness/fear/anger/surprise/disgust/contempt)")
    s.add_argument("--seq", default=None, help="run: a feed 'valence:arousal,...' e.g. '-0.9:0.9,+0.8:0.5'")
    s.add_argument("--tokens", default="256", help="starting token budget (room to think)")
    s.set_defaults(f=cmd_mind)
    s = sub.add_parser("connectome", parents=[common, mem], help="build/store/run a connectome (neurons+synapses) inside SFF; a scaffold SOKE learns on top of")
    s.add_argument("action", choices=["synth", "ingest", "neuprint", "info", "sim", "pathways"])
    s.add_argument("--sff", default=None, help="the connectome .sff (for info/sim/pathways)")
    s.add_argument("--out", default=None, help="output .sff (for synth/ingest/neuprint)")
    s.add_argument("--nodes", type=int, default=50000, help="synthetic node count")
    s.add_argument("--degree", type=int, default=12, help="synthetic average out-degree")
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--edges", default=None, help="edge-list CSV (bodyId_pre,bodyId_post,weight[,type_pre,type_post])")
    s.add_argument("--dataset", default="male-cns:v1.0", help="neuPrint dataset (needs neuprint-python + --token, runs on your machine)")
    s.add_argument("--token", default=None, help="your neuPrint access token")
    s.add_argument("--max-nodes", type=int, default=200000)
    s.add_argument("--types", default="DN.*", help="neuPrint neuron-type regex to anchor the slice")
    s.add_argument("--in-type", default=None, help="input neuron-type regex (default SEN.*)")
    s.add_argument("--out-type", default=None, help="output/readout neuron-type regex (default DN.*)")
    s.add_argument("--ticks", type=int, default=8)
    s.add_argument("--fan", type=int, default=64, help="how many input neurons to inject")
    s.add_argument("--decay", type=float, default=0.8)
    s.add_argument("-k", type=int, default=5, help="number of pathways to return")
    s.add_argument("--max-hops", type=int, default=8)
    s.set_defaults(f=cmd_connectome)
    s = sub.add_parser("concept-graph", parents=[common, mem], help="expandable concept graph: size concepts by complexity (1..50 routes), grow/prune, store in SFF")
    s.add_argument("action", choices=["build", "auto", "routes"])
    s.add_argument("--concepts", default=None, help="build: 'name:complexity,...' e.g. 'arithmetic:0.05,language:0.9'")
    s.add_argument("--texts", default=None, help="auto: a folder of .txt files, one concept each, sized by its entropy")
    s.add_argument("--text", default=None, help="routes: size one text file")
    s.add_argument("--complexity", default="0.5", help="routes: size a bare complexity in [0,1]")
    s.add_argument("--hi", type=int, default=50, help="max routes for the most complex concept")
    s.add_argument("--out", default=None, help="write the compiled graph as a connectome .sff")
    s.set_defaults(f=cmd_concept)
    s = sub.add_parser("forge-run", parents=[common, mem], help="trial-and-error learning on a template, judged on your text")
    s.add_argument("spec")
    s.add_argument("--corpus", nargs="+", required=True)
    s.add_argument("--behavior", default=None, help="a behavior/clone profile JSON — the fine-tuning climate that tilts the loop")
    s.add_argument("--clone-consent", action="store_true", help="write clone metadata to the exported .gguf (requires --export)")
    s.add_argument("--trials", type=int, default=40)
    s.add_argument("--minutes", type=float, default=60)
    s.add_argument("--priority", default="math")
    s.add_argument("--tol", type=float, default=2.0, help="the priority topic may not worsen by more than this %%")
    s.add_argument("--min-gain", type=float, default=0.001)
    s.add_argument("--per-topic", type=int, default=6)
    s.add_argument("--holdout", type=int, default=2)
    s.add_argument("--tokens", type=int, default=192)
    s.add_argument("--ops", default=None, help="comma list of operators allowed (default: all)")
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--save-dir", default=None)
    s.add_argument("--export", default=None, help="write this .gguf (+ .sff) when done")
    s.add_argument("--current", action="store_true", help="export the current template instead of the best hold-out one")
    s.set_defaults(f=cmd_forge_run)
    s = sub.add_parser("forge-export", parents=[common, mem], help="assemble a template into a runnable .gguf (+ .sff sidecar)")
    s.add_argument("spec")
    s.add_argument("--out", required=True)
    s.add_argument("--no-sidecar", action="store_true")
    s.add_argument("--behavior", default=None, help="a behavior/clone profile JSON to write as metadata + helix (never into weights)")
    s.add_argument("--clone-consent", action="store_true", help="write soke.clone.* metadata (requires the profile's consent)")
    s.set_defaults(f=cmd_forge_export)
    s = sub.add_parser("chat", parents=[common, mem], help="generate with SOKE's own engine from any llama / qwen2 / qwen2moe .gguf")
    s.add_argument("gguf")
    s.add_argument("--prompt", required=True)
    s.add_argument("--max", type=int, default=48)
    s.add_argument("--temp", type=float, default=0.7)
    s.add_argument("--top-k", type=int, default=40)
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--raw", action="store_true", help="no chat template")
    s.add_argument("--resident", default="auto", choices=["auto", "stream", "q8", "f32"])
    s.set_defaults(f=cmd_chat)
    s = sub.add_parser("score", parents=[common, mem], help="teacher-forced loss of a text under a .gguf")
    s.add_argument("gguf")
    s.add_argument("--text", default=None)
    s.add_argument("--file", default=None)
    s.add_argument("--max-tokens", type=int, default=512)
    s.add_argument("--resident", default="auto", choices=["auto", "stream", "q8", "f32"])
    s.set_defaults(f=cmd_score)
    s = sub.add_parser("gui", parents=[common])
    s.set_defaults(f=cmd_gui)
    return p


def main(argv=None) -> int:
    p = build_parser()
    a = p.parse_args(argv)
    if not a.cmd:
        return cmd_gui(a)
    return a.f(a)
