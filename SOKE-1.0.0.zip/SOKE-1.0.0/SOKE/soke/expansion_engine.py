"""
soke.expansion_engine — the Expansion & Fork Protocol (EFP-GGUF v1.0 / EBFP).

LAW 1 additive-first; LAW 2 every new parameter inherits from something that works;
LAW 3 regressions are defects; LAW 4 forks only on tension; LAW 5 SOP audits every step.

Mechanics (all function-preserving at step 0, and PROVEN so on the live model by
an equivalence test before anything is committed):
  WIDEN  (Net2WiderNet): duplicate hidden units of the MLP / an expert; the duplicated
         unit's output rows are halved so the sum is unchanged  ->  identical logits.
  DEEPEN (identity block): insert a block whose attention/MLP/expert output
         projections are zero -> the block is the identity map.
  ADD EXPERT (scaffold split): a new expert whose output projection is zero and whose
         router bias is -30 (its gate ~ e^-30) -> other gates unchanged to 1e-13.
Capacity-utilisation metric: CUM = Δloss / Δparams(M). Fork detection: per-domain
loss divergence across an evaluation window (gradient tension proxy).
"""
from __future__ import annotations

import copy
import math
import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .rng import Rng

from .model_engine import ModelConfig, SokeLM

ROUTER_OFF = -30.0


@dataclass
class GrowthRecord:
    axis: str
    params_before: int
    params_after: int
    detail: dict
    equivalence_max_abs: float
    passed: bool
    ts: float = field(default_factory=time.time)


class ExpansionEngine:
    def __init__(self, ledger=None, tol: float = 1e-5):
        self.ledger = ledger
        self.tol = tol
        self.history: list[GrowthRecord] = []
        self.capacity_points: list[tuple[int, float]] = []     # (params, best val loss) per stage

    def _log(self, event: str, payload: dict) -> None:
        if self.ledger is not None:
            self.ledger.append("EFP", event, payload, domain="parametric")

    # --------------------------------------------------------------- widen
    @staticmethod
    def widen_ff(m: SokeLM, layer: int, add: int, rng: Optional[Rng] = None) -> dict:
        rng = rng or m.rng
        w1, w2 = m.p[f"blk.{layer}.w1"], m.p[f"blk.{layer}.w2"]
        F = w1.shape[1]
        src = rng.integers(0, F, add)
        new_w1 = np.concatenate([w1, w1[:, src]], axis=1)
        new_w2 = np.concatenate([w2, w2[src, :]], axis=0)
        # halve both copies of each duplicated unit's output row (count multiplicity)
        counts = np.bincount(src, minlength=F).astype(new_w2.dtype)
        for j in range(F):
            if counts[j] > 0:
                new_w2[j, :] /= (counts[j] + 1)
        for i, j in enumerate(src):
            new_w2[F + i, :] = w2[j, :] / (counts[j] + 1)
        m.p[f"blk.{layer}.w1"], m.p[f"blk.{layer}.w2"] = new_w1.astype(m.dt), new_w2.astype(m.dt)
        m.cfg.d_ff = int(new_w1.shape[1])
        return {"layer": layer, "added": int(add), "d_ff": m.cfg.d_ff}

    @staticmethod
    def widen_expert(m: SokeLM, layer: int, expert: int, add: int, rng: Optional[Rng] = None) -> dict:
        rng = rng or m.rng
        k1, k2 = f"blk.{layer}.expert.{expert}.w1", f"blk.{layer}.expert.{expert}.w2"
        w1, w2 = m.p[k1], m.p[k2]
        F = w1.shape[1]
        src = rng.integers(0, F, add)
        new_w1 = np.concatenate([w1, w1[:, src]], axis=1)
        new_w2 = np.concatenate([w2, w2[src, :]], axis=0)
        counts = np.bincount(src, minlength=F).astype(new_w2.dtype)
        for j in range(F):
            if counts[j] > 0:
                new_w2[j, :] /= (counts[j] + 1)
        for i, j in enumerate(src):
            new_w2[F + i, :] = w2[j, :] / (counts[j] + 1)
        m.p[k1], m.p[k2] = new_w1.astype(m.dt), new_w2.astype(m.dt)
        return {"layer": layer, "expert": expert, "added": int(add), "d_expert": int(new_w1.shape[1])}

    # -------------------------------------------------------------- deepen
    @staticmethod
    def deepen(m: SokeLM, position: Optional[int] = None) -> dict:
        c = m.cfg
        pos = c.n_layers if position is None else position
        # shift existing layers >= pos up by one
        for l in range(c.n_layers - 1, pos - 1, -1):
            for k in list(m.p.keys()):
                if k.startswith(f"blk.{l}."):
                    m.p[k.replace(f"blk.{l}.", f"blk.{l + 1}.", 1)] = m.p.pop(k)
        D, F, E = c.d_model, c.d_ff, c.n_experts
        Fe = m.p["blk.0.expert.0.w1"].shape[1] if "blk.0.expert.0.w1" in m.p else c.d_expert
        r, s, dt = m.rng, 0.02, m.dt
        m.p[f"blk.{pos}.ln1"] = np.ones(D, dt)
        for n in ("wq", "wk", "wv"):
            m.p[f"blk.{pos}.{n}"] = r.normal(0, s, (D, D)).astype(dt)
        m.p[f"blk.{pos}.wo"] = np.zeros((D, D), dt)                       # identity: attention contributes 0
        m.p[f"blk.{pos}.ln2"] = np.ones(D, dt)
        m.p[f"blk.{pos}.w1"] = r.normal(0, s, (D, F)).astype(dt)
        m.p[f"blk.{pos}.w2"] = np.zeros((F, D), dt)                       # identity: MLP contributes 0
        m.p[f"blk.{pos}.router"] = r.normal(0, s, (D, E)).astype(dt)
        m.p[f"blk.{pos}.router_b"] = np.zeros(E, dt)
        for e in range(E):
            m.p[f"blk.{pos}.expert.{e}.w1"] = r.normal(0, s, (D, Fe)).astype(dt)
            m.p[f"blk.{pos}.expert.{e}.w2"] = np.zeros((Fe, D), dt)        # identity: experts contribute 0
        c.n_layers += 1
        # keep tensor order canonical
        m.p = {k: m.p[k] for k in _canonical_order(m)}
        return {"position": pos, "n_layers": c.n_layers}

    # ---------------------------------------------------------- add expert
    @staticmethod
    def add_expert(m: SokeLM, domain: str) -> dict:
        c = m.cfg
        if domain in c.experts:
            raise ValueError(f"expert for {domain} already exists")
        E = c.n_experts
        Fe = m.p["blk.0.expert.0.w1"].shape[1]
        D, r, s, dt = c.d_model, m.rng, 0.02, m.dt
        for l in range(c.n_layers):
            m.p[f"blk.{l}.router"] = np.concatenate([m.p[f"blk.{l}.router"], r.normal(0, s, (D, 1)).astype(dt)], axis=1)
            m.p[f"blk.{l}.router_b"] = np.concatenate([m.p[f"blk.{l}.router_b"], np.array([ROUTER_OFF], dt)])
            m.p[f"blk.{l}.expert.{E}.w1"] = r.normal(0, s, (D, Fe)).astype(dt)
            m.p[f"blk.{l}.expert.{E}.w2"] = np.zeros((Fe, D), dt)
        c.experts = list(c.experts) + [domain]
        m.p = {k: m.p[k] for k in _canonical_order(m)}
        return {"expert_index": E, "domain": domain, "n_experts": c.n_experts}

    # ----------------------------------------------------------- the gate
    def equivalence_test(self, parent: SokeLM, child: SokeLM, batches: list[tuple[np.ndarray, np.ndarray]],
                         priors: Optional[list] = None) -> dict:
        """EFP:GATE — the child must reproduce the parent's logits on every batch (max |Δ| <= tol)."""
        worst = 0.0
        for i, (ids, tgt) in enumerate(batches):
            pr = priors[i] if priors else None
            lp = parent.forward(ids, tgt, prior=pr, cache=False)["logits"]
            lc = child.forward(ids, tgt, prior=pr, cache=False)["logits"]
            worst = max(worst, float(np.max(np.abs(lp - lc))))
        return {"max_abs_delta": worst, "passed": worst <= self.tol, "tol": self.tol, "batches": len(batches)}

    def grow(self, m: SokeLM, axis: str, batches: list, detail: Optional[dict] = None, optimizer=None) -> GrowthRecord:
        """Snapshot -> apply -> prove equivalence -> commit (or restore). Never breaks the base."""
        detail = dict(detail or {})
        parent = copy.deepcopy(m)
        before = m.n_params()
        if axis == "width":
            layer = detail.get("layer", 0)
            add = detail.get("add", max(8, m.p[f"blk.{layer}.w1"].shape[1] // 2))
            info = self.widen_ff(m, layer, add)
        elif axis == "depth":
            info = self.deepen(m, detail.get("position"))
        elif axis == "expert":
            info = self.add_expert(m, detail["domain"])
        elif axis == "expert_width":
            info = self.widen_expert(m, detail.get("layer", 0), detail.get("expert", 0), detail.get("add", 16))
        else:
            raise ValueError(f"unknown growth axis {axis}")
        eq = self.equivalence_test(parent, m, batches)
        rec = GrowthRecord(axis, before, m.n_params(), {**detail, **info, **eq}, eq["max_abs_delta"], eq["passed"])
        if not eq["passed"]:
            m.p = parent.p
            m.cfg = parent.cfg
            self._log("gate_fail_rollback", rec.__dict__)
        else:
            if optimizer is not None:
                optimizer.resize(m.p)
            self._log("grow", {"axis": axis, "params_before": before, "params_after": m.n_params(), **info, "max_abs_delta": eq["max_abs_delta"]})
        self.history.append(rec)
        return rec

    # ------------------------------------------------------- capacity / CUM
    def record_capacity(self, params: int, val_loss: float) -> None:
        self.capacity_points.append((params, val_loss))

    def cum(self) -> Optional[float]:
        """Capacity-utilisation metric of the last growth: Δloss per million new params (>0 means growth paid)."""
        if len(self.capacity_points) < 2:
            return None
        (p0, l0), (p1, l1) = self.capacity_points[-2], self.capacity_points[-1]
        if p1 == p0:
            return None
        return (l0 - l1) / ((p1 - p0) / 1e6)

    @staticmethod
    def capacity_curve(points: list[tuple[int, float]]) -> Optional[dict]:
        """Fit loss = a * P^-b + c on >= 3 (params, loss) points by log-linear regression on (loss - c) with c = min-0.01."""
        if len(points) < 3:
            return None
        P = np.array([p for p, _ in points], float)
        L = np.array([l for _, l in points], float)
        c = float(L.min()) - 0.01
        y = np.log(np.maximum(L - c, 1e-6))
        x = np.log(P)
        # least squares y = s*x + t by the closed-form normal equations (no numpy.linalg: its compiled
        # submodule can be blocked by Windows Application Control; numpy core is all that is needed)
        n = float(x.size)
        sx, sy = float(x.sum()), float(y.sum())
        sxx, sxy = float(np.dot(x, x)), float(np.dot(x, y))
        den = n * sxx - sx * sx
        if abs(den) < 1e-12:
            return None
        slope = (n * sxy - sx * sy) / den
        icpt = (sy - slope * sx) / n
        b = -slope
        a = math.exp(icpt)
        return {"a": a, "b": b, "c": c}

    @staticmethod
    def detect_fork(domain_losses_before: dict, domain_losses_after: dict, tension: float = 0.05) -> list[dict]:
        """Gradient-tension proxy: domains whose loss rose while the majority fell."""
        deltas = {d: domain_losses_after[d] - domain_losses_before[d] for d in domain_losses_after if d in domain_losses_before}
        if not deltas:
            return []
        falling = sum(1 for v in deltas.values() if v < 0)
        out = []
        for d, v in deltas.items():
            if v > tension and falling >= max(1, len(deltas) // 2):
                out.append({"domain": d, "delta": round(v, 4), "strategy": "scaffold_split(add_expert)"})
        return out


def _canonical_order(m: SokeLM) -> list[str]:
    c = m.cfg
    order = ["tok_emb", "pos_emb"]
    for l in range(c.n_layers):
        order += [f"blk.{l}.ln1", f"blk.{l}.wq", f"blk.{l}.wk", f"blk.{l}.wv", f"blk.{l}.wo", f"blk.{l}.ln2",
                  f"blk.{l}.w1", f"blk.{l}.w2", f"blk.{l}.router", f"blk.{l}.router_b"]
        for e in range(c.n_experts):
            order += [f"blk.{l}.expert.{e}.w1", f"blk.{l}.expert.{e}.w2"]
    order.append("lnf")
    return [k for k in order if k in m.p]


def verify_suite(chk=None):
    from .util import Check
    from .model_engine import AdamW
    chk = chk or Check("expansion")
    cfg = ModelConfig(d_model=32, n_heads=4, n_layers=2, d_ff=48, ctx=16, experts=["math", "music"], d_expert=24, dtype="float64")
    m = SokeLM(cfg, seed=4)
    for k in m.p:
        if m.p[k].ndim == 2:
            m.p[k] *= 10
    rng = Rng(0)
    batches = [(rng.integers(0, 256, (2, 16)), rng.integers(0, 256, (2, 16))) for _ in range(3)]
    eng = ExpansionEngine(tol=1e-9)
    opt = AdamW(m.p)
    n0 = m.n_params()
    r = eng.grow(m, "width", batches, {"layer": 0, "add": 24}, optimizer=opt)
    chk("Net2Wider FF: identical logits at step 0", r.passed and m.n_params() > n0, f"max|Δ| {r.equivalence_max_abs:.2e}")
    r = eng.grow(m, "expert_width", batches, {"layer": 1, "expert": 1, "add": 12}, optimizer=opt)
    chk("Net2Wider expert: identical logits", r.passed, f"max|Δ| {r.equivalence_max_abs:.2e}")
    r = eng.grow(m, "depth", batches, {"position": 1}, optimizer=opt)
    chk("identity block insertion: identical logits", r.passed and m.cfg.n_layers == 3, f"max|Δ| {r.equivalence_max_abs:.2e}")
    r = eng.grow(m, "expert", batches, {"domain": "art"}, optimizer=opt)
    chk("add expert (scaffold split): gates unchanged to 1e-9", r.passed and m.cfg.n_experts == 3 and m.p["blk.0.router_b"][-1] == ROUTER_OFF, f"max|Δ| {r.equivalence_max_abs:.2e}")
    # the grown model trains (optimizer resized) and the gradient still checks against finite differences
    ids, tgt = batches[0]
    out = m.forward(ids, tgt)
    g = m.backward(out)
    name = "blk.0.w2"                       # the widened MLP output rows (new units live at the end)
    eps = 1e-6
    flat = m.p[name].reshape(-1)
    i = flat.size - 3
    old = flat[i]
    flat[i] = old + eps
    lp = m.forward(ids, tgt, cache=False)["total"]
    flat[i] = old - eps
    lm = m.forward(ids, tgt, cache=False)["total"]
    flat[i] = old
    num = (lp - lm) / (2 * eps)
    ana = g[name].reshape(-1)[i]
    chk("grown model backward still matches finite differences", num != 0 and abs(num - ana) <= 1e-6 * max(1.0, abs(num)), f"{num:.3e} vs {ana:.3e}")
    opt.step(m.p, g)
    chk("optimizer resized for new tensors", all(opt.m[k].shape == v.shape for k, v in m.p.items()))
    # gate failure path: a deliberately non-preserving change must be rolled back
    class Bad(ExpansionEngine):
        @staticmethod
        def widen_ff(m, layer, add, rng=None):
            m.p[f"blk.{layer}.w2"] = m.p[f"blk.{layer}.w2"] * 1.5
            return {"layer": layer}
    bad = Bad(tol=1e-9)
    p_before = {k: v.copy() for k, v in m.p.items()}
    r = bad.grow(m, "width", batches, {"layer": 0, "add": 4})
    chk("gate failure rolls back to the parent (never break the base)", not r.passed and all(np.array_equal(p_before[k], m.p[k]) for k in p_before))
    eng.record_capacity(1_000_000, 2.0)
    eng.record_capacity(2_000_000, 1.7)
    chk("CUM = Δloss per M params", abs(eng.cum() - 0.3) < 1e-12)
    cc = ExpansionEngine.capacity_curve([(1e6, 2.0), (2e6, 1.7), (4e6, 1.5), (8e6, 1.38)])
    chk("capacity curve fit a*P^-b+c", cc is not None and cc["b"] > 0)
    forks = ExpansionEngine.detect_fork({"math": 1.0, "music": 1.0, "art": 1.0}, {"math": 0.9, "music": 0.9, "art": 1.2})
    chk("fork detection flags the tense domain", forks and forks[0]["domain"] == "art")
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
