"""
SOKE - Self-Optimizing Knowledge Engine
(from Old English *soke*: in Anglo-Saxon and early English law, the right to hold court and administer
justice with the franchise to receive the fees or fines arising from it - jurisdiction over a territory
or over people. The engine holds court over the models it builds.)

Writes, trains, converts, heals, expands and streams SFF (.sff) models, forges new GGUF models from a
template while harvesting weights from others, and fine-tunes them with a behavioral conditioning layer.

BS Medicineman / Knight Industries

Everything carries the SOKE name. The data root is %SOKE_HOME% (default <install>\\soke_data). The SFF
on-disk magic stays "SKNT" and legacy skynet-lm .sff models still load, so existing model files keep working.
"""
SOKE_NAME = "SOKE"
SOKE_LONG = "Self-Optimizing Knowledge Engine"
SOKE_VERSION = "2.0.0"
SFF_SCHEMA = "SFF-1.0"
AUTHOR = "BS Medicineman / Knight Industries"
MOTTO = "jurisdiction over the model"
SOKE_DEF = ("SOKE - Self-Optimizing Knowledge Engine. From Old English *soke*: the right to hold court and "
            "administer justice, with the franchise to receive the fees arising from it; jurisdiction over a "
            "territory or over people.")
__version__ = SOKE_VERSION
__all__ = ["SOKE_NAME", "SOKE_LONG", "SOKE_VERSION", "SFF_SCHEMA", "AUTHOR", "MOTTO", "SOKE_DEF"]
