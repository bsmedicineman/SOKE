"""
soke.loss_engine — the Autonomous Loss Minimization protocol (ALM v1.0), the
descent engine: DIAGNOSE -> HYPOTHESIZE -> EXPERIMENT -> MEASURE -> ADOPT/REJECT
-> LEDGER -> INTERLOCK (SOP/EFP gates), with the ratchet and the anti-overfit laws.

Reality check kept in force (from the ALM text itself): a cross-entropy of 0.001
on natural language is unreachable except by memorization; the 0.001 target is
claimable ONLY against a declared scoped corpus (LAW C). On general text the
engine descends toward the corpus' own entropy floor and declares
GENERAL_FLOOR_REACHED (LAW D) instead of pretending.

Loss decomposition every cycle:
  optimization debt  = loss velocity over the window (nats/step)
  batch noise        = std of the training loss over the window
  memorization debt  = val_loss - train_loss (LAW B: gap > 0.3 -> regularize)
  rare-byte tax      = share of loss carried by bytes below 0.1% corpus frequency
  floors             = order-0 (unigram) and order-1 (bigram) entropies of the stream
Plateau classes: DESCENDING | OPT_LOCK | NOISE_LOCK | DATA_LOCK | CAP_LOCK | REPRESENTATION_LOCK
Trials: cheap horizon (K steps), CONTROL ARM from the same snapshot with the same
batches, judged on loss velocity + stability, adopted only on a clean win.
"""
from __future__ import annotations

import copy
import math
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from .rng import Rng

from .meta_optimizer import MetaOptimizer, PLAYBOOK
from .model_engine import AdamW, ByteStream, SokeLM


@dataclass
class TrainConfig:
    lr: float = 3e-3
    batch: int = 16
    warmup: int = 50
    wd: float = 0.01
    clip: float = 1.0
    beta2: float = 0.99
    val_every: int = 50
    val_batches: int = 4
    checkpoint_every: int = 200
    keyframe_every: int = 4                 # every K-th checkpoint is a key-frame, the rest are DELTA8
    target_loss: float = 0.001
    scoped: bool = False                    # LAW C: 0.001 only claimable when scoped
    trial_steps: int = 40
    window: int = 50
    max_steps: int = 100000
    stall_cycles_before_cap: int = 3
    seed: int = 369

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Diagnosis:
    train_loss: float
    val_loss: float
    velocity: float
    noise: float
    gap: float
    rare_tax: float
    unigram_floor: float
    bigram_floor: float
    grad_norm: float
    lock: str
    detail: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return asdict(self)


class LossEngine:
    def __init__(self, model: SokeLM, stream: ByteStream, cfg: TrainConfig, ledger=None, meta: Optional[MetaOptimizer] = None,
                 memguard=None, research_db=None, on_step: Optional[Callable[[dict], None]] = None):
        self.m = model
        self.stream = stream
        self.cfg = cfg
        self.ledger = ledger
        self.meta = meta or MetaOptimizer(research_db)
        self.db = research_db
        self.mg = memguard
        self.on_step = on_step
        self.opt = AdamW(model.p, lr=cfg.lr, betas=(0.9, cfg.beta2), wd=cfg.wd)
        self.history: list[dict] = []          # per step {step, loss, aux, gn, lr}
        self.val_history: list[tuple[int, float]] = []
        self.best_val = float("inf")
        self.best_step = -1
        self.milestones: list[dict] = []
        self.failed_families: dict[str, int] = {}
        self.stalled_cycles = 0
        self.halted = False
        self.halt_reason = ""
        self.floors: dict = {}
        self.stop = False
        self._rare_bytes: Optional[np.ndarray] = None

    # ----------------------------------------------------------- logging
    def _log(self, event: str, payload: dict) -> None:
        if self.ledger is not None:
            self.ledger.append("ALM", event, payload, domain="parametric")

    # ----------------------------------------------------------- schedule
    def lr_at(self, step: int) -> float:
        c = self.cfg
        if step < c.warmup:
            return c.lr * (step + 1) / c.warmup
        return c.lr

    # ------------------------------------------------------------- train
    def train_steps(self, n: int, seed: Optional[int] = None, record: bool = True) -> list[float]:
        losses = []
        rng_state = None
        if seed is not None:
            rng_state = self.stream.rng.bit_generator.state
            self.stream.rng = Rng(seed)
        for _ in range(n):
            if self.stop:
                break
            ids, tgt, texts = self.stream.batch(self.cfg.batch, self.m.cfg.ctx)
            prior = self.m.prior_bias(texts)
            out = self.m.forward(ids, tgt, prior=prior)
            g = self.m.backward(out)
            self.opt.lr = self.lr_at(self.m.step)
            gn = self.opt.step(self.m.p, g, clip=self.cfg.clip)
            loss = out["loss"]
            losses.append(loss)
            self.m.step += 1
            if record:
                row = {"step": self.m.step, "loss": loss, "aux": out["aux"], "gn": gn, "lr": self.opt.lr}
                self.history.append(row)
                if self.on_step:
                    self.on_step(row)
            if self.mg is not None and self.m.step % 10 == 0:
                self.mg.check("train")
            if self.m.step % 8 == 0:
                self.stream.refill()
        if rng_state is not None:
            self.stream.rng.bit_generator.state = rng_state
        return losses

    def evaluate(self, n_batches: Optional[int] = None, val: bool = True) -> dict:
        n = n_batches or self.cfg.val_batches
        losses, per_tok = [], []
        rng_state = self.stream.rng.bit_generator.state
        self.stream.rng = Rng(self.cfg.seed + 7)
        ids_all = []
        for _ in range(n):
            ids, tgt, texts = self.stream.batch(self.cfg.batch, self.m.cfg.ctx, val=val)
            out = self.m.forward(ids, tgt, prior=self.m.prior_bias(texts), cache=False)
            losses.append(out["loss"])
            per_tok.append(out["per_token_nll"])
            ids_all.append(tgt)
        self.stream.rng.bit_generator.state = rng_state
        loss = float(np.mean(losses))
        nll = np.concatenate([p.ravel() for p in per_tok])
        tg = np.concatenate([t.ravel() for t in ids_all])
        rare = self._rare_mask(tg)
        rare_tax = float(np.sum(nll[rare]) / max(np.sum(nll), 1e-12)) if rare.any() else 0.0
        return {"loss": loss, "rare_tax": rare_tax, "n": n}

    def _rare_mask(self, targets: np.ndarray) -> np.ndarray:
        if self._rare_bytes is None:
            buf = np.frombuffer(bytes(self.stream.buf), dtype=np.uint8)
            counts = np.bincount(buf, minlength=256) / max(buf.size, 1)
            self._rare_bytes = counts < 1e-3
        return self._rare_bytes[targets.clip(0, 255)]

    # ------------------------------------------------------------ floors
    def entropy_floors(self) -> dict:
        buf = np.frombuffer(bytes(self.stream.buf), dtype=np.uint8)
        if buf.size < 1000:
            return {"unigram": float("nan"), "bigram": float("nan")}
        p = np.bincount(buf, minlength=256).astype(np.float64)
        p /= p.sum()
        h0 = float(-np.sum(p[p > 0] * np.log(p[p > 0])))
        pairs = buf[:-1].astype(np.int64) * 256 + buf[1:]
        c2 = np.bincount(pairs, minlength=65536).astype(np.float64).reshape(256, 256)
        row = c2.sum(axis=1, keepdims=True)
        with np.errstate(divide="ignore", invalid="ignore"):
            cond = np.where(row > 0, c2 / np.maximum(row, 1), 0.0)
            h1 = float(-np.sum(c2[cond > 0] / c2.sum() * np.log(cond[cond > 0])))
        self.floors = {"unigram": h0, "bigram": h1}
        return self.floors

    # ---------------------------------------------------------- diagnose
    def diagnose(self) -> Diagnosis:
        c = self.cfg
        hist = self.history[-c.window:]
        losses = np.array([h["loss"] for h in hist]) if hist else np.array([float("nan")])
        gns = np.array([h["gn"] for h in hist]) if hist else np.array([0.0])
        if losses.size >= 10:
            x = np.arange(losses.size)
            vel = float(np.polyfit(x, losses, 1)[0])
        else:
            vel = float("nan")
        noise = float(np.std(losses)) if losses.size > 1 else 0.0
        ev = self.evaluate()
        tr = float(np.mean(losses[-10:])) if losses.size else float("nan")
        gap = ev["loss"] - tr
        floors = self.entropy_floors()
        lock = "DESCENDING"
        detail = {}
        if not math.isnan(vel) and vel < -0.002:
            lock = "DESCENDING"
        elif gap > 0.3:
            lock = "DATA_LOCK"
            detail["law"] = "B: train/val gap > 0.3 -> regularization intervention"
        elif losses.size > 1 and noise > 0.15 * max(tr, 1e-6):
            lock = "NOISE_LOCK"
        elif self.stalled_cycles >= c.stall_cycles_before_cap and self._families_exhausted(("OPT_LOCK", "NOISE_LOCK")):
            lock = "CAP_LOCK"
        elif self.stalled_cycles >= c.stall_cycles_before_cap + 2 and self._families_exhausted(("OPT_LOCK", "NOISE_LOCK", "CAP_LOCK")):
            lock = "REPRESENTATION_LOCK"
        else:
            lock = "OPT_LOCK"
        d = Diagnosis(tr, ev["loss"], vel, noise, gap, ev["rare_tax"], floors["unigram"], floors["bigram"],
                      float(np.mean(gns)), lock, detail)
        self._log("diagnose", d.as_dict())
        return d

    def _families_exhausted(self, locks: tuple) -> bool:
        for lk in locks:
            fams = PLAYBOOK.get(lk, [])
            tried = [f for f in fams if self.failed_families.get(f"{lk}:{f}", 0) >= 1]
            if len(tried) < min(2, len(fams)):
                return False
        return True

    # ------------------------------------------------------- hypotheses
    def hypothesize(self, lock: str) -> list[str]:
        ranked = self.meta.rank(lock)
        return [f for f, _ in ranked]

    def _apply_family(self, family: str) -> dict:
        """Mutate the live config/optimizer for a hypothesis; returns the change (for rollback)."""
        c = self.cfg
        before = {"lr": c.lr, "batch": c.batch, "wd": c.wd, "clip": c.clip, "beta2": c.beta2, "prior_weight": self.m.cfg.prior_weight}
        if family == "lr_down":
            c.lr *= 0.5
        elif family == "lr_up":
            c.lr *= 1.6
        elif family == "warm_restart":
            self.opt.reset(self.m.p)
        elif family == "wd_sweep":
            c.wd = 0.05 if c.wd < 0.05 else 0.0
        elif family == "wd_up":
            c.wd = min(0.2, c.wd * 2 + 0.01)
        elif family == "clip_tighten":
            c.clip = max(0.25, c.clip * 0.5)
        elif family == "beta2_down":
            c.beta2 = 0.95
        elif family == "batch_up":
            c.batch = min(64, c.batch * 2)
        elif family == "prior_weight_up":
            self.m.cfg.prior_weight = min(2.0, self.m.cfg.prior_weight * 2 + 0.1)
        elif family == "prior_weight_down":
            self.m.cfg.prior_weight = self.m.cfg.prior_weight * 0.5
        elif family == "osp_leg_swap":
            pass   # handled by the OSP hook in trial()
        self.opt.wd, self.opt.b2 = c.wd, c.beta2
        return before

    def _restore_family(self, before: dict) -> None:
        c = self.cfg
        c.lr, c.batch, c.wd, c.clip, c.beta2 = before["lr"], before["batch"], before["wd"], before["clip"], before["beta2"]
        self.m.cfg.prior_weight = before["prior_weight"]
        self.opt.wd, self.opt.b2 = c.wd, c.beta2

    # -------------------------------------------------------------- trial
    @staticmethod
    def _velocity(losses: list[float]) -> float:
        n = len(losses)
        if n < 4:
            return 0.0
        q = max(1, n // 4)
        return float(np.mean(losses[-q:]) - np.mean(losses[:q])) / n

    def trial(self, family: str, lock: str) -> dict:
        """
        Cheap trial with a CONTROL ARM: both arms start from the same snapshot and see the same
        batches (same stream seed). Candidate wins only if its velocity improves by >5% AND it is
        stable (no NaN, no spike > 2x the control's worst).
        """
        c = self.cfg
        K = c.trial_steps
        seed = int(self.stream.rng.integers(0, 2 ** 31))
        snap_p = {k: v.copy() for k, v in self.m.p.items()}
        snap_opt = copy.deepcopy(self.opt)
        snap_step = self.m.step
        snap_cfg = copy.deepcopy(self.m.cfg)
        # control arm
        ctrl = self.train_steps(K, seed=seed, record=False)
        self.m.p = {k: v.copy() for k, v in snap_p.items()}
        self.opt = copy.deepcopy(snap_opt)
        self.m.step = snap_step
        # candidate arm
        before = self._apply_family(family)
        if family == "osp_leg_swap":
            cand = self._trial_leg_swap(K, seed)
        else:
            cand = self.train_steps(K, seed=seed, record=False)
        if len(ctrl) < K or len(cand) < K:
            # a Stop landed inside the trial: neither arm ran its full horizon, so the comparison is void.
            # Restore the snapshot untouched and report an ABORTED trial (never a win, never a null against the family).
            self.m.p = snap_p
            self.opt = snap_opt
            self.m.step = snap_step
            self._restore_family(before)
            self.m.cfg = snap_cfg
            rec = {"family": family, "lock": lock, "steps": K, "v_control": 0.0, "v_candidate": 0.0, "stable": False,
                   "loss_ctrl_end": float(np.mean(ctrl[-5:])) if ctrl else float("nan"),
                   "loss_cand_end": float(np.mean(cand[-5:])) if cand else float("nan"), "success": False, "aborted": True}
            self._log("trial_aborted", rec)
            return rec
        v_c, v_k = self._velocity(ctrl), self._velocity(cand)
        stable = bool(np.all(np.isfinite(cand))) and (max(cand) <= 2.0 * max(ctrl) + 1e-9)
        win = stable and (v_k < v_c - 0.05 * abs(v_c) - 1e-6) and (np.mean(cand[-5:]) < np.mean(ctrl[-5:]))
        rec = {"family": family, "lock": lock, "steps": K, "v_control": v_c, "v_candidate": v_k, "stable": stable,
               "loss_ctrl_end": float(np.mean(ctrl[-5:])), "loss_cand_end": float(np.mean(cand[-5:])), "success": win}
        # restore snapshot; keep the change only on a win (the ratchet: nothing regresses)
        self.m.p = snap_p
        self.opt = snap_opt
        self.m.step = snap_step
        if win:
            self.opt.wd, self.opt.b2 = c.wd, c.beta2
            self._log("adopt", rec)
        else:
            self._restore_family(before)
            self.m.cfg = snap_cfg
            self.failed_families[f"{lock}:{family}"] = self.failed_families.get(f"{lock}:{family}", 0) + 1
            self._log("reject", rec)
        self.meta.record(lock, family, win, hypothesis=family, config=c.to_dict(), loss_before=rec["loss_ctrl_end"],
                         loss_after=rec["loss_cand_end"], v_control=v_c, v_candidate=v_k, stable=stable,
                         insights="control-arm trial")
        return rec

    def _trial_leg_swap(self, K: int, seed: int) -> list[float]:
        """OSP:DUAL — the Z2 leg swap on the input representation: train on reversed byte order for the
        trial horizon. Recorded as a NULL when it does not beat the control (nulls are deliverables)."""
        losses = []
        rng_state = self.stream.rng.bit_generator.state
        self.stream.rng = Rng(seed)
        for _ in range(K):
            ids, tgt, texts = self.stream.batch(self.cfg.batch, self.m.cfg.ctx)
            seq = np.concatenate([ids[:, :1], tgt], axis=1)[:, ::-1]
            ids2, tgt2 = seq[:, :-1], seq[:, 1:]
            out = self.m.forward(ids2, tgt2, prior=self.m.prior_bias(texts))
            g = self.m.backward(out)
            self.opt.lr = self.lr_at(self.m.step)
            self.opt.step(self.m.p, g, clip=self.cfg.clip)
            losses.append(out["loss"])
            self.m.step += 1
        self.stream.rng.bit_generator.state = rng_state
        return losses

    # ------------------------------------------------------------ ratchet
    def ratchet(self, val_loss: float, checkpoint: Optional[Callable[[bool], dict]] = None) -> dict:
        """Milestone only when val improves; LAW A: a descent window in which val rose is not valid."""
        improved = val_loss < self.best_val - 1e-4
        rec = {"step": self.m.step, "val": val_loss, "best": self.best_val, "improved": improved}
        self.val_history.append((self.m.step, val_loss))
        if improved:
            self.best_val = val_loss
            self.best_step = self.m.step
            self.stalled_cycles = 0
            ms = {"step": self.m.step, "val_loss": val_loss, "params": self.m.n_params(), "ts": time.time()}
            self.milestones.append(ms)
            if self.db is not None:
                self.db.log_milestone(self.m.step, self.m.n_params(), self.history[-1]["loss"] if self.history else float("nan"), val_loss, "ratchet")
            if checkpoint is not None:
                keyframe = (len(self.milestones) % self.cfg.keyframe_every) == 1
                rec["checkpoint"] = checkpoint(keyframe)
            self._log("milestone", ms)
        else:
            self.stalled_cycles += 1
        # LAW A/B: val rising three evals in a row while train falls -> HALT_DESCENT until regularized
        if len(self.val_history) >= 4:
            v = [x[1] for x in self.val_history[-4:]]
            if v[1] > v[0] and v[2] > v[1] and v[3] > v[2]:
                self.halted = True
                self.halt_reason = "LAW A: val loss rose over the descent window (overfit alarm) -> HALT_DESCENT"
                self._log("halt_descent", {"val_history": v})
        return rec

    def floor_status(self, train_loss: float, val_loss: float) -> dict:
        """LAW C/D: what may be claimed."""
        f = self.floors or self.entropy_floors()
        st = {"scoped": self.cfg.scoped, "target": self.cfg.target_loss, "unigram_floor": f.get("unigram"),
              "bigram_floor": f.get("bigram")}
        if self.cfg.scoped and val_loss <= self.cfg.target_loss:
            st["status"] = "SCOPED_TARGET_REACHED"
        elif not self.cfg.scoped and val_loss <= self.cfg.target_loss:
            st["status"] = "TARGET_NUMBER_REACHED_UNSCOPED (LAW C: not claimable as general; declare a scope)"
        elif f.get("bigram") and val_loss < f["bigram"] * 0.5:
            st["status"] = "BELOW_BIGRAM_FLOOR (model has learned long-range structure)"
        elif f.get("bigram") and abs(val_loss - f["bigram"]) < 0.05:
            st["status"] = "AT_BIGRAM_FLOOR"
        else:
            st["status"] = "DESCENDING"
        return st

    # -------------------------------------------------------------- cycle
    def run_cycle(self, steps: int, checkpoint: Optional[Callable[[bool], dict]] = None, max_trials: int = 2) -> dict:
        """One ALM cycle: train -> diagnose -> (hypothesize -> trial)* -> ratchet -> laws."""
        t0 = time.time()
        if self.halted:
            # LAW B regularization intervention, then resume
            self.cfg.wd = min(0.2, self.cfg.wd * 2 + 0.01)
            self.cfg.lr *= 0.5
            self.opt.wd = self.cfg.wd
            self.halted = False
            self._log("regularize", {"wd": self.cfg.wd, "lr": self.cfg.lr, "reason": self.halt_reason})
        losses = self.train_steps(steps)
        d = self.diagnose()
        trials = []
        if d.lock not in ("DESCENDING", "CAP_LOCK", "REPRESENTATION_LOCK"):
            for fam in self.hypothesize(d.lock)[:max_trials]:
                if self.stop:
                    break
                trials.append(self.trial(fam, d.lock))
                if trials[-1]["success"]:
                    break
        elif d.lock == "REPRESENTATION_LOCK" and not self.stop:
            for fam in self.hypothesize(d.lock)[:1]:
                trials.append(self.trial(fam, d.lock))
        r = self.ratchet(d.val_loss, checkpoint)
        fs = self.floor_status(d.train_loss, d.val_loss)
        cyc = {"steps": len(losses), "train_loss": d.train_loss, "val_loss": d.val_loss, "lock": d.lock, "velocity": d.velocity,
               "noise": d.noise, "gap": d.gap, "rare_tax": d.rare_tax, "trials": trials, "ratchet": r, "floor": fs,
               "best_val": self.best_val, "halted": self.halted, "elapsed_s": round(time.time() - t0, 2),
               "lr": self.cfg.lr, "batch": self.cfg.batch, "wd": self.cfg.wd}
        self._log("cycle", {k: v for k, v in cyc.items() if k != "trials"})
        return cyc


def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    from .ledger import NullLedger
    from .model_engine import ModelConfig
    from .meta_optimizer import ResearchDB
    chk = chk or Check("alm")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_alm_"))
    corpus = tmpdir / "c.txt"
    corpus.write_bytes((b"the chord and the melody in harmony. " * 200 + b"prove the theorem by induction on n. " * 200) * 3)
    cfg = ModelConfig(d_model=32, n_heads=4, n_layers=2, d_ff=64, ctx=32, experts=["math", "music"], d_expert=32)
    m = SokeLM(cfg, seed=3)
    bs = ByteStream([corpus], buffer_bytes=1 << 16, chunk_bytes=1 << 12)
    db = ResearchDB(tmpdir / "research.db")
    tc = TrainConfig(lr=3e-3, batch=8, warmup=10, val_every=20, trial_steps=12, window=30)
    eng = LossEngine(m, bs, tc, ledger=NullLedger(), research_db=db)
    fl = eng.entropy_floors()
    chk("entropy floors computed (unigram > bigram > 0)", fl["unigram"] > fl["bigram"] > 0, f"{fl}")
    c1 = eng.run_cycle(40, checkpoint=lambda kf: {"kf": kf})
    chk("cycle 1 trains and diagnoses", c1["steps"] == 40 and c1["lock"] in ("DESCENDING", "OPT_LOCK", "NOISE_LOCK", "DATA_LOCK"), f"lock={c1['lock']} loss={c1['train_loss']:.3f}")
    chk("ratchet records the first milestone + checkpoint", eng.best_val < float("inf") and c1["ratchet"]["improved"] and c1["ratchet"]["checkpoint"]["kf"] is True)
    # force a trial and check the control-arm protocol restores the snapshot on rejection
    snap = {k: v.copy() for k, v in m.p.items()}
    step0 = m.step
    rec = eng.trial("lr_up", "OPT_LOCK")
    restored = m.step == step0 and all(np.array_equal(snap[k], m.p[k]) for k in snap)
    chk("trial: control arm + candidate from one snapshot; snapshot restored", restored and "v_control" in rec, f"success={rec['success']} vC={rec['v_control']:.4f} vK={rec['v_candidate']:.4f}")
    chk("trial logged to research db + meta bandit", len(db.experiments()) >= 1 and db.family_stats().get("lr_up", {}).get("trials", 0) >= 1)
    rec2 = eng.trial("osp_leg_swap", "REPRESENTATION_LOCK")
    chk("OSP leg-swap trial runs and is recorded (null or win)", "success" in rec2 and rec2["stable"] in (True, False))
    # a Stop that lands inside a trial: no crash, no verdict, snapshot restored, family not counted as failed
    snap = {k: v.copy() for k, v in m.p.items()}
    step0, fails0, lr0 = m.step, dict(eng.failed_families), eng.cfg.lr
    eng.stop = True
    rec3 = eng.trial("lr_up", "OPT_LOCK")
    eng.stop = False
    chk("trial aborted by Stop: restored, no verdict, no null charged", rec3.get("aborted") and not rec3["success"] and m.step == step0
        and all(np.array_equal(snap[k], m.p[k]) for k in snap) and eng.failed_families == fails0 and eng.cfg.lr == lr0, str(rec3)[:120])
    # LAW A: synthetic rising val history halts descent, cycle applies LAW B regularization
    eng.val_history = [(1, 1.0), (2, 1.1), (3, 1.2), (4, 1.3)]
    eng.ratchet(1.4)
    chk("LAW A halts descent on rising val", eng.halted and "LAW A" in eng.halt_reason)
    wd0 = eng.cfg.wd
    eng.val_history = []                      # clear the synthetic history so the cycle's own ratchet judges fresh
    c2 = eng.run_cycle(10)
    chk("LAW B regularization intervention applied", eng.cfg.wd > wd0 and not eng.halted, f"wd {wd0} -> {eng.cfg.wd}")
    fs = eng.floor_status(0.5, 0.0009)
    chk("LAW C: 0.001 unscoped is not claimable", "LAW C" in fs["status"])
    eng.cfg.scoped = True
    chk("LAW C: scoped target claimable", eng.floor_status(0.5, 0.0009)["status"] == "SCOPED_TARGET_REACHED")
    db.close()
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
