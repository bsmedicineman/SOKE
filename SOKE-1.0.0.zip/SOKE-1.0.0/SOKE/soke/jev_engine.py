"""
soke.jev_engine — JEV, the decision / judgment engine (the LOGIC pillar's reasoning path).

The tree has two pillars. The LEFT (feminine) pillar is emotional and expressive — it runs through the language
model and the mind engine. The RIGHT (logic) pillar does NOT generate language: it SCORES a small set of
options over features and CLOSES the choice with the logic proof-state. That is JEV. It is optimized for
decisions, so it aids model building (every build step — which operator, accept or reject a trial, grow or
prune — is a decision) and it does not overtax the system with autoregressive language.

The law, inherited from behavior.py: SELECT is owned by L0 truth. JEV scores (it may bid), but a choice only
CLOSES (commits) when the logic proof-state rates it ⊤ (TT). A move that breaks the numbers (⊥⊥), goes the
wrong way on the task metric (⊥), or is an uncertain grow move (?) is vetoed or deferred, never committed.

What JEV is made of, reusing what already exists:
  - the SCORER is a connectome_engine LinearReadout / MLPPolicy over feature vectors (it learns from outcomes —
    imitation with fit(), reward with reinforce() — so the lead chat can process behavioral learning of
    decisions, the way a Sephira user tunes routes).
  - the GATE is behavior.proof_state (⊤ ⊥ ? ⊥⊥) — the same logic pillar the forge already trusts.
  - the features come from the connectome (descending activity), the mind engine (the 4-D state), the forge
    diagnostics, or plain vectors. JEV is where "flee / approach / idle from connectome activity" lives.

BS Medicineman / Knight Industries — "the answer is never on the line"
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .behavior import proof_state, P_GLOSS
from .connectome_engine import LinearReadout, MLPPolicy, _one_hot

VERDICT_GLOSS = dict(P_GLOSS)                         # TT / BOT / Q / BOTBOT explanations


@dataclass
class Decision:
    """A judged decision: the chosen option, whether the logic pillar let it CLOSE, and the trace."""
    choice: Optional[str]
    index: int
    committed: bool                                  # did the logic proof-state let it close (⊤)?
    verdict: str                                     # TT / BOT / Q / BOTBOT of the chosen option
    confidence: float
    scores: dict = field(default_factory=dict)       # option -> score
    verdicts: dict = field(default_factory=dict)     # option -> proof-state
    reason: str = ""

    def to_dict(self) -> dict:
        return {"choice": self.choice, "committed": self.committed, "verdict": self.verdict,
                "confidence": round(self.confidence, 3), "scores": {k: round(v, 3) for k, v in self.scores.items()},
                "verdicts": self.verdicts, "reason": self.reason}


class JEVEngine:
    """Scores options and closes the choice with the logic proof-state. No language generation."""

    def __init__(self, labels: Optional[list] = None, n_features: Optional[int] = None, tol: float = 0.02,
                 scorer: str = "linear", seed: int = 0, name: str = "jev"):
        self.labels = list(labels) if labels else []
        self.tol = float(tol)
        self.name = name
        self.n_features = n_features
        self._scorer = None                          # a LinearReadout / MLPPolicy once fitted
        self._kind = scorer
        self._seed = seed

    # ---- the scorer (learns decisions from outcomes) -------------------
    def fit(self, X, y, epochs: int = 400) -> "JEVEngine":
        """Imitation: learn to score options from labelled (features -> best-option) examples."""
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.int64)
        n_out = int(max(y) + 1) if not self.labels else len(self.labels)
        if self._kind == "mlp":
            self._scorer = MLPPolicy(X.shape[1], n_hidden=16, n_out=n_out, labels=self.labels or None, seed=self._seed).fit_supervised(X, y, epochs=epochs)
        else:
            self._scorer = LinearReadout().fit(X, _one_hot(y, n_out), labels=self.labels or None)
        self.n_features = X.shape[1]
        return self

    def reinforce(self, states, reward_fn, epochs: int = 300) -> "JEVEngine":
        """Reward learning: raise the decisions that pay off (no labels needed). MLP scorer only."""
        states = np.asarray(states, dtype=np.float64)
        n_out = len(self.labels) if self.labels else 3
        self._scorer = MLPPolicy(states.shape[1], n_hidden=12, n_out=n_out, labels=self.labels or None, seed=self._seed).reinforce(states, reward_fn, epochs=epochs)
        self.n_features = states.shape[1]
        return self

    def score_labels(self, features) -> np.ndarray:
        """Preference over the label set from a feature vector (softmax). If untrained, uniform."""
        if self._scorer is None or not self.labels:
            n = len(self.labels) or 1
            return np.ones(n) / n
        if isinstance(self._scorer, MLPPolicy):
            return self._scorer.probs(features)[0]
        s = self._scorer.predict(np.asarray(features, np.float32))
        s = s - s.max()
        e = np.exp(s)
        return e / e.sum()

    # ---- the core: score options, close with the logic proof-state ----
    @staticmethod
    def _verdict(cand: dict, tol: float) -> str:
        """The logic pillar's ruling on a candidate move, from its numeric health only."""
        before = float(cand.get("before", 1.0))
        after = float(cand.get("after", before))
        return proof_state(before, after, cand.get("topics_before", {}) or {}, cand.get("topics_after", {}) or {},
                           cand.get("op", ""), bool(cand.get("finite", True)), cand.get("priority"), tol)

    def decide(self, candidates: list, use_scorer: bool = False) -> Decision:
        """Choose the best option that the logic pillar lets CLOSE. Each candidate is a dict with a `name` and
        its numeric health (`before`, `after`, `finite`, `op`, `priority`, `topics_before/after`), and optionally
        a `feat` vector for the learned scorer. Score = the scorer (if fitted and use_scorer) else the task
        improvement (before-after). The chosen option COMMITS only if its verdict is ⊤ (TT)."""
        if not candidates:
            return Decision(None, -1, False, "BOT", 0.0, reason="no candidates")
        scores, verdicts = {}, {}
        raw = []
        hold_of = {}
        for c in candidates:
            name = str(c.get("name", c.get("op", "?")))
            v = self._verdict(c, self.tol)
            if use_scorer and self._scorer is not None and "feat" in c:
                sc = float(self.score_labels(c["feat"]).max())
            else:
                sc = float(c.get("before", 1.0) - c.get("after", c.get("before", 1.0)))   # task improvement
            scores[name] = sc; verdicts[name] = v; raw.append((name, sc, v))
            hold_of[name] = (str(c.get("op", "")) == "hold" or name == "hold")
        # closeable = the logic pillar rated it ⊤; highest score wins, ties broken TOWARD holding (commit a
        # change only when it strictly beats doing nothing — the conservative, forge-min-gain rule).
        closeable = [(n, s, v) for n, s, v in raw if v == "TT"]
        if closeable:
            n, s, v = max(closeable, key=lambda t: (t[1], hold_of[t[0]]))
            committed = True
        else:
            n, s, v = max(raw, key=lambda t: (t[1], hold_of[t[0]]))   # nothing may close — surface the best, uncommitted
            committed = False
        idx = [str(c.get("name", c.get("op", "?"))) for c in candidates].index(n)
        span = max(scores.values()) - min(scores.values()) or 1.0
        conf = float(min(1.0, max(0.0, (s - min(scores.values())) / span)))
        reason = (f"logic closed '{n}' (⊤): best task-improving, finite move" if committed
                  else f"nothing closed — best was '{n}' but the logic pillar ruled {v} ({VERDICT_GLOSS.get(v, v)}); do not commit")
        return Decision(n, idx, committed, v, conf, scores, verdicts, reason)

    # ---- build-decision helpers (JEV aids model building) --------------
    def accept_trial(self, loss_before: float, loss_after: float, op: str, finite: bool = True,
                     prio_before: Optional[float] = None, prio_after: Optional[float] = None,
                     priority: Optional[str] = None) -> Decision:
        """The forge's accept/reject as a single JEV route: keep the change only if the logic pillar closes it."""
        cand = {"name": op, "op": op, "before": loss_before, "after": loss_after, "finite": finite}
        if priority is not None and prio_before is not None and prio_after is not None:
            cand.update({"priority": priority, "topics_before": {priority: prio_before}, "topics_after": {priority: prio_after}})
        return self.decide([cand, {"name": "hold", "op": "hold", "before": loss_before, "after": loss_before, "finite": True}])

    def grow_or_prune(self, gain_if_grow: float, cost_if_grow: float = 0.0) -> Decision:
        """Decide grow vs prune vs hold from the measured gain (feeds concept_graph.optimize_sizes / the forge)."""
        base = 1.0
        return self.decide([
            {"name": "grow", "op": "add_expert", "before": base, "after": base - gain_if_grow + cost_if_grow, "finite": True},
            {"name": "prune", "op": "drop_expert", "before": base, "after": base + 0.001, "finite": True},
            {"name": "hold", "op": "hold", "before": base, "after": base, "finite": True},
        ])

    def flee_approach_idle(self, activity) -> Decision:
        """The connectome example: score flee / approach / idle from descending (motor) activity. Pure decision."""
        if not self.labels:
            self.labels = ["flee", "approach", "idle"]
        p = self.score_labels(activity)
        i = int(np.argmax(p))
        return Decision(self.labels[i], i, True, "TT", float(p[i]),
                        {self.labels[k]: float(p[k]) for k in range(len(self.labels))}, {}, "decision-only route (no language)")

    # ---- pillar routing: which pillar should answer -------------------
    @staticmethod
    def route(n_options: int, open_language: bool) -> str:
        """Which pillar reasons this: the RIGHT (JEV) pillar for a bounded decision (few options, no prose
        needed) — cheap; the LEFT (language) pillar for open generation. This is the other pillar's path."""
        return "left" if open_language or n_options <= 1 else "right"

    def cost(self, n_candidates: int) -> dict:
        """A JEV decision is O(features * options) — a small matmul, NO autoregressive language pass. That is
        what makes it cheap and decision-optimized."""
        f = int(self.n_features or 0)
        return {"llm_forward": False, "kind": "decision",
                "approx_flops": int(max(1, f) * max(1, n_candidates)), "note": "no token-by-token language"}


def verify_suite(chk=None, tmpdir=None):
    from .util import Check
    from .rng import Rng
    chk = chk or Check("jev_engine")
    jev = JEVEngine(tol=0.02)

    # ---- the logic pillar closes the improving, finite move; vetoes the rest ----
    cands = [
        {"name": "swap_A", "op": "swap_expert", "before": 1.00, "after": 0.90, "finite": True},   # improves ⊤
        {"name": "swap_B", "op": "swap_expert", "before": 1.00, "after": 1.05, "finite": True},   # worse   ⊥
        {"name": "blow",   "op": "extrapolate", "before": 1.00, "after": float("nan"), "finite": False},  # ⊥⊥
    ]
    d = jev.decide(cands)
    chk("JEV closes the improving finite move (⊤), not the worse or non-finite ones", d.choice == "swap_A" and d.committed and d.verdict == "TT", d.reason)
    chk("a non-finite move is ruled ⊥⊥ (contradiction), never chosen to close", jev._verdict(cands[2], 0.02) == "BOTBOT")

    # a grow move that pushes the priority topic UP is deferred (?), not committed
    dg = jev.decide([{"name": "grow_math", "op": "add_expert", "before": 1.0, "after": 0.99, "finite": True,
                      "priority": "math", "topics_before": {"math": 1.0}, "topics_after": {"math": 1.2}}])
    chk("an uncertain grow move (priority drifting up) is deferred ? — bid, not close", dg.verdict == "Q" and not dg.committed, dg.reason)

    # when everything is worse, JEV commits nothing and says so
    dn = jev.decide([{"name": "a", "op": "swap_expert", "before": 1.0, "after": 1.1, "finite": True},
                     {"name": "b", "op": "swap_expert", "before": 1.0, "after": 1.2, "finite": True}])
    chk("when nothing improves, JEV closes nothing (surfaces the least-bad, uncommitted)", dn.committed is False, dn.reason)

    # ---- accept_trial: the forge accept as one JEV route -----------------
    a1 = jev.accept_trial(loss_before=1.0, loss_after=0.8, op="blend_expert")
    chk("accept_trial keeps a real improvement", a1.choice == "blend_expert" and a1.committed)
    a2 = jev.accept_trial(loss_before=1.0, loss_after=1.0, op="swap_attn")     # no change -> hold
    chk("accept_trial holds when a move does not improve", a2.choice == "hold" or not a2.committed)

    # ---- grow_or_prune ---------------------------------------------------
    chk("grow_or_prune grows on a real gain", jev.grow_or_prune(gain_if_grow=0.2).choice == "grow")
    chk("grow_or_prune holds when growth does not pay", jev.grow_or_prune(gain_if_grow=0.0).choice in ("hold", "prune"))

    # ---- the scorer LEARNS decisions (imitation) -------------------------
    rng = Rng(3)
    X = rng.normal(0, 1, size=(120, 4))
    y = (X[:, 0] + X[:, 1] > X[:, 2] + X[:, 3]).astype(np.int64)               # a real decision boundary
    j2 = JEVEngine(labels=["no", "go"], scorer="mlp", seed=1).fit(X, y, epochs=400)
    acc = float((np.array([int(np.argmax(j2.score_labels(x))) for x in X]) == y).mean())
    chk("JEV learns a decision rule from outcomes (imitation) >= 90%", acc >= 0.90, f"acc {acc:.2f}")

    # ---- reinforce raises decision reward (contextual bandit) ------------
    ctx = np.array([0, 1, 2] * 20)
    S = _one_hot(ctx, 3)
    def reward(i, act):
        return 1.0 if act == ctx[i] else 0.0
    j3 = JEVEngine(labels=["a", "b", "c"], scorer="mlp", seed=5)
    j3.reinforce(S, reward, epochs=400)
    gr = float(np.mean([reward(i, int(np.argmax(j3.score_labels(S[i])))) for i in range(len(ctx))]))
    chk("JEV reinforcement raises decision reward toward optimal (>0.9)", gr > 0.9, f"greedy reward {gr:.2f}")

    # ---- flee / approach / idle from features (the connectome example) ---
    Xr = np.concatenate([rng.normal(m, 0.3, size=(30, 3)) for m in (-1.0, 0.0, 1.0)])
    yr = np.array([0] * 30 + [1] * 30 + [2] * 30)
    j4 = JEVEngine(labels=["flee", "approach", "idle"], scorer="mlp", seed=2).fit(Xr, yr, epochs=400)
    dfa = j4.flee_approach_idle(rng.normal(1.0, 0.3, size=3))
    chk("JEV routes flee/approach/idle from activity, no language", dfa.choice in ("flee", "approach", "idle") and dfa.committed)

    # ---- pillar routing: decisions go RIGHT (JEV), open language LEFT -----
    chk("a bounded decision routes down the RIGHT (JEV) pillar", JEVEngine.route(n_options=3, open_language=False) == "right")
    chk("open language routes down the LEFT (language) pillar", JEVEngine.route(n_options=3, open_language=True) == "left")

    # ---- cost: a JEV decision does NO language forward, and is fast -------
    c = j2.cost(n_candidates=8)
    chk("a JEV decision declares no LLM forward (decision-optimized, not language)", c["llm_forward"] is False)
    t0 = time.time()
    for _ in range(5000):
        j2.decide([{"name": "x", "op": "swap_expert", "before": 1.0, "after": 0.9, "finite": True},
                   {"name": "y", "op": "swap_expert", "before": 1.0, "after": 1.1, "finite": True}])
    dt = time.time() - t0
    chk("5000 JEV decisions run fast (no autoregression) — avoids overtaxing the system", dt < 2.0, f"{dt:.2f}s for 5000")
    return chk


if __name__ == "__main__":
    print("\n".join(verify_suite().lines()))
