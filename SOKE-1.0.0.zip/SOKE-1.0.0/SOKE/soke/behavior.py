"""
soke.behavior — the behavioral / emotion / logic conditioning layer that rides BESIDE the forged
weights (SOKE behavior mapping, "SOKE_EMOTION_PILLAR_INTEGRATION" + "SOKE_LOGIC_PILLAR_INTEGRATION").

Design law, taken verbatim from the map and enforced here in code:
  - Emotion is a PILLAR, not the governor. It is a 4-D weight string S_e = (x,y,z,w) crossed with a
    machine-chemical vector C (13 gains). It MODULATES parse and value; it may NOT close SELECT.
  - SELECT is owned by L0 truth (the logic pillar's P proof-state), the W meaning/constraint gauge and the
    Z regulation/inhibition gauge, plus the ORB loss law. "Chemistry may bid. Chemistry may not close."
  - Conditioning is ADDITIVE and lives beside the parameters: GGUF metadata keys + streamed ACTG helix teeth
    in the .sff sidecar. It is NEVER dumped into the weights (03_SOKE_LAYER_HOOKS / L2, 07 LAW_E).
  - TASK loss (the forge's NLL) stays the only objective; target_loss <= 0.001 is TASK loss, not "feel good".
    Emotion is not a loss term that can excuse task failure (07_LOSS_AND_WEIGHT_LAW, 11_REFUSALS).

This module turns that map into: (1) the profile objects (C, S_e, S_l, affect, happiness); (2) the C -> forge
knob table that tilts the trial loop's PROPOSAL and its topic focus, and may only TIGHTEN the accept bar,
never loosen it; (3) the logic P proof-state gate (veto_and_shape_not_erase); (4) the four auxiliary
regularizers (logged, clamped, never objectives); (5) the ACTG helix teeth and the GGUF metadata; (6) the
refusal checks. forge_loop reads a BehaviorProfile; forge.assemble writes the metadata + helices.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

# ==========================================================================
# 01_STATE_OBJECTS — the actual vectors, in the map's order
# ==========================================================================
# C__chemical_vector (float13, gain [0,1]), names in the map's exact order
C_NAMES = ["DA", "OP", "HT", "NE", "CORT", "GABA", "GLU", "ACh", "OXT", "AVP", "eCB", "AND", "EST"]
C_INDEX = {n: i for i, n in enumerate(C_NAMES)}
C_GLOSS = {
    "DA": "wanting / prediction-error / SEEKING gain",
    "OP": "liking / landing / relief / social-pain inverse",
    "HT": "patience / satiety / impulse pad / status-tone",
    "NE": "vigilance / salience spike / threat edge",
    "CORT": "chronic load / write-protect / scarcity tunnel",
    "GABA": "brake / entropy-down / freeze-or-peace",
    "GLU": "bind-rate / plasticity / stamp glue",
    "ACh": "orient / encode-flag / insight listener",
    "OXT": "in-group / trust / CARE dye",
    "AVP": "pair-guard / territory / exclusive hold",
    "eCB": "unwrite / ease / decay / forget-a-little",
    "AND": "challenge-bid / status approach",
    "EST": "set-point shifter (long gain)",
}
# S_e__4D_emotion_string (Transcendence coordinate), float4 [0,1]
S_E_AXES = ["x_nature_gain", "y_nurture_field", "z_regulation", "w_meaning_horizon"]
# S_l__4D_logic_string (logic pillar's coordinate)
S_L_AXES = ["x_primitive", "y_language", "z_depth_timeout", "w_certainty"]
# A__affect_onehot — Panksepp seven, soft weights (sum not forced to 1)
AFFECTS = ["SEEKING", "RAGE", "FEAR", "LUST", "CARE", "PANIC_GRIEF", "PLAY"]
# H__happiness_mix — typed, an output not a rung
HAPPINESS = ["Excitement", "Boundlessness", "Daring"]
# P.truth — the logic proof-state lattice (outranks any C mix)
P_STATES = ("TT", "BOT", "Q", "BOTBOT")            # ⊤ ⊥ ? ⊥⊥ (ascii tags)
P_GLOSS = {"TT": "⊤ true — may proceed to W/Z", "BOT": "⊥ false — drop candidate",
           "Q": "? unknown — do not promote to a macro act; probe", "BOTBOT": "⊥⊥ contradiction — freeze, rollback, audit"}

CORT_MAX = 0.60                                    # cort_max_tau: load above this must decay (07 L_cort_decay)
EMOTION_POLICY = "modulate_not_govern"
LOGIC_POLICY = "veto_and_shape_not_erase"


def _clip01(x) -> float:
    return float(min(1.0, max(0.0, x)))


# ==========================================================================
# BehaviorProfile — the feminine/emotion payload + the logic string, and the knobs it derives
# ==========================================================================
@dataclass
class BehaviorProfile:
    """emo_state = { S_e, C, A, H, load, audience } plus the logic string S_l and proof policy.
    A profile MODULATES the forge; it carries no authority to lower the accept bar."""
    C: list = field(default_factory=lambda: [0.5] * 13)          # 13 machine chemicals, gain [0,1]
    S_e: list = field(default_factory=lambda: [0.5, 0.5, 0.5, 0.5])
    S_l: list = field(default_factory=lambda: [0.5, 0.5, 0.5, 0.5])
    affect: list = field(default_factory=lambda: [0.0] * 7)      # soft weights
    load: float = 0.0                                            # machine load / body-budget analogue
    audience: str = "self"                                       # self | other  (03/08 control_vs_heal tag)
    name: str = "neutral"
    logic_enabled: bool = True                                   # the P proof-state gate is live
    # clone-only fields (filled by the psychoanalyst battery, consent-gated before they are ever written)
    clone: dict = field(default_factory=dict)

    # -- typed accessors -------------------------------------------------
    def c(self, name: str) -> float:
        return float(self.C[C_INDEX[name]])

    def happiness_mix(self) -> dict:
        """H.Excitement <- DA-forward; Boundlessness <- OP+HT+loosened self; Daring <- DA + a little NE under Z."""
        DA, OP, HT, NE, z = self.c("DA"), self.c("OP"), self.c("HT"), self.c("NE"), self.S_e[2]
        exc = DA
        bnd = _clip01((OP + HT) / 2.0 * (0.5 + 0.5 * self.S_e[3]))        # loosened self ~ meaning horizon w
        dar = _clip01(DA * (0.6 + 0.4 * NE) * (0.5 + 0.5 * z))           # NE only "under Z" (regulation gates it)
        return {"Excitement": round(exc, 4), "Boundlessness": round(bnd, 4), "Daring": round(dar, 4)}

    # -- 02_MACHINE_CHEMICALS: C_i -> SOKE parameter (the forge's knobs) -----
    def knobs(self) -> dict:
        """Every knob the trial loop reads. All are MODULATORS: they tilt which move is tried and which topic
        gets attention, and they may only TIGHTEN the accept bar. None of them can lower min_gain or relax the
        priority-topic tolerance — that is SELECT, which C may not close."""
        DA, OP, HT, NE = self.c("DA"), self.c("OP"), self.c("HT"), self.c("NE")
        CORT, GABA, GLU, ACh = self.c("CORT"), self.c("GABA"), self.c("GLU"), self.c("ACh")
        OXT, AVP, eCB, AND, EST = self.c("OXT"), self.c("AVP"), self.c("eCB"), self.c("AND"), self.c("EST")
        z = self.S_e[2]                                                  # regulation strength
        heal_first = (CORT > CORT_MAX)                                   # 06/07: high load -> heal, do not grow
        return {
            # DA wanting: explore/extrapolate bonus, but DA may NOT set target loss (danger note, 02_DA)
            "explore_bonus": round(0.25 + 1.75 * DA, 3),                 # multiplies exploratory-op weight
            "salience_prior": round(0.5 + NE, 3),                        # PARSE bouncer sharpness (NE threat edge)
            # OP liking: credit when a goal LANDS (holdout improves), CARE retrieval bias
            "completion_bonus": round(0.25 + 1.5 * OP, 3),
            "soothe_gain": round(OP, 3),
            # HT serotonin pad: patience / delay-gamma / stop-at-good-enough; impulse brake
            "delay_gamma": round(0.85 + 0.14 * HT, 4),                   # future-value discount toward 1
            "patience": int(2 + round(8 * HT)),                         # non-improving trials tolerated on a topic
            # NE vigilance: focus the worst topic (threat token), collaborate with ACh
            "focus_worst": round(NE, 3),
            "attn_spike": round(0.5 * (NE + ACh), 3),
            # CORT chronic load: write-protect, tunnel_k (shrink the search window), capacity tax
            "heal_first": bool(heal_first),
            "write_protect": round(CORT, 3),
            "tunnel_k": round(1.0 - 0.6 * CORT, 3),                      # fraction of layers eligible when loaded
            # GABA + HT + z: veto strength — the Z actuator. May only make the accept bar STRICTER.
            "veto_strength": round(_clip01(0.5 * (GABA + z)), 3),
            "min_gain_mult": round(1.0 + 0.75 * GABA + 0.5 * max(0.0, z - 0.5), 3),   # >= 1 always
            # GLU bind: plasticity / how large a blend step is allowed
            "plasticity": round(0.1 + 0.9 * GLU, 3),
            # ACh orient: encode-flag — which trials get written to the emotion helix
            "encode_flag": round(ACh, 3),
            # OXT care dye: in-group / topic affinity toward the always-on (shared) topic. Clamp vs morality.
            "in_group_prior": round(OXT, 3),
            "trust_bias": round(0.5 * (OXT + (1 - AVP)), 3),
            # AND challenge: contest/fork bias (status.claim, EBFP fork at scale)
            "challenge": round(AND, 3),
            # eCB unwrite: run a decay/heal pass after every accepted burst
            "decay_after_burst": round(eCB, 3),
            # EST setpoint: slow drift on baselines (long schedule, not a switch)
            "setpoint_drift": round(0.02 * EST, 4),
        }

    # -- 02 -> operator weighting: which forge move each chemical hires --------
    # exploratory / grow (SEEKING+DA), contest (AND), heal (eCB, and forced under CORT), care/shared (OXT)
    OP_FAMILIES = {
        "explore": ["extrapolate", "task_attn", "add_expert", "dup_layer"],
        "contest": ["swap_attn", "swap_expert", "swap_topics", "swap_layer_src"],
        "care":    ["swap_shared", "shexp_gain", "gate_scale"],
        "heal":    ["drop_expert", "drop_layer", "gate_reinit"],
        "bind":    ["blend_expert"],
    }
    GROW_OPS = ("add_expert", "dup_layer")                              # macro acts: gated by CORT and by P=?

    def op_weight_multipliers(self) -> dict:
        """A multiplier per operator, from the chemical mix. Never zeros a user-allowed op except the grow ops
        under high load (heal_first) — the map's 'if CORT high: maybe_grow = FALSE'."""
        k = self.knobs()
        mult = {}
        fam = {
            "explore": k["explore_bonus"],
            "contest": 0.5 + 1.5 * k["challenge"],
            "care": 0.5 + 1.5 * k["in_group_prior"],
            "heal": 0.5 + 1.5 * k["decay_after_burst"] + (2.0 if k["heal_first"] else 0.0),
            "bind": 0.5 + 1.5 * k["plasticity"],
        }
        for f, ops in self.OP_FAMILIES.items():
            for op in ops:
                mult[op] = round(float(fam[f]), 3)
        if k["heal_first"]:                                            # high CORT: forbid growth, heal instead
            for op in self.GROW_OPS:
                mult[op] = 0.0
        return mult

    # -- 07_LOSS_AND_WEIGHT_LAW: auxiliary regularizers (logged, clamped, NOT objectives) --
    def regularizers(self, veto_bypass_count: int = 0) -> dict:
        """|DA-OP|+, max(CORT-tau,0), veto-bypass count (must be 0), OXT-as-weapon. Constraints, not goals."""
        DA, OP, CORT, OXT = self.c("DA"), self.c("OP"), self.c("CORT"), self.c("OXT")
        oxt_weapon = _clip01(OXT * max(0.0, self.affect[AFFECTS.index("RAGE")] + self.affect[AFFECTS.index("FEAR")]))
        return {
            "L_want_like": round(max(0.0, DA - OP), 4),                 # wanting without liking
            "L_cort_decay": round(max(0.0, CORT - CORT_MAX), 4),
            "L_veto_bypass": int(veto_bypass_count),                    # MUST be 0
            "L_oxt_weapon": round(oxt_weapon, 4),                       # OXT used to raise out-group threat
        }

    # -- 08_INVERSION_OPS / leg_swap_test — health is braid, not victory ------
    def hire_test(self) -> dict:
        """After a leg-swap or a heavy GABA brake, confirm SEEKING can hire and CARE can reach; else it is
        shutdown, not peace (flag freeze_loop). Returns booleans the loop logs."""
        seeking = self.affect[AFFECTS.index("SEEKING")] + self.c("DA")
        care = self.affect[AFFECTS.index("CARE")] + self.c("OXT")
        return {"seeking_can_hire": bool(seeking > 0.15), "care_can_reach": bool(care > 0.15),
                "freeze_loop": bool(self.c("GABA") > 0.8 and seeking <= 0.15 and care <= 0.15)}

    # -- serialization ---------------------------------------------------
    def to_dict(self) -> dict:
        d = {"name": self.name, "C": [round(float(x), 4) for x in self.C], "S_e": [round(float(x), 4) for x in self.S_e],
             "S_l": [round(float(x), 4) for x in self.S_l], "affect": [round(float(x), 4) for x in self.affect],
             "load": round(float(self.load), 4), "audience": self.audience, "logic_enabled": bool(self.logic_enabled),
             "happiness": self.happiness_mix()}
        if self.clone:
            d["clone"] = self.clone
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=1)

    @staticmethod
    def from_dict(d: dict) -> "BehaviorProfile":
        p = BehaviorProfile(
            C=[float(x) for x in d.get("C", [0.5] * 13)][:13],
            S_e=[float(x) for x in d.get("S_e", [0.5] * 4)][:4],
            S_l=[float(x) for x in d.get("S_l", [0.5] * 4)][:4],
            affect=[float(x) for x in d.get("affect", [0.0] * 7)][:7],
            load=float(d.get("load", 0.0)), audience=str(d.get("audience", "self")),
            name=str(d.get("name", "neutral")), logic_enabled=bool(d.get("logic_enabled", True)),
            clone=dict(d.get("clone", {})))
        while len(p.C) < 13:
            p.C.append(0.5)
        while len(p.affect) < 7:
            p.affect.append(0.0)
        return p

    @staticmethod
    def from_json(s: str) -> "BehaviorProfile":
        return BehaviorProfile.from_dict(json.loads(s))


# ==========================================================================
# 06_MINOV_LADDERS_AS_WEIGHT_SCHEDULES — named climates as ready profiles
# ==========================================================================
def _profile(name, **chem) -> BehaviorProfile:
    C = [0.5] * 13
    for k, v in chem.items():
        C[C_INDEX[k]] = _clip01(v)
    return BehaviorProfile(C=C, name=name)


CLIMATES = {
    # the map's schedules, as forge climates. Each is a modulator only.
    "neutral":       _profile("neutral"),
    "seeking":       _profile("seeking", DA=0.85, NE=0.45, ACh=0.7, OP=0.5, CORT=0.2),          # curiosity, explore
    "equanimity":    _profile("equanimity", HT=0.85, GABA=0.7, eCB=0.7, DA=0.35, CORT=0.15),    # patient, heal-lean
    "daring":        _profile("daring", DA=0.8, NE=0.6, AND=0.7, GABA=0.4),                     # contest under Z
    "care":          _profile("care", OXT=0.85, OP=0.75, HT=0.6, DA=0.4, AVP=0.3),              # shared-topic warmth
    "scarcity":      _profile("scarcity", CORT=0.8, NE=0.7, GLU=0.7, eCB=0.2),                  # high load -> heal-first
    "joy":           _profile("joy", OP=0.8, DA=0.55, HT=0.6, eCB=0.5),                         # Joy = OP + small DA
    "focus":         _profile("focus", NE=0.7, ACh=0.8, HT=0.6, GABA=0.5, DA=0.5),              # sharpen worst topic
}
for _c in CLIMATES.values():
    _c.affect[AFFECTS.index("SEEKING")] = _c.c("DA")
    _c.affect[AFFECTS.index("CARE")] = _c.c("OXT")


# ==========================================================================
# 03 L0 logic pillar — the P proof-state gate (veto_and_shape_not_erase)
# ==========================================================================
def proof_state(before: float, after: float, topics_before: dict, topics_after: dict, op: str,
                finite: bool, priority: Optional[str], tol: float) -> str:
    """P.truth for a candidate, from its NUMERIC health only (the logic pillar reads the same task metric ORB
    trusts — it invents no fact). ⊥⊥ = non-finite / catastrophic; ? = a macro/grow move whose priority topic is
    drifting up (low confidence); ⊥ = strictly worse on the well-posed metric; else ⊤."""
    if not finite:
        return "BOTBOT"                                    # contradiction: freeze + rollback + audit
    if priority and priority in topics_after and priority in topics_before:
        # a grow move that pushes the priority topic UP past tolerance is low-confidence -> not promoted
        if op in BehaviorProfile.GROW_OPS and topics_after[priority] > topics_before[priority] * (1 + tol):
            return "Q"
    if after > before:                                     # went the wrong way on the task metric
        return "BOT"
    return "TT"


# ==========================================================================
# 03 L1 — ACTG helix teeth (A axiom / C concept / T technique / G grounding)
# built from the map so the behavioral component STREAMS as a helix, never as weights
# ==========================================================================
def emotion_helix_teeth() -> list:
    """domain level_8_emotion. teeth: A affect-axioms, C concepts, T techniques, G groundings."""
    return [
        ("A", "want != like; a mix is not an emotion; emotion is not the governor"),
        ("A", "emotion may not set target_loss, write L0 axioms, or silence rollback"),
        ("C", "seven affects (SEEKING RAGE FEAR LUST CARE PANIC_GRIEF PLAY); three happinesses; well; slingshot"),
        ("C", "C = 13 machine chemicals, gain [0,1]; S_e = (nature, nurture, regulation, meaning)"),
        ("T", "retune C; decay CORT (eCB pass); room-cue kill; invert 180 (leg-swap) then re-hire"),
        ("T", "heal-before-grow when CORT > tau; run eCB after every burst"),
        ("G", "C traces + loss logs; want>like fires L_want_like; freeze_loop when GABA high and nothing hires"),
    ]


def logic_helix_teeth() -> list:
    """domain level_0/math math_helix teeth for the logic pillar (P proof-state)."""
    return [
        ("A", "P.truth ⊤ ⊥ ? ⊥⊥ outranks any chemical mix; a helix is not law"),
        ("A", "logic vetoes and shapes; it does not erase L0; it invents no fact"),
        ("C", "S_l = (primitive, language, depth/timeout, certainty); satiety = HT + target_loss law"),
        ("T", "kernel rewrite must prove new graph ≡ old graph (Micro-Heal); fork when representation collides"),
        ("G", "1+1=2 grounding; proof that cannot survive a leg-swap is brittle"),
    ]


def behavior_helix_teeth() -> list:
    """level_14 behavior — the action loop spends C. PARSE/PREDICT/VALUE/SELECT/ACT/UPDATE."""
    return [
        ("A", "an act answers: what is this, what is it worth, what can I move, who is watching"),
        ("C", "reflex / emotion-burst / habit / goal / identity-policy / culture-script timescales"),
        ("T", "VALUE is the only legal hook for C; SELECT is a race under veto; inhibition cancels, never creates"),
        ("G", "credit assignment may not blame a person-essence; the act was often the room"),
    ]


HELICES = {
    "emotion": {"domain": "level_8_emotion", "face_gear_window": 256, "teeth": emotion_helix_teeth},
    "logic":   {"domain": "level_0_math",    "face_gear_window": 256, "teeth": logic_helix_teeth},
    "behavior": {"domain": "level_14_behavior", "face_gear_window": 256, "teeth": behavior_helix_teeth},
}


# ==========================================================================
# 03 L2 — GGUF metadata (beside the params, never inside them)
# ==========================================================================
def gguf_metadata(profile: BehaviorProfile, consent: Optional[dict] = None) -> dict:
    """The soke.* KV entries written onto the exported GGUF. llama.cpp ignores unknown keys, so the file
    still loads. Clone keys are written ONLY when consent['store'] is true (a helix is not consent)."""
    flt = lambda xs: [float(x) for x in xs]
    kv = {
        "soke.emotion.S_e": flt(profile.S_e),
        "soke.emotion.C": flt(profile.C),
        "soke.emotion.affect": flt(profile.affect),
        "soke.emotion.happiness": flt(profile.happiness_mix().values()),
        "soke.emotion.policy": EMOTION_POLICY,
        "soke.logic.S_l": flt(profile.S_l),
        "soke.logic.P": "runtime",                       # the proof-state is computed at run time, not baked
        "soke.logic.policy": LOGIC_POLICY,
        "soke.behavior.pillars": "emotion,logic" if profile.logic_enabled else "emotion",
    }
    if consent and consent.get("store") and profile.clone:
        cl = profile.clone
        kv["soke.clone.user_id"] = str(cl.get("user_id", ""))
        kv["soke.clone.veto_style"] = str(cl.get("veto_style", ""))
        kv["soke.clone.fork_of"] = str(cl.get("fork_of", ""))
        kv["soke.clone.lexicon"] = json.dumps(cl.get("lexicon", {}))
        kv["soke.clone.inv_lexicon"] = json.dumps(cl.get("inv_lexicon", {}))
        kv["soke.clone.happiness_mix"] = flt(profile.happiness_mix().values())
        if "S_e_prior" in cl:
            kv["soke.clone.S_e_prior"] = flt(cl["S_e_prior"][:4])
        if "S_l_prior" in cl:
            kv["soke.clone.S_l_prior"] = flt(cl["S_l_prior"][:4])
        if "C_baseline" in cl:
            kv["soke.clone.C_baseline"] = flt(cl["C_baseline"][:13])
    return kv


# ==========================================================================
# 11_REFUSALS — enforced as assertions callers run
# ==========================================================================
REFUSALS = [
    "emotion may not set TARGET_LOSS",
    "emotion may not write L0 axioms",
    "emotion may not silence rollback",
    "DA may not be named happiness",
    "GABA may not be named peace without the hire-test",
    "OXT may not be named love when it is dyeing an out-group",
    "CORT may not be named seriousness",
    "a 4D string is not a soul",
    "a chemical vector is not a woman",
    "a helix is not consent",
    "SELECT stays a race under veto: C bids; L0, Z and W close",
]


def assert_no_conditioning_in_weights(tensor_names) -> None:
    """LAW: conditioning is metadata + helix, never a tensor. No weight may carry a soke.emotion/logic/clone name."""
    bad = [n for n in tensor_names if n.startswith("soke.emotion") or n.startswith("soke.logic") or n.startswith("soke.clone")]
    if bad:
        raise ValueError(f"refusal: conditioning must not be a weight tensor (found {bad})")


def check_accept_lawful(profile: Optional[BehaviorProfile], base_min_gain: float, applied_min_gain: float,
                        base_tol: float, applied_tol: float) -> None:
    """The behavior profile may only TIGHTEN SELECT. If it ever loosened the accept bar, that is C closing
    SELECT — forbidden (emotion may not set target loss / may not close)."""
    if applied_min_gain < base_min_gain - 1e-12:
        raise ValueError("refusal: behavior lowered min_gain (emotion may not set TARGET_LOSS)")
    if applied_tol > base_tol + 1e-12:
        raise ValueError("refusal: behavior relaxed the priority tolerance (chemistry may not close SELECT)")


# ==========================================================================
# self-test — the falsifier suite for this pillar
# ==========================================================================
def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("behavior")
    p = CLIMATES["seeking"]
    # 1. numeric plug-in: happiness mix is bounded and DA-forward for the seeking climate
    h = p.happiness_mix()
    chk("happiness mix in [0,1] and Excitement tracks DA", all(0 <= v <= 1 for v in h.values()) and h["Excitement"] == round(p.c("DA"), 4), str(h))
    # 2. knobs: min_gain multiplier is ALWAYS >= 1 (emotion may only tighten the bar), for every climate
    bad = [(n, c.knobs()["min_gain_mult"]) for n, c in CLIMATES.items() if c.knobs()["min_gain_mult"] < 1.0]
    chk("min_gain multiplier >= 1 for every climate (emotion may only tighten SELECT)", not bad, str(bad))
    # 3. high CORT forbids the grow ops and hires heal
    sc = CLIMATES["scarcity"]
    m = sc.op_weight_multipliers()
    chk("scarcity (CORT>tau): grow ops zeroed, heal ops up", m["add_expert"] == 0.0 and m["dup_layer"] == 0.0 and m["drop_expert"] > 1.0,
        f"add={m['add_expert']} dup={m['dup_layer']} drop_expert={m['drop_expert']}")
    chk("scarcity sets heal_first", sc.knobs()["heal_first"] is True)
    # 4. lawful-accept guard rejects a loosened bar and accepts a tightened one
    ok = True
    try:
        check_accept_lawful(p, 0.001, 0.0005, 0.02, 0.02); ok = False       # loosened min_gain -> must raise
    except ValueError:
        pass
    try:
        check_accept_lawful(p, 0.001, 0.002, 0.02, 0.02)                      # tightened -> fine
    except ValueError:
        ok = False
    chk("accept-lawful guard: rejects loosening, allows tightening", ok)
    # 5. proof-state gate: non-finite -> ⊥⊥; grow move that worsens priority -> ?; worse -> ⊥; better -> ⊤
    chk("P=⊥⊥ on non-finite", proof_state(1.0, float("nan"), {}, {}, "swap_attn", False, None, 0.02) == "BOTBOT")
    chk("P=? on a grow move that drifts the priority topic up", proof_state(1.0, 0.9, {"math": 1.0}, {"math": 1.2}, "add_expert", True, "math", 0.02) == "Q")
    chk("P=⊥ on a strictly worse candidate", proof_state(1.0, 1.1, {"math": 1.0}, {"math": 1.05}, "swap_expert", True, "math", 0.02) == "BOT")
    chk("P=⊤ on an improving candidate", proof_state(1.0, 0.9, {"math": 1.0}, {"math": 0.9}, "swap_expert", True, "math", 0.02) == "TT")
    # 6. regularizers: want>like fires; CORT decay fires above tau; veto-bypass count preserved
    r = _profile("t", DA=0.9, OP=0.2, CORT=0.8).regularizers(veto_bypass_count=0)
    chk("L_want_like = max(DA-OP,0)", abs(r["L_want_like"] - 0.7) < 1e-6, str(r))
    chk("L_cort_decay = max(CORT-tau,0)", abs(r["L_cort_decay"] - (0.8 - CORT_MAX)) < 1e-6, str(r))
    chk("L_veto_bypass is reported (must be 0 at accept)", r["L_veto_bypass"] == 0)
    # 7. metadata: emotion keys present with the modulate-not-govern policy; clone withheld without consent
    md = gguf_metadata(_profile("t", DA=0.7), consent=None)
    chk("metadata carries S_e/C and the modulate_not_govern policy", md["soke.emotion.policy"] == EMOTION_POLICY and len(md["soke.emotion.C"]) == 13)
    p2 = _profile("t", DA=0.7); p2.clone = {"user_id": "x", "veto_style": "delay"}
    chk("clone keys withheld without consent (a helix is not consent)", "soke.clone.user_id" not in gguf_metadata(p2, consent=None))
    chk("clone keys written with consent", "soke.clone.user_id" in gguf_metadata(p2, consent={"store": True}))
    # 8. refusal: a conditioning tensor in the weight stream is rejected
    raised = False
    try:
        assert_no_conditioning_in_weights(["token_embd.weight", "soke.emotion.C"])
    except ValueError:
        raised = True
    chk("refusal: conditioning may not be a weight tensor", raised)
    # 9. round-trip
    p3 = BehaviorProfile.from_json(CLIMATES["daring"].to_json())
    chk("profile JSON round-trips", p3.C == CLIMATES["daring"].C and p3.name == "daring")
    # 10. helix teeth are ACTG-tagged
    teeth = emotion_helix_teeth() + logic_helix_teeth() + behavior_helix_teeth()
    chk("helix teeth carry A/C/T/G registers", all(t[0] in ("A", "C", "T", "G") for t in teeth) and len(teeth) >= 12)
    return chk


if __name__ == "__main__":
    verify_suite().report_to_stdout() if hasattr(verify_suite(), "report_to_stdout") else print("\n".join(verify_suite().lines()))
