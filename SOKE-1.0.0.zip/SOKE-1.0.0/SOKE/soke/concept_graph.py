"""
soke.concept_graph — an EXPANDABLE concept graph for language / knowledge mapping.

The idea (operator's): the Google fruit-fly connectome and the Kabbalah Tree of Life are the SAME shape — a
few input nodes, typed paths, and hubs where many routes converge ("significant steps" where nodes multiply).
This module makes that shape EXPANDABLE and puts it in SOKE's build process:

  - Each CONCEPT (a topic / knowledge unit) is given a NUMBER OF ROUTES sized to its complexity — a simple
    concept (say integer addition) gets 1 route; a complex one (natural language) gets up to ~50. Routes are
    taken in a canonical order from a Tree-of-Life motif (11 vessels, 22 SEPHIRA-typed arrows: mother = lateral,
    double = vertical, simple = diagonal). More routes touch more vessels and pile up on the hubs — growth at
    the significant steps, exactly the space-foam pattern.
  - Complexity is MEASURED, not guessed: the unigram entropy of the concept's own text sets its route count.
  - The graph GROWS and PRUNES: `grow`/`prune` change one concept's routes; `grow_where_needed` hands more
    routes to the busier concepts; `optimize_sizes` grows the load-bearing concept and KEEPS the change only if
    a measured objective improves — otherwise it reverts and records the kill (honest-null discipline).
  - It runs on the connectome substrate already in SOKE: a ConceptGraph compiles to a
    connectome_engine.Connectome, so it stores in SFF (paged, checksummed), simulates, traces pathways, and a
    LinearReadout / MLPPolicy learns on top — that is SOKE learning on the concept scaffold.

SEPHIRA's full typed-tensor LLM (mother/double/simple as trainable maps, four stacked worlds, Da'at attention)
lives in the operator's `sephira` PyTorch package; here the SAME typing rides as edge metadata on an
expandable graph SOKE can size, grow, store and learn on. That boundary is stated, not blurred.

BS Medicineman / Knight Industries — "the answer is never on the line"
"""
from __future__ import annotations

import math
from collections import Counter
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from .connectome_engine import Connectome

# --------------------------------------------------------------------------
# The Tree-of-Life motif: 11 vessels, the 22 SEPHIRA-typed directed arrows (from SEPHIRA_TREE_BUILD_v2 §3.2/§4).
# node 1 = Keter (input), node 10 = Malkuth (output), 11 = Da'at. class: mother/double/simple.
# --------------------------------------------------------------------------
CLASS_WEIGHT = {"mother": 3, "double": 2, "simple": 1}     # reciprocal-typed synapse strength

BASE_ARROWS = [
    (1, 2, "simple"), (1, 3, "simple"),                    # He, Vav
    (1, 11, "double"), (2, 11, "simple"), (3, 11, "simple"),  # Bet/Tet/Yod upper (V,Q,K inlets)
    (2, 3, "mother"), (3, 2, "mother"),                    # Shin (lateral, both ways)
    (2, 4, "double"), (3, 5, "double"),                    # Gimel, Dalet
    (11, 4, "simple"), (11, 5, "simple"), (11, 6, "double"),  # lower halves
    (2, 6, "simple"), (3, 6, "simple"),                    # Zayin, Chet
    (4, 5, "mother"), (5, 4, "mother"),                    # Aleph (lateral)
    (4, 6, "simple"), (5, 6, "simple"),                    # Lamed, Nun
    (4, 7, "double"), (5, 8, "double"),                    # Kaf, Pe
    (6, 7, "simple"), (6, 8, "simple"),                    # Samekh, Ayin
    (7, 8, "mother"), (8, 7, "mother"),                    # Mem (lateral)
    (6, 9, "double"), (7, 9, "simple"), (8, 9, "simple"),  # Resh, Tzadi, Qof
    (9, 10, "double"),                                     # Tav (tied readout)
]
_ADJ: dict = {}
for _s, _d, _c in BASE_ARROWS:
    _ADJ.setdefault(_s, []).append((_d, _c))


def _enumerate_routes(max_routes: int = 64, max_len: int = 12) -> list:
    """Simple directed routes 1 -> 10 over ONE world's motif, ordered by (length, node tuple). Route 0 is the
    shortest way in; each further route adds vessels/arrows within the world."""
    found: list = []

    def dfs(node, path):
        if len(found) >= 4000 or len(path) > max_len:
            return
        if node == 10:
            found.append(path); return
        for nb, _c in _ADJ.get(node, []):
            if nb not in path:
                dfs(nb, path + (nb,))

    dfs(1, (1,))
    found.sort(key=lambda p: (len(p), p))
    return found[:max_routes]


ONE_WORLD = _enumerate_routes(64)                          # canonical routes inside a single tree (11 vessels)
ROUTES = ONE_WORLD                                         # alias (route 0 = the shortest way in)
ROUTES_PER_WORLD = 8                                       # after this many routes a concept opens a NEW world
WORLD_CAP = 7                                              # up to 7 stacked worlds (the four-worlds doctrine, extended)
WORLD_SIZE = 11                                            # vessels per world (1..11)
MAX_ROUTES = ROUTES_PER_WORLD * WORLD_CAP                  # 56; paths_for clamps the usable range to 50
_CLS_OF = {(s, d): c for s, d, c in BASE_ARROWS}


# --------------------------------------------------------------------------
# complexity  <->  route count
# --------------------------------------------------------------------------
def text_complexity(text: str) -> float:
    """Normalized complexity in [0,1] from the unigram (byte) Shannon entropy of the text. Low-entropy,
    repetitive text (e.g. 'a+b=c' arithmetic) scores low; rich natural language scores high. 8 bits max."""
    if not text:
        return 0.0
    b = text.encode("utf-8", "replace")
    counts = Counter(b)
    n = len(b)
    H = -sum((c / n) * math.log2(c / n) for c in counts.values())   # bits/byte, 0..8
    return max(0.0, min(1.0, H / 8.0))


def paths_for(complexity: float, hi: int = 50, lo: int = 1) -> int:
    """Route count for a concept of the given normalized complexity. Simple -> lo (1), complex -> hi (50)."""
    hi = min(hi, MAX_ROUTES)
    c = max(0.0, min(1.0, float(complexity)))
    return int(max(lo, min(hi, round(lo + (hi - lo) * c))))


# --------------------------------------------------------------------------
# the expandable concept graph
# --------------------------------------------------------------------------
class ConceptGraph:
    """A set of concepts, each given `k` routes through the Tree-of-Life motif, wired between a shared input hub
    and output hub. Compiles to a connectome_engine.Connectome (SFF / simulate / pathways / readout)."""

    IN_HUB = 0
    OUT_HUB = 1
    _STRIDE = 100                                          # vessel-id namespace per concept

    def __init__(self, routes: Optional[dict] = None, name: str = "concepts"):
        self.name = name
        self.routes: dict = dict(routes or {})            # concept name -> k (route count)
        self._cnx: Optional[Connectome] = None
        self._members: dict = {}                          # concept -> node-id array (set on build)

    # ---- construction from complexity / text -----------------------------
    @staticmethod
    def from_complexities(complexities: dict, hi: int = 50, name: str = "concepts") -> "ConceptGraph":
        return ConceptGraph({c: paths_for(v, hi=hi) for c, v in complexities.items()}, name=name)

    @staticmethod
    def auto_size_from_texts(texts: dict, hi: int = 50, name: str = "concepts") -> "ConceptGraph":
        """Size every concept from the MEASURED complexity of its own text. This is the language/knowledge map:
        the data decides how many routes (how much wiring) a concept gets."""
        return ConceptGraph.from_complexities({c: text_complexity(t) for c, t in texts.items()}, hi=hi, name=name)

    # ---- edits -----------------------------------------------------------
    def grow(self, concept: str, d: int = 1) -> int:
        self.routes[concept] = int(max(1, min(MAX_ROUTES, self.routes.get(concept, 0) + d)))
        self._cnx = None
        return self.routes[concept]

    def prune(self, concept: str, d: int = 1) -> int:
        return self.grow(concept, -d)

    def set_routes(self, concept: str, k: int) -> int:
        self.routes[concept] = int(max(1, min(MAX_ROUTES, k)))
        self._cnx = None
        return self.routes[concept]

    def grow_where_needed(self, loads: dict, budget: int) -> dict:
        """Distribute `budget` extra routes across concepts in proportion to their load (activity / error), so
        the busiest concepts — the significant steps — grow most. Returns the added counts."""
        names = [c for c in self.routes if loads.get(c, 0.0) > 0]
        tot = sum(loads.get(c, 0.0) for c in names) or 1.0
        added = {}
        for c in names:
            share = int(round(budget * loads.get(c, 0.0) / tot))
            if share:
                added[c] = self.grow(c, share) and share
        self._cnx = None
        return added

    # ---- compile to a connectome ----------------------------------------
    def _concept_edges(self, ci: int, k: int):
        """Edges (globally-namespaced) for one concept using its first k routes, STACKING a new world every
        ROUTES_PER_WORLD routes (the four-worlds doctrine: more routes -> more worlds -> more vessels). Returns
        (edges, vessels, class_counter)."""
        base = 2 + ci * self._STRIDE
        k = int(max(1, min(k, MAX_ROUTES)))
        n_worlds = (k + ROUTES_PER_WORLD - 1) // ROUTES_PER_WORLD
        used: dict = {}                                    # (gsrc, gdst) -> class
        vessels: set = set()
        remaining = k
        for w in range(n_worlds):
            wb = base + w * WORLD_SIZE                      # this world's vessel-id base
            rw = min(remaining, ROUTES_PER_WORLD); remaining -= rw
            for r in range(rw):
                path = ONE_WORLD[r]
                for a, b in zip(path[:-1], path[1:]):
                    used[(wb + a, wb + b)] = _CLS_OF.get((a, b), "simple")
                    vessels.add(wb + a); vessels.add(wb + b)
            if w > 0:                                       # chain worlds: prev output vessel -> this input vessel
                prev_out = base + (w - 1) * WORLD_SIZE + 10
                used[(prev_out, wb + 1)] = "double"
                vessels.add(prev_out); vessels.add(wb + 1)
        cls_count = Counter(used.values())
        edges = [(gs, gd, CLASS_WEIGHT[c], "CPT.x", "CPT.x") for (gs, gd), c in used.items()]
        edges.append((self.IN_HUB, base + 1, CLASS_WEIGHT["mother"], "SEN.in", "CPT.x"))
        out_v = base + (n_worlds - 1) * WORLD_SIZE + 10
        if out_v in vessels:
            edges.append((out_v, self.OUT_HUB, CLASS_WEIGHT["mother"], "CPT.x", "DN.out"))
        return edges, vessels, cls_count

    def build(self) -> Connectome:
        if self._cnx is not None:
            return self._cnx
        edges = []
        raw_members = {}                                  # concept -> original vessel ids (pre-relabel)
        for ci, (concept, k) in enumerate(sorted(self.routes.items())):
            ce, vessels, _ = self._concept_edges(ci, k)
            # relabel this concept's vessel types with the concept name so each concept is its own tap
            ce = [(s, d, w, (pt if pt in ("SEN.in",) else f"CPT.{concept}"),
                   (qt if qt in ("DN.out",) else f"CPT.{concept}")) for (s, d, w, pt, qt) in ce]
            edges.extend(ce)
            raw_members[concept] = sorted(vessels)
        cnx = Connectome.from_edges(edges, name=self.name)
        # from_edges relabels every original id to a contiguous index; invert body_ids to map members back
        inv = {int(k): i for i, k in enumerate(cnx.body_ids)} if cnx.body_ids is not None else {}
        self._members = {c: np.array([inv[o] for o in ids if o in inv], dtype=np.int64) for c, ids in raw_members.items()}
        self._cnx = cnx
        return cnx

    def to_connectome(self) -> Connectome:
        return self.build()

    def to_sff(self, path, memguard=None) -> dict:
        return self.build().to_sff(path, memguard=memguard)

    # ---- counts / description -------------------------------------------
    def n_routes(self) -> int:
        return int(sum(self.routes.values()))

    def counts(self) -> dict:
        c = self.build()
        return {"concepts": len(self.routes), "routes": self.n_routes(), "nodes": c.n_nodes, "synapses": c.n_edges}

    def class_mix(self) -> dict:
        """How many mother / double / simple arrows the whole graph uses (the SEPHIRA typing, summed)."""
        mix = Counter()
        for ci, (concept, k) in enumerate(sorted(self.routes.items())):
            _, _, cls_count = self._concept_edges(ci, k)
            mix.update(cls_count)
        return dict(mix)

    def describe(self) -> str:
        c = self.counts()
        mix = self.class_mix()
        rows = sorted(self.routes.items(), key=lambda kv: -kv[1])
        lines = [f"Concept graph '{self.name}': {c['concepts']} concepts, {c['routes']} routes, "
                 f"{c['nodes']:,} vessels, {c['synapses']:,} arrows.",
                 "  routes per concept: " + ", ".join(f"{n}={k}" for n, k in rows[:12]),
                 f"  SEPHIRA typing (arrows): mother={mix.get('mother',0)} double={mix.get('double',0)} simple={mix.get('simple',0)}",
                 "  substrate: compiles to a connectome (SFF-paged); simulate / pathways / a readout policy run on it."]
        return "\n".join(lines)

    # ---- honest-null growth ---------------------------------------------
    def optimize_sizes(self, objective: Callable[["ConceptGraph"], float], loads: Optional[dict] = None,
                        rounds: int = 4, step: int = 2, budget_cap: int = 50) -> dict:
        """Grow the busiest concept by `step` routes each round; KEEP the growth only if `objective` (LOWER is
        better) improved by more than 1e-9 — otherwise revert and record a kill. Returns the log."""
        log = {"kept": [], "killed": [], "start": None, "end": None}
        cur = float(objective(self))
        log["start"] = cur
        order = sorted(self.routes, key=lambda c: -(loads or {}).get(c, 1.0))
        for rnd in range(rounds):
            grew = False
            for concept in order:
                if self.routes[concept] >= min(MAX_ROUTES, budget_cap):
                    continue
                before = self.routes[concept]
                self.grow(concept, step)
                trial = float(objective(self))
                if trial < cur - 1e-9:
                    log["kept"].append({"concept": concept, "k": self.routes[concept], "obj": trial})
                    cur = trial; grew = True; break
                else:
                    self.set_routes(concept, before)       # revert
                    log["killed"].append({"concept": concept, "tried_k": before + step, "obj": trial})
            if not grew:
                break
        log["end"] = cur
        return log


def verify_suite(chk=None, tmpdir=None):
    import tempfile
    from .util import Check
    from .connectome_engine import MLPPolicy
    from .rng import Rng
    chk = chk or Check("concept_graph")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_cpt_"))

    # ---- routes enumerated, canonical, connect input->output -------------
    chk("motif enumerates >= 50 routes 1->10", len(ROUTES) >= 50, f"{len(ROUTES)} routes")
    chk("route 0 is the shortest and starts at 1, ends at 10", ROUTES[0][0] == 1 and ROUTES[0][-1] == 10
        and all(len(ROUTES[0]) <= len(r) for r in ROUTES))

    # ---- complexity -> routes: simple gets 1, complex gets many ----------
    chk("paths_for is clamped to [1,50] and monotone", paths_for(0.0) == 1 and paths_for(1.0) == min(50, MAX_ROUTES)
        and paths_for(0.5) >= paths_for(0.1), f"{paths_for(0.0)},{paths_for(0.5)},{paths_for(1.0)}")
    simple_txt = "a+b=c; " * 200                                   # low entropy
    rich_txt = "the quick brown fox jumps over the lazy dog, and philosophy of art in nature. " * 20
    cs, cr = text_complexity(simple_txt), text_complexity(rich_txt)
    chk("text_complexity: rich language > simple arithmetic", cr > cs, f"simple {cs:.3f} < rich {cr:.3f}")
    chk("a simple concept needs few routes, a complex one many", paths_for(cs) < paths_for(cr),
        f"simple->{paths_for(cs)} routes, rich->{paths_for(cr)} routes")

    # ---- concept(k) grows nodes and edges with k -------------------------
    g = ConceptGraph({"math": 1, "language": 12})
    g.build()
    lang_before = g._members["language"].copy()
    math_before = len(g._members["math"])
    chk("more routes => more vessels (language has more than math)",
        len(g._members["language"]) > math_before, f"math {math_before} vs lang {len(g._members['language'])}")
    n_before = g.counts()["nodes"]
    g.grow("math", 20); g.build()
    chk("grow() adds vessels for the grown concept", len(g._members["math"]) > math_before, f"math {math_before} -> {len(g._members['math'])}")
    chk("grow() leaves the OTHER concept untouched", np.array_equal(g._members["language"], lang_before))
    chk("total vessel count increased after grow", g.counts()["nodes"] > n_before, f"{n_before} -> {g.counts()['nodes']}")
    g.prune("math", 20)
    chk("prune() is the inverse of grow()", g.routes["math"] == 1)

    # ---- SEPHIRA typing preserved ----------------------------------------
    mix = ConceptGraph({"x": 50}).class_mix()
    chk("typed arrows carry the mother/double/simple classes", mix.get("mother", 0) >= 1 and mix.get("double", 0) >= 1
        and mix.get("simple", 0) >= 1, str(mix))

    # ---- compiles to a connectome, round-trips through SFF ---------------
    cg = ConceptGraph.from_complexities({"math": 0.05, "language": 0.9, "music": 0.4})
    cnx = cg.build()
    chk("compiles to a connectome with SEN.in and DN.out taps", cnx.group("SEN.*").size >= 1 and cnx.group("DN.*").size >= 1)
    sff = tmpdir / "cg.sff"; cg.to_sff(sff)
    back = Connectome.from_sff(sff)
    chk("concept graph round-trips through SFF (nodes/edges preserved)", back.n == cnx.n and back.n_edges == cnx.n_edges,
        f"{back.n},{back.n_edges}")
    paths = cnx.pathways(cnx.group("SEN.*"), cnx.group("DN.*"), k=1, max_hops=20)
    chk("a route runs input hub -> output hub through the concepts", len(paths) >= 1, str(paths[:1]))

    # ---- load-proportional growth is monotone ----------------------------
    g2 = ConceptGraph({"a": 2, "b": 2, "c": 2})
    add = g2.grow_where_needed({"a": 9.0, "b": 3.0, "c": 0.0}, budget=12)
    chk("grow_where_needed gives the busiest concept the most routes, none to idle",
        g2.routes["a"] > g2.routes["b"] and g2.routes["c"] == 2, f"a={g2.routes['a']} b={g2.routes['b']} c={g2.routes['c']}")

    # ---- capacity: how many random (state -> label) pairs the concept can MEMORISE, a strict capacity test.
    # more routes -> more worlds -> more vessels -> more readable state -> more it can fit. Binds on route count.
    def memorise_acc(concept: str, graph: "ConceptGraph", N: int = 80, n_out: int = 4, seed: int = 1) -> float:
        c = graph.build()
        mem = graph._members[concept]
        rng = Rng(seed)
        X = []
        for _ in range(N):
            vals = rng.normal(0, 1, size=mem.size).astype(np.float32)
            X.append(c.simulate(mem, vals, ticks=3, readout_idx=mem))
        X = np.asarray(X, dtype=np.float64)
        y = rng.integers(0, n_out, size=N)                 # RANDOM labels: only capacity can fit them
        pol = MLPPolicy(mem.size, n_hidden=8, n_out=n_out, seed=1).fit_supervised(X, y, epochs=500, lr=0.3)
        return pol.accuracy(X, y)

    g_small = ConceptGraph({"c": 1}); g_small.build()
    g_big = ConceptGraph({"c": 48}); g_big.build()
    v_small, v_big = g_small._members["c"].size, g_big._members["c"].size
    chk("routes add vessels by stacking worlds (k=48 has far more vessels than k=1)", v_big > v_small,
        f"k=1 {v_small} vessels vs k=48 {v_big} vessels")
    a_small = memorise_acc("c", g_small)
    a_big = memorise_acc("c", g_big)
    chk("capacity grows with routes: the bigger concept memorises strictly more random pairs", a_big > a_small,
        f"k=1 acc {a_small:.2f} ({v_small}v) -> k=48 acc {a_big:.2f} ({v_big}v)")

    # ---- honest-null growth: the objective measures ONLY 'complex'. Load makes the optimiser try the busier
    # 'simple' first (a KILL — reverted, it does not touch the objective), then 'complex' (a KEEP).
    def objective(graph: "ConceptGraph") -> float:
        return 1.0 - memorise_acc("complex", graph)        # LOWER is better
    g3 = ConceptGraph({"simple": 1, "complex": 1})
    log = g3.optimize_sizes(objective, loads={"simple": 5.0, "complex": 1.0}, rounds=5, step=16)
    chk("optimize_sizes lowered the objective (kept growth that helped)", log["end"] < log["start"] - 1e-9,
        f"{log['start']:.3f} -> {log['end']:.3f}")
    chk("optimize_sizes KEPT growth on 'complex' (the concept the objective measures)",
        any(e["concept"] == "complex" for e in log["kept"]), f"kept={[e['concept'] for e in log['kept']]}")
    chk("optimize_sizes RECORDED a kill on 'simple' (growth that did not help, reverted)",
        any(e["concept"] == "simple" for e in log["killed"]) and g3.routes["simple"] == 1,
        f"killed={[e['concept'] for e in log['killed']]}, simple k={g3.routes['simple']}")
    return chk


if __name__ == "__main__":
    cg = ConceptGraph.from_complexities({"arithmetic": 0.05, "language": 0.95, "music": 0.4, "physics": 0.5})
    print(cg.describe())
    print("\n".join(verify_suite().lines()))
