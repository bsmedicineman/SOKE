"""
soke.diagnose — why a forge build isn't improving, and what to change. Real analysis of the ForgeTab's
live state (donors, template, probes, trial history, behavior climate); no model required. The Home advisor
console calls diagnose_build() and suggest_edits(); both return plain data the chat prints.
"""
from __future__ import annotations

from typing import Optional


def _family_size(fg) -> int:
    try:
        from .forge import donor_status
        sig = fg.spec.donors[fg.spec.d["base"]]["sig"] if fg.spec.donors else None
    except Exception:
        sig = None
    if sig is None:
        return len(getattr(fg, "chosen_donors", lambda: [])() or [])
    n = 0
    for d in getattr(fg, "donors", []):
        try:
            if d.sig == sig:
                n += 1
        except Exception:
            pass
    return max(n, len(fg.spec.donors) if fg.spec else 0)


def diagnose_build(fg) -> dict:
    """Return {'findings': [...], 'fixes': [...]} for the ForgeTab's current target."""
    findings, fixes = [], []
    sp = getattr(fg, "spec", None)
    tr = getattr(fg, "trainer", None)
    pr = getattr(fg, "probes", None)
    beh = getattr(fg, "behavior", None)

    ndon = len(sp.donors) if sp else 0
    if ndon <= 1:
        findings.append(f"Only {ndon} donor in the family — blends, task-arithmetic and swaps have nothing to mix, so almost every move is a copy of the same weights. That is the biggest reason nothing improves.")
        fixes.append("Add a SECOND model of the exact same shape (arch, width, depth, heads, vocabulary) to the model folder and tick it on the Forge → Donors page. Then blend/extrapolate moves have something to work with.")
    else:
        findings.append(f"{ndon} donors in the family — good, blends and task-arithmetic have material to mix.")

    if pr is None:
        findings.append("No probes are attached — the loop has nothing to measure against, so every trial is a coin-flip.")
        fixes.append("Import a corpus (Import tab) and run 'Generate probes', or add a folder on Forge → Probes.")
    else:
        counts = {t: len(pr.train.get(t, [])) for t in pr.topics}
        thin = [t for t, c in counts.items() if c < 4]
        tot = getattr(pr, "n_tokens", 0)
        findings.append(f"Probes: {tot} tokens, per-topic train counts {counts}.")
        if thin:
            findings.append(f"Topics {thin} have very few probe chunks — the score on them is noisy, so real gains get rejected as within the noise.")
            fixes.append("Raise 'chunks per topic' (Forge → Probes) to 8–12 and 'tokens per chunk' to 256, and import more text for the thin topics. More probe tokens = a steadier score = smaller true gains become visible.")
        if tot and tot < 2000:
            fixes.append("The probe set is small; more tokens make the loss less jumpy and let the ratchet keep smaller wins.")

    if tr is not None and tr.trials:
        acc = [t for t in tr.trials if t.accepted]
        nulls = [t for t in tr.trials if not t.accepted]
        findings.append(f"{len(tr.trials)} trials so far: {len(acc)} kept, {len(nulls)} nulls.")
        # near-miss nulls: how many were rejected by a tiny margin
        deltas = [(t.before - t.after) for t in nulls if t.after == t.after]  # finite
        near = [d for d in deltas if 0 < d < tr.min_gain]
        if near:
            findings.append(f"{len(near)} nulls actually LOWERED the loss but by less than the accept bar (min_gain={tr.min_gain:g}). The bar is eating real gains.")
            fixes.append(f"Lower min_gain (Forge → Learn) from {tr.min_gain:g} toward 0.0002, or raise the probe token count so the same gain clears the noise.")
        # priority veto rejections
        pri_rej = sum(1 for t in nulls if "priority" in (t.desc or "").lower())
        if pri_rej:
            findings.append(f"{pri_rej} candidates were rejected only because the priority topic '{getattr(tr,'priority',None)}' would slip within tolerance.")
            fixes.append("Raise the priority tolerance (Forge → Learn, the '% may worsen' box) to 3–5 %, or pick a different priority topic.")
        # operators that never win
        dead = [op for op, st in tr.op_stats.items() if st["tried"] >= 3 and st["won"] == 0]
        if dead:
            findings.append(f"Operators that keep failing: {', '.join(dead)}.")
            fixes.append("Untick the dead operators (Forge → Learn) and lean on the ones that win, or switch the preset — a different starting layout gives them something to bite on.")
        if acc and all(abs(t.before - t.after) < 1e-4 for t in acc):
            findings.append("The accepted moves are tiny — you are near a local optimum for this donor set and preset.")
            fixes.append("Try bolder moves: enable 'extrapolate past the donors' and 'add expert', or restart from the 'random soup' preset, which owes nothing to the current layout.")
    elif tr is not None:
        findings.append("The loop has not run yet — press Start on Forge → Learn.")

    if beh is not None:
        k = beh.knobs()
        if k["min_gain_mult"] > 1.4:
            findings.append(f"The behavior climate '{beh.name}' tightens the accept bar ×{k['min_gain_mult']:.2f} — deliberately strict, but it also rejects small wins.")
            fixes.append("For exploration, switch the climate to 'seeking' or 'neutral' (Forge → Behavior); save the strict climate for polishing.")
        if k["heal_first"]:
            findings.append(f"'{beh.name}' has heal-first on (high CORT) — grow moves are disabled, so the model can only shrink.")
            fixes.append("If you want the model to grow experts/layers, lower CORT or pick a non-scarcity climate.")

    if not findings:
        findings.append("Nothing obviously wrong in the setup — the remaining gains are small. Add donors or corpus, or accept that this donor set is near its floor.")
    return {"findings": findings, "fixes": fixes}


def suggest_edits(fg) -> list:
    """Concrete, ordered template edits to try next."""
    out = []
    sp = getattr(fg, "spec", None)
    if sp is None:
        return ["Build a template on the Forge tab first."]
    ndon = len(sp.donors)
    moe = bool(sp.layers[0].get("experts")) if sp.layers else False
    if ndon <= 1:
        out.append("Add a second same-shape donor — with one donor there is nothing to blend; this is the highest-value change.")
    if moe:
        out.append("On the worst-scoring topic's expert, try a blend of the two best donors (double-click the cell → blend, t≈0.5).")
        out.append("For one layer, set the topic expert to an extrapolation (A + 1.3·(B−A)) to reach weights neither donor has.")
        out.append("Duplicate the strongest middle layer (depth surgery) and re-run — sometimes depth beats width.")
    else:
        out.append("Switch to the 'math-always-on' preset so a shared expert carries the priority topic on every token.")
    out.append("Regenerate probes with more tokens per chunk (256) so the loop can see smaller true gains.")
    out.append("Lower min_gain to 0.0003 and set the priority tolerance to 3 % for a few dozen trials, then tighten again to polish.")
    return out


def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("diagnose")

    class _Spec:
        def __init__(self, ndon, moe=True):
            self.donors = {f"D{i}": {"path": "", "sig": "s"} for i in range(ndon)}
            self.d = {"base": "D0", "name": "t"}
            self.topics = ["math", "language"]
            self.layers = [{"experts": [{"topic": "math"}, {"topic": "language"}]}] if moe else [{"ffn": {}}]

        def summary(self):
            return "spec"

    class _FG:
        def __init__(self, ndon):
            self.spec = _Spec(ndon); self.trainer = None; self.probes = None; self.behavior = None
            self.donors = []
    r = diagnose_build(_FG(1))
    chk("single-donor build is flagged as the main blocker", any("Only 1 donor" in f for f in r["findings"]) and any("second" in x.lower() for x in r["fixes"]))
    r2 = diagnose_build(_FG(3))
    chk("multi-donor build is not flagged for donor count", any("3 donors" in f for f in r2["findings"]))
    s = suggest_edits(_FG(1))
    chk("suggest_edits leads with adding a donor for a 1-donor spec", "second same-shape donor" in s[0])
    chk("suggest_edits returns a short ordered list", 2 <= len(s) <= 8)
    return chk


if __name__ == "__main__":
    print("\n".join(verify_suite().lines()))
