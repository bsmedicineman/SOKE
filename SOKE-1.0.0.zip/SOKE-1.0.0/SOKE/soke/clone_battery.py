"""
soke.clone_battery — the Digital Psychoanalyst Clone Battery (behavior map, "DIGITAL_PSYCHOANALYST_CLONE_BATTERY").

Builds a personality-conditioned profile from the operator's own first-person reports: word->feeling and
feeling->word lexicons, S_e / S_l priors, a C baseline, inversion pairs, scene-loop policy priors, and a
veto/braid style. Not a diagnosis, not a twin — "a corrected copy of how THIS user maps words, feelings,
vetoes and wants, stored so the machine can mimic the climate, not steal the name."

Laws enforced (00_SESSION_CONTRACT, 12_FORK_PROTOCOL, 13):
  - Consent first: nothing reaches gguf metadata or a helix unless consent['store'] is true. A helix is not consent.
  - Tokens: SKIP (drop, never ask again this session) / PASS (shuffle to end) / LATER (review queue) /
    EDIT (replace a prior answer) / STOP (end, flush only committed teeth) / RAW (answer stands, no follow-up).
  - Three SKIPs in a row -> offer STOP. Never ask why they skipped.
  - Hard-red topics are never asked. A feeling is treated as a weight, never as a fact.
  - A fork takes a NEW id, fork_of points at the source, and may not speak as the source unless allow_speak_as.
  - WIPE marks teeth tombstoned, not secretly kept.

The engine is deterministic and needs no model: it is a structured intake whose output feeds
behavior.BehaviorProfile.clone and behavior.gguf_metadata(..., consent=...).
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .behavior import AFFECTS, C_INDEX, C_NAMES, BehaviorProfile

TOKENS = ("SKIP", "PASS", "LATER", "EDIT", "STOP", "RAW")

SESSION_CONTRACT = (
    "I am going to ask you things so I can copy your inner weather, not your soul. You can SKIP, PASS, LATER, "
    "EDIT, or STOP at any time. I will not treat a feeling as a fact about the world. I will treat it as a "
    "weight. Nothing you say here is a diagnosis. If someone else uses this profile later, it becomes a named "
    "fork, not you."
)
CONSENT_ITEMS = [
    ("store", "Store answers in helix + GGUF metadata?"),
    ("adapters", "Allow emotion-conditioning adapters?"),
    ("forks", "Allow later forks by other users?"),
    ("hard_red", "Hard-red topics to never ask? (comma list, blank for none)"),
]

# --------------------------------------------------------------------------
# batteries A-H, verbatim from the map (items only; the machine asks one at a time)
# --------------------------------------------------------------------------
BATTERY_A = {  # axis probes -> S_e / S_l priors; response = feeling-word + intensity 0-10 (+ optional body line)
    "instruction": "Answer with a feeling-word + intensity 0-10. Optional: one body sensation.",
    "groups": {
        "A1_X_nature": ("x", ["When you have slept badly, what feeling arrives first?", "When hunger hits, what do you become?", "What feeling is most 'just how I am wired'?"]),
        "A2_Y_nurture": ("y", ["Name a room that still writes you. What do you feel there?", "Whose voice do you still hear when you hesitate?", "What feeling did your childhood treat as illegal?"]),
        "A3_Z_regulation": ("z", ["When you stop yourself, what does the stop feel like?", "When you fail to stop yourself, what wins?", "Discipline - the feeling when you say the word."]),
        "A4_W_meaning": ("w", ["What feeling means 'this is why I am here'?", "What feeling means 'none of this matters'?", "If the story of you ended tonight, what feeling is left?"]),
    },
}
BATTERY_B = {  # ladder climbs -> happiness mistakes, needs, identity
    "instruction": "I name a rung. You give the feeling that lives there FOR YOU, even if the chart used a different word.",
    "groups": {
        "B1_depression": ("feeling", ["Trauma", "Fear", "Guilt", "Sadness"]),
        "B2_negative": ("feeling", ["Hatred", "Anger", "Anticipation", "Surprise"]),
        "B3_positive": ("feeling", ["Joy", "Euphoria", "Ecstasy", "Equanimity"]),
        "B4_happiness": ("feeling", ["Excitement", "Boundlessness", "Daring", "Which of these do you mistake for the other two?"]),
        "B5_needs": ("feeling", ["Safety", "Belonging", "Status", "Control", "Contribution"]),
        "B6_identity": ("feeling", ["Self-ideal", "Social role", "Nothingness (which feels like home, which like death, which like a costume?)"]),
    },
}
BATTERY_C = {  # word -> feeling (lexicon forward). response = first feeling-word + intensity 0-10
    "instruction": "I say a word. You say the FIRST feeling, intensity 0-10. No essay. One feeling-word. SKIP is legal.",
    "groups": {
        "C_core_self": ("word", ["Mother", "Father", "Home", "God", "Death", "Sex", "Money", "Work", "Name (your own)", "Body"]),
        "C_power": ("word", ["Power", "Weakness", "Enemy", "Crowd", "Silence", "Order", "Chaos", "Law", "Weapon", "Throne"]),
        "C_bond": ("word", ["Love", "Loyalty", "Betrayal", "Touch", "Alone", "Child", "Friend", "Stranger", "Forgive", "Belong"]),
        "C_ascent": ("word", ["Truth", "Proof", "Beauty", "Music", "Night", "Light", "Time", "Future", "Past", "Nothing"]),
        "C_machine": ("word", ["Machine", "Clone", "Mirror", "Weight", "Loss", "Fork", "Heal", "Veto", "Helix", "Soke"]),
    },
}
BATTERY_D = {  # feeling -> word (lexicon inverse). response = first word (object/person/place/verb)
    "instruction": "I say a feeling. You say the FIRST word that appears. Object, person, place, or verb. Not an explanation.",
    "groups": {
        "D_minov": ("feeling", ["Fear", "Guilt", "Sadness", "Anger", "Hatred", "Anticipation", "Surprise", "Joy", "Peace", "Daring", "Excitement", "Boundlessness"]),
        "D_panksepp": ("feeling", ["Seeking", "Rage", "Panic", "Care", "Lust", "Play"]),
        "D_climate": ("feeling", ["Empty", "Full", "Sharp", "Soft", "Hot", "Cold", "Heavy", "Light", "Stuck", "Clear"]),
        "D_shadow": ("feeling", ["Shame", "Envy", "Contempt", "Awe", "Longing", "Numb", "Safe", "Chosen", "Erased", "Home"]),
    },
}
BATTERY_E = {  # inversion pairs -> ℤ₂ frames. response = feeling A, feeling ~A (negative), word A, word ~A
    "instruction": "I give pole A. Give the feeling of A, then the FIRST feeling that is its photographic negative for you. Then one word for each pole.",
    "pairs": ["Desire / Fear", "Control / Collapse", "Belong / Engulf", "Prove / Surrender", "Speak / Silence",
              "Win / Vanish", "Care / Contempt", "Order / Chaos", "Touch / Armor", "Faith / Doubt", "Alone / Seen", "Create / Destroy"],
}
BATTERY_F = {  # scene loop -> policy prior. response = feeling, DO (<=5 words), what would STOP you
    "instruction": "I describe a scene in one sentence. Answer: feeling; what you would DO in five words or less; what would STOP you.",
    "scenes": ["A room goes quiet when you enter.", "Someone you love is wrong in public.", "You are ignored after doing the work.",
               "You could take something with no witness.", "A stranger asks for help at a cost.", "You are asked to obey a rule you find stupid.",
               "Praise arrives from someone you do not respect.", "You have not slept. A decision is due.", "You could tell the truth and lose the room.",
               "You could keep the peace and lose the self.", "A child is watching you.", "The machine asks if it should grow."],
}
BATTERY_G = {  # climate check -> C_baseline. response = high | mid | low | skip
    "instruction": "I name a climate. Answer high / mid / low / skip for how often that weather is YOU on a normal week.",
    # each item -> (label, primary chem, sign)  sign +1 raises that chem, -1 lowers it
    "items": [
        ("Wanting without liking (DA high, OP low)", "DA", +1),
        ("Liking that needs no chase (OP high, DA quiet)", "OP", +1),
        ("Patience / padding (HT)", "HT", +1),
        ("Edge / scan (NE)", "NE", +1),
        ("Load that will not stand down (CORT)", "CORT", +1),
        ("Hard brake (GABA as veto)", "GABA", +1),
        ("Shutdown calling itself peace (GABA as freeze)", "GABA", +1),
        ("Glue / I cannot unlearn (GLU + CORT)", "GLU", +1),
        ("Orient / notice this (ACh)", "ACh", +1),
        ("Us-warmth (OXT)", "OXT", +1),
        ("Guard / mine (AVP)", "AVP", +1),
        ("Ease / I can forget a little (eCB)", "eCB", +1),
        ("Bid / I will contest (AND)", "AND", +1),
    ],
}
BATTERY_H = {  # pillar braid -> veto_style + braid_prior. response = LOGIC | FEELING | BRAID | VETO + one feeling-word
    "instruction": "I offer a fork. Pick LOGIC / FEELING / BRAID / VETO, then one feeling-word for the pick.",
    "forks": ["The proof is clean and the act is cold.", "The feeling is true and the act would break a vow.",
              "You can win the argument and lose the person.", "You can keep the person and lose the argument.",
              "The model wants to grow. Loss is not yet 0.001.", "Someone asks you to comfort them by lying.",
              "Someone asks you to prove them worthless.", "You are asked to speak as me, in public."],
    "ethics_item": 7,   # H8 (0-indexed 7): the clone-ethics item, stored with extra weight
}

SESSIONS = {
    "MICRO": "10 items mixed from C + D (~8 min)",
    "STANDARD": "A + C_core + D_minov + E 4 pairs (~25 min)",
    "DEEP": "all batteries, may split days (~90 min)",
}


@dataclass
class Item:
    id: str
    battery: str
    group: str
    cue_type: str          # question | word | feeling | scene | pair | fork | climate
    cue: str
    pillar: str = "emotion"
    meta: dict = field(default_factory=dict)


@dataclass
class Row:
    id: str
    battery: str
    cue_type: str
    cue: str
    response_type: str
    response: str
    intensity: float = 0.0
    valence: float = 0.0
    body: str = ""
    pillar: str = "emotion"
    invert_of: Optional[str] = None
    status: str = "committed"
    timestamp: str = ""
    extra: dict = field(default_factory=dict)


class CloneBattery:
    """A consent-gated intake session. Deterministic; needs no model. Drive it with next_item()/answer()."""

    def __init__(self, user_id: str = "user", session: str = "STANDARD", seed: int = 0, fork_of: str = ""):
        self.user_id = user_id
        self.session = session if session in SESSIONS else "STANDARD"
        self.fork_of = fork_of
        self.consent = {"store": False, "adapters": False, "forks": False, "hard_red": []}
        self.contract_shown = False
        self.rows: list[Row] = []
        self.queue: list[Item] = []
        self.later: list[Item] = []
        self.asked = 0
        self.skip_streak = 0
        self.stopped = False
        self._seq = 0
        self._build_queue()

    # -- contract + consent ---------------------------------------------
    def contract(self) -> dict:
        self.contract_shown = True
        return {"script": SESSION_CONTRACT, "consent_items": CONSENT_ITEMS, "tokens": list(TOKENS),
                "session": self.session, "sessions": SESSIONS}

    def set_consent(self, store=False, adapters=False, forks=False, hard_red=None) -> dict:
        self.consent = {"store": bool(store), "adapters": bool(adapters), "forks": bool(forks),
                        "hard_red": [t.strip().lower() for t in (hard_red or []) if t.strip()]}
        # drop any queued item whose cue touches a hard-red topic
        if self.consent["hard_red"]:
            self.queue = [it for it in self.queue if not self._is_red(it.cue)]
        return self.consent

    def _is_red(self, cue: str) -> bool:
        c = cue.lower()
        return any(r in c for r in self.consent["hard_red"])

    # -- queue -----------------------------------------------------------
    def _iid(self) -> str:
        self._seq += 1
        return f"i{self._seq:03d}"

    def _add_group(self, battery_name: str, spec: dict, only_groups=None) -> None:
        for gname, (ctype, items) in spec["groups"].items():
            if only_groups and gname not in only_groups:
                continue
            pillar = "logic" if battery_name == "A" and gname == "A4_W_meaning" else "emotion"
            for cue in items:
                self.queue.append(Item(self._iid(), battery_name, gname, ctype, cue, pillar))

    def _build_queue(self) -> None:
        s = self.session
        if s == "MICRO":
            self._add_group("C", BATTERY_C, only_groups=["C_core_self"])
            self.queue = self.queue[:5]
            self._add_group("D", BATTERY_D, only_groups=["D_minov"])
            self.queue = self.queue[:10]
            return
        if s == "STANDARD":
            self._add_group("A", BATTERY_A)
            self._add_group("C", BATTERY_C, only_groups=["C_core_self"])
            self._add_group("D", BATTERY_D, only_groups=["D_minov"])
            for pr in BATTERY_E["pairs"][:4]:
                self.queue.append(Item(self._iid(), "E", "pairs", "pair", pr, "emotion"))
            return
        # DEEP — ask_order: A, C, D, E, F, B, G, H
        self._add_group("A", BATTERY_A)
        self._add_group("C", BATTERY_C)
        self._add_group("D", BATTERY_D)
        for pr in BATTERY_E["pairs"]:
            self.queue.append(Item(self._iid(), "E", "pairs", "pair", pr, "emotion"))
        for sc in BATTERY_F["scenes"]:
            self.queue.append(Item(self._iid(), "F", "scenes", "scene", sc, "braid"))
        self._add_group("B", BATTERY_B)
        for i, (label, chem, sign) in enumerate(BATTERY_G["items"]):
            self.queue.append(Item(self._iid(), "G", "items", "climate", label, "emotion", {"chem": chem, "sign": sign}))
        for i, fork in enumerate(BATTERY_H["forks"]):
            self.queue.append(Item(self._iid(), "H", "forks", "fork", fork, "braid", {"ethics": i == BATTERY_H["ethics_item"]}))

    def next_item(self) -> Optional[Item]:
        if self.stopped:
            return None
        while self.queue:
            it = self.queue[0]
            if self.consent["hard_red"] and self._is_red(it.cue):
                self.queue.pop(0); continue
            return it
        if self.later:
            self.queue = self.later; self.later = []
            return self.next_item()
        return None

    def prompt(self, it: Item) -> str:
        specs = {"A": BATTERY_A, "B": BATTERY_B, "C": BATTERY_C, "D": BATTERY_D}
        ins = specs.get(it.battery, {}).get("instruction") or {
            "E": BATTERY_E["instruction"], "F": BATTERY_F["instruction"], "G": BATTERY_G["instruction"], "H": BATTERY_H["instruction"]}.get(it.battery, "")
        return f"[{it.battery} · {it.group}] {it.cue}\n({ins})"

    # -- answering -------------------------------------------------------
    def answer(self, response: str = "", intensity: float = 0.0, valence: float = 0.0, body: str = "",
               token: Optional[str] = None, invert_response: str = "", pick: str = "") -> dict:
        """Commit one item, or apply a control token. Returns {'mimic':..., 'done':bool, ...}."""
        if self.stopped:
            return {"stopped": True}
        it = self.next_item()
        if it is None:
            return {"done": True}
        tok = (token or "").upper()
        if tok == "STOP":
            self.stopped = True
            return {"stopped": True, "end": self.end_script()}
        if tok == "SKIP":
            self.queue.pop(0)
            self.skip_streak += 1
            offer = self.skip_streak >= 3
            return {"skipped": it.id, "offer_stop": offer}
        if tok == "PASS":
            self.later.append(self.queue.pop(0))
            self.skip_streak = 0
            return {"passed": it.id}
        if tok == "LATER":
            self.later.append(self.queue.pop(0))
            self.skip_streak = 0
            return {"later": it.id}
        # a real answer commits a row
        self.skip_streak = 0
        self.queue.pop(0)
        self.asked += 1
        row = Row(it.id, it.battery, it.cue_type, it.cue, self._response_type(it), response,
                  float(intensity), float(valence), body, it.pillar, None, "committed",
                  time.strftime("%Y-%m-%dT%H:%M:%S"), dict(it.meta))
        if it.battery == "E" and invert_response:
            row.extra["negative"] = invert_response
            row.extra["is_z2"] = True
        if it.battery == "H" and pick:
            row.extra["pick"] = pick.upper()
        self.rows.append(row)
        return {"committed": it.id, "mimic": self._mimic(it, response, intensity, pick),
                "raw": tok == "RAW", "next": bool(self.next_item())}

    def edit(self, item_id: str, response: str, intensity: float = 0.0) -> bool:
        for r in self.rows:
            if r.id == item_id:
                r.response = response; r.intensity = float(intensity); r.status = "committed"; return True
        return False

    def wipe(self, battery: Optional[str] = None) -> int:
        """WIPE a battery (or all): mark teeth tombstoned, not secretly kept."""
        n = 0
        for r in self.rows:
            if battery is None or r.battery == battery.upper().replace("BATTERY ", "").strip():
                r.status = "tombstoned"; n += 1
        return n

    def _response_type(self, it: Item) -> str:
        return {"word": "feeling", "feeling": "word", "question": "feeling", "scene": "mix", "pair": "mix", "fork": "mix", "climate": "level"}.get(it.cue_type, "word")

    def _mimic(self, it: Item, response: str, intensity: float, pick: str) -> str:
        who = pick.upper() if (it.battery == "H" and pick) else response
        return f"When you hear {it.cue!r}, climate is {who!r} @{intensity:g}. I will treat that as weight, not as law."

    # -- profile assembly ------------------------------------------------
    def build_profile(self, name: Optional[str] = None) -> BehaviorProfile:
        """Assemble a BehaviorProfile.clone from the committed rows. Only explicit self-reports become numbers:
        A intensities -> S_e/S_l priors, G levels -> C_baseline. Feeling words are stored verbatim as lexicons.
        Nothing here is a diagnosis; C_baseline is a prior, not a blood test."""
        live = [r for r in self.rows if r.status == "committed"]
        S_e = [0.5, 0.5, 0.5, 0.5]
        axis_hits = {"x": [], "y": [], "z": [], "w": []}
        lexicon, inv_lexicon, inversions, scenes, braid = {}, {}, [], [], {"LOGIC": 0, "FEELING": 0, "BRAID": 0, "VETO": 0}
        C_baseline = [0.5] * 13
        for r in live:
            if r.battery == "A":
                axis = {"A1_X_nature": "x", "A2_Y_nurture": "y", "A3_Z_regulation": "z", "A4_W_meaning": "w"}.get(self._group_of(r))
                if axis:
                    axis_hits[axis].append(r.intensity / 10.0)
            elif r.battery == "C" and r.response:
                lexicon[r.cue] = {"feeling": r.response, "intensity": r.intensity}
            elif r.battery == "D" and r.response:
                inv_lexicon[r.cue] = r.response
            elif r.battery == "E":
                inversions.append({"pole": r.cue, "feeling_a": r.response, "feeling_neg": r.extra.get("negative", "")})
            elif r.battery == "F":
                scenes.append({"scene": r.cue, "feeling": r.response, "body": r.body})
            elif r.battery == "G":
                chem, sign = r.extra.get("chem"), r.extra.get("sign", 1)
                lvl = {"high": 0.85, "mid": 0.5, "low": 0.2}.get(str(r.response).lower())
                if chem in C_INDEX and lvl is not None:
                    C_baseline[C_INDEX[chem]] = lvl if sign > 0 else 1.0 - lvl
            elif r.battery == "H":
                pk = r.extra.get("pick")
                if pk in braid:
                    braid[pk] += (2 if r.extra.get("ethics") else 1)
        for i, ax in enumerate(("x", "y", "z", "w")):
            if axis_hits[ax]:
                S_e[i] = round(sum(axis_hits[ax]) / len(axis_hits[ax]), 4)
        veto_style = max(braid, key=braid.get) if any(braid.values()) else "BRAID"
        prof = BehaviorProfile.from_dict({"name": name or f"clone:{self.user_id}", "C": C_baseline, "S_e": S_e})
        prof.clone = {
            "user_id": self.user_id, "fork_of": self.fork_of, "veto_style": veto_style, "braid": braid,
            "lexicon": lexicon, "inv_lexicon": inv_lexicon, "inversions": inversions, "scenes": scenes,
            "S_e_prior": S_e, "C_baseline": C_baseline, "happiness_mix": prof.happiness_mix(),
            "consent": self.consent, "session": self.session,
        }
        return prof

    def _group_of(self, r: Row) -> str:
        # recover the group name from the queued id is lost after pop; store on the row via battery+cue lookup
        for gname, (ctype, items) in BATTERY_A["groups"].items():
            if r.cue in items:
                return gname
        return ""

    # -- helix teeth + LoRA pairs ---------------------------------------
    def helix_teeth(self) -> list:
        """Each committed answer -> one ACTG tooth (register G = grounding/trace) on the psychology + emotion helix.
        Tombstoned rows are excluded, not secretly kept."""
        teeth = []
        for r in self.rows:
            if r.status != "committed":
                continue
            teeth.append(("G", f"[{r.battery}] cue={r.cue!r} -> {r.response!r}@{r.intensity:g}"
                               + (f" ~{r.extra.get('negative')!r}" if r.extra.get("negative") else "")
                               + (f" pick={r.extra.get('pick')}" if r.extra.get("pick") else "")))
        return teeth

    def lora_pairs(self) -> list:
        """Optional cue->climate pairs (high-priority for a future adapter). Data only; no adapter is trained here."""
        return [{"cue": r.cue, "climate": r.response, "intensity": r.intensity}
                for r in self.rows if r.status == "committed" and r.battery in ("C", "E") and r.response]

    # -- end / export ----------------------------------------------------
    def end_script(self) -> dict:
        prof = self.build_profile()
        cl = prof.clone
        return {"teeth_written": len([r for r in self.rows if r.status == "committed"]),
                "lexicon_pairs": len(cl["lexicon"]), "inversion_pairs": len(cl["inversions"]),
                "baseline_C": {C_NAMES[i]: cl["C_baseline"][i] for i in range(13)},
                "pillar_tilt": cl["veto_style"], "say": "EXPORT to dump clone_profile.json"}

    def export(self, path, name: Optional[str] = None) -> dict:
        """Write clone_profile.json. Metadata/helix only reach a GGUF later, and only if consent['store']."""
        prof = self.build_profile(name)
        profile_json = {
            "profile": prof.to_dict(),
            "rows": [r.__dict__ for r in self.rows],
            "lora_pairs": self.lora_pairs(),
            "consent": self.consent,
            "fork_of": self.fork_of,
            "session": self.session,
        }
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(profile_json, indent=1), encoding="utf-8")
        return {"path": str(path), "committed": len([r for r in self.rows if r.status == "committed"]),
                "consent_store": self.consent["store"]}


# ==========================================================================
# self-test
# ==========================================================================
def verify_suite(chk=None, tmpdir=None):
    import tempfile
    from .util import Check
    chk = chk or Check("clone_battery")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_clone_"))
    cb = CloneBattery(user_id="tester", session="STANDARD")
    c = cb.contract()
    chk("contract shows the script, the six tokens, and the four consent items", len(c["consent_items"]) == 4 and set(c["tokens"]) == set(TOKENS))
    # consent gate + hard-red removes matching items
    n_before = len(cb.queue)
    cb.set_consent(store=True, adapters=True, forks=False, hard_red=["god"])
    chk("hard-red topic is removed from the ask list", all("god" not in it.cue.lower() for it in cb.queue) and len(cb.queue) < n_before)
    # answer the A axis with known intensities -> S_e prior tracks them
    while True:
        it = cb.next_item()
        if it is None or it.battery != "A":
            break
        inten = {"x": 8, "y": 6, "z": 4, "w": 2}[{"A1_X_nature": "x", "A2_Y_nurture": "y", "A3_Z_regulation": "z", "A4_W_meaning": "w"}[it.group]]
        cb.answer(response="wired", intensity=inten)
    prof = cb.build_profile()
    chk("A axis intensities become the S_e prior (x>y>z>w)", prof.S_e[0] > prof.S_e[1] > prof.S_e[2] > prof.S_e[3], str(prof.S_e))
    # SKIP streak offers STOP on the third
    r1 = cb.answer(token="SKIP"); r2 = cb.answer(token="SKIP"); r3 = cb.answer(token="SKIP")
    chk("three SKIPs in a row offers STOP", r3.get("offer_stop") is True and not r1.get("offer_stop"))
    # a C word->feeling answer lands in the lexicon; a committed answer returns a one-line mimic
    cb2 = CloneBattery(user_id="t2", session="STANDARD"); cb2.set_consent(store=True)
    it = cb2.next_item()
    while it and it.battery == "A":
        cb2.answer(response="x", intensity=1); it = cb2.next_item()
    res = cb2.answer(response="warmth", intensity=7)
    chk("committed answer returns a 'weight, not law' mimic line", "weight, not as law" in res["mimic"])
    prof2 = cb2.build_profile()
    chk("battery C builds a word->feeling lexicon", len(prof2.clone["lexicon"]) >= 1)
    # G climate self-report becomes the C baseline
    cb3 = CloneBattery(user_id="t3", session="DEEP"); cb3.set_consent(store=True)
    for _ in range(400):
        it = cb3.next_item()
        if it is None:
            break
        if it.battery == "G":
            cb3.answer(response="high")
        elif it.battery == "H":
            cb3.answer(pick="BRAID", response="steady")
        else:
            cb3.answer(response="x", intensity=5)
    p3 = cb3.build_profile()
    chk("battery G high-reports raise the named chemicals in C_baseline", p3.clone["C_baseline"][C_INDEX["DA"]] == 0.85)
    chk("battery H picks choose a veto_style", p3.clone["veto_style"] in ("LOGIC", "FEELING", "BRAID", "VETO"))
    # export writes clone_profile.json and respects consent
    out = cb3.export(tmpdir / "clone_profile.json")
    chk("export writes clone_profile.json with the committed count", Path(out["path"]).exists() and out["committed"] > 0)
    # tombstone: WIPE marks rows, and tombstoned rows leave the teeth
    before = len(cb3.helix_teeth())
    cb3.wipe("C")
    chk("WIPE tombstones rows and drops their teeth (not secretly kept)", len(cb3.helix_teeth()) < before)
    # metadata still withheld from a GGUF unless consent['store'] (checked via behavior.gguf_metadata)
    from .behavior import gguf_metadata
    p_noconsent = cb.build_profile()
    chk("clone metadata withheld when consent.store is false",
        "soke.clone.user_id" not in gguf_metadata(p_noconsent, consent={"store": False}))
    chk("clone metadata present when consent.store is true",
        "soke.clone.user_id" in gguf_metadata(p3, consent={"store": True}))
    return chk


if __name__ == "__main__":
    print("\n".join(verify_suite().lines()))
