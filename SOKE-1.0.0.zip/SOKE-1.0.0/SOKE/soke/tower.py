"""
soke.tower — the Knowledge Tower / Domain Lattice (DLP v1.0).

    logic > math > language > measurement > science > physics > chemistry > biology
    > senses/perception > emotion, time&place > history, technology > culture
    > morality, law/power, art > music, behavior > psychology, religion, medicine,
    economics > finance, philosophy > understanding > opinion

Each node carries: parents (with STRONG/SOFT/BROKEN edge audit from the DLP text),
veracity stratum, default registers (Q R T L H + custom gauges), the ACTG memory
map, and a routing lexicon. Walk-back (understanding) is a graph traversal that
terminates at a PROVEN node or at the first SOFT/BROKEN edge — and says which.

DLP LAW 0: no domain is opened before its parents are verified.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Optional

STRATA = ("PROVABLE", "EXECUTABLE", "EMPIRICAL", "STATISTICAL", "CONSTRUCTED", "NORMATIVE", "META")
STRATUM_STATUS = {"PROVABLE": "TRUE", "EXECUTABLE": "VERIFIED", "EMPIRICAL": "EMPIRICALLY_TRUE",
                  "STATISTICAL": "EMPIRICAL+CI", "CONSTRUCTED": "CONSTRUCTED", "NORMATIVE": "CLAIMED", "META": "META"}
# CRP veracity scale
VERACITY = {"PROVABLE": 1.0, "EXECUTABLE": 0.9, "EMPIRICAL": 0.7, "STATISTICAL": 0.6,
            "CONSTRUCTED": 0.5, "NORMATIVE": 0.4, "META": 0.4}
STRONG, SOFT, BROKEN = "STRONG", "SOFT", "BROKEN"


@dataclass
class Domain:
    id: int
    name: str
    parents: list[tuple[str, str]]          # (parent_name, edge_strength)
    stratum: str
    registers: list[str]
    gauges: list[str]
    operations: list[str]
    actg: dict                              # A/C/T/G meaning in this domain
    lexicon: list[str]
    truth_regime: str = ""
    description: str = ""
    level: int = 0

    @property
    def veracity(self) -> float:
        return VERACITY[self.stratum]


def _d(i, name, parents, stratum, regs, gauges, ops, actg, lex, regime="", desc=""):
    return Domain(i, name, parents, stratum, regs, gauges, ops, actg, lex, regime, desc)


DOMAINS: list[Domain] = [
    _d(0, "logic", [], "PROVABLE", [], ["identity"], ["modus_ponens", "resolution", "truth_table"],
       {"A": "axiom", "C": "concept", "T": "technique", "G": "grounding"},
       ["logic", "proposition", "implies", "iff", "tautology", "syllogism", "valid", "premise", "boolean", "predicate", "quantifier", "contradiction", "inference"],
       "axiomatic", "propositional and predicate logic: truth tables are a decision procedure"),
    _d(1, "math", [("logic", STRONG)], "PROVABLE", [], ["identity"], ["frame_definition", "gauge_transport", "proof_search"],
       {"A": "axiom", "C": "definition", "T": "proof_technique", "G": "numeric_grounding"},
       ["math", "theorem", "proof", "integer", "prime", "algebra", "geometry", "calculus", "equation", "polynomial", "matrix", "sqrt", "sum", "derivative", "integral", "fraction", "number", "set", "function", "vector", "angle", "triangle", "ratio", "limit", "topology", "group"],
       "axiomatic", "the frame calculus; the only layer where TRUE is earned mechanically"),
    _d(2, "language", [("math", STRONG)], "EXECUTABLE", ["H", "T", "Q"], ["syntax", "semantic", "zipf"], ["concatenation", "hierarchy", "zipf_profile"],
       {"A": "grammar_rule", "C": "meaning", "T": "parsing", "G": "corpus_frequency"},
       ["word", "grammar", "sentence", "language", "verb", "noun", "syntax", "semantic", "translate", "letter", "alphabet", "token", "vocabulary", "dictionary", "phrase", "text", "speak", "write", "english", "spanish", "latin"],
       "conventional", "math expressed through symbols; Zipf bootstrap"),
    _d(3, "measurement", [("language", STRONG)], "EXECUTABLE", ["Q", "R", "L"], ["unit"], ["rms", "harmonic_sum", "unit_conversion"],
       {"A": "unit_definition", "C": "quantity", "T": "calibration", "G": "reading"},
       ["measure", "unit", "meter", "second", "kilogram", "hertz", "calibrate", "precision", "error", "uncertainty", "scale", "gauge", "instrument", "metric", "tolerance", "frequency"],
       "operational", "units are agreed language; everything downstream inherits honest uncertainty from here"),
    _d(4, "science", [("measurement", STRONG)], "EMPIRICAL", ["Q", "R", "T", "L"], ["scientific"], ["orthogonal_solve", "hypothesis_test"],
       {"A": "law", "C": "model", "T": "experiment", "G": "observation"},
       ["science", "hypothesis", "experiment", "evidence", "theory", "observe", "replicate", "falsify", "data", "laboratory", "research", "study", "method"],
       "falsifiable", "systematic mapping of observations to frame equations"),
    _d(5, "physics", [("science", STRONG)], "EMPIRICAL", ["T", "Q", "R", "H"], ["physical"], ["rotation_composition", "energy_quadrature", "impedance"],
       {"A": "physical_law", "C": "physical_concept", "T": "calculation_technique", "G": "experimental_measurement"},
       ["physics", "force", "energy", "mass", "velocity", "momentum", "wave", "field", "quantum", "electron", "photon", "gravity", "particle", "relativity", "thermodynamic", "entropy", "voltage", "current", "magnet", "spacetime", "oscillat", "resonan", "impedance"],
       "mathematical+empirical", "physics IS measurement + math; laws are right-angle constructions"),
    _d(6, "chemistry", [("physics", STRONG)], "EMPIRICAL", ["R", "Q"], ["chemical"], ["harmonic_reaction_rates"],
       {"A": "reaction_rule", "C": "molecular_structure", "T": "reaction_technique", "G": "lab_data"},
       ["chemistry", "molecule", "atom", "bond", "reaction", "acid", "base", "element", "compound", "periodic", "catalyst", "ion", "solvent", "oxid", "carbon", "hydrogen", "oxygen", "polymer"],
       "emergent", "periodic structure = group theory discovered in data"),
    _d(7, "biology", [("chemistry", STRONG)], "EMPIRICAL", ["R", "Q", "T"], ["biological"], ["steady_state_solve"],
       {"A": "biological_rule", "C": "structure", "T": "technique", "G": "measurement"},
       ["biology", "cell", "gene", "dna", "protein", "organism", "evolution", "species", "enzyme", "tissue", "neuron", "brain", "metabol", "bacteria", "virus", "plant", "animal", "selection", "mutation"],
       "emergent", "chemistry at scale + selection (selection is provable as an algorithm)"),
    _d(8, "senses_perception", [("biology", STRONG)], "EMPIRICAL", ["T", "Q"], ["perceptual"], ["spread_metric"],
       {"A": "transduction_rule", "C": "percept", "T": "signal_processing", "G": "sensor_reading"},
       ["sense", "perceive", "vision", "hearing", "touch", "smell", "taste", "signal", "stimulus", "retina", "pitch", "loud", "bright", "color", "attention", "sensor"],
       "evolved approximation", "signal processing grounds to math directly"),
    _d(9, "emotion", [("senses_perception", STRONG)], "EMPIRICAL", ["R", "Z2"], ["affect"], ["leg_swap"],
       {"A": "affect_rule", "C": "emotion_concept", "T": "regulation_technique", "G": "physiological_data"},
       ["emotion", "feel", "fear", "joy", "anger", "sad", "love", "anxiety", "mood", "arousal", "valence", "empathy", "happy", "grief", "calm", "stress", "desire"],
       "subjective+biological", "body first: interoception precedes feeling"),
    _d(10, "time_place", [("emotion", SOFT), ("math", STRONG), ("measurement", STRONG)], "EXECUTABLE", ["T", "R", "L"], ["spatiotemporal"], ["calendar_composition"],
       {"A": "periodicity_rule", "C": "coordinate", "T": "timestamping", "G": "location_reading"},
       ["time", "place", "date", "calendar", "clock", "location", "map", "latitude", "longitude", "season", "year", "hour", "geography", "where", "when", "era", "century", "region"],
       "physical+perceptual", "time grounds to periodicity; place to frames; kept with both parents"),
    _d(11, "history", [("time_place", STRONG), ("measurement", STRONG)], "EXECUTABLE", [], ["chronology"], ["append_only_log"],
       {"A": "provenance_rule", "C": "event", "T": "source_criticism", "G": "record"},
       ["history", "historical", "ancient", "war", "empire", "king", "revolution", "dynasty", "century", "civilization", "archive", "chronicle", "medieval", "record", "past"],
       "evidentiary", "record only: provenance-locked, never derived"),
    _d(12, "technology", [("physics", STRONG), ("chemistry", STRONG), ("history", SOFT)], "EXECUTABLE", ["H", "Q", "R"], ["tool"], ["tool_frame_composition"],
       {"A": "engineering_rule", "C": "device", "T": "build_procedure", "G": "artifact_test"},
       ["technology", "engine", "computer", "software", "program", "code", "machine", "circuit", "device", "algorithm", "network", "tool", "build", "compile", "hardware", "python", "function", "class", "gpu", "cpu", "memory", "file", "byte", "data", "model", "train", "tensor", "gguf"],
       "functional", "applied physics/chem — verifiable by the artifact working"),
    _d(13, "culture", [("language", STRONG), ("technology", STRONG), ("history", STRONG), ("emotion", SOFT)], "CONSTRUCTED", ["H", "Q", "R"], ["cultural"], ["composite_braid"],
       {"A": "convention", "C": "custom", "T": "practice", "G": "ethnography"},
       ["culture", "tradition", "society", "custom", "ritual", "community", "language", "nation", "festival", "family", "social", "people", "tribe", "identity", "myth"],
       "shared convention", "language + tools + group form; CONSTRUCTED stratum opens here"),
    _d(14, "morality", [("culture", SOFT), ("language", STRONG), ("emotion", SOFT)], "NORMATIVE", ["morality"], ["morality"], ["additive_moral_weights"],
       {"A": "norm", "C": "value", "T": "judgment", "G": "consequence_record"},
       ["moral", "ethic", "right", "wrong", "virtue", "duty", "justice", "good", "evil", "ought", "harm", "fair", "honest", "conscience", "guilt"],
       "normative", "influence true, derivation FALSE — stored as CLAIMED with that annotation"),
    _d(15, "law_power", [("morality", STRONG), ("culture", STRONG)], "CONSTRUCTED", ["law"], ["legal"], ["legal_constraint"],
       {"A": "statute", "C": "right", "T": "procedure", "G": "case_record"},
       ["law", "legal", "court", "judge", "police", "government", "power", "rule", "contract", "crime", "constitution", "rights", "authority", "enforce", "statute", "regulation"],
       "enforced normative", "law = morality + enforcement (that edge IS definitional)"),
    _d(16, "art", [("senses_perception", STRONG), ("culture", STRONG), ("emotion", STRONG), ("math", STRONG), ("history", STRONG)], "CONSTRUCTED", ["Q", "T", "H", "R", "L"], ["aesthetic"], ["multi_frame_overlay"],
       {"A": "aesthetic_principle", "C": "form", "T": "craft", "G": "artwork"},
       ["art", "paint", "sculpt", "beauty", "aesthetic", "design", "poem", "novel", "film", "dance", "theater", "drawing", "style", "color", "composition", "canvas", "gallery", "creative"],
       "aesthetic", "sense + culture + emotion + math + history"),
    _d(17, "music", [("art", STRONG), ("time_place", STRONG), ("math", STRONG), ("emotion", STRONG), ("language", STRONG)], "CONSTRUCTED", ["T", "Q", "R"], ["musical"], ["harmonic_composition"],
       {"A": "harmonic_rule", "C": "musical_concept", "T": "composition_technique", "G": "audio_data"},
       ["music", "note", "chord", "harmony", "melody", "rhythm", "scale", "octave", "tempo", "song", "instrument", "tuning", "interval", "major", "minor", "pitch", "beat", "frequency", "consonan", "dissonan", "guitar", "piano"],
       "aesthetic+mathematical", "strongest lower-tree math edge: frequency ratios made audible"),
    _d(18, "behavior", [("emotion", STRONG), ("history", STRONG), ("culture", STRONG), ("biology", STRONG)], "STATISTICAL", ["L", "R"], ["utility"], ["incentive_optimization"],
       {"A": "incentive_rule", "C": "habit", "T": "conditioning", "G": "observed_choice"},
       ["behavior", "habit", "incentive", "reward", "punish", "choice", "decide", "act", "motivation", "conditioning", "response", "routine", "learn", "practice", "game"],
       "incentive+emotional", "optimization over frames"),
    _d(19, "psychology", [("behavior", STRONG), ("biology", SOFT), ("emotion", STRONG), ("culture", STRONG)], "STATISTICAL", ["H"], ["belief"], ["belief_update"],
       {"A": "psychological_rule", "C": "mental_state", "T": "assessment", "G": "study_data"},
       ["psychology", "mind", "cognition", "memory", "belief", "personality", "consciousness", "perception", "bias", "trauma", "therapy", "mental", "think", "dream", "self", "ego", "awareness"],
       "probabilistic", "consciousness gap stored as a BROKEN edge node"),
    _d(20, "religion", [("language", STRONG), ("culture", STRONG), ("art", STRONG), ("emotion", STRONG), ("morality", SOFT)], "NORMATIVE", ["myth"], ["myth"], ["narrative_solve"],
       {"A": "doctrine", "C": "belief", "T": "ritual", "G": "history"},
       ["religion", "god", "faith", "prayer", "sacred", "church", "temple", "scripture", "spirit", "soul", "divine", "holy", "worship", "prophet", "kabbalah", "sephir", "tree of life", "myth", "angel"],
       "narrative+normative", "claim-systems with cultural parentage; non-derivability noted"),
    _d(21, "medicine", [("biology", STRONG), ("emotion", STRONG), ("behavior", STRONG), ("chemistry", STRONG), ("physics", STRONG)], "EMPIRICAL", ["R", "Q"], ["health"], ["dosage_balance"],
       {"A": "medical_rule", "C": "diagnosis", "T": "treatment", "G": "clinical_data"},
       ["medicine", "medical", "doctor", "patient", "disease", "drug", "dose", "symptom", "diagnos", "treatment", "surgery", "health", "infection", "vaccine", "clinic", "therapy", "anatomy", "blood", "heart"],
       "clinical", "biology + emotion + behavior"),
    _d(22, "economics", [("math", STRONG), ("behavior", STRONG), ("history", STRONG), ("culture", STRONG), ("measurement", STRONG)], "STATISTICAL", ["L", "R", "Q"], ["economic"], ["log_additive_dynamics"],
       {"A": "economic_law", "C": "market_concept", "T": "economic_technique", "G": "market_data"},
       ["economy", "economic", "market", "price", "supply", "demand", "trade", "money", "inflation", "labor", "capital", "goods", "cost", "tax", "gdp", "wealth", "scarcity", "utility"],
       "model-dependent", "game theory grounds; the rest is STATISTICAL"),
    _d(23, "finance", [("economics", STRONG), ("psychology", STRONG), ("math", STRONG)], "STATISTICAL", ["L", "T"], ["financial"], ["log_growth", "angular_risk"],
       {"A": "financial_rule", "C": "instrument", "T": "trading_technique", "G": "financial_data"},
       ["finance", "stock", "bond", "invest", "portfolio", "risk", "return", "asset", "option", "trading", "crypto", "wallet", "bank", "loan", "interest", "dividend", "volatil", "hedge", "bankr"],
       "market-dependent", "behavioral economics is the empirical joint"),
    _d(24, "philosophy", [("logic", STRONG), ("math", STRONG), ("language", STRONG), ("science", SOFT), ("art", SOFT), ("morality", SOFT), ("religion", SOFT)], "META", ["universal"], ["universal"], ["meta_transport"],
       {"A": "philosophical_rule", "C": "concept", "T": "reasoning_technique", "G": "historical_data"},
       ["philosophy", "metaphysic", "epistemolog", "ontolog", "ethics", "meaning", "truth", "existence", "knowledge", "reason", "argument", "dialectic", "stoic", "plato", "kant", "why"],
       "meta", "the META node: holds the edges themselves as objects of study"),
    _d(25, "understanding", [("philosophy", STRONG)], "META", ["Q", "R", "T", "L", "H"], ["all"], ["inversion", "walk_back"],
       {"A": "traceability_rule", "C": "explanation", "T": "walk_back", "G": "trace_depth"},
       ["understand", "explain", "because", "derive", "trace", "insight", "comprehend", "grasp", "reason", "connect", "integrate"],
       "meta", "understanding = maximum walk-back depth"),
    _d(26, "opinion", [("understanding", STRONG)], "NORMATIVE", ["L", "Q"], ["opinion"], ["probabilistic_stance"],
       {"A": "stance_rule", "C": "position", "T": "hedging", "G": "confidence_interval"},
       ["opinion", "believe", "think", "prefer", "probably", "maybe", "guess", "view", "stance", "seems", "i think", "in my", "arguably", "likely"],
       "subjective+probabilistic", "a belief with its broken edge declared"),
]
# service domains (not tower nodes)
PARAMETRIC, STAGING, RESEARCH = 200, 201, 202
SERVICE_DOMAINS = {PARAMETRIC: "parametric", STAGING: "staging", RESEARCH: "research"}

BY_NAME: dict[str, Domain] = {d.name: d for d in DOMAINS}
BY_ID: dict[int, Domain] = {d.id: d for d in DOMAINS}
_ALIASES = {"senses": "senses_perception", "perception": "senses_perception", "time": "time_place", "place": "time_place",
            "law": "law_power", "power": "law_power", "tech": "technology", "econ": "economics", "psych": "psychology",
            "mathematics": "math", "parametric": "parametric", "staging": "staging", "research": "research"}


def _assign_levels() -> None:
    for d in DOMAINS:
        d.level = 0
    changed = True
    while changed:
        changed = False
        for d in DOMAINS:
            lv = max([BY_NAME[p].level + 1 for p, _ in d.parents], default=0)
            if lv != d.level:
                d.level = lv
                changed = True


_assign_levels()


def domain_id(name: str) -> int:
    name = _ALIASES.get(name, name)
    if name in BY_NAME:
        return BY_NAME[name].id
    for k, v in SERVICE_DOMAINS.items():
        if v == name:
            return k
    raise KeyError(f"unknown domain {name}")


def domain_name(did: int) -> str:
    if did in BY_ID:
        return BY_ID[did].name
    return SERVICE_DOMAINS.get(did, f"domain_{did}")


def registers_for(name: str) -> list[str]:
    """Inheritance rule: registers(B) = registers(A) ∪ default_registers(B) over all ancestors."""
    seen: list[str] = []
    stack = [name]
    visited = set()
    while stack:
        n = stack.pop()
        if n in visited:
            continue
        visited.add(n)
        d = BY_NAME[n]
        for r in d.registers:
            if r not in seen:
                seen.append(r)
        stack.extend(p for p, _ in d.parents)
    return seen


def ancestors(name: str) -> list[str]:
    out: list[str] = []
    stack = [p for p, _ in BY_NAME[name].parents]
    while stack:
        n = stack.pop(0)
        if n not in out:
            out.append(n)
            stack.extend(p for p, _ in BY_NAME[n].parents)
    return out


def walk_back(name: str) -> dict:
    """
    DLP:WALK_BACK — trace a domain's parents toward math/logic. Terminates at a PROVABLE node
    (full trace) or records where derivation hands off to construction/claim.
    Returns {depth, terminates_at, stratum, handoff_edge, path}.
    """
    d = BY_NAME[name]
    best = None
    stack = [(name, [name], None, 0)]
    while stack:
        cur, path, handoff, depth = stack.pop()
        node = BY_NAME[cur]
        if node.stratum == "PROVABLE":
            cand = {"depth": depth, "terminates_at": cur, "full_trace": handoff is None, "handoff_edge": handoff, "path": path}
            if best is None or (cand["full_trace"] and not best["full_trace"]) or (cand["full_trace"] == best["full_trace"] and depth < best["depth"]):
                best = cand
            continue
        if not node.parents:
            continue
        for p, strength in node.parents:
            h = handoff
            if strength != STRONG and h is None:
                h = f"{p}->{cur} ({strength})"
            stack.append((p, path + [p], h, depth + 1))
    if best is None:
        best = {"depth": 0, "terminates_at": None, "full_trace": False, "handoff_edge": None, "path": [name]}
    best["stratum"] = d.stratum
    best["status"] = STRATUM_STATUS[d.stratum]
    best["veracity"] = d.veracity
    return best


def edge_audit() -> list[dict]:
    rows = []
    for d in DOMAINS:
        for p, s in d.parents:
            rows.append({"child": d.name, "parent": p, "strength": s,
                         "child_stratum": d.stratum, "parent_stratum": BY_NAME[p].stratum})
    return rows


def boot_order() -> list[str]:
    """Acquisition order: parents before children (Kahn), ties by level then id."""
    order: list[str] = []
    done: set[str] = set()
    remaining = sorted(DOMAINS, key=lambda d: (d.level, d.id))
    while remaining:
        progressed = False
        for d in list(remaining):
            if all(p in done for p, _ in d.parents):
                order.append(d.name)
                done.add(d.name)
                remaining.remove(d)
                progressed = True
        if not progressed:
            raise RuntimeError("cycle in tower")
    return order


# --------------------------------------------------------------------------
# routing: text -> domain scores (lexicon prior; the learned router lives in the model)
# --------------------------------------------------------------------------
_WORD = re.compile(r"[a-z][a-z0-9_]+")


def route_text(text: str, top: int = 3) -> list[tuple[str, float]]:
    low = text.lower()
    toks = _WORD.findall(low)
    n = max(len(toks), 1)
    scores: dict[str, float] = {}
    for d in DOMAINS:
        s = 0.0
        for kw in d.lexicon:
            if " " in kw:
                c = low.count(kw)
            else:
                c = sum(1 for t in toks if t.startswith(kw))
            if c:
                s += (1.0 + math.log(c)) / (1.0 + 0.15 * len(d.lexicon))
        if s > 0:
            scores[d.name] = s / math.sqrt(n) * 10.0
    ranked = sorted(scores.items(), key=lambda kv: -kv[1])[:top]
    if not ranked:
        return [("language", 0.0)]
    return ranked


def route_domain(text: str) -> str:
    return route_text(text, 1)[0][0]


def tower_json() -> dict:
    return {"domains": [{"id": d.id, "name": d.name, "level": d.level, "stratum": d.stratum, "veracity": d.veracity,
                         "parents": d.parents, "registers": d.registers, "gauges": d.gauges, "operations": d.operations,
                         "actg": d.actg, "truth_regime": d.truth_regime, "description": d.description} for d in DOMAINS],
            "service": SERVICE_DOMAINS, "boot_order": boot_order()}


def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("tower")
    chk("27 tower domains", len(DOMAINS) == 27 and len(BY_NAME) == 27)
    chk("root is logic, math under logic", BY_NAME["math"].parents == [("logic", STRONG)] and BY_NAME["logic"].parents == [])
    bo = boot_order()
    chk("boot order: parents first", all(bo.index(p) < bo.index(d.name) for d in DOMAINS for p, _ in d.parents), str(bo[:6]))
    chk("boot order starts logic, math, language, measurement", bo[:4] == ["logic", "math", "language", "measurement"])
    wb = walk_back("music")
    chk("music walks back to math with a full trace", wb["full_trace"] and wb["terminates_at"] == "math", str(wb["path"]))
    wm = walk_back("morality")
    chk("morality walk-back reaches math via language but is CLAIMED", wm["status"] == "CLAIMED" and wm["veracity"] == 0.4, f"{wm}")
    wo = walk_back("opinion")
    chk("opinion: handoff edge recorded (philosophy is META, edges SOFT)", wo["terminates_at"] in ("math", "logic") and wo["status"] == "CLAIMED", f"{wo['handoff_edge']}")
    chk("register inheritance physics ⊇ language+measurement", set(registers_for("physics")) >= {"T", "Q", "R", "H", "L"})
    chk("stratum can never exceed weakest parent (music CONSTRUCTED under art CONSTRUCTED)", BY_NAME["music"].stratum == "CONSTRUCTED")
    r = route_text("why does a major chord sound sad? the harmonic ratio of the interval")
    chk("router: chord/harmonic -> music", r[0][0] == "music", str(r))
    chk("router: kinetic energy -> physics", route_domain("the kinetic energy of a 2 kg mass moving at 3 m/s") == "physics")
    chk("router: default language", route_domain("zzz qqq") == "language")
    chk("domain ids stable", domain_id("music") == 17 and domain_name(17) == "music" and domain_id("parametric") == 200)
    chk("edge audit lists SOFT culture->morality", any(e["child"] == "morality" and e["parent"] == "culture" and e["strength"] == SOFT for e in edge_audit()))
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
