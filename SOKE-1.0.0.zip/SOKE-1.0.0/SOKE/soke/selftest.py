"""
soke.selftest — the falsifier suite: every module's executed checks, one report.

    python soke_main.py selftest            full (includes training/orchestrator runs, a few seconds)
    python soke_main.py selftest --quick    codecs, container, math, tower, tokenizer, engine, forge (~5 s)
"""
from __future__ import annotations

import inspect
import sys
import tempfile
import time
import traceback
from pathlib import Path

from .util import Check

QUICK = ["util", "rng", "frame_engine", "teeth", "sff", "gguf_rewrites", "tower", "actg_parser", "memory_engine",
         "proof_engine", "math_engine", "kernels", "ledger", "memguard", "tokenizer", "llm_engine", "behavior", "clone_battery", "forge", "forge_loop", "diagnose", "pdf_ingest", "tandem", "connectome_engine", "concept_graph", "mind_engine", "jev_engine", "improve_engine", "research_engine", "multimodel", "browse_engine", "self_improve", "model_tests", "command_router"]
FULL = QUICK + ["meta_optimizer", "model_engine", "expansion_engine", "heal_engine", "loss_engine", "orchestrator"]


def _suite_util(chk: Check) -> None:
    from .util import canonical_json, content_hash, sha256_8, crc32, human_bytes
    chk("canonical json sorts keys", canonical_json({"b": 1, "a": [1, 2]}) == '{"a":[1,2],"b":1}')
    chk("content hash stable", content_hash({"x": 1}) == content_hash({"x": 1}))
    chk("sha256_8 fits u64", 0 < sha256_8(b"abc") < 2 ** 64)
    chk("crc32 known value", crc32(b"123456789") == 0xCBF43926)
    chk("human bytes", human_bytes(1536) == "1.5 KB")


def _suite_ledger(chk: Check, tmpdir: Path) -> None:
    from .ledger import Ledger
    led = Ledger(tmpdir / "ledger" / "events.jsonl")
    led.append("MFP", "store", {"id": 1}, domain="math")
    led.append("ALM", "cycle", {"loss": 1.0}, domain="parametric")
    ok, n, bad = led.verify_chain()
    chk("ledger chain verifies", ok and n == 2)
    chk("dual index by protocol and domain", len(led.by_protocol("ALM")) == 1 and len(led.by_domain("math")) == 1)
    raw = led.path.read_text().splitlines()
    raw[0] = raw[0].replace('"id": 1', '"id": 2')
    led.path.write_text("\n".join(raw) + "\n")
    led2 = Ledger(tmpdir / "ledger" / "events.jsonl")
    ok2, n2, bad2 = led2.verify_chain()
    chk("tampered record breaks the chain at seq 0", not ok2 and bad2 == 0)


def _suite_memguard(chk: Check) -> None:
    from .memguard import MemGuard, rss_bytes, MemoryBudgetExceeded, rss_route
    r = rss_bytes()
    chk("rss measurable", r > 0, f"route={rss_route()} rss={r / 2 ** 20:.0f} MB")
    mg = MemGuard(soft_mb=1, hard_mb=1)
    try:
        mg.check("test")
        chk("hard cap trips", False)
    except MemoryBudgetExceeded:
        chk("hard cap trips", mg.trips == 1)
    mg2 = MemGuard(soft_mb=768, hard_mb=900)
    chk("chunk size shrinks toward the soft cap", 1 << 20 <= mg2.chunk_bytes() <= 16 << 20)


def run(quick: bool = False, verbose: bool = True, out=sys.stdout) -> tuple[bool, dict]:
    tmpdir = Path(tempfile.mkdtemp(prefix="soke_selftest_"))
    names = QUICK if quick else FULL
    total = Check("SOKE")
    per: dict[str, tuple[int, int, float]] = {}
    crashes: list[tuple[str, str]] = []
    t_all = time.time()
    for name in names:
        t0 = time.time()
        chk = Check(name)
        try:
            if name == "util":
                _suite_util(chk)
            elif name == "ledger":
                _suite_ledger(chk, tmpdir / "ledger_t")
            elif name == "memguard":
                _suite_memguard(chk)
            else:
                mod = __import__(f"soke.{name}", fromlist=["verify_suite"])
                fn = mod.verify_suite
                # pass the scratch directory only to suites that declare a `tmpdir` parameter
                # (signature-inspected: never call twice, never feed a Path into another argument)
                if "tmpdir" in inspect.signature(fn).parameters:
                    (tmpdir / name).mkdir(parents=True, exist_ok=True)
                    fn(chk, tmpdir=tmpdir / name)
                else:
                    fn(chk)
        except Exception as e:  # a crash is a failure with the traceback as its artifact
            chk(f"{name} suite crashed", False, f"{type(e).__name__}: {e}")
            crashes.append((name, traceback.format_exc()))
            if verbose:
                print("  " + traceback.format_exc().strip().replace("\n", "\n  "), file=out)
        dt = time.time() - t0
        per[name] = (chk.passed, chk.total, dt)
        if verbose:
            print(f"--- {name} ({dt:.1f}s)", file=out)
            print(chk.report(), file=out)
        for ok, n, d in chk.rows:
            total.rows.append((ok, f"{name}: {n}", d))
    # environment guard: the program must run wherever `import numpy` succeeds — SOKE never imports the
    # lazily-loaded numpy.random / numpy.fft packages (their own compiled .pyd files were blocked by a
    # Windows Application Control policy on an operator machine while numpy's core loaded fine)
    env = Check("environment")
    lazy = [m for m in ("numpy.random", "numpy.fft") if m in sys.modules]
    env("numpy.random / numpy.fft never imported", not lazy, f"imported: {lazy}" if lazy else "numpy core (+ its eager linalg) only")
    if verbose:
        import numpy as _np
        print(f"--- environment (numpy {_np.__version__}, python {sys.version.split()[0]}, {sys.platform})", file=out)
        print(env.report(), file=out)
    per["environment"] = (env.passed, env.total, 0.0)
    for ok, n, d in env.rows:
        total.rows.append((ok, f"environment: {n}", d))
    summary = {"passed": total.passed, "total": total.total, "ok": total.ok, "elapsed_s": round(time.time() - t_all, 1),
               "crashes": [c[0] for c in crashes],
               "per_suite": {k: {"passed": v[0], "total": v[1], "s": round(v[2], 1)} for k, v in per.items()}}
    print(f"\nSOKE selftest: {total.passed}/{total.total} PASS in {summary['elapsed_s']}s "
          f"({'ALL PASS' if total.ok else 'FAILURES: ' + ', '.join(n for ok, n, _ in total.rows if not ok)})", file=out)
    return total.ok, summary


if __name__ == "__main__":
    ok, _ = run(quick="--quick" in sys.argv)
    sys.exit(0 if ok else 1)
