"""
soke.pdf_ingest — read text out of PDFs and ebooks with the standard library only (zlib for FlateDecode,
zipfile for epub). Best-effort: it recovers the text of PDFs that use ordinary fonts and literal/hex string
operators (most LaTeX, Word-exported and born-digital PDFs). It does NOT do OCR, so a scanned/image-only PDF
yields little or nothing — that is reported honestly, not faked.

Used two ways: `iter_file_text` (in memory_engine) routes .pdf/.epub/.htm through here so probes and the
knowledge tower can read books, and the Knowledge tab's "Ingest books" builds a knowledge + behavior summary
from a folder of them.
"""
from __future__ import annotations

import html
import re
import zlib
from pathlib import Path

BOOK_SUFFIXES = {".pdf", ".epub", ".htm", ".html", ".xhtml"}


# --------------------------------------------------------------------------
# PDF
# --------------------------------------------------------------------------
_LIT_ESC = {"n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f", "(": "(", ")": ")", "\\": "\\"}


def _decode_literal(b: bytes) -> str:
    """Decode a PDF literal string body (between the parens), handling escapes and octal codes."""
    out = []
    i, n = 0, len(b)
    while i < n:
        c = b[i]
        if c == 0x5C and i + 1 < n:                       # backslash
            nxt = chr(b[i + 1])
            if nxt in _LIT_ESC:
                out.append(_LIT_ESC[nxt]); i += 2; continue
            if nxt == "\n":                               # line continuation
                i += 2; continue
            if nxt.isdigit():                             # up to 3 octal digits
                j = i + 1; oct_ = ""
                while j < n and len(oct_) < 3 and chr(b[j]).isdigit():
                    oct_ += chr(b[j]); j += 1
                try:
                    out.append(chr(int(oct_, 8)))
                except ValueError:
                    pass
                i = j; continue
            out.append(nxt); i += 2; continue
        out.append(chr(c)); i += 1
    return "".join(out)


def _decode_hex(b: bytes) -> str:
    h = re.sub(rb"[^0-9A-Fa-f]", b"", b)
    if len(h) % 2:
        h += b"0"
    try:
        return bytes.fromhex(h.decode("ascii")).decode("latin-1", "replace")
    except Exception:
        return ""


def _text_from_content(content: bytes) -> str:
    """Pull text from a decoded content stream: (...)Tj, <...>Tj, [...]TJ, with spaces at big kerns / gaps."""
    out = []
    i, n = 0, len(content)
    # walk the stream, collecting string operands and emitting on Tj / TJ / ' / "
    pending = []                                          # list of (text, is_array_end)
    while i < n:
        c = content[i]
        if c == 0x28:                                     # '(' literal string
            depth, j = 1, i + 1
            body = bytearray()
            while j < n and depth:
                cj = content[j]
                if cj == 0x5C:
                    body += content[j:j + 2]; j += 2; continue
                if cj == 0x28:
                    depth += 1
                elif cj == 0x29:
                    depth -= 1
                    if depth == 0:
                        break
                body.append(cj); j += 1
            pending.append(_decode_literal(bytes(body)))
            i = j + 1; continue
        if c == 0x3C and i + 1 < n and content[i + 1] != 0x3C:   # '<' hex string (not '<<')
            j = content.find(b">", i + 1)
            if j == -1:
                break
            pending.append(_decode_hex(content[i + 1:j])); i = j + 1; continue
        if c == 0x5D:                                     # ']' end of TJ array -> a number gap ~ a space
            pending.append(" "); i += 1; continue
        # operators
        if content[i:i + 2] == b"Tj" or content[i:i + 2] == b"TJ":
            if pending:
                out.append("".join(pending)); pending = []
            out.append(" ")
            i += 2; continue
        if c in (0x27, 0x22):                             # ' and " move to next line then show
            if pending:
                out.append("".join(pending)); pending = []
            out.append("\n"); i += 1; continue
        if content[i:i + 2] in (b"Td", b"TD", b"T*"):     # line moves -> newline
            out.append("\n"); i += 2; continue
        i += 1
    return "".join(out)


def _pdf_streams(data: bytes):
    """Yield decoded (inflated where FlateDecode) content of every stream object."""
    pos = 0
    while True:
        s = data.find(b"stream", pos)
        if s == -1:
            return
        header = data[max(0, s - 400):s]
        e = data.find(b"endstream", s)
        if e == -1:
            return
        body_start = s + 6
        if data[body_start:body_start + 2] == b"\r\n":
            body_start += 2
        elif data[body_start:body_start + 1] in (b"\n", b"\r"):
            body_start += 1
        raw = data[body_start:e]
        pos = e + 9
        if b"/Image" in header or b"/DCTDecode" in header or b"/JPXDecode" in header:
            continue                                      # an image XObject, not text
        flate = b"/FlateDecode" in header or b"/Fl " in header
        if flate:
            try:
                raw = zlib.decompress(raw)
            except Exception:
                try:
                    raw = zlib.decompressobj().decompress(raw)
                except Exception:
                    continue
        elif b"/Filter" in header:
            continue                                      # some other filter we don't handle
        yield raw


def pdf_to_text(path, max_bytes: int = 300 * 1024 * 1024) -> str:
    data = Path(path).read_bytes()[:max_bytes]
    if not data.startswith(b"%PDF"):
        raise ValueError("not a PDF")
    parts = []
    for content in _pdf_streams(data):
        if b"BT" in content and (b"Tj" in content or b"TJ" in content):
            parts.append(_text_from_content(content))
        elif b"Tj" in content or b"TJ" in content:
            parts.append(_text_from_content(content))
    text = "\n".join(p for p in parts if p.strip())
    return _tidy(text)


# --------------------------------------------------------------------------
# epub / html
# --------------------------------------------------------------------------
def _strip_html(s: str) -> str:
    s = re.sub(r"(?is)<(script|style).*?</\1>", " ", s)
    s = re.sub(r"(?is)<br\s*/?>", "\n", s)
    s = re.sub(r"(?is)</(p|div|h[1-6]|li)>", "\n", s)
    s = re.sub(r"(?s)<[^>]+>", " ", s)
    return html.unescape(s)


def epub_to_text(path) -> str:
    import zipfile
    out = []
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if n.lower().endswith((".xhtml", ".html", ".htm"))]
        for n in names:
            try:
                out.append(_strip_html(z.read(n).decode("utf-8", "replace")))
            except Exception:
                continue
    return _tidy("\n".join(out))


def html_to_text(path) -> str:
    return _tidy(_strip_html(Path(path).read_text(encoding="utf-8", errors="replace")))


def _tidy(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def book_to_text(path) -> str:
    p = Path(path); suf = p.suffix.lower()
    if suf == ".pdf":
        return pdf_to_text(p)
    if suf == ".epub":
        return epub_to_text(p)
    if suf in (".htm", ".html", ".xhtml"):
        return html_to_text(p)
    raise ValueError(f"not a supported book: {suf}")


def iter_book_text(path, chunk_bytes: int = 64 * 1024):
    text = book_to_text(path)
    for i in range(0, len(text), chunk_bytes):
        yield text[i:i + chunk_bytes]


# --------------------------------------------------------------------------
# a tiny valid PDF for the self-test
# --------------------------------------------------------------------------
def _make_test_pdf(path, text: str = "Hello SOKE the theorem proves 2+2=4") -> Path:
    content = f"BT /F1 12 Tf 72 720 Td ({text}) Tj ET".encode("latin-1")
    comp = zlib.compress(content)
    objs = []
    objs.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objs.append(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
    objs.append(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>")
    objs.append(b"<< /Length %d /Filter /FlateDecode >>\nstream\n" % len(comp) + comp + b"\nendstream")
    objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    out = bytearray(b"%PDF-1.4\n")
    offs = []
    for i, o in enumerate(objs, 1):
        offs.append(len(out))
        out += b"%d 0 obj\n" % i + o + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n" % (len(objs) + 1) + b"0000000000 65535 f \n"
    for off in offs:
        out += b"%010d 00000 n \n" % off
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF" % (len(objs) + 1, xref)
    Path(path).write_bytes(bytes(out))
    return Path(path)


def verify_suite(chk=None, tmpdir=None):
    import tempfile
    from .util import Check
    chk = chk or Check("pdf_ingest")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_pdf_"))
    p = _make_test_pdf(tmpdir / "t.pdf")
    txt = pdf_to_text(p)
    chk("FlateDecode PDF text is recovered", "Hello SOKE" in txt and "theorem" in txt, repr(txt[:80]))
    chk("book_to_text dispatches on .pdf", "SOKE" in book_to_text(p))
    # html
    (tmpdir / "b.html").write_text("<html><body><h1>Title</h1><p>math &amp; science</p><script>x=1</script></body></html>")
    h = html_to_text(tmpdir / "b.html")
    chk("html stripped, entities decoded, script dropped", "math & science" in h and "x=1" not in h, repr(h))
    # epub
    import zipfile
    ep = tmpdir / "b.epub"
    with zipfile.ZipFile(ep, "w") as z:
        z.writestr("a.xhtml", "<html><body><p>philosophy of art</p></body></html>")
    chk("epub xhtml text recovered", "philosophy of art" in epub_to_text(ep))
    # a non-text (image-only) stream yields little, and that is not a crash
    chk("image-only content does not crash and returns a string", isinstance(pdf_to_text(_make_test_pdf(tmpdir / "t2.pdf", "x")), str))
    return chk


if __name__ == "__main__":
    print("\n".join(verify_suite().lines()))
