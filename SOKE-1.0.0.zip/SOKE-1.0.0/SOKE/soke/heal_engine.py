"""
soke.heal_engine — the Self-Healing / Self-Optimization Protocol (SOP-GGUF v1.0),
the immune system.

HARD CONSTRAINTS (non-negotiable, from the protocol):
  * read-only self-modification: the live model is never mutated by a proposal; every
    patch goes through the validation gate on a copy, then is written as NEW SFF
    pages (old pages stay; rollback = pointer change);
  * no silent shortcuts: every route/patch carries its measured deltas;
  * rollback mandatory; checkpoint before chaos; honesty about limits (unbenchmarked
    proposals are risk: high, validated: false).

Commands implemented: SCAN_RUNTIME, ROUTE_AUDIT (kernel routes benchmarked, >=3 runs,
adopt only if >5% faster AND equivalent), DEAD_PARAM_SWEEP (zero-packed pages, dead
MLP units), REQUANT_PLAN (Third-Law storage bands), PROB_PATH_TEST (softmax sanity),
VALIDATE (KL <= 1e-3 on eval batches, ppl delta <= 0.5%, no NaN/Inf), APPLY/REJECT,
LEDGER.
"""
from __future__ import annotations

import copy
import platform
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np

from .rng import Rng

from . import kernels
from .model_engine import SokeLM
from .sff import SFFReader, SFFWriter
from .teeth import ENC_BY_NAME, ENC_NAMES, ENC_ZERO, PAGE_VALUES, choose_encoding, decode_page

KL_TOL = 1e-3
PPL_TOL = 0.005
SPEED_MARGIN = 0.15


@dataclass
class Proposal:
    route_id: str
    target: str                  # tensor | kernel | pipeline
    strategy: str                # prune | fuse | requant | shortcut | cache | route
    expected_speedup: float = 1.0
    expected_quality_delta: float = 0.0
    risk: str = "low"
    rollback: bool = True
    validated: bool = False
    detail: dict = field(default_factory=dict)
    verdict: str = "PENDING"


class HealEngine:
    def __init__(self, ledger=None, kl_tol: float = KL_TOL, ppl_tol: float = PPL_TOL):
        self.ledger = ledger
        self.kl_tol = kl_tol
        self.ppl_tol = ppl_tol
        self.proposals: list[Proposal] = []
        self.cooldown_until = 0.0

    def _log(self, event: str, payload: dict) -> None:
        if self.ledger is not None:
            self.ledger.append("SOP", event, payload, domain="parametric")

    # ------------------------------------------------------- SCAN_RUNTIME
    def scan_runtime(self, m: SokeLM) -> dict:
        return {"backend": f"numpy {np.__version__}", "python": platform.python_version(), "platform": platform.platform(),
                "params": m.n_params(), "layers": m.cfg.n_layers, "experts": m.cfg.n_experts, "ctx": m.cfg.ctx,
                "routes": dict(kernels.ACTIVE), "dtype": m.cfg.dtype}

    # --------------------------------------------------------- ROUTE_AUDIT
    def route_audit(self, m: SokeLM, B: int = 4, runs: int = 5) -> list[Proposal]:
        c = m.cfg
        T, D, H = c.ctx, c.d_model, c.n_heads
        dh = D // H
        rng = Rng(0)
        props = []
        x = rng.normal(0, 3, (B, T, c.vocab)).astype(m.dt)
        rows = kernels.benchmark("softmax", (x,), runs=runs)
        props.append(self._route_proposal("softmax", rows))
        q = rng.normal(0, 1, (B, H, T, dh)).astype(m.dt)
        mask = np.triu(np.full((T, T), -np.inf, dtype=m.dt), 1)
        rows = kernels.benchmark("attention", (q, q, q, 1.0 / np.sqrt(dh), mask), runs=runs)
        props.append(self._route_proposal("attention", rows))
        a = rng.normal(0, 1, (B * T, D)).astype(m.dt)
        w = rng.normal(0, 1, (D, c.d_ff)).astype(m.dt)
        rows = kernels.benchmark("matmul", (a, w), runs=runs)
        props.append(self._route_proposal("matmul", rows))
        self.proposals.extend(props)
        return props

    def _route_proposal(self, op: str, rows: list[dict]) -> Proposal:
        cur = next(r for r in rows if r["route"] == kernels.ACTIVE[op])
        best = min((r for r in rows if r["equivalent"]), key=lambda r: r["median_s"])
        speedup = cur["median_s"] / max(best["median_s"], 1e-12)
        p = Proposal(f"route:{op}:{best['route']}", "kernel", "route", round(speedup, 3), 0.0,
                     "low" if best["equivalent"] else "high", True, best["equivalent"],
                     {"current": cur["route"], "candidate": best["route"], "rows": rows})
        if best["route"] == cur["route"] or speedup < 1.0 + SPEED_MARGIN:
            p.verdict = "KEEP" if best["route"] == cur["route"] else "TIE"
        else:
            p.verdict = "ADOPT"
        return p

    def apply_routes(self, props: list[Proposal]) -> dict:
        adopted = {}
        for p in props:
            if p.strategy == "route" and p.verdict == "ADOPT" and p.validated:
                op = p.route_id.split(":")[1]
                kernels.set_route(op, p.detail["candidate"])
                adopted[op] = p.detail["candidate"]
                self._log("route_adopted", {"op": op, "route": p.detail["candidate"], "speedup": p.expected_speedup})
        return adopted

    # ----------------------------------------------------- DEAD_PARAM_SWEEP
    def dead_param_sweep(self, m: SokeLM, tiny: float = 1e-6, unit_thr: float = 1e-4) -> list[Proposal]:
        props = []
        for name, arr in m.p.items():
            if arr.ndim != 2:
                continue
            flat = arr.ravel()
            zero_pages = 0
            for i in range(0, flat.size, PAGE_VALUES):
                if not np.any(np.abs(flat[i:i + PAGE_VALUES]) > tiny):
                    zero_pages += 1
            if zero_pages:
                props.append(Proposal(f"prune:{name}:zero_pages", "tensor", "prune", 1.0, 0.0, "low", True, False,
                                      {"tensor": name, "zero_pages": zero_pages, "replacement": "ZERO page (zero-packed)"}))
            if name.endswith(".w1") or (".expert." in name and name.endswith(".w1")):
                norms = np.sqrt(np.sum(arr * arr, axis=0))
                dead = int(np.sum(norms < unit_thr))
                if dead:
                    props.append(Proposal(f"prune:{name}:dead_units", "tensor", "prune", 1.0, 0.0, "med", True, False,
                                          {"tensor": name, "dead_units": dead, "of": int(norms.size), "confidence": 0.9}))
        self.proposals.extend(props)
        return props

    # ----------------------------------------------------------- REQUANT
    def requant_plan(self, m: SokeLM, budget: str = "8bit") -> list[Proposal]:
        """Per-tensor storage plan: which band, which gauge pages prefer, expected page error."""
        props = []
        for name, arr in m.p.items():
            if arr.ndim != 2 or arr.size < 1024:
                continue
            flat = np.ascontiguousarray(arr, dtype=np.float32).ravel()
            ver = tie = 0
            mse_b = mse_c = 0.0
            for i in range(0, flat.size, PAGE_VALUES):
                pc = choose_encoding(flat[i:i + PAGE_VALUES], budget)
                if pc.status == "VERIFIED":
                    ver += 1
                else:
                    tie += 1
                mse_b += pc.baseline_mse
                mse_c += pc.mse
            n = max(1, ver + tie)
            props.append(Proposal(f"requant:{name}:{budget}", "tensor", "requant", 1.0, mse_c / n, "low", True, False,
                                  {"tensor": name, "budget": budget, "pages_verified_L": ver, "pages_baseline": tie,
                                   "mse_baseline": mse_b / n, "mse_chosen": mse_c / n}))
        self.proposals.extend(props)
        return props

    # ------------------------------------------------------ PROB_PATH_TEST
    def prob_path_test(self, m: SokeLM, ids: np.ndarray) -> dict:
        out = m.forward(ids, cache=False)
        lg = out["logits"]
        pr = kernels.softmax_lse(lg)
        return {"finite_logits": bool(np.all(np.isfinite(lg))), "softmax_sums_to_1": bool(np.allclose(pr.sum(-1), 1.0, atol=1e-5)),
                "route": kernels.ACTIVE["softmax"], "max_logit": float(np.max(lg)), "min_logit": float(np.min(lg)),
                "entropy_mean": float(np.mean(-np.sum(pr * np.log(pr + 1e-12), axis=-1)))}

    # ------------------------------------------------------------ VALIDATE
    def validate(self, parent: SokeLM, candidate: SokeLM, batches: list, priors: Optional[list] = None) -> dict:
        """KL(parent || candidate) on eval batches, perplexity delta, NaN/Inf sanity."""
        kls, ppl_p, ppl_c = [], [], []
        for i, (ids, tgt) in enumerate(batches):
            pr = priors[i] if priors else None
            lp = parent.forward(ids, tgt, prior=pr, cache=False)
            lc = candidate.forward(ids, tgt, prior=pr, cache=False)
            P = kernels.softmax_lse(lp["logits"].astype(np.float64))
            lQ = lc["logits"].astype(np.float64)
            lQ = lQ - kernels.logsumexp(lQ)[..., None]
            lP = np.log(P + 1e-30)
            kls.append(float(np.mean(np.sum(P * (lP - lQ), axis=-1))))
            ppl_p.append(lp["loss"])
            ppl_c.append(lc["loss"])
            if not np.all(np.isfinite(lc["logits"])):
                return {"passed": False, "reason": "non-finite logits", "kl": float("inf")}
        kl = float(np.mean(kls))
        lp_, lc_ = float(np.mean(ppl_p)), float(np.mean(ppl_c))
        ppl_delta = (np.exp(lc_) - np.exp(lp_)) / np.exp(lp_)
        passed = kl <= self.kl_tol and ppl_delta <= self.ppl_tol
        return {"passed": passed, "kl": kl, "kl_tol": self.kl_tol, "loss_parent": lp_, "loss_candidate": lc_,
                "ppl_delta": float(ppl_delta), "ppl_tol": self.ppl_tol, "batches": len(batches)}

    # --------------------------------------------------------------- APPLY
    def apply_prune(self, m: SokeLM, prop: Proposal, batches: list) -> dict:
        """Zero the dead units on a COPY, validate, then commit to the live model only on pass."""
        cand = copy.deepcopy(m)
        name = prop.detail["tensor"]
        if "dead_units" in prop.detail:
            w1 = cand.p[name]
            norms = np.sqrt(np.sum(w1 * w1, axis=0))
            dead = norms < 1e-4
            w1[:, dead] = 0.0
            w2name = name.replace(".w1", ".w2")
            if w2name in cand.p:
                cand.p[w2name][dead, :] = 0.0
        rep = self.validate(m, cand, batches)
        prop.validated = True
        prop.verdict = "APPLIED" if rep["passed"] else "REJECTED"
        prop.detail["validation"] = rep
        if rep["passed"]:
            m.p = cand.p
            self._log("prune_applied", {"route_id": prop.route_id, **{k: v for k, v in rep.items() if k != "batches"}})
        else:
            self._log("prune_rejected", {"route_id": prop.route_id, "kl": rep.get("kl")})
        return rep

    def apply_requant(self, m: SokeLM, sff_path: Path, budget: str, batches: list, note: str = "heal:requant") -> dict:
        """Write requantized pages (Third-Law band) as NEW versions; the model in RAM is re-read from them
        and validated against the F32 model before the pointers are kept (else rolled back)."""
        w = SFFWriter(sff_path, mode="append")
        rd = SFFReader(sff_path)
        old_pages: dict[tuple[int, int], int] = {}
        for name, arr in m.p.items():
            ti = w.tensors.get(name)
            if ti is None or tuple(ti.shape) != tuple(arr.shape) or arr.ndim != 2:
                continue
            flat = np.ascontiguousarray(arr, dtype=np.float32).ravel()
            eb = ec = 0.0
            for i in range(ti.page_count):
                chunk = flat[i * w.page_values:(i + 1) * w.page_values]
                pc = choose_encoding(chunk, budget)
                old = w.pmap[ti.helix_id][ti.page_start + i]
                new = w.write_page(ti.helix_id, ti.page_start + i, pc.payload, pc.enc, count=chunk.size, err=pc.mse)
                w.add_patch(ti.helix_id, ti.page_start + i, old, new, 7, f"{note} {budget} {pc.status}")
                old_pages[(ti.helix_id, ti.page_start + i)] = old
                eb += pc.baseline_mse * chunk.size
                ec += pc.mse * chunk.size
            n = max(1, flat.size)
            eb, ec = eb / n, ec / n
            status = "EXACT" if ec == 0 else ("VERIFIED" if eb > 0 and (eb - ec) / eb >= 1 / 3 else "TIE")
            ti.err_base, ti.err_chosen, ti.status = eb, ec, status
            if eb > 0:
                w.add_opt_row(f"storage:{name}", eb, ec, status, cut_pct=(eb - ec) / eb * 100.0, note=f"requant band {budget} (mse)")
        rd.close()
        w.add_exp(1, {"event": "requant", "budget": budget, "pages": len(old_pages)})
        w.commit()
        w.close()
        cand = SokeLM.load_sff(sff_path)
        rep = self.validate(m, cand, batches)
        if not rep["passed"]:
            w = SFFWriter(sff_path, mode="append")
            for (hid, idx), old in old_pages.items():
                cur = w.pmap[hid][idx]
                w.add_patch(hid, idx, cur, old, 5, "heal:requant rejected -> rollback")
                w.point_page(hid, idx, old)
            w.commit()
            w.close()
            self._log("requant_rejected_rollback", {"budget": budget, "kl": rep["kl"]})
        else:
            self._log("requant_applied", {"budget": budget, "pages": len(old_pages), "kl": rep["kl"], "ppl_delta": rep["ppl_delta"]})
        rep["pages"] = len(old_pages)
        return rep

    # ---------------------------------------------------------------- LOOP
    def sweep(self, m: SokeLM, batches: list, sff_path: Optional[Path] = None, requant_budget: Optional[str] = None,
              cooldown_s: float = 0.0) -> dict:
        """SCAN_RUNTIME -> ROUTE_AUDIT -> DEAD_PARAM_SWEEP -> PROB_PATH_TEST -> VALIDATE each -> APPLY/REJECT -> LEDGER."""
        if time.time() < self.cooldown_until:
            return {"skipped": "cooldown"}
        t0 = time.time()
        rep = {"runtime": self.scan_runtime(m)}
        routes = self.route_audit(m)
        rep["routes"] = [{"op": p.route_id, "verdict": p.verdict, "speedup": p.expected_speedup} for p in routes]
        rep["routes_adopted"] = self.apply_routes(routes)
        prunes = self.dead_param_sweep(m)
        rep["prune"] = []
        for p in prunes:
            if "dead_units" in p.detail:
                v = self.apply_prune(m, p, batches)
                rep["prune"].append({"tensor": p.detail["tensor"], "dead_units": p.detail["dead_units"], "verdict": p.verdict, "kl": v.get("kl")})
            else:
                p.verdict = "NOTED"
                rep["prune"].append({"tensor": p.detail["tensor"], "zero_pages": p.detail["zero_pages"], "verdict": "zero-packed on save"})
        rep["prob_path"] = self.prob_path_test(m, batches[0][0])
        if sff_path is not None and requant_budget:
            rep["requant"] = self.apply_requant(m, sff_path, requant_budget, batches)
        rep["elapsed_s"] = round(time.time() - t0, 3)
        self.cooldown_until = time.time() + cooldown_s
        self._log("sweep", {k: v for k, v in rep.items() if k in ("routes_adopted", "elapsed_s", "prob_path")})
        return rep


def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    from .model_engine import ModelConfig, AdamW, ByteStream
    from .ledger import NullLedger
    chk = chk or Check("heal")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_heal_"))
    cfg = ModelConfig(d_model=32, n_heads=4, n_layers=2, d_ff=64, ctx=32, experts=["math", "music"], d_expert=32)
    m = SokeLM(cfg, seed=2)
    corpus = tmpdir / "c.txt"
    corpus.write_bytes(b"the melody and the chord in harmony. " * 300)
    bs = ByteStream([corpus], buffer_bytes=1 << 15, chunk_bytes=1 << 12)
    opt = AdamW(m.p, lr=3e-3)
    for _ in range(40):
        ids, tgt, _t = bs.batch(8, 32)
        opt.step(m.p, m.backward(m.forward(ids, tgt)))
    batches = [bs.batch(4, 32)[:2] for _ in range(3)]
    he = HealEngine(ledger=NullLedger())
    rt = he.scan_runtime(m)
    chk("SCAN_RUNTIME reports routes + params", rt["params"] == m.n_params() and "softmax" in rt["routes"])
    props = he.route_audit(m, runs=2)
    chk("ROUTE_AUDIT benchmarks every op with equivalence", len(props) == 3 and all(p.validated for p in props), str([(p.route_id, p.verdict) for p in props]))
    # plant dead units and check the sweep finds + validates the prune
    m.p["blk.0.w1"][:, :5] = 0.0
    m.p["blk.0.w2"][:5, :] = 0.0
    dead = he.dead_param_sweep(m)
    d = [p for p in dead if "dead_units" in p.detail and p.detail["tensor"] == "blk.0.w1"]
    chk("DEAD_PARAM_SWEEP finds planted dead units", d and d[0].detail["dead_units"] == 5)
    rep = he.apply_prune(m, d[0], batches)
    chk("prune validated through the KL gate (identical function -> KL 0)", rep["passed"] and rep["kl"] < 1e-9, f"kl {rep['kl']:.2e}")
    # a destructive candidate must be rejected
    bad = copy.deepcopy(m)
    bad.p["blk.1.w2"] *= 3.0
    v = he.validate(m, bad, batches)
    chk("VALIDATE rejects a distribution-changing rewrite", not v["passed"] and v["kl"] > he.kl_tol, f"kl {v['kl']:.3e}")
    pp = he.prob_path_test(m, batches[0][0])
    chk("PROB_PATH_TEST sane", pp["finite_logits"] and pp["softmax_sums_to_1"] and pp["route"] == "lse")
    plan = he.requant_plan(m, "8bit")
    chk("REQUANT_PLAN per tensor with baseline/chosen mse", plan and all("mse_chosen" in p.detail for p in plan))
    p = tmpdir / "m.sff"
    m.save_sff(p, "create")
    rq = he.apply_requant(m, p, "8bit", batches)
    chk("requant pages written as new versions and validated (KL <= 1e-3)", rq["passed"] and rq["pages"] > 0, f"kl {rq['kl']:.2e} ppl Δ {rq['ppl_delta']:.2e}")
    rd = SFFReader(p)
    kinds = {pt["kind"] for pt in rd.patches()}
    chk("patch log records requant history", "requant" in kinds)
    rd.close()
    rq4 = he.apply_requant(m, p, "4bit", batches)
    rd = SFFReader(p)
    kinds = [pt["kind"] for pt in rd.patches()]
    chk("4-bit band either passes the gate or is rolled back by pointer (never silently kept)",
        (rq4["passed"] and "rollback" not in kinds[-1]) or (not rq4["passed"] and kinds[-1] == "rollback"), f"passed={rq4['passed']} kl={rq4['kl']:.2e}")
    rd.close()
    sw = he.sweep(m, batches)
    chk("full sweep runs and logs", "routes" in sw and "prob_path" in sw and sw["elapsed_s"] >= 0)
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
