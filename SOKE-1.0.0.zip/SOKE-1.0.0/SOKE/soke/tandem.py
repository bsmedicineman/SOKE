"""
soke.tandem — OPTIONAL scaffold for tandem / knowledge-tree GGUF models.

The idea (operator's, not yet fully built): instead of one big model, write several small GGUFs — one per
branch of the knowledge tree — plus a small, purely-mathematical DRIVER model that runs as an agent and
routes a prompt down the tree to the branch that should answer. Smaller files overall; each branch is
independently forgeable and fine-tunable; the math driver guides the language models beneath it.

This module DEFINES that structure (a `TandemSpec`: a driver + a tree of branch models), routes a prompt to a
branch by the knowledge tower, and can run a single branch that already has a model. The full multi-model
runtime — the driver actually orchestrating several loaded models at once, and fine-tuning their interaction —
is NOT built yet; this is the scaffold the operator asked to have present, and it says so honestly.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class Branch:
    name: str
    topics: list                       # topics that route to this branch
    model: Optional[str] = None        # a .gguf path, or None (not built yet)
    children: list = field(default_factory=list)   # nested Branch dicts

    def to_dict(self) -> dict:
        return {"name": self.name, "topics": list(self.topics), "model": self.model,
                "children": [c.to_dict() if isinstance(c, Branch) else c for c in self.children]}


class TandemSpec:
    """driver (math agent) + a tree of branch models. STRUCTURE + ROUTING only; the multi-model runtime is a stub."""

    def __init__(self, driver: Optional[dict] = None, branches: Optional[list] = None, name: str = "tandem"):
        self.name = name
        self.driver = driver or {"role": "math-driver", "model": None, "topics": ["math", "logic", "measurement"]}
        self.branches: list = branches or []

    # -- build a default tree from the knowledge tower ------------------
    @staticmethod
    def scaffold(name: str = "tandem", extra_topics: Optional[list] = None) -> "TandemSpec":
        """A default tree: a math driver over language / science / humanities branches, each with sub-branches."""
        tree = [
            Branch("language", ["language", "grammar"], children=[Branch("code", ["technology", "code"])]),
            Branch("science", ["science", "measurement"], children=[Branch("biology", ["biology"]), Branch("physics", ["physics"])]),
            Branch("humanities", ["philosophy", "religion", "art", "music", "culture"],
                   children=[Branch("art", ["art", "music"]), Branch("ethics", ["morality", "philosophy"])]),
            Branch("behavior", ["behavior", "psychology"]),
        ]
        for t in (extra_topics or []):
            tree.append(Branch(t, [t]))
        return TandemSpec(branches=tree, name=name)

    # -- routing --------------------------------------------------------
    def route(self, text: str) -> list:
        """Return the branch path (names) the driver would send this prompt to, using the knowledge tower's router."""
        try:
            from .tower import route_text
            r = route_text(text, top=1)
            topic = r[0][0] if r and r[0][1] > 0.5 else None
        except Exception:
            topic = None
        if topic is None:
            return ["driver"]
        path = self._find(self.branches, topic, [])
        return ["driver"] + path if path else ["driver"]

    def _find(self, nodes, topic, acc) -> list:
        for b in nodes:
            bb = b if isinstance(b, Branch) else Branch(**b)
            if topic in bb.topics:
                return acc + [bb.name]
            sub = self._find(bb.children, topic, acc + [bb.name])
            if sub:
                return sub
        return []

    def branch_for(self, path: list):
        """The Branch object at a routed path (path excludes the leading 'driver')."""
        nodes, node = self.branches, None
        for name in path:
            node = next((b if isinstance(b, Branch) else Branch(**b) for b in nodes if (b.name if isinstance(b, Branch) else b["name"]) == name), None)
            if node is None:
                return None
            nodes = node.children
        return node

    # -- run one branch (the only runtime piece that exists) -----------
    def run_branch(self, path: list, prompt: str, memguard=None, max_new: int = 48) -> dict:
        """Generate from the branch's model if it has one. This runs ONE model; the driver-orchestrated
        multi-model run is not built."""
        b = self.branch_for([p for p in path if p != "driver"])
        if b is None or not b.model or not Path(b.model).exists():
            return {"branch": path, "ran": False, "note": "this branch has no model yet — forge one and set its path"}
        from .llm_engine import LLM
        m = LLM(b.model, memguard=memguard, resident="stream")
        txt, info = m.generate(prompt, max_new=max_new, temperature=0.7)
        m.close()
        return {"branch": path, "ran": True, "text": txt, "info": info}

    # -- io -------------------------------------------------------------
    def describe(self) -> str:
        lines = [f"Tandem '{self.name}' — a math driver over a tree of branch models (OPTIONAL / scaffold).",
                 f"  driver: {self.driver['role']}  model={self.driver.get('model') or '(none yet)'}  topics={self.driver['topics']}"]

        def walk(nodes, depth):
            for b in nodes:
                bb = b if isinstance(b, Branch) else Branch(**b)
                lines.append("  " + "  " * depth + f"├─ {bb.name}  topics={bb.topics}  model={bb.model or '(none yet)'}")
                walk(bb.children, depth + 1)
        walk(self.branches, 1)
        built = self._count_models()
        lines.append(f"  models attached: {built} / {self._count_branches()} branches. The driver-orchestrated runtime is not built yet — "
                     "SOKE can route a prompt to a branch and run that ONE branch's gguf.")
        return "\n".join(lines)

    def _count_branches(self) -> int:
        n = [0]

        def w(nodes):
            for b in nodes:
                bb = b if isinstance(b, Branch) else Branch(**b)
                n[0] += 1; w(bb.children)
        w(self.branches)
        return n[0]

    def _count_models(self) -> int:
        n = [1 if self.driver.get("model") else 0]

        def w(nodes):
            for b in nodes:
                bb = b if isinstance(b, Branch) else Branch(**b)
                n[0] += 1 if bb.model else 0; w(bb.children)
        w(self.branches)
        return n[0]

    def to_json(self) -> str:
        return json.dumps({"name": self.name, "driver": self.driver,
                           "branches": [b.to_dict() if isinstance(b, Branch) else b for b in self.branches]}, indent=1)

    @staticmethod
    def from_json(s: str) -> "TandemSpec":
        d = json.loads(s)
        def mk(nodes):
            return [Branch(n["name"], n.get("topics", []), n.get("model"), mk(n.get("children", []))) for n in nodes]
        return TandemSpec(driver=d.get("driver"), branches=mk(d.get("branches", [])), name=d.get("name", "tandem"))


def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("tandem")
    sp = TandemSpec.scaffold("kt")
    chk("scaffold builds a driver + a branch tree", sp._count_branches() >= 6 and sp.driver["role"] == "math-driver")
    path = sp.route("prove the theorem that the integral of the derivative")
    chk("a math prompt routes to the driver (math lives on the driver)", path[0] == "driver", str(path))
    path2 = sp.route("the painting used complementary color and a soft melody")
    chk("an art prompt routes down to a humanities/art branch", "humanities" in path2 or "art" in path2, str(path2))
    r = sp.run_branch(path2, "hello")
    chk("running a branch with no model is reported honestly, not faked", r["ran"] is False and "no model yet" in r["note"])
    chk("round-trips through json", TandemSpec.from_json(sp.to_json())._count_branches() == sp._count_branches())
    chk("describe names it a scaffold and counts models", "scaffold" in sp.describe().lower() and "not built yet" in sp.describe())
    return chk


if __name__ == "__main__":
    print(TandemSpec.scaffold().describe())
    print("\n".join(verify_suite().lines()))
