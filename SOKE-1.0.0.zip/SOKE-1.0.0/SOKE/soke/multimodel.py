"""
soke.multimodel — use ANY installed model, and orchestrate several, KIMI-style.

Three pieces, all built on machinery SOKE already has:

1. Ollama surfacing — list every model Ollama has pulled so you can pick one as the advisor or as a donor,
   tagged by whether this engine can RUN it (chat) and whether the forge can HARVEST it (dense qwen2/llama).

2. KIMI wide-MoE — fuse a family of same-shape models into ONE mixture-of-experts with MANY small experts and
   a small top-k. Only the k experts a token routes to are read from disk, so capacity lives on the SSD, not in
   RAM ("smaller neurons streamed"). Different donor models seed different experts, so several models become one
   streamed model. Feed the result to soke.improve_engine.SelfImprover(start_spec=...) to tune it under the
   honest-null gate.

3. Multi-model routing — a driver routes each prompt to ONE branch model and runs just that one (streaming, so
   one model is resident at a time — friendly to the RAM budget). This makes soke.tandem.TandemSpec functional
   by attaching real model files to its branches. Simultaneous many-model execution is deliberately NOT done: it
   breaks the memory budget, and the honest scaffold already said so.

    from soke.multimodel import list_ollama_models, kimi_moe_spec, tandem_from_models
    models = list_ollama_models()                       # [{label, path, arch, runnable, status, size_mb}, ...]
    spec = kimi_moe_spec(donors, ["math","language"], n_experts=8, n_used=2)   # wide streamed MoE
    tan = tandem_from_models([{ "path": p1, "topics": ["math"] }, { "path": p2, "topics": ["language"] }])
    tan.run_branch(tan.route("parse this sentence"), "hello")
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from .forge import Donor, ForgeSpec, describe_gguf, donor_status, family_groups, inventory_ollama, op_copy
from .llm_engine import SUPPORTED_ARCHS
from .tandem import Branch, TandemSpec


def _model_row(d: Donor) -> dict:
    """A pickable row for one model: what it is, whether we can run it, whether the forge can harvest it."""
    return {"id": d.id, "label": d.label, "path": d.path, "arch": d.arch,
            "n_layer": d.n_layer, "n_embd": int(d.hp.get("n_embd", 0)) if d.hp else 0,
            "size_mb": round(d.size / 2 ** 20, 1) if d.size else 0.0,
            "runnable": d.arch in SUPPORTED_ARCHS,           # can this engine CHAT with it as an advisor
            "status": donor_status(d)}                       # "ok" (harvestable) | "moe" | "arch"


def list_ollama_models(models_dir=None) -> list[dict]:
    """Every model Ollama has pulled, as pickable rows. Empty list if Ollama isn't installed / has no models."""
    try:
        return [_model_row(d) for d in inventory_ollama(models_dir)]
    except Exception:
        return []


def runnable_advisors(models_dir=None) -> list[dict]:
    """Only the Ollama models this engine can load as an advisor (a runnable architecture)."""
    return [m for m in list_ollama_models(models_dir) if m["runnable"]]


def _family(donors: list[Donor]) -> tuple[str, list[Donor]]:
    """The largest same-shape 'ok' (dense, harvestable) family among the donors."""
    groups = family_groups(donors)
    if not groups:
        raise ValueError("no harvestable dense family here — a streamed MoE needs same-shape dense qwen2 donors "
                         "(check the Donors page: models must share arch/width/depth/heads/vocab and not already be MoE)")
    sig, fam = max(groups.items(), key=lambda kv: len(kv[1]))
    return sig, fam


def kimi_moe_spec(donors: list[Donor], topics: list[str], n_experts: int = 8, n_used: int = 2,
                  base: Optional[str] = None, seed: int = 0) -> ForgeSpec:
    """Build a WIDE mixture-of-experts from a same-shape family: n_experts routed experts (>= the topic count),
    seeded round-robin from every donor in the family, with a small top-k. Served streaming, only n_used experts
    per token are read from disk. Requires a qwen2 family (llama.cpp's qwen2moe expert layout)."""
    sig, fam = _family(donors)
    if fam[0].arch not in ("qwen2", "qwen2moe"):
        raise ValueError(f"KIMI streamed MoE needs a qwen2-family donor; this family is {fam[0].arch!r}. "
                         "Dense llama donors can still be merged (Improve → tune), just not into a routed MoE here.")
    base_topics = [t for t in (topics or ["general"])] or ["general"]
    spec = ForgeSpec.preset("all-routed", fam, base_topics, base=base, n_used=max(1, min(n_used, len(base_topics))), seed=seed)
    ids = [d.id for d in fam]
    start = spec.n_expert
    add = max(0, int(n_experts) - start)
    for k in range(add):                                     # widen: append an expert to EVERY layer, cycling donors
        lbl = f"e{start + k}"
        donor = ids[k % len(ids)]
        for layer in spec.layers:
            layer["experts"].append({"topic": lbl, "op": op_copy(donor)})
    spec.d["n_used"] = max(1, min(int(n_used), spec.n_expert))
    spec.d["name"] = f"kimi-moe {spec.n_expert}x-top{spec.d['n_used']} ({len(fam)} donor{'s' if len(fam) > 1 else ''})"
    return spec


def describe_kimi(spec: ForgeSpec) -> str:
    ne, nu = spec.n_expert, int(spec.d.get("n_used", 0))
    donors = list(spec.donors)
    return (f"{spec.d.get('name', 'kimi-moe')}: {len(spec.layers)} layers, {ne} experts, top-{nu} per token "
            f"(≈{nu}/{ne} of the experts read from disk per token), donors {donors}. Serve with RAM mode 'stream'.")


def tandem_from_models(models: list[dict], name: str = "tandem", driver_topics: Optional[list] = None) -> TandemSpec:
    """A functional multi-model router: each entry {path, topics, name?} becomes a branch with a real model file.
    The driver routes a prompt to ONE branch (soke.tandem), which runs alone under streaming residency."""
    branches = []
    for i, m in enumerate(models):
        p = m["path"]
        nm = m.get("name") or Path(p).stem
        branches.append(Branch(nm, list(m.get("topics", [])), model=p))
    ts = TandemSpec(driver={"role": "math-driver", "model": None, "topics": driver_topics or ["math", "logic", "measurement"]},
                    branches=branches, name=name)
    return ts


# ==========================================================================
# self-test
# ==========================================================================
def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    import numpy as np
    from .util import Check
    from .forge import _synthetic_family, SpecStore
    from .llm_engine import LLM
    from .rng import Rng
    from .forge_loop import Probes
    chk = chk or Check("multimodel")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_mm_"))

    qwen = _synthetic_family(tmpdir / "q", 3, arch="qwen2")        # a same-shape dense qwen2 family
    llama = _synthetic_family(tmpdir / "l", 2, arch="llama")       # a llama family (not MoE-able here)

    # --- pickable rows: runnable + harvest status
    rows = [_model_row(d) for d in qwen]
    chk("model row tags a qwen2 donor as runnable + harvestable ('ok')", rows[0]["runnable"] and rows[0]["status"] == "ok", str(rows[0]))
    chk("list_ollama_models is empty when there is no Ollama store", list_ollama_models(tmpdir / "no_such_ollama") == [])

    # --- KIMI wide-MoE: many experts, small top-k, seeded from several donors, served streaming
    spec = kimi_moe_spec(qwen, ["math", "language"], n_experts=8, n_used=2, seed=1)
    chk("kimi_moe_spec builds the requested width + top-k", spec.n_expert == 8 and spec.d["n_used"] == 2 and spec.arch_out == "qwen2moe", describe_kimi(spec))
    seed_donors = {e["op"].get("donor") for e in spec.layers[0]["experts"]}
    chk("kimi experts are seeded from more than one donor (several models fused into one)", len(seed_donors) > 1, str(seed_donors))
    served = LLM(store=SpecStore(spec), )
    ok_stream = served.cfg.n_expert == 8 and served.cfg.n_expert_used == 2
    rr = served.nll_batch([[1, 2, 3, 4, 5, 6, 7, 8]])
    served.close()
    chk("kimi MoE serves streaming: 8 experts, only 2 read per token, and it runs", ok_stream and np.isfinite(rr["nll"]), f"n_expert {served.cfg.n_expert}, used {served.cfg.n_expert_used}")
    chk("kimi_moe_spec refuses a llama-only family (no routed-MoE layout)", _raises(lambda: kimi_moe_spec(llama, ["math"], n_experts=6)))

    # --- KIMI spec drives the improve loop via start_spec, and the wide MoE survives the loop scaffolding
    from .improve_engine import SelfImprover
    rng = Rng(3); V = 96
    probes = Probes(topics=["math", "language"],
                    train={t: [list(rng.integers(0, V, 24)) for _ in range(3)] for t in ["math", "language"]},
                    holdout={t: [list(rng.integers(0, V, 24)) for _ in range(2)] for t in ["math", "language"]}, n_tokens=1)
    imp = SelfImprover(qwen, ["math", "language"], probes, start_spec=spec, min_gain=1e3, priority_topic=None, seed=2)
    rep = imp.improve(rounds=1, trials_per_round=6)
    chk("start_spec: the improve loop runs on the KIMI spec and keeps its width (honest-null kept 0)",
        imp.trainer.spec.n_expert == 8 and rep["n_kept"] == 0, f"n_expert {imp.trainer.spec.n_expert}, kept {rep['n_kept']}")

    # --- multi-model routing: real models on branches; the driver routes to ONE and runs it
    tan = tandem_from_models([{"path": qwen[0].path, "topics": ["math", "measurement"], "name": "mathbox"},
                              {"path": qwen[1].path, "topics": ["language", "grammar"], "name": "langbox"}], name="mm")
    r = tan.run_branch(["driver", "langbox"], "parse this", memguard=None, max_new=4)
    chk("tandem runs the routed branch's real model (one model, streamed)", r["ran"] is True and "text" in r, str({k: r.get(k) for k in ('ran', 'branch')}))
    path = tan.route("the grammar of this language sentence and its clause structure")
    chk("tandem routes a language prompt toward the language branch (or the driver if unsure)", path[0] == "driver", str(path))
    return chk


def _raises(fn) -> bool:
    try:
        fn(); return False
    except Exception:
        return True


if __name__ == "__main__":
    print(verify_suite().report())
