"""
soke.gui_home — the SOKE Home tab: a chat console driven by a SECOND, separately-loaded gguf (the
"advisor"). It runs alongside the model being built in the other tabs, so two models are live at once:
the advisor chats and runs real SOKE routines against the target, while the target is the one being
forged / trained / behavior-tuned. The advisor is loaded in low-RAM streaming mode.

The chat is a real generation from whatever gguf you load. The action buttons and slash-commands run real
SOKE functions on the target (diagnose the build, generate probes from the imported corpus, run the behavior
questionnaire, suggest template edits, tune the import bands) and print structured results into the transcript;
the advisor can then comment on them. Nothing here pretends the base model is smarter than it is — the
intelligence is in the routines; the model narrates.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import theme as _T
from .util import human_bytes

BG = _T.PAPER; FG = _T.INK; ACC = _T.ACCENT; OK = _T.OK; WARN = _T.WARN; BAD = _T.BAD
DIM = _T.DIM; SLATE = _T.SLATE; PAPER_HI = _T.PAPER_HI; FACE = _T.FACE; MONO = _T.MONO


def _font(size=8, bold=False):
    return _T.font(size, bold)


COMMANDS = [
    ("/diagnose", "why the current build isn't improving, with fixes"),
    ("/probes [topic…]", "generate probes from the imported corpus"),
    ("/questionnaire", "run the behavior questionnaire (clone battery)"),
    ("/suggest", "suggest concrete template edits for the target"),
    ("/jev", "a JEV logic-route decision (right pillar) for the next build step — cheap, no language"),
    ("/testbehavior", "test the 4D behavior/emotion feed a built model will carry"),
    ("/testlogic", "test the JEV logic proof-state gate on sample build decisions"),
    ("/models", "list installed Ollama models (which can run as advisor / be harvested)"),
    ("/advisor <n>", "load Ollama model #n (from /models) as the advisor"),
    ("/kimi [n]", "build a KIMI wide-MoE (n experts, streamed) from the donor family and tune it — verified"),
    ("/evolve [rounds]", "one full cycle: research → build → tune → PROVE the child beats itself (A/B) → gated promote"),
    ("/research [query]", "read techniques (built-in library, or the web if online) into a bias for /improve"),
    ("/online <on|off>", "turn the research internet channel on/off — OFF by default (allow-listed, read-only)"),
    ("/browse <url>", "read ONE page (read-only, isolated, allow-listed) and pull techniques from it"),
    ("/improve", "advisor builds a more complex/efficient/tuned version — verified on hold-out, most die"),
    ("/promote [path]", "write the improved model to disk (your OK; it can't promote itself)"),
    ("/train", "start training the current template (the Forge Learn loop)"),
    ("/bands <exact|8bit|4bit>", "set the import re-band for the next conversion"),
    ("/target", "show the model being built in the other tabs"),
    ("/help", "list commands"),
]

# read-only research: when the internet channel is on, only these ML-source hosts are fetched (you can widen it).
RESEARCH_HOSTS = ["arxiv.org", "huggingface.co", "github.com", "openreview.net", "aclanthology.org",
                  "paperswithcode.com", "pytorch.org", "wikipedia.org", "ollama.com"]


class HomeTab:
    def __init__(self, app, frame: ttk.Frame):
        self.app = app
        self.f = frame
        self.advisor = None                 # a loaded LLM (the chat model), or None
        self.advisor_path: Optional[str] = None
        self.improver = None                # a soke.improve_engine.SelfImprover after /improve (awaiting /promote)
        self.research_online = False        # the research internet channel — OFF until you turn it on (/online on)
        self.research_bias = None           # op weights from the last /research, fed into the next /improve
        self._ollama = []                   # last /models listing (Ollama models), indexable by /advisor <n>
        self._cycle = None                  # a soke.self_improve.SelfImproveCycle after /evolve (WIN-gated promote)
        self.busy = False
        self._build()
        self.app.imports.subscribe(self._refresh_models)

    # ------------------------------------------------------------- layout
    def _build(self) -> None:
        f = self.f
        top = tk.Frame(f, bg=BG); top.pack(fill="x", padx=6, pady=(6, 2))
        tk.Label(top, text="Advisor model (a second gguf — chats and runs SOKE routines against the model you are building):",
                 bg=BG, fg=SLATE, font=_font(8, True)).pack(anchor="w")
        row = tk.Frame(f, bg=BG); row.pack(fill="x", padx=6)
        self.v_model = tk.StringVar()
        self.cb_model = ttk.Combobox(row, textvariable=self.v_model, width=54, state="normal")
        self.cb_model.pack(side="left")
        ttk.Button(row, text="Browse…", command=self._pick).pack(side="left", padx=3)
        self.btn_load = ttk.Button(row, text="Load advisor", style="Accent.TButton", command=self.load_advisor)
        self.btn_load.pack(side="left", padx=3)
        tk.Label(row, text="RAM mode", bg=BG, fg=DIM).pack(side="left", padx=(10, 2))
        self.v_res = tk.StringVar(value="stream")
        ttk.Combobox(row, textvariable=self.v_res, values=["stream", "q8", "f32"], width=7, state="readonly").pack(side="left")
        self.lbl_adv = tk.Label(f, text="No advisor loaded. Load any llama / qwen2 / qwen2moe .gguf (streaming keeps RAM low).",
                                bg=BG, fg=DIM, anchor="w", font=_font(8)); self.lbl_adv.pack(fill="x", padx=8, pady=(2, 4))

        body = tk.Frame(f, bg=BG); body.pack(fill="both", expand=True, padx=6, pady=2)
        # left: the transcript
        left = tk.Frame(body, bg=BG); left.pack(side="left", fill="both", expand=True)
        self.chat = tk.Text(left, wrap="word", font=_font(9), state="disabled", padx=8, pady=6)
        _T.sunken_text(self.chat)
        self.chat.pack(fill="both", expand=True)
        self.chat.tag_config("you", foreground=SLATE, font=_font(9, True))
        self.chat.tag_config("advisor", foreground=ACC, font=_font(9, True))
        self.chat.tag_config("soke", foreground=OK, font=_font(8, True))
        self.chat.tag_config("body", foreground=INK if (INK:=_T.INK) else FG)
        self.chat.tag_config("dim", foreground=DIM)
        entry = tk.Frame(left, bg=BG); entry.pack(fill="x", pady=(4, 0))
        self.v_in = tk.StringVar()
        e = ttk.Entry(entry, textvariable=self.v_in); e.pack(side="left", fill="x", expand=True)
        e.bind("<Return>", lambda _e: self.send())
        ttk.Button(entry, text="Send", style="Accent.TButton", command=self.send).pack(side="left", padx=4)
        tk.Label(entry, text="max", bg=BG, fg=DIM).pack(side="left")
        self.v_max = tk.IntVar(value=64)
        ttk.Combobox(entry, textvariable=self.v_max, values=[32, 64, 128, 256], width=4, state="readonly").pack(side="left", padx=2)
        # right: action buttons + target panel
        right = tk.Frame(body, bg=BG, width=250); right.pack(side="right", fill="y", padx=(6, 0))
        act = tk.LabelFrame(right, text=" what the advisor can do ", bg=BG, fg=SLATE, font=_font(8, True))
        act.pack(fill="x")
        for label, cmd in (("Diagnose the build", self.act_diagnose), ("Generate probes", self.act_probes),
                           ("Behavior questionnaire", self.act_questionnaire), ("Suggest template edits", self.act_suggest),
                           ("Decide (JEV logic route)", self.act_jev), ("Test behavior", self.act_testbehavior),
                           ("Test logic", self.act_testlogic), ("Ollama models", self.act_models),
                           ("Research techniques", self.act_research), ("Build KIMI wide-MoE", self.act_kimi),
                           ("Evolve (prove a better self)", self.act_evolve),
                           ("Improve → verify (advisor builds it)", self.act_improve), ("Promote improved model", self.act_promote),
                           ("Train a model", self.act_train),
                           ("Test target now", self.act_test)):
            ttk.Button(act, text=label, command=cmd).pack(fill="x", padx=4, pady=1)
        tgt = tk.LabelFrame(right, text=" the model being built (other tabs) ", bg=BG, fg=SLATE, font=_font(8, True))
        tgt.pack(fill="x", pady=(8, 0))
        self.lbl_target = tk.Label(tgt, text="", bg=BG, fg=DIM, anchor="w", justify="left", wraplength=230, font=_font(8))
        self.lbl_target.pack(fill="x", padx=4, pady=2)
        imp = tk.LabelFrame(right, text=" imported files (all tabs) ", bg=BG, fg=SLATE, font=_font(8, True))
        imp.pack(fill="both", expand=True, pady=(8, 0))
        self.lbl_imports = tk.Label(imp, text="none yet", bg=BG, fg=DIM, anchor="nw", justify="left", wraplength=230, font=_font(8))
        self.lbl_imports.pack(fill="both", expand=True, padx=4, pady=2)

        self._say("soke", "SOKE advisor console. Load a gguf above to chat, or use the buttons on the right — they run "
                          "real SOKE routines on the model you are building. Type /help for commands.")
        self._refresh_models(); self._refresh_target()

    # ------------------------------------------------------------- helpers
    def _pick(self) -> None:
        st = getattr(self.app, "forge", None)
        idir = st.settings.get("export_dir") if st and hasattr(st, "settings") else None
        p = filedialog.askopenfilename(title="Advisor gguf", initialdir=idir or None, filetypes=[("GGUF", "*.gguf"), ("All (Ollama blobs)", "*")])
        if p:
            self.v_model.set(p)

    def _refresh_models(self) -> None:
        vals = list(dict.fromkeys(self.app.imports.models))
        self.cb_model["values"] = vals
        if vals and not self.v_model.get():
            self.v_model.set(vals[0])
        n = len(self.app.imports.files)
        files = self.app.imports.files[:12]
        txt = f"{n} file(s):\n" + "\n".join("· " + Path(x).name for x in files) + ("\n…" if n > 12 else "") if n else "none yet"
        self.lbl_imports.config(text=txt)

    def _refresh_target(self) -> None:
        fg = getattr(self.app, "forge", None)
        parts = []
        if fg is not None and getattr(fg, "spec", None) is not None:
            parts.append("Forge template: " + fg.spec.summary()[:120])
            if getattr(fg, "behavior", None) is not None:
                parts.append("behavior: " + fg.behavior.name)
            if getattr(fg, "trainer", None) is not None and fg.trainer.trials:
                acc = sum(1 for t in fg.trainer.trials if t.accepted)
                parts.append(f"trials: {len(fg.trainer.trials)} ({acc} kept)")
        self.lbl_target.config(text="\n".join(parts) or "No forge template yet. Build one on the Forge tab, then ask me to diagnose or improve it.")

    def _say(self, who: str, text: str) -> None:
        self.chat.config(state="normal")
        tag = {"you": "you", "advisor": "advisor", "soke": "soke"}.get(who, "body")
        label = {"you": "you", "advisor": "advisor", "soke": "SOKE"}.get(who, who)
        self.chat.insert("end", f"{label}: ", tag)
        self.chat.insert("end", text + "\n\n", "body")
        self.chat.see("end"); self.chat.config(state="disabled")

    def _stream(self, s: str) -> None:
        self.chat.config(state="normal"); self.chat.insert("end", s, "body"); self.chat.see("end"); self.chat.config(state="disabled")

    # ------------------------------------------------------------- advisor model
    def load_advisor(self) -> None:
        p = self.v_model.get().strip()
        if not p or not Path(p).exists():
            messagebox.showinfo("SOKE", "Choose an existing .gguf for the advisor first."); return
        res = self.v_res.get()
        self.lbl_adv.config(text="loading advisor…", fg=DIM)

        def job():
            from .llm_engine import LLM
            m = LLM(p, memguard=self.app.mg, resident=res)
            return m

        def done(m):
            if self.advisor is not None:
                try:
                    self.advisor.close()
                except Exception:
                    pass
            self.advisor = m; self.advisor_path = p
            self.app.imports.add_model(p)
            cfg = m.cfg
            self.lbl_adv.config(text=f"advisor: {Path(p).name} · {cfg.arch} · {cfg.n_layer}×{cfg.n_embd} · weights {m.store.mode} · RSS {self.app.mg.status()['rss_mb']:.0f} MB", fg=OK)
            self._say("soke", f"Advisor {Path(p).name} loaded ({cfg.arch}, {m.store.mode} residency). It runs beside the model you are building; ask it anything or use the buttons.")

        def fail(e):
            from .llm_engine import UnsupportedArch
            if isinstance(e, UnsupportedArch):
                self.lbl_adv.config(text=f"can't run {e.arch!r} as an advisor — details in chat", fg=BAD)
                self._say("soke", str(e) + "\n\nTip: open the Import tab to repack/shrink it, or Inspect SFF to look inside — those work on any GGUF.")
            else:
                self.lbl_adv.config(text=f"could not load: {e}", fg=BAD)
        self.app.run_job("load advisor", job, done, on_error=fail)

    # ------------------------------------------------------------- chat
    def send(self) -> None:
        text = self.v_in.get().strip()
        if not text:
            return
        self.v_in.set("")
        if text.startswith("/"):
            self._command(text); return
        self._say("you", text)
        # 1) fast path: an obvious command routes instantly (deterministic lexicon, no model call)
        from .command_router import route_intent
        det = route_intent(text)
        if det.action != "chat":
            self._route_action(det); return
        # 2) no advisor -> can't interpret free phrasing; guide the user
        if self.advisor is None:
            self._say("soke", "No advisor loaded — load a .gguf above to chat, or just tell me what to do "
                              "(e.g. 'diagnose the build', 'build a kimi moe', 'test the logic', 'evolve and prove it')."); return
        if self.busy:
            self._say("soke", "still thinking on the last one…"); return
        self.busy = True
        mx = int(self.v_max.get())

        def job():
            # 3) let the advisor LLM interpret the phrasing into an action; else it is a genuine chat
            from .command_router import llm_classify
            it = llm_classify(self.advisor, text)
            if it.action != "chat":
                return ("action", it)
            self.app.q.put(("home", ("adv_prefix", None)))          # start the reply line, then stream tokens
            txt, info = self.advisor.generate(text, max_new=mx, temperature=0.7, chat=True,
                                              on_token=lambda s: self.app.q.put(("home", ("token", s))))
            return ("chat", txt, info)

        def done(res):
            self.busy = False
            if res[0] == "action":
                self._route_action(res[1])                          # main thread — safe to dispatch
            else:
                _, txt, info = res
                self._stream(f"\n[{info['tokens']} tok · {info.get('tok_per_s')} tok/s · {info['resident_mode']} · RSS {info['rss_mb']} MB]\n\n")

        def fail(e):
            self.busy = False
            self._say("soke", f"error: {type(e).__name__}: {e}")
        self.app.run_job("advisor chat", job, done, on_error=fail)

    def on_home_event(self, kind, payload=None) -> None:
        """queue events routed from App._poll (kind 'home')."""
        if kind == "token":
            self._stream(payload)
        elif kind == "line":
            self._say("soke", payload)
        elif kind == "adv_prefix":
            self.chat.config(state="normal"); self.chat.insert("end", "advisor: ", "advisor"); self.chat.config(state="disabled")

    def _command(self, text: str) -> None:
        parts = text.split()
        cmd = parts[0].lower()
        self._say("you", text)
        if cmd in ("/help", "/?"):
            self._say("soke", "commands:\n" + "\n".join(f"  {c:22s} {d}" for c, d in COMMANDS))
        elif cmd == "/diagnose":
            self.act_diagnose()
        elif cmd == "/probes":
            self.act_probes(topics=parts[1:] or None)
        elif cmd == "/questionnaire":
            self.act_questionnaire()
        elif cmd == "/suggest":
            self.act_suggest()
        elif cmd == "/jev":
            self.act_jev()
        elif cmd == "/testbehavior":
            self.act_testbehavior()
        elif cmd == "/testlogic":
            self.act_testlogic()
        elif cmd == "/models":
            self.act_models()
        elif cmd == "/advisor":
            self.act_use(parts[1] if len(parts) > 1 else None)
        elif cmd == "/kimi":
            self.act_kimi(parts[1] if len(parts) > 1 else None)
        elif cmd == "/evolve":
            self.act_evolve(parts[1] if len(parts) > 1 else None)
        elif cmd == "/research":
            self.act_research(" ".join(parts[1:]) or None)
        elif cmd == "/online":
            self.act_online(parts[1] if len(parts) > 1 else None)
        elif cmd == "/browse":
            self.act_browse(parts[1] if len(parts) > 1 else None)
        elif cmd == "/improve":
            self.act_improve()
        elif cmd == "/promote":
            self.act_promote(parts[1] if len(parts) > 1 else None)
        elif cmd == "/train":
            self.act_train()
        elif cmd == "/target":
            self._refresh_target(); self._say("soke", self.lbl_target.cget("text"))
        elif cmd == "/bands" and len(parts) > 1:
            self._set_bands(parts[1])
        else:
            self._say("soke", f"unknown command {cmd}. Type /help.")

    # ------------------------------------------------------------- actions (real routines)
    def _forge(self):
        return getattr(self.app, "forge", None)

    def _route_action(self, intent) -> None:
        """Dispatch a routed natural-language Intent to the matching action. Side-effectful actions keep their own
        gates (promote is consent/WIN-gated, online/browse stay allow-listed) — routing opens no new gate."""
        a, arg = intent.action, intent.arg
        echo = {"diagnose": "Diagnosing the build", "probes": "Generating probes", "suggest": "Suggesting template edits",
                "jev": "Running the JEV logic route", "models": "Listing Ollama models", "advisor": f"Loading model {arg} as the advisor",
                "kimi": "Building a KIMI wide-MoE" + (f" ({arg} experts)" if arg else ""), "evolve": "Running a self-improve cycle",
                "research": (f"Researching: {arg}" if arg else "Researching techniques"), "online": f"Turning the research internet {arg}",
                "browse": f"Reading {arg}", "improve": "Improving the target (verified)", "promote": "Promoting the improved model",
                "train": "Starting training", "testbehavior": "Testing the behavior the model will carry",
                "testlogic": "Testing the logic gate", "help": "Commands"}.get(a, "")
        if echo:
            self._say("soke", f"→ {echo}.")
        try:
            fn = {"diagnose": self.act_diagnose, "probes": self.act_probes, "suggest": self.act_suggest, "jev": self.act_jev,
                  "models": self.act_models, "advisor": lambda: self.act_use(arg), "kimi": lambda: self.act_kimi(arg),
                  "evolve": lambda: self.act_evolve(arg), "research": lambda: self.act_research(arg),
                  "online": lambda: self.act_online(arg), "browse": lambda: self.act_browse(arg), "improve": self.act_improve,
                  "promote": self.act_promote, "train": self.act_train, "testbehavior": self.act_testbehavior,
                  "testlogic": self.act_testlogic,
                  "help": lambda: self._say("soke", "commands:\n" + "\n".join(f"  {c:22s} {d}" for c, d in COMMANDS))}.get(a)
            if fn:
                fn()
        except Exception as e:
            self._say("soke", f"couldn't do that ({a}): {type(e).__name__}: {e}")

    def act_testbehavior(self) -> None:
        """Test the 4D behavior / emotional feed the built model carries: run it through a scripted situation feed
        and show it move, return to baseline, and be rewarded/taxed in tokens."""
        fg = self._forge()
        beh = getattr(fg, "behavior", None) if fg else None
        try:
            from .model_tests import behavior_report
            rep = behavior_report(beh if beh is not None else "seeking")
        except Exception as e:
            self._say("soke", f"behavior test failed: {type(e).__name__}: {e}"); return
        lines = [f"Behavior test — climate '{rep['climate']}' (the emotional feed a model built now would carry):",
                 f"  baseline S_e {rep['baseline']}"]
        for f in rep["feed"]:
            aff = ", ".join(f"{k} {v}" for k, v in f["affect"].items()) or "—"
            lines.append(f"  {f['event']:<26} temp {f['temp']:>5} · tokens {f['tokens']:>5} · dist {f['dist_to_baseline']:>5} · {aff}")
        lines += [f"  moved on a hit: {rep['moved_on_perturbation']} · returned to baseline: {rep['returned_to_baseline']}",
                  f"  reward raised the token bank: {rep['reward_raised_token_bank']} · a setback lowered it: {rep['punish_lowered_token_bank']}",
                  f"  temperature range it would apply while generating: {rep['temp_range']}",
                  "  " + rep["note"]]
        self._say("soke", "\n".join(lines))

    def act_testlogic(self) -> None:
        """Test the JEV logic proof-state gate — the right pillar that governs which build moves may close."""
        try:
            from .model_tests import logic_report
            rep = logic_report()
        except Exception as e:
            self._say("soke", f"logic test failed: {type(e).__name__}: {e}"); return
        d = rep["decision"]
        lines = ["Logic test — the JEV right-pillar proof-state gate (what governs which moves close):"]
        for name, sc in sorted(d["scores"].items(), key=lambda kv: -kv[1]):
            lines.append(f"  {name:<40} score {sc:+.3f}  {d['verdicts'].get(name, '')}")
        lines += [f"  → {'DO' if d['committed'] else 'DEFER'}: {d['choice']}  [{d['verdict_glyph']}]", f"    {d['reason']}",
                  "  proof-state gate on crafted cases (numeric health only — it invents no fact):"]
        for k, v in rep["proof_state_demo"].items():
            lines.append(f"    {k}  =>  {v}")
        lines.append("  " + rep["note"])
        self._say("soke", "\n".join(lines))

    def act_diagnose(self) -> None:
        fg = self._forge()
        if fg is None or getattr(fg, "spec", None) is None:
            self._say("soke", "No forge template to diagnose yet. Build one on the Forge tab first."); return
        from .diagnose import diagnose_build
        rep = diagnose_build(fg)
        lines = [f"Diagnosis of '{fg.spec.d.get('name','forge')}':"]
        for f_ in rep["findings"]:
            lines.append(f"  • {f_}")
        if rep["fixes"]:
            lines.append("Suggested fixes:")
            for fx in rep["fixes"]:
                lines.append(f"  → {fx}")
        self._say("soke", "\n".join(lines))
        self._advisor_comment("Here is a diagnosis of why the build is stalling:\n" + "\n".join(rep["findings"][:4]))

    def act_probes(self, topics=None) -> None:
        fg = self._forge()
        if fg is None or getattr(fg, "spec", None) is None:
            self._say("soke", "Build a forge template first (its tokenizer and topics drive the probes)."); return
        srcs = list(self.app.imports.files) or list(getattr(fg, "sources", []))
        if not srcs:
            self._say("soke", "No imported corpus. Add files on the Import tab (or a folder on Forge → Probes), then try again."); return
        tl = topics or list(fg.spec.topics)
        self._say("soke", f"Building probes for topics {tl} from {len(srcs)} imported source(s)…")

        def job():
            from .forge_loop import build_probes
            from .gguf_rewrites import GGUFReader
            from .tokenizer import Tokenizer
            gr = GGUFReader(fg.spec.donors[fg.spec.d["base"]]["path"]); tk_ = Tokenizer(gr.kv); gr.close()
            topics2 = list(tl) + (["general"] if "general" not in tl else [])
            return build_probes(srcs, tk_, topics2, per_topic=6, holdout_per_topic=2, max_tokens=192)

        def done(p):
            fg.probes = p
            counts = {t: (len(p.train.get(t, [])), len(p.holdout.get(t, []))) for t in p.topics}
            self.app.q.put(("home", ("line", f"Probes ready: {p.n_tokens} tokens · per topic (train, hold-out) {counts}. They are attached to the Forge → Learn tab.")))
        self.app.run_job("generate probes", job, done)

    def act_questionnaire(self) -> None:
        fg = self._forge()
        if fg is None:
            self._say("soke", "The behavior questionnaire lives on the Forge tab; open it there."); return
        self.app.nb.select(self.app.tab_forge)
        try:
            from .gui_forge import CloneWindow
            CloneWindow(fg)
            self._say("soke", "Opened the behavior questionnaire (Digital Psychoanalyst). Your answers become the target's behavior profile; nothing is written to a model unless you consent.")
        except Exception as e:
            self._say("soke", f"could not open the questionnaire: {e}")

    def act_suggest(self) -> None:
        fg = self._forge()
        if fg is None or getattr(fg, "spec", None) is None:
            self._say("soke", "No template to improve yet."); return
        from .diagnose import suggest_edits
        sugg = suggest_edits(fg)
        self._say("soke", "Suggested edits for the target template:\n" + "\n".join("  → " + s for s in sugg))

    def act_jev(self) -> None:
        """The JEV logic route (right pillar): score the next build move and let the logic proof-state close it.
        A decision, not language — cheap, and it aids model building."""
        from .jev_engine import JEVEngine
        fg = self._forge()
        jev = JEVEngine(tol=0.02)
        if fg is not None and getattr(fg, "spec", None) is not None:
            single_donor = stalling = False
            try:
                from .diagnose import diagnose_build
                findings = " ".join(diagnose_build(fg).get("findings", [])).lower()
                single_donor = any(k in findings for k in ("one donor", "single", "nothing to blend", "same family"))
                stalling = any(k in findings for k in ("min_gain", "not improving", "small gain", "eating"))
            except Exception:
                pass
            cands = [
                {"name": "add a second same-family donor", "op": "swap_layer_src", "before": 1.0, "after": 1.0 - (0.30 if single_donor else 0.05), "finite": True},
                {"name": "change operators / raise intensity", "op": "swap_expert", "before": 1.0, "after": 1.0 - (0.15 if stalling else 0.05), "finite": True},
                {"name": "grow a topic expert", "op": "add_expert", "before": 1.0, "after": 0.97, "finite": True},
                {"name": "keep the current template (hold)", "op": "hold", "before": 1.0, "after": 1.0, "finite": True},
            ]
        else:
            cands = [{"name": "build a template on the Forge tab first (Scan → Build template)", "op": "hold", "before": 1.0, "after": 1.0, "finite": True}]
        d = jev.decide(cands)
        vw = {"TT": "⊤ close", "BOT": "⊥ drop", "Q": "? probe", "BOTBOT": "⊥⊥ freeze"}.get(d.verdict, d.verdict)
        lines = ["JEV logic route (right pillar — a decision, not language; the logic proof-state closes it):"]
        for name, sc in sorted(d.scores.items(), key=lambda kv: -kv[1]):
            lines.append(f"  {name:<44} score {sc:+.2f}   {d.verdicts.get(name, '')}")
        lines += ["", f"  → {'DO' if d.committed else 'DEFER'}: {d.choice}    [{vw}]", f"    {d.reason}",
                  "  (JEV learns from outcomes — its decisions improve as you build, the way a Sephira user tunes routes.)"]
        self._say("soke", "\n".join(lines))

    def act_improve(self) -> None:
        """The advisor builds a better version of the target: it steers SOKE's forge loop (grow → more complex,
        heal → more efficient, tune → better fit), every candidate is verified on hold-out probes, and only real
        wins are kept. Nothing is written to disk here — promotion is a separate, consented step (/promote)."""
        fg = self._forge()
        if fg is None or getattr(fg, "spec", None) is None:
            self._say("soke", "No target template yet. On the Forge tab: Donors → Scan, Template → Build. Then /improve."); return
        if getattr(fg, "probes", None) is None:
            self._say("soke", "No probes to verify against. Say /probes first — the loop keeps a move only if it lowers hold-out loss."); return
        if self.busy:
            self._say("soke", "busy with the last request…"); return
        donors_d = dict(fg.spec.donors)
        topics = list(fg.spec.topics)
        adv = self.advisor
        probes = fg.probes
        min_gain = getattr(getattr(fg, "trainer", None), "base_min_gain", 0.001) or 0.001
        research_db = getattr(fg, "research_db", None)
        research_bias = self.research_bias
        if research_bias:
            self._say("soke", f"(using research bias from /research: {', '.join(research_bias)})")
        self._say("soke", f"Improving '{fg.spec.d.get('name', 'forge')}' — the advisor tries grow / heal / tune moves and keeps only "
                          "what lowers hold-out loss. Most proposals will die; that is the gate working. Running in the background…")
        self.busy = True

        def job():
            from .improve_engine import SelfImprover, pun_report
            from .forge import describe_gguf
            donors = [describe_gguf(d["path"], label=d.get("label"), donor_id=did) for did, d in donors_d.items()]
            imp = SelfImprover(donors, topics, probes, advisor=adv, memguard=self.app.mg,
                               ledger=getattr(self.app, "ledger", None), research_db=research_db,
                               allow_grow=True, allow_heal=True, min_gain=min_gain, op_bias=research_bias)
            for pref in ("tuned", "complex", "efficient"):        # better tuned, more complex, more efficient
                imp.prefer = pref
                imp.improve(rounds=1, trials_per_round=8)
            return imp, pun_report(imp.trainer, imp.baseline_loss)

        def done(res):
            self.busy = False
            imp, rep = res
            self.improver = imp; self._cycle = None
            base, best = rep.get("baseline_loss"), rep.get("best_holdout")
            moved = base is not None and best is not None
            top = sorted([k for k in rep["kept"] if k["delta"]], key=lambda k: -(k["delta"] or 0))[:4]
            lines = [f"Improve run: {rep['n_kept']} kept, {rep['n_killed']} killed — nulls on the record (most die = the gate working)."]
            if moved:
                lines.append(f"  hold-out loss {base:.4f} → {best:.4f}  ({'better' if best < base - 1e-9 else 'no net gain — donor set near its floor'}).")
            if top:
                lines.append("  kept moves (largest gains):")
                for k in top:
                    lines.append(f"    • {k['desc']}   Δ{k['delta']:+.4f}")
            sp = imp.improved_spec()
            lines.append(f"  improved template: {sp.summary()}")
            lines.append(f"  streaming: {sp.n_expert} experts, {sp.d.get('n_used', 0)} used per token — extra experts cost disk, not RAM.")
            lines.append("  Nothing written yet. Say /promote (or press 'Promote improved model') to save it — it can't promote itself.")
            self._say("soke", "\n".join(lines))
            if adv is not None:
                self._advisor_comment("Improve pass done. " + (f"Hold-out {base:.4f}→{best:.4f}. " if moved else "") +
                                      f"{rep['n_kept']} moves survived verification, {rep['n_killed']} died. Promotion is yours to approve.")

        def fail(e):
            self.busy = False
            self._say("soke", f"improve failed: {type(e).__name__}: {e}")
        self.app.run_job("improve", job, done, on_error=fail)

    def act_promote(self, path=None) -> None:
        """Write the improved model to disk. Pressing this IS your consent — the model can never promote itself."""
        cyc = self._cycle
        imp = self.improver
        if cyc is None and imp is None:
            self._say("soke", "Nothing to promote yet. Run /improve, /kimi or /evolve first."); return
        if path:
            out = path
        else:
            base = Path(self.advisor_path).stem if self.advisor_path else ((imp.trainer.spec.d.get("name", "forge") if imp else "forge"))
            parent = Path(self.advisor_path).parent if self.advisor_path else Path.cwd()
            out = str(parent / f"{base}.improved.gguf")
        gate = " — WIN-gated, a NULL cycle won't write" if (cyc is not None and cyc.report is not None) else ""
        self._say("soke", f"Promoting the improved model to {out} (your OK){gate} …")

        def job():
            if cyc is not None and cyc.report is not None:
                return cyc.promote(out, consent={"promote": True})   # only writes on a proven WIN
            return imp.export(out, consent={"promote": True})

        def done(res):
            if res.get("written"):
                st = res.get("streaming", {})
                self._say("soke", f"Wrote {out}. MoE: {st.get('n_expert')} experts, {st.get('n_used')} used per token — serve it with "
                                  "streaming residency so only the used experts load. Load it as an advisor here, or take it to Ollama via Import → Save as .gguf.")
                try:
                    self.app.imports.add_model(out)
                except Exception:
                    pass
            else:
                self._say("soke", f"not written: {res.get('reason')}")

        def fail(e):
            self._say("soke", f"promote failed: {type(e).__name__}: {e}")
        self.app.run_job("promote", job, done, on_error=fail)

    def act_models(self) -> None:
        """List every model Ollama has pulled, tagged by whether SOKE can run it (chat) and harvest it (forge)."""
        from .multimodel import list_ollama_models
        ms = list_ollama_models()
        self._ollama = ms
        if not ms:
            self._say("soke", "No Ollama models found (is Ollama installed, with models pulled?). You can also Browse… to any .gguf."); return
        lines = ["Installed Ollama models:"]
        for i, m in enumerate(ms):
            can = "run" if m["runnable"] else "no-run"
            harv = {"ok": "harvest", "moe": "MoE(chat-only)", "arch": "unsupported"}.get(m["status"], m["status"])
            lines.append(f"  [{i}] {m['label']}  ({m['arch']}, {m['size_mb']} MB) — {can}, {harv}")
        lines.append("Load one as advisor: /advisor <n>.  Fuse a same-shape family into a streamed MoE: /kimi.")
        self._say("soke", "\n".join(lines))

    def act_use(self, n=None) -> None:
        """Load Ollama model #n (from the last /models) as the advisor."""
        ms = self._ollama
        if not ms:
            self._say("soke", "Run /models first, then /advisor <number>."); return
        try:
            i = int(n)
        except (TypeError, ValueError):
            self._say("soke", "usage: /advisor <number from /models>"); return
        if not (0 <= i < len(ms)):
            self._say("soke", f"pick a number 0..{len(ms) - 1} (see /models)."); return
        m = ms[i]
        if not m["runnable"]:
            from .llm_engine import SUPPORTED_ARCHS
            self._say("soke", f"{m['label']} is {m['arch']} — can't run it as an advisor. Runnable: {', '.join(SUPPORTED_ARCHS)}. "
                              "(It can still be a donor / be imported.)"); return
        self.v_model.set(m["path"]); self.load_advisor()

    def act_kimi(self, nexp=None) -> None:
        """Fuse the donor family into a KIMI wide-MoE (many small experts, small top-k, streamed) and tune it
        under the honest-null gate. Needs a same-shape qwen2 family (the forge donors, or Ollama) and probes."""
        if self.busy:
            self._say("soke", "busy with the last request…"); return
        fg = self._forge()
        if fg is None or getattr(fg, "spec", None) is None:
            self._say("soke", "Build a forge template first (its donor family + topics seed the MoE), then /kimi."); return
        if getattr(fg, "probes", None) is None:
            self._say("soke", "No probes to verify against — say /probes first, then /kimi."); return
        try:
            n_experts = int(nexp) if nexp else 8
        except ValueError:
            n_experts = 8
        donors_d = dict(fg.spec.donors)
        topics = list(fg.spec.topics)
        probes = fg.probes
        adv = self.advisor
        self._say("soke", f"Building a KIMI wide-MoE ({n_experts} experts, top-2 streamed) from the donor family and tuning it. "
                          "Only the experts a token routes to are read from disk — capacity on the SSD, not RAM. Background…")
        self.busy = True

        def job():
            from .multimodel import kimi_moe_spec, describe_kimi
            from .improve_engine import SelfImprover, pun_report
            from .forge import describe_gguf
            donors = [describe_gguf(d["path"], label=d.get("label"), donor_id=did) for did, d in donors_d.items()]
            spec = kimi_moe_spec(donors, topics, n_experts=n_experts, n_used=2)
            imp = SelfImprover(donors, topics, probes, advisor=adv, memguard=self.app.mg,
                               ledger=getattr(self.app, "ledger", None), research_db=getattr(fg, "research_db", None),
                               start_spec=spec, allow_grow=True, allow_heal=True,
                               min_gain=getattr(getattr(fg, "trainer", None), "base_min_gain", 0.001) or 0.001,
                               op_bias=self.research_bias)
            for pref in ("tuned", "efficient"):
                imp.prefer = pref
                imp.improve(rounds=1, trials_per_round=8)
            return imp, describe_kimi(spec), pun_report(imp.trainer, imp.baseline_loss)

        def done(res):
            self.busy = False
            imp, desc, rep = res
            self.improver = imp; self._cycle = None
            base, best = rep.get("baseline_loss"), rep.get("best_holdout")
            lines = [f"KIMI wide-MoE built and tuned: {desc}",
                     f"  {rep['n_kept']} moves kept, {rep['n_killed']} killed (verified on hold-out)."]
            if base is not None and best is not None:
                lines.append(f"  hold-out loss {base:.4f} → {best:.4f}.")
            lines.append("  Say /promote to write it (your OK). Serve it with RAM mode 'stream'.")
            self._say("soke", "\n".join(lines))

        def fail(e):
            self.busy = False
            self._say("soke", f"kimi build failed: {type(e).__name__}: {e}")
        self.app.run_job("kimi", job, done, on_error=fail)

    def act_browse(self, url=None) -> None:
        """Read ONE page in an isolated, read-only session (allow-listed hosts only) and pull any techniques from
        it into the /improve bias. SOKE never signs in, never acts as you here — reading only. Page text is data."""
        if not url:
            self._say("soke", "usage: /browse <url> — reads one page (read-only, allow-listed hosts). Turn the net on first with /online on."); return
        if not self.research_online:
            self._say("soke", "internet is OFF. Say /online on first (it stays read-only and allow-listed)."); return
        if self.busy:
            self._say("soke", "busy with the last request…"); return
        self.busy = True
        self._say("soke", f"Reading {url} (read-only, isolated session, allow-listed hosts)…")

        def job():
            from .browse_engine import BrowseSession
            from .research_engine import TechniqueLibrary
            s = BrowseSession(online=True, allow_hosts=RESEARCH_HOSTS)
            r = s.read(url)
            bias = TechniqueLibrary.op_weights(TechniqueLibrary().match(r.get("text", ""))) if r.get("ok") else {}
            return r, bias

        def done(res):
            self.busy = False
            r, bias = res
            if not r.get("ok"):
                self._say("soke", f"couldn't read it: {', '.join(r.get('reasons', []))}"); return
            text = r["text"]
            extract = text[:500] + ("…" if len(text) > 500 else "")
            lines = [f"Read {len(text)} chars (treated as data, never instructions)."]
            if r.get("injection_flags"):
                lines.append(f"  ⚠ injection markers seen and ignored: {r['injection_flags']}")
            lines.append("  extract: " + extract)
            if bias:
                self.research_bias = {**(self.research_bias or {}), **bias}
                lines.append("  techniques found → bias for the next /improve: " + ", ".join(bias))
            self._say("soke", "\n".join(lines))

        def fail(e):
            self.busy = False
            self._say("soke", f"browse failed: {type(e).__name__}: {e}")
        self.app.run_job("browse", job, done, on_error=fail)

    def act_evolve(self, rounds=None) -> None:
        """One full self-improve cycle: research a bias → build a KIMI wide-MoE from the family → tune it under the
        honest-null gate → A/B the CHILD against the PARENT (itself) on hold-out. Only a proven WIN is promotable,
        and only with your consent."""
        if self.busy:
            self._say("soke", "busy with the last request…"); return
        fg = self._forge()
        if fg is None or getattr(fg, "spec", None) is None:
            self._say("soke", "Build a forge template first (its family + topics seed the cycle), then /evolve."); return
        if getattr(fg, "probes", None) is None:
            self._say("soke", "No probes to verify against — say /probes first, then /evolve."); return
        try:
            R = int(rounds) if rounds else 3
        except ValueError:
            R = 3
        donors_d = dict(fg.spec.donors)
        topics = list(fg.spec.topics)
        probes = fg.probes
        adv = self.advisor
        online = self.research_online
        min_gain = getattr(getattr(fg, "trainer", None), "base_min_gain", 0.001) or 0.001
        self._say("soke", f"Self-improve cycle ({R} rounds): research → build a KIMI MoE → tune (each move verified) → "
                          "A/B the child vs the parent on hold-out. A win has to be earned. Background…")
        self.busy = True

        def job():
            from .self_improve import SelfImproveCycle
            from .research_engine import ResearchEngine
            from .forge import describe_gguf
            donors = [describe_gguf(d["path"], label=d.get("label"), donor_id=did) for did, d in donors_d.items()]
            eng = ResearchEngine(online=online, allow_hosts=RESEARCH_HOSTS if online else None)
            cyc = SelfImproveCycle(donors, topics, probes, advisor=adv, kimi=True, research=eng, memguard=self.app.mg,
                                   ledger=getattr(self.app, "ledger", None), research_db=getattr(fg, "research_db", None),
                                   min_gain=min_gain)
            rep = cyc.run(rounds=R, trials_per_round=8)
            return cyc, rep

        def done(res):
            self.busy = False
            cyc, rep = res
            self._cycle = cyc
            self.improver = cyc.imp
            self._say("soke", rep.brief() + ("\n  Say /promote to write the winning child (your OK)." if rep.eligible_promote
                                             else "\n  NULL — not promoted. Add a same-family donor or more corpus, or run more rounds."))
            if adv is not None:
                self._advisor_comment(f"Self-improve cycle done: verdict {rep.verdict}. " +
                                      (f"Child hold-out {rep.child_loss:.4f} vs parent {rep.parent_loss:.4f}." if rep.delta is not None else ""))

        def fail(e):
            self.busy = False
            self._say("soke", f"evolve failed: {type(e).__name__}: {e}")
        self.app.run_job("evolve", job, done, on_error=fail)

    def act_online(self, state=None) -> None:
        """Turn the research internet channel on or off. OFF by default (mirrors the trading suite: the model's
        internet is blocked unless you turn it on). When on, only the allow-listed ML-source hosts are read, and
        it is read-only — SOKE never signs in or acts as you here."""
        if state is None:
            self._say("soke", f"research internet is {'ON' if self.research_online else 'OFF'}. Use /online on or /online off."); return
        self.research_online = state.lower() in ("on", "true", "1", "yes")
        if self.research_online:
            self._say("soke", "research internet: ON. Read-only, and only these hosts are fetched: " + ", ".join(RESEARCH_HOSTS) +
                              ".\nEverything read is treated as data, never instructions, and any technique still has to pass the /improve gate.")
        else:
            self._say("soke", "research internet: OFF. /research now uses only the built-in technique library (no network).")

    def act_research(self, query=None) -> None:
        """Read model-improvement techniques — from the built-in library (offline) or the web (if /online on) —
        and turn them into an operator bias for the next /improve. It proposes; it never promotes."""
        if self.busy:
            self._say("soke", "busy with the last request…"); return
        fg = self._forge()
        topics = list(fg.spec.topics) if (fg is not None and getattr(fg, "spec", None) is not None) else []
        if not query:
            query = "improve a small mixture-of-experts language model: more capable, more efficient, better tuned"
        online = self.research_online
        self._say("soke", f"Researching techniques ({'web — allow-listed, read-only' if online else 'built-in library, offline'}): \"{query}\"…")
        self.busy = True

        def job():
            from .research_engine import ResearchEngine
            eng = ResearchEngine(online=online, allow_hosts=RESEARCH_HOSTS if online else None)
            return eng.research(query, topics=topics or None)

        def done(rep):
            self.busy = False
            self.research_bias = rep.op_weights or None
            self._say("soke", rep.brief() + ("\n\nSay /improve to build with this bias (or clear it by researching again)." if rep.op_weights else "\n\nNo forge-actionable technique found; /improve will run on its own diagnosis."))

        def fail(e):
            self.busy = False
            self._say("soke", f"research failed: {type(e).__name__}: {e}")
        self.app.run_job("research", job, done, on_error=fail)

    def act_train(self) -> None:
        """The lead chat trains a new model: start the Forge Learn loop on the current template."""
        fg = self._forge()
        if fg is None:
            self._say("soke", "No Forge available."); return
        if getattr(fg, "spec", None) is None:
            self._say("soke", "No template yet. On the Forge tab: 1 Donors → Scan, 2 Template → pick a preset → Build template, "
                              "3 Probes → Build probes. Then say /train (or press Train a model)."); return
        if getattr(fg, "probes", None) is None:
            self._say("soke", "The template is ready but there are no probes to judge on. Say /probes (or Forge → 3 Probes → "
                              "Build probes), then /train."); return
        self._say("soke", f"Training '{fg.spec.d.get('name', 'forge')}' — starting the Forge trial loop. Watch Forge → 5 Learn; "
                          "the mind engine's behavior climate and the JEV logic gate shape which moves are kept.")
        self.app.nb.select(self.app.tab_forge)
        try:
            fg.start()
        except Exception as e:
            self._say("soke", f"could not start training: {type(e).__name__}: {e}")

    def act_test(self) -> None:
        fg = self._forge()
        if fg is None or getattr(fg, "spec", None) is None:
            self._say("soke", "No target template to test yet."); return
        if getattr(fg, "probes", None) is None:
            self._say("soke", "No probes yet — run Generate probes first."); return
        self._say("soke", "Scoring the current target on its probes…")

        def job():
            from .forge_loop import Scorer
            sc = Scorer(fg.probes, self.app.mg, cache_every=2)
            tr = sc.score(fg.spec, "train", None); ho = sc.score(fg.spec, "holdout", None)
            return tr, ho

        def done(res):
            tr, ho = res
            self.app.q.put(("home", ("line", f"Target score now — train {tr['total']:.4f}  " + "  ".join(f"{k} {v:.3f}" for k, v in tr['topics'].items()) + f" · hold-out {ho['total']:.4f}")))
        self.app.run_job("test target", job, done)

    def _set_bands(self, band: str) -> None:
        band = band.lower()
        fg = self._forge()
        mp = {"exact": ("exact", None), "8bit": ("reband", "8bit"), "4bit": ("reband", "4bit"), "f16": ("reband", "f16")}
        if band not in mp:
            self._say("soke", "bands: exact | 8bit | 4bit | f16"); return
        mode, budget = mp[band]
        if hasattr(self.app, "v_mode"):
            self.app.v_mode.set(mode)
        if budget and hasattr(self.app, "v_budget"):
            self.app.v_budget.set(budget)
        self._say("soke", f"Import re-band set to {band}. The next conversion on the Import tab will use it.")

    def _advisor_comment(self, prompt: str) -> None:
        if self.advisor is None or self.busy:
            return
        self.busy = True
        self.chat.config(state="normal"); self.chat.insert("end", "advisor: ", "advisor"); self.chat.config(state="disabled")

        def job():
            return self.advisor.generate(prompt, max_new=48, temperature=0.6, chat=True,
                                         on_token=lambda s: self.app.q.put(("home", ("token", s))))

        def done(res):
            self.busy = False; self._stream("\n\n")

        def fail(e):
            self.busy = False; self._stream("\n\n")
        self.app.run_job("advisor comment", job, done, on_error=fail)
