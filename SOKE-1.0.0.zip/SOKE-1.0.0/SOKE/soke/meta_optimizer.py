"""
soke.meta_optimizer — the research brain's memory of what works.

The 10M-parameter learned optimizer of the SOKE layout is out of reach for a
stdlib+numpy build and is NOT pretended here. What ships is the honest core of
that component: a strategy bandit over ALM hypothesis families, backed by the
research database (sqlite3, the "optimization_history.db" of the doc).

  score(family) = prior + w * (wins - losses) / (1 + trials)      (UCB-style bonus)
  PRUNE_SPACE: a family that failed >= 3 times under the same lock class is
  deprioritized (never deleted — nulls are deliverables).
"""
from __future__ import annotations

import json
import math
import sqlite3
import threading
import time
from pathlib import Path
from typing import Optional

# hypothesis families per plateau class (ALM Phase 2 playbooks)
PLAYBOOK = {
    "OPT_LOCK": ["lr_down", "lr_up", "warm_restart", "wd_sweep", "clip_tighten", "beta2_down"],
    "NOISE_LOCK": ["batch_up", "lr_down", "clip_tighten"],
    "DATA_LOCK": ["wd_up", "batch_up", "lr_down"],
    "CAP_LOCK": ["expand_width", "expand_depth", "expand_expert"],
    "REPRESENTATION_LOCK": ["osp_leg_swap", "prior_weight_up", "prior_weight_down"],
    "DESCENDING": [],
}
DEFAULT_PRIOR = {"lr_down": 0.6, "lr_up": 0.3, "warm_restart": 0.4, "wd_sweep": 0.3, "clip_tighten": 0.3, "beta2_down": 0.2,
                 "batch_up": 0.5, "wd_up": 0.5, "expand_width": 0.6, "expand_depth": 0.4, "expand_expert": 0.5,
                 "osp_leg_swap": 0.2, "prior_weight_up": 0.3, "prior_weight_down": 0.3}


class ResearchDB:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.con = sqlite3.connect(str(self.path), check_same_thread=False)   # GUI worker threads share it
        self.lock = threading.RLock()
        self.con.execute("""CREATE TABLE IF NOT EXISTS experiments (
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, lock TEXT, family TEXT, hypothesis TEXT, config TEXT,
            loss_before REAL, loss_after REAL, v_control REAL, v_candidate REAL, stable INTEGER, success INTEGER, insights TEXT)""")
        self.con.execute("""CREATE TABLE IF NOT EXISTS milestones (
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, step INTEGER, params INTEGER, train_loss REAL, val_loss REAL, note TEXT)""")
        self.con.commit()

    def log_experiment(self, **row) -> int:
        cols = ["ts", "lock", "family", "hypothesis", "config", "loss_before", "loss_after", "v_control", "v_candidate", "stable", "success", "insights"]
        vals = [row.get("ts", time.time()), row.get("lock"), row.get("family"), row.get("hypothesis"),
                json.dumps(row.get("config", {}), default=str), row.get("loss_before"), row.get("loss_after"),
                row.get("v_control"), row.get("v_candidate"), int(bool(row.get("stable", True))), int(bool(row.get("success"))),
                row.get("insights", "")]
        with self.lock:
            cur = self.con.execute(f"INSERT INTO experiments ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", vals)
            self.con.commit()
            return int(cur.lastrowid)

    def log_milestone(self, step: int, params: int, train_loss: float, val_loss: float, note: str = "") -> None:
        with self.lock:
            self.con.execute("INSERT INTO milestones (ts, step, params, train_loss, val_loss, note) VALUES (?,?,?,?,?,?)",
                             (time.time(), step, params, train_loss, val_loss, note))
            self.con.commit()

    def family_stats(self) -> dict[str, dict]:
        out: dict[str, dict] = {}
        with self.lock:
            rows = list(self.con.execute("SELECT family, lock, SUM(success), COUNT(*) FROM experiments GROUP BY family, lock"))
        for fam, lock, succ, n in rows:
            d = out.setdefault(fam, {"wins": 0, "trials": 0, "by_lock": {}})
            d["wins"] += int(succ or 0)
            d["trials"] += int(n)
            d["by_lock"][lock] = {"wins": int(succ or 0), "trials": int(n)}
        return out

    def experiments(self, limit: int = 50) -> list[dict]:
        with self.lock:
            cur = self.con.execute("SELECT id, ts, lock, family, hypothesis, loss_before, loss_after, v_control, v_candidate, stable, success, insights FROM experiments ORDER BY id DESC LIMIT ?", (limit,))
            rows = cur.fetchall()
        keys = ["id", "ts", "lock", "family", "hypothesis", "loss_before", "loss_after", "v_control", "v_candidate", "stable", "success", "insights"]
        return [dict(zip(keys, r)) for r in rows]

    def milestones(self) -> list[dict]:
        with self.lock:
            rows = list(self.con.execute("SELECT ts, step, params, train_loss, val_loss, note FROM milestones ORDER BY id"))
        return [dict(zip(["ts", "step", "params", "train_loss", "val_loss", "note"], r)) for r in rows]

    def close(self) -> None:
        self.con.close()


class MetaOptimizer:
    def __init__(self, db: Optional[ResearchDB] = None, exploration: float = 0.3, prune_after: int = 3):
        self.db = db
        self.exploration = exploration
        self.prune_after = prune_after
        self.local: dict[str, dict] = {}     # in-memory stats when no DB

    def _stats(self) -> dict[str, dict]:
        if self.db is not None:
            return self.db.family_stats()
        return self.local

    def rank(self, lock: str, exclude: Optional[set] = None) -> list[tuple[str, float]]:
        fams = [f for f in PLAYBOOK.get(lock, []) if f not in (exclude or set())]
        stats = self._stats()
        total = sum(s.get("trials", 0) for s in stats.values()) + 1
        rows = []
        for f in fams:
            s = stats.get(f, {"wins": 0, "trials": 0, "by_lock": {}})
            bl = s.get("by_lock", {}).get(lock, {"wins": 0, "trials": 0})
            fails = bl["trials"] - bl["wins"]
            score = DEFAULT_PRIOR.get(f, 0.3) + (s["wins"] - (s["trials"] - s["wins"])) / (1.0 + s["trials"])
            score += self.exploration * math.sqrt(math.log(total) / (1.0 + s["trials"]))
            if fails >= self.prune_after and bl["wins"] == 0:
                score -= 10.0            # PRUNE_SPACE: deprioritized, still listed
            rows.append((f, round(score, 4)))
        rows.sort(key=lambda kv: -kv[1])
        return rows

    def record(self, lock: str, family: str, success: bool, **extra) -> None:
        if self.db is not None:
            self.db.log_experiment(lock=lock, family=family, success=success, **extra)
        d = self.local.setdefault(family, {"wins": 0, "trials": 0, "by_lock": {}})
        d["trials"] += 1
        d["wins"] += int(success)
        bl = d["by_lock"].setdefault(lock, {"wins": 0, "trials": 0})
        bl["trials"] += 1
        bl["wins"] += int(success)

    def pruned(self, lock: str) -> list[str]:
        out = []
        for f, s in self._stats().items():
            bl = s.get("by_lock", {}).get(lock)
            if bl and bl["trials"] - bl["wins"] >= self.prune_after and bl["wins"] == 0:
                out.append(f)
        return out


def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    chk = chk or Check("meta")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_meta_"))
    db = ResearchDB(tmpdir / "research.db")
    mo = MetaOptimizer(db)
    r0 = mo.rank("OPT_LOCK")
    chk("playbook ranked by prior", r0[0][0] == "lr_down", str(r0[:3]))
    for _ in range(3):
        mo.record("OPT_LOCK", "lr_down", False, hypothesis="lr x0.5", loss_before=2.0, loss_after=2.0, v_control=-0.01, v_candidate=-0.01)
    mo.record("OPT_LOCK", "warm_restart", True, hypothesis="restart", loss_before=2.0, loss_after=1.8, v_control=-0.01, v_candidate=-0.05)
    r1 = mo.rank("OPT_LOCK")
    chk("PRUNE_SPACE after 3 failures", "lr_down" in mo.pruned("OPT_LOCK") and r1[-1][0] == "lr_down" and r1[0][0] == "warm_restart", str(r1))
    chk("research db persists experiments", len(db.experiments()) == 4 and db.family_stats()["warm_restart"]["wins"] == 1)
    db.log_milestone(100, 2_000_000, 1.5, 1.6, "ratchet")
    chk("milestones table", db.milestones()[0]["step"] == 100)
    db.close()
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
