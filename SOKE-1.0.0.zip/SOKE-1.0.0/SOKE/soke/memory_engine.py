"""
soke.memory_engine — the Helical Memory System (HMS) on top of SFF.

One helix per knowledge-tower domain; teeth are ACTG records (A axiom, C concept,
T technique, G grounding). Writes land as small unsorted chunks in a STAGING helix
(PAIRED_PENDING), and a consolidation job assembles them into the domain strands
in dependency order (parents-first boot order, then arrival order) — genome
assembly: overlap -> layout -> consensus. Reads are the FACE GEAR: an indexed seek
(O(log N) over FNV-1a word keys) to the page and record, then a bounded window
ride along the strand. RAM = window, never the reel.

Everything here streams: files are ingested in chunks (default 64 KB), pages are
tooth runs of bounded size, the SFF reader maps the file.
"""
from __future__ import annotations

import os
import re
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterator, Optional

import numpy as np

from .actg_parser import classify_base
from .sff import (HELIX_KIND_KNOWLEDGE, HELIX_KIND_STAGING, NO_PAGE, SFFReader, SFFWriter)
from .teeth import (ENC_TOOTH, ToothRecord, encode_tooth_run, iter_tooth_run, pair_legal)
from .tower import BY_ID, BY_NAME, STAGING, boot_order, domain_id, domain_name, route_domain

_WORD = re.compile(r"[a-z0-9][a-z0-9_]{1,}")
STOP = set("the a an and or of to in is are was were be for on with as by at from that this it its into than then".split())
PAGE_BYTES = 64 * 1024
REG_CODE = {"R": 0, "Q": 1, "T": 2, "L": 3, "H": 4, "LIN": 5}


def fnv1a64(s: str) -> int:
    h = 0xcbf29ce484222325
    for b in s.encode("utf-8"):
        h ^= b
        h = (h * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF
    return h


def seek_keys(text: str, ident: str = "", max_keys: int = 24) -> list[int]:
    words = []
    if ident:
        words.append(ident.lower())
    for w in _WORD.findall(text.lower()):
        if w in STOP or len(w) < 3:
            continue
        words.append(w)
        if len(words) >= max_keys:
            break
    out = []
    seen = set()
    for w in words:
        h = fnv1a64(w)
        if h not in seen:
            seen.add(h)
            out.append(h)
    return out


def extract_docx_text(path: Path) -> str:
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml").decode("utf-8", errors="replace")
    xml = re.sub(r"</w:p>", "\n", xml)
    xml = re.sub(r"<w:tab/>", "\t", xml)
    text = re.sub(r"<[^>]+>", "", xml)
    return re.sub(r"&amp;", "&", re.sub(r"&lt;", "<", re.sub(r"&gt;", ">", text)))


def iter_file_text(path: Path, chunk_bytes: int = 64 * 1024) -> Iterator[str]:
    """Stream a text-like file in chunks; docx is extracted first (stdlib)."""
    path = Path(path)
    if path.suffix.lower() == ".docx":
        text = extract_docx_text(path)
        for i in range(0, len(text), chunk_bytes):
            yield text[i:i + chunk_bytes]
        return
    if path.suffix.lower() in (".pdf", ".epub", ".htm", ".html", ".xhtml"):
        from .pdf_ingest import iter_book_text
        yield from iter_book_text(path, chunk_bytes)
        return
    with open(path, "rb") as f:
        carry = b""
        while True:
            b = f.read(chunk_bytes)
            if not b:
                if carry:
                    yield carry.decode("utf-8", errors="replace")
                return
            b = carry + b
            # cut at the last newline so records end on line boundaries
            cut = b.rfind(b"\n")
            if cut <= 0 or len(b) < chunk_bytes // 2:
                cut = len(b)
            yield b[:cut].decode("utf-8", errors="replace")
            carry = b[cut:]


@dataclass
class Bookmark:
    helix_id: int
    page_index: int
    record_offset: int
    label: str = ""


class FaceGear:
    """Streaming reader riding one helix; holds only a window of records."""

    def __init__(self, mem: "HelicalMemory", helix_id: int, window: int = 256):
        self.mem = mem
        self.helix_id = helix_id
        self.window = window
        self.page_index = 0
        self.record_offset = 0
        self.bookmarks: list[Bookmark] = []

    def seek(self, page_index: int, record_offset: int = 0) -> None:
        self.page_index = page_index
        self.record_offset = record_offset

    def bookmark(self, label: str = "") -> Bookmark:
        b = Bookmark(self.helix_id, self.page_index, self.record_offset, label)
        self.bookmarks.append(b)
        return b

    def rewind(self, bm: Bookmark) -> None:
        self.seek(bm.page_index, bm.record_offset)

    def ride(self, n: Optional[int] = None) -> Iterator[ToothRecord]:
        """Yield up to n (default window) records from the current position, advancing it."""
        from .teeth import decode_tooth
        n = n or self.window
        rd = self.mem.reader
        pages = rd.helix_pages(self.helix_id)
        yielded = 0
        while self.page_index < len(pages) and yielded < n:
            pid = pages[self.page_index]
            if pid == NO_PAGE:
                self.page_index += 1
                self.record_offset = 0
                continue
            raw = bytes(rd.page_bytes(pid))          # one page window, never the reel
            off = self.record_offset
            while off < len(raw) and yielded < n:
                base, payload, nxt = decode_tooth(raw, off)
                rec = ToothRecord.from_bytes(base, payload)
                off = nxt
                self.record_offset = off
                yielded += 1
                yield rec
            if off >= len(raw):
                self.page_index += 1
                self.record_offset = 0

    def fast_forward(self, query: str) -> Optional[tuple[int, int]]:
        """Index seek: jump to the first record on this helix matching a query key."""
        hits = self.mem.seek(query, helix_id=self.helix_id, limit=1)
        if not hits:
            return None
        _, page_index, off = hits[0][:3]
        self.seek(page_index, off)
        return page_index, off


class HelicalMemory:
    def __init__(self, path: Path, ledger=None, memguard=None, page_bytes: int = PAGE_BYTES):
        self.path = Path(path)
        self.ledger = ledger
        self.memguard = memguard
        self.page_bytes = page_bytes
        self.staging: list[ToothRecord] = []
        self._staging_bytes = 0
        self.reader: Optional[SFFReader] = None
        if not self.path.exists():
            w = SFFWriter(self.path, file_kind=1, meta={"model_id": self.path.stem, "tower": "knowledge-tower-v1"},
                          model_id=self.path.stem)
            w.add_helix("staging", domain_id=STAGING, register_kind=5, kind=HELIX_KIND_STAGING)
            for name in boot_order():
                d = BY_NAME[name]
                rk = REG_CODE.get(d.registers[0], 5) if d.registers else 5
                w.add_helix(f"helix:{name}", domain_id=d.id, register_kind=rk, kind=HELIX_KIND_KNOWLEDGE)
            w.commit()
            w.close()
        self._open()

    def _open(self) -> None:
        if self.reader:
            self.reader.close()
        self.reader = SFFReader(self.path)

    def close(self) -> None:
        if self.reader:
            self.reader.close()
            self.reader = None

    def _log(self, event: str, payload: dict, domain: str = "sys") -> None:
        if self.ledger is not None:
            self.ledger.append("HMS", event, payload, domain=domain)

    # ------------------------------------------------------------- writing
    def helix_for_domain(self, dom: int) -> int:
        name = f"helix:{domain_name(dom)}"
        h = self.reader.helix_by_name.get(name)
        if h is None:
            raise KeyError(f"no helix for domain {dom}")
        return h.helix_id

    def record(self, text: str, domain: Optional[str] = None, base: Optional[str] = None, ident: str = "",
               pair_with: Optional[ToothRecord] = None) -> ToothRecord:
        """Stage a record (small chunk, unsorted). Returns the staged record."""
        dom = domain_id(domain) if domain else domain_id(route_domain(text))
        base = base or classify_base(text)
        d = BY_ID.get(dom)
        gauge = REG_CODE.get(d.registers[0], 5) if d and d.registers else 5
        flags = 1  # PAIRED_PENDING
        rec = ToothRecord(base, dom, ident, text, gauge, flags)
        if pair_with is not None:
            if not pair_legal(pair_with.base, base):
                raise ValueError(f"illegal pairing {pair_with.base}-{base}")
            rec.flags &= ~1
            pair_with.flags &= ~1
        self.staging.append(rec)
        self._staging_bytes += len(text) + 64
        if self._staging_bytes > 8 * self.page_bytes:
            self.consolidate()
        return rec

    def ingest_file(self, path: Path, domain: Optional[str] = None, chunk_bytes: int = 64 * 1024,
                    progress: Optional[Callable[[dict], None]] = None) -> dict:
        path = Path(path)
        t0 = time.time()
        n = 0
        nbytes = 0
        doms: dict[str, int] = {}
        for i, chunk in enumerate(iter_file_text(path, chunk_bytes)):
            if not chunk.strip():
                continue
            if self.memguard is not None:
                self.memguard.check(f"ingest {path.name}")
            dom = domain or route_domain(chunk)
            rec = self.record(chunk, domain=dom, ident=f"{path.name}#{i}")
            doms[dom] = doms.get(dom, 0) + 1
            n += 1
            nbytes += len(chunk)
            if progress and n % 16 == 0:
                progress({"file": str(path), "chunks": n, "bytes": nbytes})
        self.consolidate()
        st = {"file": str(path), "chunks": n, "bytes": nbytes, "domains": doms, "elapsed_s": round(time.time() - t0, 2)}
        self._log("ingest_file", st, domain=max(doms, key=doms.get) if doms else "sys")
        return st

    def consolidate(self) -> dict:
        """
        Genome assembly of the staging area:
          overlap  — pair pending records that share an ident stem and pair legally (A-T, C-G, A-C, T-G)
          layout   — domain strands in DLP boot order, arrival order inside a domain
          consensus— duplicate invariants collapse to one record
          write    — tooth-run pages (<= page_bytes) appended to each domain helix, seek keys indexed
        """
        if not self.staging:
            return {"records": 0}
        t0 = time.time()
        recs = self.staging
        self.staging = []
        self._staging_bytes = 0
        # consensus: dedupe by invariant hash
        seen = set()
        uniq = []
        for r in recs:
            inv = r.compute_invariant()
            if inv in seen:
                continue
            seen.add(inv)
            r.invariant = inv
            uniq.append(r)
        # overlap: pair pending teeth within a domain by ident stem
        by_stem: dict[tuple[int, str], list[ToothRecord]] = {}
        for r in uniq:
            stem = r.ident.split("#")[0].lower()
            by_stem.setdefault((r.domain, stem), []).append(r)
        paired = 0
        for group in by_stem.values():
            pend = [r for r in group if r.flags & 1]
            for i in range(len(pend)):
                if not (pend[i].flags & 1):
                    continue
                for j in range(i + 1, len(pend)):
                    if (pend[j].flags & 1) and pend[i].base != pend[j].base and pair_legal(pend[i].base, pend[j].base):
                        pend[i].flags &= ~1
                        pend[j].flags &= ~1
                        paired += 1
                        break
        # layout: boot order
        order = {domain_id(n): k for k, n in enumerate(boot_order())}
        uniq.sort(key=lambda r: order.get(r.domain, 999))
        w = SFFWriter(self.path, mode="append")
        pages_written = 0
        keys: list[tuple[int, int, int]] = []
        by_dom: dict[int, list[ToothRecord]] = {}
        for r in uniq:
            by_dom.setdefault(r.domain, []).append(r)
        for dom, rows in by_dom.items():
            hname = f"helix:{domain_name(dom)}"
            h = w.helix_by_name(hname)
            if h is None:
                hid = w.add_helix(hname, domain_id=dom, register_kind=5, kind=HELIX_KIND_KNOWLEDGE)
            else:
                hid = h.helix_id
            pm = w.pmap.setdefault(hid, [])
            buf: list[ToothRecord] = []
            size = 0
            i = 0
            while i <= len(rows):
                flush = i == len(rows) or (size + len(rows[i].text) + 80 > self.page_bytes and buf)
                if flush and buf:
                    run = encode_tooth_run(buf)
                    idx = len(pm)
                    pid = w.write_page(hid, idx, run, ENC_TOOTH, count=len(buf))
                    # record offsets inside the run for the seek index
                    off = 0
                    for r in buf:
                        for k in seek_keys(r.text, r.ident):
                            keys.append((k, pid, off))
                        off += len(_tooth_len(r))
                    pages_written += 1
                    w.helices[hid].frame_count += len(buf)
                    buf, size = [], 0
                if i < len(rows):
                    buf.append(rows[i])
                    size += len(rows[i].text) + 80
                i += 1
        w.add_index_keys(keys)
        node = w.add_lineage_node(1, f"consolidate:{len(uniq)} records", ref_index=pages_written)
        w.add_lineage_edge(node, node, 18)
        w.commit(ledger_bytes=self.ledger.export_bytes() if self.ledger is not None else None)
        w.close()
        self._open()
        st = {"records": len(uniq), "duplicates_dropped": len(recs) - len(uniq), "pairs_matched": paired,
              "pages": pages_written, "keys": len(keys), "elapsed_s": round(time.time() - t0, 3)}
        self._log("consolidate", st)
        return st

    # ------------------------------------------------------------- reading
    def seek(self, query: str, helix_id: Optional[int] = None, limit: int = 8) -> list[tuple]:
        """
        O(log N) key seek: returns [(helix_id, page_index, record_offset, score, ToothRecord)] best first.
        Only the hit pages are touched.
        """
        rd = self.reader
        keys = seek_keys(query)
        if not keys:
            return []
        hits: dict[tuple[int, int], int] = {}
        for k in keys:
            for pid, off in rd.seek_key(k):
                hits[(pid, off)] = hits.get((pid, off), 0) + 1
        if not hits:
            return []
        ranked = sorted(hits.items(), key=lambda kv: -kv[1])
        out = []
        page_index_of: dict[int, tuple[int, int]] = {}
        for hid, pm in rd.pmap.items():
            for i, p in enumerate(pm.tolist()):
                if p != NO_PAGE:
                    page_index_of[int(p)] = (hid, i)
        for (pid, off), score in ranked:
            hid, pidx = page_index_of.get(pid, (None, None))
            if hid is None or (helix_id is not None and hid != helix_id):
                continue
            raw = bytes(rd.page_bytes(pid))
            from .teeth import decode_tooth
            base, payload, _ = decode_tooth(raw, off)
            rec = ToothRecord.from_bytes(base, payload)
            out.append((hid, pidx, off, score, rec))
            if len(out) >= limit:
                break
        return out

    def gear(self, domain: str, window: int = 256) -> FaceGear:
        return FaceGear(self, self.helix_for_domain(domain_id(domain)), window)

    def read_domain(self, domain: str, limit: int = 1_000_000) -> Iterator[ToothRecord]:
        g = self.gear(domain, window=limit)
        yield from g.ride(limit)

    def mesh_down(self, domain: str, query: str, depth: int = 3) -> list[tuple[str, ToothRecord]]:
        """Walk-down understanding: seek the query on the domain, then on each ancestor strand (one turn each)."""
        from .tower import ancestors
        out = []
        chain = [domain] + ancestors(domain)[:depth]
        for d in chain:
            try:
                hid = self.helix_for_domain(domain_id(d))
            except KeyError:
                continue
            for h in self.seek(query, helix_id=hid, limit=1):
                out.append((d, h[4]))
        return out

    def stats(self) -> dict:
        rd = self.reader
        per: dict[str, dict] = {}
        pending = 0
        total = 0
        for h in rd.helices.values():
            pages = [p for p in rd.helix_pages(h.helix_id) if p != NO_PAGE]
            per[h.name] = {"pages": len(pages), "records": h.frame_count}
            total += h.frame_count
        return {"path": str(self.path), "records": total, "staging": len(self.staging), "helices": per,
                "index_keys": int(rd._keys.size), "size": os.path.getsize(self.path)}


def _tooth_len(r: ToothRecord) -> bytes:
    from .teeth import encode_tooth
    return encode_tooth(r.base, r.to_bytes())


def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    from .ledger import NullLedger
    chk = chk or Check("memory")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_mem_"))
    mem = HelicalMemory(tmpdir / "knowledge.sff", ledger=NullLedger())
    chk("knowledge SFF created with 27 domain helices + staging", len(mem.reader.helices) == 28)
    r1 = mem.record("Theorem: for all n, n + 0 = n (Peano).", domain="math", base="A", ident="peano")
    r2 = mem.record("Induction technique: prove P(0), then P(n) -> P(n+1).", domain="math", base="T", ident="peano")
    r3 = mem.record("A major chord has frequency ratios 4:5:6; the perfect fifth is 3:2.", domain="music", ident="chord")
    r4 = mem.record("The kinetic energy of a 2 kg mass at 3 m/s is 9 J (measured).", domain="physics", ident="ke")
    st = mem.consolidate()
    chk("consolidate wrote pages and keys", st["records"] == 4 and st["pages"] == 3 and st["keys"] > 8, str(st))
    chk("overlap step paired A-T on shared ident", st["pairs_matched"] == 1)
    hits = mem.seek("perfect fifth ratio chord")
    chk("O(log N) seek finds the music record", hits and hits[0][4].ident == "chord" and hits[0][0] == mem.helix_for_domain(17), f"{len(hits)} hits")
    chk("seek misses cleanly", mem.seek("zzzz qqqq") == [])
    g = mem.gear("math", window=1)
    first = list(g.ride(1))
    chk("face gear rides one record at a time", len(first) == 1 and first[0].base == "A")
    second = list(g.ride(1))
    chk("face gear advances", len(second) == 1 and second[0].base == "T")
    bm = g.bookmark("start")
    g.seek(0, 0)
    chk("rewind to bookmark", g.rewind(bm) is None and g.page_index == bm.page_index)
    # streaming ingest of a file with mixed domains
    p = tmpdir / "corpus.txt"
    lines = []
    for i in range(400):
        lines.append(["the electron charge and the magnetic field force in physics", "a chord of notes with harmony and rhythm in the melody",
                      "the court and the judge apply the law and the statute", "prove the theorem by induction on the integer n"][i % 4])
    p.write_text("\n".join(lines))
    st2 = mem.ingest_file(p, chunk_bytes=2048)
    chk("file ingested in chunks (streaming)", st2["chunks"] >= 8 and set(st2["domains"]) <= {"physics", "music", "law_power", "math", "language"}, str(st2["domains"]))
    ms = mem.stats()
    chk("stats: records across helices", ms["records"] >= st2["chunks"] + 4 and ms["staging"] == 0)
    chk("mesh-down walks ancestors", len(mem.mesh_down("music", "chord harmony", depth=2)) >= 1)
    # persistence: reopen
    mem.close()
    mem2 = HelicalMemory(tmpdir / "knowledge.sff", ledger=NullLedger())
    chk("reopen keeps index + records", mem2.seek("induction")[0][4].base == "T" and mem2.stats()["records"] == ms["records"])
    mem2.close()
    # docx extraction (stdlib)
    d = tmpdir / "t.docx"
    with zipfile.ZipFile(d, "w") as z:
        z.writestr("word/document.xml", "<w:document><w:body><w:p><w:r><w:t>Hello docx world</w:t></w:r></w:p></w:body></w:document>")
    chk("docx text extraction", "Hello docx world" in extract_docx_text(d))
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
