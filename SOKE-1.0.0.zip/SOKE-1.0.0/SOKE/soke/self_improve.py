"""
soke.self_improve — the whole loop as one honest cycle: an advisor model builds a better version of itself
and PROVES it beats itself before anything is promoted.

One cycle:
  1. research  — pull an operator bias from techniques (offline library by default; the web only if you turned it
                 on). A bias, never a command.
  2. build     — a KIMI wide-MoE start spec from the model's own family (qwen2), else a dense preset. The extra
                 experts stream from disk; capacity on the SSD, not in RAM.
  3. tune      — soke.improve_engine drives grow/heal/tune moves, each kept ONLY if it lowers hold-out loss
                 (honest-null; most die).
  4. A/B       — score the PARENT (the base model alone) and the CHILD (the tuned result) on the SAME hold-out
                 probes. The child is a WIN only if it is lower by a margin. Otherwise it is a NULL, on the record.
  5. promote   — gated: only a WIN can be written, and only with your explicit consent. The model can neither
                 declare its own win (the A/B does) nor promote itself (you do).

    from soke.self_improve import SelfImproveCycle
    cyc = SelfImproveCycle(donors, ["math","language"], probes, advisor=llm)   # advisor optional
    rep = cyc.run(rounds=3)                 # rep.verdict in {"WIN","NULL"}, rep.parent_loss vs rep.child_loss
    cyc.promote("better.gguf", consent={"promote": True})   # refused unless rep.verdict == "WIN"
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .forge import Donor, ForgeSpec
from .forge_loop import Probes, Scorer
from .improve_engine import SelfImprover, pun_report
from .memguard import MemGuard


@dataclass
class CycleReport:
    verdict: str                     # "WIN" | "NULL"
    parent_loss: Optional[float]
    child_loss: Optional[float]
    delta: Optional[float]           # parent - child (positive = child better)
    n_kept: int = 0
    n_killed: int = 0
    rounds: int = 0
    techniques: list = field(default_factory=list)
    spec_summary: str = ""
    streaming: dict = field(default_factory=dict)
    eligible_promote: bool = False

    def brief(self) -> str:
        pl = f"{self.parent_loss:.4f}" if self.parent_loss is not None else "?"
        cl = f"{self.child_loss:.4f}" if self.child_loss is not None else "?"
        lines = [f"Self-improve cycle — verdict {self.verdict}.",
                 f"  parent (itself) hold-out {pl}  vs  child hold-out {cl}   (Δ {self.delta:+.4f})" if self.delta is not None else "  A/B not available",
                 f"  moves: {self.n_kept} kept, {self.n_killed} killed over {self.rounds} rounds."]
        if self.techniques:
            lines.append("  techniques biased in: " + ", ".join(self.techniques))
        if self.streaming:
            lines.append(f"  child: {self.spec_summary}  (top-{self.streaming.get('n_used')} of {self.streaming.get('n_expert')} experts stream per token)")
        lines.append("  " + ("WIN — eligible to promote (your consent still required)." if self.eligible_promote
                             else "NULL — not promoted; the child did not beat itself. That is the gate working."))
        return "\n".join(lines)


def ab_verdict(parent_loss: Optional[float], child_loss: Optional[float], margin: float = 1e-4) -> str:
    """WIN only if the child's hold-out loss is below the parent's by at least `margin`. Any non-finite -> NULL."""
    import math
    if parent_loss is None or child_loss is None or not (math.isfinite(parent_loss) and math.isfinite(child_loss)):
        return "NULL"
    return "WIN" if child_loss < parent_loss - margin else "NULL"


class SelfImproveCycle:
    def __init__(self, donors: list[Donor], topics: list[str], probes: Probes, advisor=None, base: Optional[str] = None,
                 kimi: bool = True, n_experts: int = 8, research=None, gated: bool = True, memguard: Optional[MemGuard] = None,
                 ledger=None, research_db=None, min_gain: float = 0.001, win_margin: float = 1e-4, seed: int = 0):
        if not donors:
            raise ValueError("no donors")
        self.mg = memguard or MemGuard()
        self.donors = donors
        self.topics = list(topics)
        self.probes = probes
        self.win_margin = win_margin
        self.base_id = base or donors[0].id
        self.base_donor = next((d for d in donors if d.id == self.base_id), donors[0])

        # 1. research -> an operator bias (offline library by default; the web only if `research` is online)
        self.techniques: list = []
        op_bias = None
        try:
            eng = research
            if eng is None:
                from .research_engine import ResearchEngine
                eng = ResearchEngine(online=False)          # offline: no network, built-in library
            rep = eng.research("improve a language model: more capable, more efficient, better tuned", topics=self.topics)
            op_bias = rep.op_weights or None
            self.techniques = [t["name"] for t in rep.techniques]
        except Exception:
            op_bias = None

        # 2. build -> a KIMI wide-MoE start spec if the family allows it, else a preset (SelfImprover picks it)
        start_spec = None
        if kimi:
            try:
                from .multimodel import kimi_moe_spec
                start_spec = kimi_moe_spec(donors, self.topics, n_experts=n_experts, n_used=2, base=self.base_id, seed=seed)
            except Exception:
                start_spec = None                            # not a qwen family (or too few donors) -> preset path

        self.imp = SelfImprover(donors, topics, probes, advisor=advisor, base=self.base_id, start_spec=start_spec,
                                op_bias=op_bias, gated=gated, memguard=self.mg, ledger=ledger, research_db=research_db,
                                min_gain=min_gain, priority_topic=None, seed=seed)
        self.report: Optional[CycleReport] = None

    def parent_loss(self) -> Optional[float]:
        """Score the PARENT — the base model alone, as a plain dense model — on the same hold-out probes, with a
        fresh scorer so the improve loop's own caches are untouched."""
        try:
            parent_spec = ForgeSpec.preset("dense", [self.base_donor], self.topics, base=self.base_id)
            sc = Scorer(self.probes, self.mg).score(parent_spec, "holdout")
            return float(sc["total"])
        except Exception:
            return None

    def run(self, rounds: int = 3, trials_per_round: int = 8, prefer_cycle=("tuned", "complex", "efficient")) -> CycleReport:
        """Tune the child for `rounds` rounds (cycling the emphasis), then run the parent-vs-child A/B."""
        for i in range(max(1, rounds)):
            self.imp.prefer = prefer_cycle[i % len(prefer_cycle)]
            self.imp.improve(rounds=1, trials_per_round=trials_per_round)
        pr = pun_report(self.imp.trainer, self.imp.baseline_loss)
        parent = self.parent_loss()
        child = self.imp.trainer.best_hold_total
        child = float(child) if child == child and abs(child) != float("inf") else None
        verdict = ab_verdict(parent, child, self.win_margin)
        sp = self.imp.improved_spec()
        self.report = CycleReport(
            verdict=verdict, parent_loss=parent, child_loss=child,
            delta=(parent - child) if (parent is not None and child is not None) else None,
            n_kept=pr["n_kept"], n_killed=pr["n_killed"], rounds=max(1, rounds), techniques=self.techniques,
            spec_summary=sp.summary(), streaming={"n_expert": sp.n_expert, "n_used": int(sp.d.get("n_used", 0))},
            eligible_promote=(verdict == "WIN"))
        return self.report

    def promote(self, out_path, consent: Optional[dict] = None) -> dict:
        """Write the child — but ONLY if the A/B said WIN and you consent. A NULL is never promoted (honest-null:
        we do not ship a model that failed to beat itself)."""
        if self.report is None:
            return {"written": False, "reason": "run the cycle first"}
        if self.report.verdict != "WIN":
            return {"written": False, "reason": f"verdict is {self.report.verdict} — the child did not beat the parent on hold-out, so it is not promoted"}
        return self.imp.export(out_path, consent=consent, use_holdout_best=True)


# ==========================================================================
# self-test
# ==========================================================================
def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    from .forge import _synthetic_family
    from .llm_engine import LLM
    from .rng import Rng
    chk = chk or Check("self_improve")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_selfimp_"))

    # --- the A/B verdict is a pure, honest rule
    chk("A/B: a clear improvement is a WIN", ab_verdict(1.0, 0.9) == "WIN")
    chk("A/B: no improvement is a NULL", ab_verdict(1.0, 1.0) == "NULL" and ab_verdict(1.0, 1.05) == "NULL")
    chk("A/B: a non-finite loss is a NULL (never a false win)", ab_verdict(1.0, float("nan")) == "NULL" and ab_verdict(None, 0.5) == "NULL")

    donors = _synthetic_family(tmpdir, 3, arch="qwen2")
    topics = ["math", "language"]
    rng = Rng(3); V = 96
    probes = Probes(topics=topics,
                    train={t: [list(rng.integers(0, V, 24)) for _ in range(3)] for t in topics},
                    holdout={t: [list(rng.integers(0, V, 24)) for _ in range(2)] for t in topics}, n_tokens=1)

    # --- the cycle runs end to end: research bias + KIMI build + tune + a real parent-vs-child A/B
    cyc = SelfImproveCycle(donors, topics, probes, kimi=True, n_experts=6, min_gain=0.0, seed=2)
    rep = cyc.run(rounds=2, trials_per_round=6)
    import math as _m
    chk("cycle produces a finite parent-vs-child A/B", rep.parent_loss is not None and rep.child_loss is not None
        and _m.isfinite(rep.parent_loss) and _m.isfinite(rep.child_loss), f"parent {rep.parent_loss} child {rep.child_loss}")
    chk("cycle verdict matches the A/B rule on its own numbers", rep.verdict == ab_verdict(rep.parent_loss, rep.child_loss, cyc.win_margin))
    chk("cycle built a KIMI wide-MoE child (6 experts, top-2 streamed)", rep.streaming.get("n_expert") == 6 and rep.streaming.get("n_used") == 2, str(rep.streaming))
    chk("cycle used the offline technique library as a bias (no network)", isinstance(rep.techniques, list))

    # --- honest-null: an impossible bar keeps nothing, so the child can't beat the parent -> NULL, no promote
    strict = SelfImproveCycle(donors, topics, probes, kimi=True, n_experts=6, min_gain=1e3, seed=4)
    rep2 = strict.run(rounds=1, trials_per_round=6)
    chk("honest-null: with nothing kept, the cycle does not manufacture a win", rep2.n_kept == 0)
    ref = strict.promote(tmpdir / "no.gguf", consent={"promote": True})
    if rep2.verdict != "WIN":
        chk("gated: a NULL verdict is never promoted, even with consent", ref["written"] is False and not (tmpdir / "no.gguf").exists())
    else:
        chk("gated: a WIN verdict promotes with consent", ref.get("written") is True)

    # --- promotion gate on a forced WIN: consent required, and the written model loads
    win = SelfImproveCycle(donors, topics, probes, kimi=True, n_experts=6, min_gain=0.0, seed=5)
    win.run(rounds=1, trials_per_round=4)
    win.report.verdict = "WIN"; win.report.eligible_promote = True         # force the WIN branch to test the gate
    out = tmpdir / "win.gguf"
    chk("gated: a WIN without consent is not written", win.promote(out, consent=None)["written"] is False and not out.exists())
    okw = win.promote(out, consent={"promote": True})
    chk("gated: a WIN with consent writes a servable model", okw.get("written") is True and out.exists())
    m = LLM(out, memguard=win.mg); good = m.cfg.n_layer >= 1; m.close()
    chk("the promoted child loads and serves", good)
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
