"""
soke.improve_engine — the advisor drives the forge.

A loaded advisor LLM (any runnable GGUF: llama/mistral/qwen2/qwen2moe/gemma/gemma2) is put in charge of building
a MORE COMPLEX, MORE EFFICIENT, BETTER-TUNED version of itself or another model. It does NOT reimplement the
learning loop — it steers the one SOKE already has (soke.forge_loop.ForgeTrainer):

    complex   : grow ops (add_expert, dup_layer, extrapolate past the donors)
    efficient : the output is an MoE served by the streaming WeightStore — only the n_used experts of each token
                are read from disk, so the extra experts ("smaller neurons") cost disk, not RAM; heal ops
                (drop_expert, drop_layer) trim what does not earn its place
    tuned     : every candidate is scored by the real forward pass on held-out probes and kept ONLY if it lowers
                the loss; everything else is a null, logged and never softened (the PUN ledger discipline)

The advisor's only power is the PROPOSAL: it tilts which operators are tried (op_weights) and which topic is the
priority. It can never loosen the accept bar, change its own permissions, or promote a model — the honest-null
gate is the forge's, and export is consent-gated. This mirrors the trading suite: the model may bid, it may not
close, and it cannot change stage.

    from soke.improve_engine import SelfImprover
    imp = SelfImprover.from_advisor("advisor.gguf", ["math","language"], probes, extra_donor_paths=["sibling.gguf"])
    rep = imp.improve(rounds=3, trials_per_round=20)      # PUN report: kept vs killed, most die = success
    imp.export("better.gguf", consent={"promote": True})  # refused unless you consent
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np

from .diagnose import diagnose_build, suggest_edits
from .forge import Donor, ForgeSpec, assemble, describe_gguf
from .forge_loop import DEFAULT_OP_WEIGHTS, OPERATORS, ForgeTrainer, Probes
from .memguard import MemGuard

# operators grouped by what the user asked for. "complex" grows capacity; "efficient" trims it; "tuned" reshapes.
GROW_OPS = ("add_expert", "dup_layer", "extrapolate")
HEAL_OPS = ("drop_expert", "drop_layer")
TUNE_OPS = ("blend_expert", "swap_expert", "task_attn", "swap_attn", "swap_shared", "gate_scale", "swap_topics")


@dataclass
class AdvisorPlan:
    """A round's steering: operator weights, the priority topic, and where it came from."""
    op_weights: dict
    priority_topic: Optional[str] = None
    rationale: str = ""
    source: str = "diagnostic"                       # "diagnostic" | "advisor-llm"
    findings: list = field(default_factory=list)
    fixes: list = field(default_factory=list)


class _DiagCtx:
    """The minimal surface soke.diagnose reads: spec / trainer / probes / behavior / donors."""
    def __init__(self, spec, trainer, probes, donors, behavior=None):
        self.spec = spec
        self.trainer = trainer
        self.probes = probes
        self.donors = donors
        self.behavior = behavior


def parse_advisor_ranking(text: str, operators=OPERATORS) -> dict:
    """Turn free advisor text into operator weights. Every operator named (as `blend_expert` or `blend expert`)
    gets a weight by order of first appearance: first named = highest. Deterministic; unnamed operators are absent."""
    low = (text or "").lower()
    hits = []
    for op in operators:
        pos = min((p for p in (low.find(op), low.find(op.replace("_", " "))) if p >= 0), default=-1)
        if pos >= 0:
            hits.append((pos, op))
    hits.sort()
    n = len(hits)
    return {op: float(n - i) for i, (_, op) in enumerate(hits)}


def diagnostic_plan(ctx: _DiagCtx, prefer: str = "tuned", allow_grow: bool = True, allow_heal: bool = True) -> AdvisorPlan:
    """Deterministic backbone: start from the forge defaults, tilt toward the requested emphasis, aim the priority
    at the worst-scoring topic, and attach soke.diagnose's findings/fixes so the chat can print them."""
    w = dict(DEFAULT_OP_WEIGHTS)
    boost = {"complex": GROW_OPS, "efficient": HEAL_OPS, "tuned": TUNE_OPS}.get(prefer, TUNE_OPS)
    for op in boost:
        w[op] = w.get(op, 0.0) + 3.0
    if not allow_grow:
        for op in GROW_OPS:
            w[op] = 0.0
    if not allow_heal:
        for op in HEAL_OPS:
            w[op] = 0.0
    # priority = the worst topic the trainer has measured so far (NE vigilance), else None
    pri = None
    tr = ctx.trainer
    if tr is not None and getattr(tr, "score", None) and tr.score.get("topics"):
        pri = max(tr.score["topics"], key=tr.score["topics"].get)
    diag = diagnose_build(ctx)
    return AdvisorPlan(op_weights=w, priority_topic=pri, source="diagnostic",
                       rationale="; ".join(suggest_edits(ctx)[:3]), findings=diag["findings"], fixes=diag["fixes"])


def advisor_plan(advisor, ctx: _DiagCtx, prefer: str = "tuned", allow_grow: bool = True, allow_heal: bool = True,
                 max_new: int = 96) -> AdvisorPlan:
    """The diagnostic plan, then (if an advisor LLM is given) let it re-tilt the weights. The advisor only
    MULTIPLIES the backbone weights by what it names — it can never zero the loop or loosen the gate. Any failure
    in the advisor call falls back to the pure diagnostic plan."""
    base = diagnostic_plan(ctx, prefer=prefer, allow_grow=allow_grow, allow_heal=allow_heal)
    if advisor is None:
        return base
    try:
        ops = [k for k, v in base.op_weights.items() if v > 0]
        prompt = ("You tune a mixture-of-experts model. Findings: " + " ".join(base.findings[:3]) +
                  " Available moves: " + ", ".join(ops) +
                  ". List the 3 best moves to try next, best first, by their exact names.")
        txt, _ = advisor.generate(prompt, max_new=max_new, temperature=0.0, chat=True)
        ranked = parse_advisor_ranking(txt, ops)
        if ranked:
            w = dict(base.op_weights)
            for op, r in ranked.items():                 # multiply, never replace: the backbone floor stays
                w[op] = w.get(op, 0.0) * (1.0 + r)
            return AdvisorPlan(op_weights=w, priority_topic=base.priority_topic, source="advisor-llm",
                               rationale="advisor ranked: " + ", ".join(k for k in ranked), findings=base.findings, fixes=base.fixes)
    except Exception:
        pass
    return base


def pun_report(trainer: ForgeTrainer, baseline_loss: Optional[float] = None) -> dict:
    """The keep/kill ledger, honest-null style: every trial is kept (it lowered the loss) or killed (a null, on
    the record with its reason). Most die — that is the loop working, not failing."""
    kept, killed = [], []
    for t in trainer.trials:
        fin = t.after == t.after                          # not NaN
        rec = {"op": t.op, "desc": t.desc, "before": round(t.before, 5), "after": (round(t.after, 5) if fin else None),
               "delta": (round(t.before - t.after, 5) if fin else None), "holdout": t.holdout}
        (kept if t.accepted else killed).append(rec)
    return {"n_kept": len(kept), "n_killed": len(killed), "kept": kept, "killed": killed,
            "baseline_loss": (round(baseline_loss, 5) if baseline_loss is not None else None),
            "final_loss": (round(trainer.score["total"], 5) if trainer.score else None),
            "best_holdout": (round(trainer.best_hold_total, 5) if np.isfinite(trainer.best_hold_total) else None),
            "ops": trainer.op_stats}


class SelfImprover:
    """Drives one ForgeTrainer across several rounds, re-tilting the proposal each round from the advisor's plan."""

    def __init__(self, donors: list[Donor], topics: list[str], probes: Probes, advisor=None,
                 preset: Optional[str] = None, base: Optional[str] = None, prefer: str = "tuned",
                 allow_grow: bool = True, allow_heal: bool = True, min_gain: float = 0.001, priority_topic: Optional[str] = None,
                 tol_priority: float = 0.02, memguard: Optional[MemGuard] = None, ledger=None, research_db=None,
                 seed: int = 0, gated: bool = True, behavior=None, on_event=None, op_bias: Optional[dict] = None,
                 start_spec: Optional[ForgeSpec] = None):
        if not donors:
            raise ValueError("no donors — give the advisor GGUF (and optionally same-shape siblings) as donors")
        self.mg = memguard or MemGuard()
        self.advisor = advisor
        self.prefer = prefer
        self.allow_grow = allow_grow
        self.allow_heal = allow_heal
        self.gated = gated
        self.op_bias = dict(op_bias) if op_bias else None    # e.g. from research_engine: op -> extra multiplier
        self.donors = donors
        self.topics = list(topics)
        self.probes = probes
        # an MoE preset when the family allows it (qwen2 family -> qwen2moe): experts are the streamed "small neurons".
        fam = donors[0].arch
        if preset is None:
            preset = "all-routed" if fam in ("qwen2", "qwen2moe") else "dense"
        # start_spec (e.g. a KIMI wide-MoE from multimodel.kimi_moe_spec) is used verbatim; else a preset
        self.preset_kind = start_spec.d.get("kind", preset) if start_spec is not None else preset
        self.spec0 = start_spec.copy() if start_spec is not None else ForgeSpec.preset(preset, donors, topics, base=base, n_used=2, seed=seed)
        self.trainer = ForgeTrainer(self.spec0.copy(), probes, memguard=self.mg, ledger=ledger, research_db=research_db,
                                    on_event=on_event, priority_topic=priority_topic, tol_priority=tol_priority,
                                    min_gain=min_gain, seed=seed, behavior=behavior)
        self.baseline_loss: Optional[float] = None
        self.plans: list[AdvisorPlan] = []

    @staticmethod
    def from_advisor(advisor_path, topics: list[str], probes: Probes, extra_donor_paths: Optional[list] = None,
                     advisor=None, **kw) -> "SelfImprover":
        """Build from the advisor GGUF on disk (its own donor) plus optional same-shape siblings to blend with.
        `advisor` (a loaded soke.llm_engine.LLM) is the model that proposes; if None the loop runs on the
        diagnostic backbone alone."""
        donors = [describe_gguf(advisor_path, label="advisor", donor_id="A")]
        for i, p in enumerate(extra_donor_paths or []):
            donors.append(describe_gguf(p, label=f"sibling{i}", donor_id=f"S{i}"))
        return SelfImprover(donors, topics, probes, advisor=advisor, **kw)

    def _ctx(self) -> _DiagCtx:
        return _DiagCtx(self.trainer.spec, self.trainer, self.probes, self.donors, behavior=self.trainer.behavior)

    def plan_round(self) -> AdvisorPlan:
        return advisor_plan(self.advisor, self._ctx(), prefer=self.prefer, allow_grow=self.allow_grow, allow_heal=self.allow_heal)

    def improve(self, rounds: int = 1, trials_per_round: int = 20, time_budget_s: Optional[float] = None) -> dict:
        """Run the loop for `rounds` rounds, re-planning between rounds. Returns the PUN report."""
        tr = self.trainer
        if tr.score is None:
            tr.baseline()
            self.baseline_loss = tr.hold["total"] if tr.hold else tr.score["total"]
        for _ in range(max(1, rounds)):
            plan = self.plan_round()
            self.plans.append(plan)
            w = {k: max(0.0, float(v)) for k, v in plan.op_weights.items()}
            if self.op_bias:                               # research-derived bias: tilt WHICH ops are tried
                for op, mult in self.op_bias.items():
                    w[op] = w.get(op, 0.0) * (1.0 + max(0.0, float(mult)))
            if sum(w.values()) <= 0:                       # never leave the loop with nothing to try
                w = dict(DEFAULT_OP_WEIGHTS)
            tr.weights = w
            if plan.priority_topic and plan.priority_topic in self.probes.topics:
                tr.priority = plan.priority_topic
            tr.run(max_trials=trials_per_round, time_budget_s=time_budget_s)
        return pun_report(tr, self.baseline_loss)

    def improved_spec(self) -> ForgeSpec:
        """The best held-out template — the version that actually earned its keep."""
        return self.trainer.best_holdout_spec

    def export(self, out_path, consent: Optional[dict] = None, use_holdout_best: bool = True) -> dict:
        """Write the improved model. Consent-gated: promoting a model is an act, not a bid. Refused unless
        `consent` is truthy (in the GUI this is your explicit unlock). The written GGUF is an MoE served by the
        streaming store — only the used experts of each token are read from disk."""
        if self.gated and not (consent and (consent.get("promote") or consent.get("store"))):
            return {"written": False, "reason": "promotion needs your consent (consent={'promote': True}); "
                    "the model may propose and be verified, but it cannot promote itself"}
        spec = self.improved_spec() if use_holdout_best else self.trainer.spec
        res = assemble(spec, out_path, memguard=self.mg, ledger=self.trainer.ledger, behavior=self.trainer.behavior,
                       clone_consent=consent)
        res["written"] = True
        res["streaming"] = {"n_expert": spec.n_expert, "n_used": int(spec.d.get("n_used", 0)),
                            "note": "served with resident='stream': only n_used experts per token are read from disk"}
        return res


# ==========================================================================
# self-test
# ==========================================================================
def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    from .forge import _synthetic_family
    from .llm_engine import LLM
    from .rng import Rng
    chk = chk or Check("improve_engine")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_improve_"))

    # --- pure functions: the advisor's proposal, deterministic and gate-free
    r = parse_advisor_ranking("Try blend_expert first, then add expert, then a swap attn.")
    chk("advisor ranking: named moves get descending weights, first named highest",
        r.get("blend_expert", 0) > r.get("add_expert", 0) > r.get("swap_attn", 0) > 0 and "drop_layer" not in r, str(r))
    chk("advisor ranking: nothing named -> empty (falls back to the backbone)", parse_advisor_ranking("no moves here") == {})

    donors = _synthetic_family(tmpdir, 3, arch="qwen2")           # same-shape family, MoE-capable
    topics = ["math", "language"]
    rng = Rng(3); V = 96
    probes = Probes(topics=topics,
                    train={t: [list(rng.integers(0, V, 24)) for _ in range(4)] for t in topics},
                    holdout={t: [list(rng.integers(0, V, 24)) for _ in range(2)] for t in topics},
                    n_tokens=24 * 6 * len(topics))

    # single-donor diagnosis leads with "add a donor" (honest: nothing to blend)
    solo = SelfImprover([donors[0]], topics, probes, min_gain=0.0, priority_topic=None, seed=1)
    solo.trainer.baseline()
    plan1 = diagnostic_plan(solo._ctx(), prefer="complex")
    chk("diagnostic plan: 1-donor build is told to add a donor first", any("donor" in f.lower() for f in plan1.fixes))
    chk("diagnostic plan: 'complex' emphasis raises a grow op above its default", plan1.op_weights["add_expert"] > DEFAULT_OP_WEIGHTS["add_expert"])

    # --- honest-null: an impossible accept bar keeps NOTHING, and every trial is logged as a null
    from .meta_optimizer import ResearchDB
    db = ResearchDB(tmpdir / "research.db")
    strict = SelfImprover(donors, topics, probes, min_gain=1e3, priority_topic=None, seed=2, research_db=db)
    rep = strict.improve(rounds=1, trials_per_round=12)
    chk("honest-null: an impossible min_gain keeps 0 and kills all", rep["n_kept"] == 0 and rep["n_killed"] == 12, f"kept {rep['n_kept']} killed {rep['n_killed']}")
    chk("honest-null: the best held-out template never regressed past baseline",
        rep["best_holdout"] is not None and rep["best_holdout"] <= (rep["baseline_loss"] or 0) + 1e-9)
    exps = db.experiments(limit=50)
    chk("PUN ledger: every killed trial is recorded, none marked success", len(exps) >= 12 and not any(e.get("success") for e in exps))

    # --- the gate never accepts a worsening move (min_gain=0 -> after <= before for every kept trial)
    tuned = SelfImprover(donors, topics, probes, min_gain=0.0, priority_topic=None, seed=5)
    rep2 = tuned.improve(rounds=2, trials_per_round=10)
    bad = [k for k in rep2["kept"] if k["delta"] is not None and k["delta"] < -1e-12]
    chk("gate: no accepted move ever raised the loss (bid, not close)", not bad, f"kept {rep2['n_kept']}, regressions {len(bad)}")

    # --- MORE COMPLEX + streamed neurons: force a grow, confirm experts increase and n_used < n_expert
    grow = SelfImprover(donors, topics, probes, min_gain=-1e9, priority_topic=None, seed=4, allow_grow=True)
    ne0 = grow.trainer.spec.n_expert
    grow.trainer.weights = {"add_expert": 1.0}                    # force the grow op
    grow.trainer.run(max_trials=1)
    ne1 = grow.trainer.spec.n_expert
    chk("complex: a kept grow move adds an expert (a new streamed neuron)", ne1 == ne0 + 1, f"{ne0} -> {ne1}")
    served = LLM(store=__import__("soke.forge", fromlist=["SpecStore"]).SpecStore(grow.trainer.spec, grow.mg), memguard=grow.mg)
    chk("efficient: the grown model is MoE with n_used < n_expert, so only some experts stream per token",
        served.cfg.n_expert == ne1 and served.cfg.n_expert_used < served.cfg.n_expert, f"n_expert {served.cfg.n_expert}, used {served.cfg.n_expert_used}")
    rr = served.nll_batch([[1, 2, 3, 4, 5, 6, 7, 8]])            # it actually runs, streamed
    chk("efficient: the streamed MoE runs a forward pass", np.isfinite(rr["nll"]))
    served.close()

    # --- promotion is consent-gated: refused without consent, written with it, and the file loads
    out = tmpdir / "better.gguf"
    ref = tuned.export(out, consent=None)
    chk("gated: export without consent writes nothing (the model can't promote itself)", ref["written"] is False and not out.exists())
    ok = tuned.export(out, consent={"promote": True})
    chk("gated: export with consent writes a servable model", ok["written"] and out.exists() and ok["streaming"]["n_expert"] >= 2)
    m = LLM(out, memguard=tuned.mg); good = m.cfg.n_layer >= 1; m.close()
    chk("gated: the promoted model loads and reports its layers", good)

    # --- research bias hook: an op the research feed favours is up-weighted in the round's plan (still gated)
    biased = SelfImprover(donors, topics, probes, min_gain=0.0, priority_topic=None, seed=6, op_bias={"add_expert": 5.0})
    biased.improve(rounds=1, trials_per_round=0)          # sets the (biased) plan weights without running trials
    chk("research op_bias raises the favoured operator's proposal weight (bid only — the gate still decides)",
        biased.trainer.weights["add_expert"] > DEFAULT_OP_WEIGHTS["add_expert"], f"add_expert weight {biased.trainer.weights['add_expert']}")
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
