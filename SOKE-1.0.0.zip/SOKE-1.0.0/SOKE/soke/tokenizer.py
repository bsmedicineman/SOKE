"""
soke.tokenizer — GGUF tokenizers in the standard library (no sentencepiece, no regex module).

Two families, both read straight from a GGUF's `tokenizer.ggml.*` keys:

  * gpt2  — byte-level BPE (Qwen2, Llama 3, GPT-2, most modern models). Pre-tokenization follows the
            model's `tokenizer.ggml.pre` pattern (qwen2 / llama-bpe / default) implemented as a hand
            scanner over Unicode categories (Python's `re` has no \\p{L}); then GPT-2 byte-to-unicode
            mapping and rank-ordered merges from `tokenizer.ggml.merges`.
  * llama — SentencePiece-style (Llama 1/2, Mistral, Gemma): ' ' -> '▁', greedy bigram merges by
            `tokenizer.ggml.scores` (highest score first, ties leftmost), byte fallback <0xNN>.

VERIFIED against llama.cpp's own tokenizer test vectors (models/ggml-vocab-{qwen2,llama-bpe,llama-spm}
.gguf.inp/.out): every case identical (see verify_suite).
"""
from __future__ import annotations

import heapq
import unicodedata
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------- byte <-> unicode (GPT-2)
def _bytes_to_unicode() -> dict[int, str]:
    bs = list(range(ord("!"), ord("~") + 1)) + list(range(ord("¡"), ord("¬") + 1)) + list(range(ord("®"), ord("ÿ") + 1))
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return {b: chr(c) for b, c in zip(bs, cs)}


BYTE_TO_UNI = _bytes_to_unicode()
UNI_TO_BYTE = {v: k for k, v in BYTE_TO_UNI.items()}


def _is_letter(ch: str) -> bool:
    return unicodedata.category(ch).startswith("L")


def _is_number(ch: str) -> bool:
    return unicodedata.category(ch).startswith("N")


def _is_space(ch: str) -> bool:
    return ch.isspace()


# ---------------------------------------------------------------- pre-tokenizers (regex semantics by hand)
def pretokenize(text: str, pre: str) -> list[str]:
    """Split text into the words BPE merges never cross, following the model's pre-tokenizer pattern."""
    if pre in ("qwen2", "llama-bpe", "llama3", "deepseek-llm", "deepseek-coder", "smaug-bpe", "gpt-4o", "chatglm-bpe",
               "falcon3", "megrez", "tekken", "minerva-7b", "seed-coder", "hunyuan", "llama4", "pixtral", "gpt2-pre"):
        digits_max = 1 if pre in ("qwen2", "gpt2-pre") else 3
        return _split_llama3_like(text, digits_max)
    return _split_gpt2(text)


def _split_llama3_like(text: str, digits_max: int) -> list[str]:
    """(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\\r\\n\\p{L}\\p{N}]?\\p{L}+|\\p{N}{1,k}| ?[^\\s\\p{L}\\p{N}]+[\\r\\n]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+"""
    out: list[str] = []
    n = len(text)
    i = 0
    while i < n:
        ch = text[i]
        # 1. contractions
        if ch == "'" and i + 1 < n:
            low2 = text[i + 1:i + 3].lower()
            if low2 in ("re", "ve", "ll"):
                out.append(text[i:i + 3]); i += 3; continue
            if text[i + 1].lower() in ("s", "t", "m", "d"):
                out.append(text[i:i + 2]); i += 2; continue
        # 2. optional non-letter/number/newline char followed by letters
        j = i
        if ch not in "\r\n" and not _is_letter(ch) and not _is_number(ch):
            j = i + 1
        if j < n and _is_letter(text[j]):
            k = j
            while k < n and _is_letter(text[k]):
                k += 1
            out.append(text[i:k]); i = k; continue
        # 3. numbers (1..digits_max)
        if _is_number(ch):
            k = i
            while k < n and k - i < digits_max and _is_number(text[k]):
                k += 1
            out.append(text[i:k]); i = k; continue
        # 4. optional space + punctuation run + trailing newlines
        j = i + 1 if ch == " " else i
        if j < n and not _is_space(text[j]) and not _is_letter(text[j]) and not _is_number(text[j]):
            k = j
            while k < n and not _is_space(text[k]) and not _is_letter(text[k]) and not _is_number(text[k]):
                k += 1
            while k < n and text[k] in "\r\n":
                k += 1
            out.append(text[i:k]); i = k; continue
        # 5-7. whitespace
        if _is_space(ch):
            k = i
            while k < n and _is_space(text[k]):
                k += 1
            run = text[i:k]
            # 5. \s*[\r\n]+ : the run up to (and including) its last newline
            last_nl = max(run.rfind("\r"), run.rfind("\n"))
            if last_nl >= 0:
                out.append(run[:last_nl + 1]); i += last_nl + 1; continue
            # 6. \s+(?!\S): all of it if at end of text, else all but the last char (which attaches forward)
            if k >= n:
                out.append(run); i = k; continue
            if len(run) > 1:
                out.append(run[:-1]); i += len(run) - 1; continue
            # 7. \s+ : single whitespace char followed by non-space (a letter case was taken by rule 2 with ' ' prefix;
            #    this is e.g. a space before a digit or before a non-space that rule 4 did not take)
            out.append(run); i = k; continue
        # fallback: single char (should not happen)
        out.append(ch); i += 1
    return out


def _split_gpt2(text: str) -> list[str]:
    """'s|'t|'re|'ve|'m|'ll|'d| ?\\p{L}+| ?\\p{N}+| ?[^\\s\\p{L}\\p{N}]+|\\s+(?!\\S)|\\s+  (case-sensitive contractions)"""
    out: list[str] = []
    n = len(text)
    i = 0
    while i < n:
        ch = text[i]
        if ch == "'" and i + 1 < n:
            if text[i + 1:i + 3] in ("re", "ve", "ll"):
                out.append(text[i:i + 3]); i += 3; continue
            if text[i + 1] in ("s", "t", "m", "d"):
                out.append(text[i:i + 2]); i += 2; continue
        j = i + 1 if ch == " " else i
        if j < n and _is_letter(text[j]):
            k = j
            while k < n and _is_letter(text[k]):
                k += 1
            out.append(text[i:k]); i = k; continue
        if j < n and _is_number(text[j]):
            k = j
            while k < n and _is_number(text[k]):
                k += 1
            out.append(text[i:k]); i = k; continue
        if j < n and not _is_space(text[j]) and not _is_letter(text[j]) and not _is_number(text[j]):
            k = j
            while k < n and not _is_space(text[k]) and not _is_letter(text[k]) and not _is_number(text[k]):
                k += 1
            out.append(text[i:k]); i = k; continue
        if _is_space(ch):
            k = i
            while k < n and _is_space(text[k]):
                k += 1
            if k >= n or k - i == 1:
                out.append(text[i:k]); i = k; continue
            out.append(text[i:k - 1]); i = k - 1; continue
        out.append(ch); i += 1
    return out


# ---------------------------------------------------------------- the tokenizer
class Tokenizer:
    """Built from a GGUF's kv dict (GGUFReader(...).kv). Byte-level BPE or SentencePiece by `tokenizer.ggml.model`."""

    def __init__(self, kv: dict):
        self.model = str(kv.get("tokenizer.ggml.model", "gpt2"))
        self.pre = str(kv.get("tokenizer.ggml.pre", "default"))
        self.tokens: list[str] = list(kv.get("tokenizer.ggml.tokens", []))
        self.types: list[int] = list(kv.get("tokenizer.ggml.token_type", [1] * len(self.tokens)))
        self.scores: list[float] = list(kv.get("tokenizer.ggml.scores", []))
        self.bos_id = kv.get("tokenizer.ggml.bos_token_id")
        self.eos_id = kv.get("tokenizer.ggml.eos_token_id")
        self.unk_id = kv.get("tokenizer.ggml.unknown_token_id")
        self.pad_id = kv.get("tokenizer.ggml.padding_token_id")
        self.add_bos = bool(kv.get("tokenizer.ggml.add_bos_token", self.model == "llama"))
        self.add_eos = bool(kv.get("tokenizer.ggml.add_eos_token", False))
        self.add_space_prefix = bool(kv.get("tokenizer.ggml.add_space_prefix", True))
        self.chat_template = kv.get("tokenizer.chat_template")
        self.vocab: dict[str, int] = {}
        for i, t in enumerate(self.tokens):
            self.vocab.setdefault(t, i)
        # special / control tokens (type 3 = CONTROL, 4 = USER_DEFINED) are matched literally in the input
        self.special: dict[str, int] = {t: i for i, t in enumerate(self.tokens) if self.types[i] in (3, 4) and t}
        self._special_sorted = sorted(self.special, key=len, reverse=True)
        if self.model == "gpt2":
            merges = kv.get("tokenizer.ggml.merges", [])
            self.ranks: dict[tuple[str, str], int] = {}
            for r, m in enumerate(merges):
                a, _, b = m.partition(" ")
                self.ranks[(a, b)] = r
        self._cache: dict[str, list[int]] = {}

    @property
    def n_vocab(self) -> int:
        return len(self.tokens)

    # ------------------------------------------------------------- encode
    def encode(self, text: str, add_special: bool = True, parse_special: bool = True) -> list[int]:
        ids: list[int] = []
        if add_special and self.add_bos and self.bos_id is not None:
            ids.append(int(self.bos_id))
        first = True
        for kind, frag in self._partition(text, parse_special):
            if kind == "special":
                ids.append(self.special[frag])
                first = False
                continue
            if not frag:
                continue
            if self.model == "gpt2":
                ids.extend(self._encode_bpe(frag))
            else:
                ids.extend(self._encode_spm(frag, first))
            first = False
        if add_special and self.add_eos and self.eos_id is not None:
            ids.append(int(self.eos_id))
        return ids

    def _partition(self, text: str, parse_special: bool) -> list[tuple[str, str]]:
        if not parse_special or not self.special:
            return [("text", text)]
        out: list[tuple[str, str]] = []
        i = 0
        buf = ""
        while i < len(text):
            hit = None
            for sp in self._special_sorted:
                if text.startswith(sp, i):
                    hit = sp
                    break
            if hit:
                if buf:
                    out.append(("text", buf)); buf = ""
                out.append(("special", hit)); i += len(hit)
            else:
                buf += text[i]; i += 1
        if buf:
            out.append(("text", buf))
        return out

    def _encode_bpe(self, text: str) -> list[int]:
        ids: list[int] = []
        for word in pretokenize(text, self.pre):
            if word in self._cache:
                ids.extend(self._cache[word]); continue
            sym = [BYTE_TO_UNI[b] for b in word.encode("utf-8")]
            whole = "".join(sym)
            if whole in self.vocab:                 # llama.cpp / tiktoken: a whole pre-token that is a vocab entry is one token
                self._cache[word] = [self.vocab[whole]]
                ids.append(self.vocab[whole]); continue
            sym = self._bpe(sym)
            wid: list[int] = []
            for s in sym:
                tid = self.vocab.get(s)
                if tid is None:
                    # should not happen with a complete byte-level vocab; fall back to single bytes
                    for chh in s:
                        wid.append(self.vocab.get(chh, int(self.unk_id or 0)))
                else:
                    wid.append(tid)
            self._cache[word] = wid
            ids.extend(wid)
        return ids

    def _bpe(self, sym: list[str]) -> list[str]:
        if len(sym) < 2:
            return sym
        while True:
            best = None
            best_rank = None
            for i in range(len(sym) - 1):
                r = self.ranks.get((sym[i], sym[i + 1]))
                if r is not None and (best_rank is None or r < best_rank):
                    best_rank, best = r, i
            if best is None:
                return sym
            merged = sym[best] + sym[best + 1]
            # merge every occurrence of this exact pair (left to right), as BPE does
            out: list[str] = []
            i = 0
            while i < len(sym):
                if i < len(sym) - 1 and sym[i] == sym[best] and sym[i + 1] == sym[best + 1]:
                    out.append(merged); i += 2
                else:
                    out.append(sym[i]); i += 1
            sym = out

    def _encode_spm(self, text: str, first: bool) -> list[int]:
        if self.add_space_prefix and first and text:
            text = " " + text
        text = text.replace(" ", "▁")
        syms = list(text)                      # one symbol per code point
        if not syms:
            return []
        # bigram merges by score (heap of (-score, left_index, ...)), invalidated entries skipped
        left = list(range(-1, len(syms) - 1))
        right = list(range(1, len(syms) + 1))
        alive = [True] * len(syms)
        heap: list = []

        def push(i: int, j: int) -> None:
            if i < 0 or j >= len(syms):
                return
            s = syms[i] + syms[j]
            tid = self.vocab.get(s)
            if tid is not None and tid < len(self.scores):
                heapq.heappush(heap, (-float(self.scores[tid]), i, j, s))

        for i in range(len(syms) - 1):
            push(i, i + 1)
        while heap:
            negscore, i, j, s = heapq.heappop(heap)
            if not alive[i] or not alive[j] or syms[i] + syms[j] != s:
                continue
            syms[i] = s
            alive[j] = False
            right[i] = right[j]
            if right[i] < len(syms):
                left[right[i]] = i
            push(left[i], i)
            push(i, right[i])
        ids: list[int] = []
        i = 0
        while i < len(syms):
            if alive[i]:
                tid = self.vocab.get(syms[i])
                if tid is not None:
                    ids.append(tid)
                else:
                    for b in syms[i].encode("utf-8"):       # byte fallback
                        bt = self.vocab.get(f"<0x{b:02X}>")
                        ids.append(bt if bt is not None else int(self.unk_id or 0))
            i = right[i] if alive[i] else i + 1
        return ids

    # ------------------------------------------------------------- decode
    def decode(self, ids, skip_special: bool = True) -> str:
        if self.model == "gpt2":
            buf = bytearray()
            for t in ids:
                t = int(t)
                if t < 0 or t >= len(self.tokens):
                    continue
                if skip_special and self.types[t] in (3, 4):
                    continue
                piece = self.tokens[t]
                if self.types[t] == 6:                      # BYTE token "<0xNN>"
                    try:
                        buf.append(int(piece[3:-1], 16)); continue
                    except ValueError:
                        pass
                for ch in piece:
                    b = UNI_TO_BYTE.get(ch)
                    if b is None:
                        buf.extend(ch.encode("utf-8"))
                    else:
                        buf.append(b)
            return buf.decode("utf-8", errors="replace")
        out = bytearray()
        for t in ids:
            t = int(t)
            if t < 0 or t >= len(self.tokens):
                continue
            typ = self.types[t]
            if skip_special and typ in (3, 4):
                continue
            piece = self.tokens[t]
            if typ == 6 and piece.startswith("<0x"):
                out.append(int(piece[3:-1], 16)); continue
            out.extend(piece.replace("▁", " ").encode("utf-8"))
        s = out.decode("utf-8", errors="replace")
        return s[1:] if s.startswith(" ") and self.add_space_prefix else s

    def piece(self, t: int) -> str:
        return self.decode([t], skip_special=False)

    # ------------------------------------------------------------- chat
    def chat_prompt(self, user: str, system: Optional[str] = None) -> str:
        """A minimal ChatML / Llama-3 prompt chosen from the template's markers (no Jinja engine)."""
        tpl = str(self.chat_template or "")
        if "<|im_start|>" in tpl or "<|im_start|>" in self.special:
            sysm = system or "You are a helpful assistant."
            return f"<|im_start|>system\n{sysm}<|im_end|>\n<|im_start|>user\n{user}<|im_end|>\n<|im_start|>assistant\n"
        if "<|start_header_id|>" in tpl or "<|start_header_id|>" in self.special:
            sysm = f"<|start_header_id|>system<|end_header_id|>\n\n{system}<|eot_id|>" if system else ""
            return f"<|begin_of_text|>{sysm}<|start_header_id|>user<|end_header_id|>\n\n{user}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n"
        if "[INST]" in tpl:
            return f"[INST] {user} [/INST]"
        return user


def load_tokenizer(gguf_path) -> Tokenizer:
    from .gguf_rewrites import GGUFReader
    gr = GGUFReader(gguf_path)
    try:
        return Tokenizer(gr.kv)
    finally:
        gr.close()


# ---------------------------------------------------------------- tests
def _read_vectors(inp: Path, out: Path) -> list[tuple[str, list[int]]]:
    raw = inp.read_text(encoding="utf-8")
    cases = raw.split("__ggml_vocab_test__\n")
    # the file ends with the marker; the last split element is empty
    if cases and cases[-1] == "":
        cases = cases[:-1]
    lines = out.read_text(encoding="utf-8").split("\n")
    res = []
    for i, c in enumerate(cases):
        c = c[:-1] if c.endswith("\n") else c
        ids = [int(x) for x in lines[i].split()] if i < len(lines) else []
        res.append((c, ids))
    return res


def verify_suite(chk=None, vocab_dir: Optional[Path] = None):
    from .util import Check
    chk = chk or Check("tokenizer")
    # 1. byte mapping round trip
    for b in (0, 32, 65, 127, 128, 200, 255):
        chk(f"byte<->unicode {b}", UNI_TO_BYTE[BYTE_TO_UNI[b]] == b) if b in (0, 255) else None
    # 2. pre-tokenizer rules on hand-checked strings (qwen2 pattern)
    chk("pre: contractions + words", pretokenize("I'm here, you're not", "qwen2") == ["I", "'m", " here", ",", " you", "'re", " not"])
    chk("pre: digits one at a time (qwen2) / up to 3 (llama-bpe)", pretokenize("2024", "qwen2") == ["2", "0", "2", "4"] and pretokenize("20245", "llama-bpe") == ["202", "45"])
    chk("pre: trailing spaces keep one for the next word", pretokenize("a   b", "qwen2") == ["a", "  ", " b"])
    chk("pre: newlines glue to preceding spaces", pretokenize("x \n\ny", "qwen2") == ["x", " \n\n", "y"])
    chk("pre: punctuation with leading space and trailing newline", pretokenize("hi !!\n", "qwen2") == ["hi", " !!\n"])
    # 3. llama.cpp test vectors when present (models/ggml-vocab-*.gguf + .inp/.out)
    vocab_dir = Path(vocab_dir) if vocab_dir else None
    if vocab_dir and vocab_dir.exists():
        from .gguf_rewrites import GGUFReader
        for name in ("ggml-vocab-qwen2", "ggml-vocab-llama-bpe", "ggml-vocab-llama-spm"):
            g = vocab_dir / f"{name}.gguf"
            if not g.exists():
                continue
            gr = GGUFReader(g)
            tok = Tokenizer(gr.kv)
            gr.close()
            vec = _read_vectors(vocab_dir / f"{name}.gguf.inp", vocab_dir / f"{name}.gguf.out")
            bad = []
            for text, want in vec:
                got = tok.encode(text, add_special=False, parse_special=False)
                if got != want:
                    bad.append((text[:30], want[:8], got[:8]))
            chk(f"{name}: {len(vec)} llama.cpp vectors identical", not bad, f"first mismatch {bad[0]}" if bad else f"{len(vec)} cases")
            # decode round trip on the non-special cases
            rt = all(tok.decode(tok.encode(t, add_special=False, parse_special=False)) == t for t, _ in vec if t and "�" not in t)
            chk(f"{name}: decode(encode(x)) == x", rt)
    return chk


if __name__ == "__main__":
    import sys
    print(verify_suite(vocab_dir=Path(sys.argv[1]) if len(sys.argv) > 1 else None).report())
