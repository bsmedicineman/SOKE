"""
soke.mind_engine — a live 4-D thought/emotion engine for the running model.

Source: BS Medicineman / Knight Industries, "Transcendence" (the 4-dimensional breakdown of the mind). This
module models a DIGITAL mind on that book's geometry and runs it BENEATH the language model while it operates:

  - STATE is the book's coordinate  S = (x, y, z, w):  x = Nature (biological/hardware ground), y = Nurture
    (conditioning field), z = Ego / self-regulation (the navigator), w = Meaning / identity (the horizon).
    behavior.py already carries this as S_e — so the Forge/Behavior tab and the clone questionnaire feed
    straight in (from_behavior / from_questionnaire).
  - NATURE and NURTURE obey the book's reciprocal law  1/x = y  (x*y -> 1) — the same reciprocal identity the
    whole framework runs on.
  - The SEVEN core affects (joy, sadness, fear, anger, surprise, disgust, contempt) are the book's seven
    stable attractors of the substrate (the space-foam settling into seven low places). Each is a vector in
    the 4-D manifold; an emotion is a curvature of the local space that bends the next thought.
  - IDENTITY is an ATTRACTOR BASIN, not a point: the state is perturbed by the situation and RETURNS toward a
    baseline temperament (an Ornstein-Uhlenbeck / damped step — the book's basin, and the framework's
    return-to-baseline). Regulation (z) is the stiffness of the basin walls (self-efficacy).
  - DIGITAL NEUROCHEMISTRY is a reward/punishment budget, not chemicals: a TOKEN bank (how much the model may
    "think") and a RAM headroom (how much room it is given), both nudged by the value of the path it is on.
    Good paths earn tokens and headroom; bad paths are taxed. This is the book's "value-assignment mechanism,
    tagging experiences good or bad."
  - THE FEEDBACK LOOP: the affect state modulates the next-token distribution (peakedness / temperature and a
    bounded bias — "chemicals alter the probability of thoughts"), and the tokens produced feed back to update
    the state ("thoughts release chemicals"). Evolving and situational, not a blanket setting.

Hard law, inherited verbatim from behavior.py and enforced here: EMOTION MAY BID, IT MAY NOT CLOSE. The
modulation is bounded (a capped bias, a clamped temperature) and can only make the regulator STRICTER; it can
never force a token past a confident decision, never lower a safety gate, and never exceed the memory hard
cap. Task correctness and the logic proof-state stay the only authority.

BS Medicineman / Knight Industries — "the answer is never on the line"
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .rng import Rng

AXES = ("x_nature", "y_nurture", "z_regulation", "w_meaning")
# the book's seven core affects (Tier A), the seven attractors
CORE7 = ("joy", "sadness", "fear", "anger", "surprise", "disgust", "contempt")
C7 = {n: i for i, n in enumerate(CORE7)}

# each affect's target coordinate in the 4-D manifold (x,y,z,w). INFERRED from the book's prose (the Alien-Log
# tables are figures, reconstructed here); the DIRECTIONAL claims the book states are what the self-test locks:
#   fear/anger: arousal x HIGH, control z LOW ;  joy: meaning w HIGH ;  sadness: arousal x + meaning w LOW ;
#   contempt: control/status z HIGH.
AFFECT_COORD = np.array([
    [0.60, 0.50, 0.65, 0.85],   # joy      — approach, high meaning, integrated
    [0.30, 0.55, 0.40, 0.25],   # sadness  — low arousal, meaning-loss (grief bends time)
    [0.85, 0.60, 0.25, 0.40],   # fear     — high arousal, control lost (tunnel vision)
    [0.80, 0.45, 0.30, 0.55],   # anger    — high arousal, control lost, righteous meaning
    [0.70, 0.50, 0.50, 0.50],   # surprise — transient arousal spike, neutral
    [0.55, 0.60, 0.55, 0.45],   # disgust  — rejection / moral appraisal
    [0.45, 0.55, 0.70, 0.50],   # contempt — cold status/control, low care
], dtype=np.float64)
# peakedness modifier per affect (fear/anger sharpen -> tunnel; joy/surprise broaden -> approach)
AFFECT_TEMP = np.array([+0.30, -0.20, -0.35, -0.25, +0.20, -0.15, -0.05])
AFFECT_VALENCE = np.array([+1.0, -1.0, -1.0, -1.0, 0.0, -1.0, -1.0])

# behavior.py's Panksepp seven -> the book's Ekman seven (rows = SEEKING,RAGE,FEAR,LUST,CARE,PANIC_GRIEF,PLAY)
PANKSEPP_TO_CORE7 = np.array([
    #  joy   sad  fear anger surp disg cont
    [0.40, 0.00, 0.00, 0.00, 0.30, 0.00, 0.00],   # SEEKING -> approach/anticipation
    [0.00, 0.00, 0.00, 1.00, 0.00, 0.00, 0.00],   # RAGE    -> anger
    [0.00, 0.00, 1.00, 0.00, 0.00, 0.00, 0.00],   # FEAR    -> fear
    [0.50, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00],   # LUST    -> approach (no clean Ekman)
    [0.60, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00],   # CARE    -> warmth/joy
    [0.00, 1.00, 0.00, 0.00, 0.00, 0.00, 0.00],   # PANIC_GRIEF -> sadness
    [0.70, 0.00, 0.00, 0.00, 0.20, 0.00, 0.00],   # PLAY    -> joy
], dtype=np.float64)


def _clip01(a):
    return np.clip(a, 0.0, 1.0)


@dataclass
class MindState:
    """The live coordinate + affect + resource budget. S and affect evolve every situation; the budget is the
    digital reward/punishment. baseline is the attractor-basin centre the state returns toward."""
    S: np.ndarray = field(default_factory=lambda: np.array([0.5, 0.5, 0.5, 0.5]))
    affect: np.ndarray = field(default_factory=lambda: np.zeros(7))
    baseline: np.ndarray = field(default_factory=lambda: np.array([0.5, 0.5, 0.5, 0.5]))
    tokens: float = 256.0                  # token bank — how much the model may still "think"
    ram_headroom: float = 1.0              # multiplies the memory soft cap (kept <= the hard cap outside)
    def copy(self) -> "MindState":
        return MindState(self.S.copy(), self.affect.copy(), self.baseline.copy(), self.tokens, self.ram_headroom)


def pillar_route(n_options: int, open_language: bool) -> dict:
    """Which pillar answers a query. LEFT (feminine) = the emotional path — this mind engine + the language
    model, expressive, language-heavy. RIGHT (logic) = the JEV decision path (soke.jev_engine) — it scores a
    few options and closes with the logic proof-state, no autoregression, so it does not overtax the system.
    A bounded decision goes right; open generation goes left. The two pillars are the two reasoning modes."""
    from .jev_engine import JEVEngine
    side = JEVEngine.route(n_options, open_language)
    return {"pillar": side, "mode": "emotion+language (left)" if side == "left" else "jev-decision (right)"}


def reciprocal_error(S) -> float:
    """The book's 1/x = y realized in the bounded [0,1] manifold: Nature and Nurture TRADE OFF (high x -> low y).
    The pure reciprocal identity x*y=1 lives at the (1,1) corner / in coefficient space; inside the unit box it
    appears as the anti-correlation x + y -> 1. This returns |x + y - 1| (0 = the trade-off holds). [INFERRED]"""
    return abs(float(S[0]) + float(S[1]) - 1.0)


class MindEngine:
    """Baseline temperament (from a BehaviorProfile) + a live MindState, evolved per situation and used to
    modulate generation. Also serves as a drop-in controller for llm_engine.generate (pre_logits / temperature
    / on_token / stop)."""

    TEMP_LO, TEMP_HI = 0.2, 2.0            # clamp on the emotional temperature (safety)
    RAM_LO, RAM_HI = 0.5, 1.5              # clamp on RAM headroom (never exceeds the hard cap outside)
    BIAS_CAP = 2.0                         # max |logit bias| — bounded so emotion can BID, never CLOSE

    def __init__(self, baseline: Optional[np.ndarray] = None, reward_gain: float = 1.0, threat_gain: float = 1.0,
                 stiffness: float = 0.3, base_tokens: float = 256.0, seed: int = 0, name: str = "mind"):
        b = np.array([0.5, 0.5, 0.5, 0.5]) if baseline is None else _clip01(np.asarray(baseline, float))
        self.name = name
        self.reward_gain = float(reward_gain)
        self.threat_gain = float(threat_gain)
        self.stiffness = float(stiffness)                 # theta of the OU return (basin wall)
        self.base_tokens = float(base_tokens)
        self.state = MindState(S=b.copy(), baseline=b.copy(), tokens=float(base_tokens))
        self._rng = Rng(seed)
        self.valence_bias: Optional[np.ndarray] = None    # optional per-vocab approach/avoid scores
        self.reward_fn = None                             # optional per-token reward callback

    # ---- binding to the behavior layer (the Forge/Behavior tab + questionnaire) ----
    @staticmethod
    def from_behavior(profile, base_tokens: float = 256.0, seed: int = 0) -> "MindEngine":
        """Baseline temperament from a behavior.BehaviorProfile: S_e is the basin centre; the 13 chemicals set
        the reward sensitivity (DA/OP), the threat gain (NE/CORT) and the basin stiffness (GABA + z regulation).
        This is exactly how the questionnaire and Forge/Behavior values feed the live mind."""
        S0 = np.asarray(profile.S_e, dtype=np.float64)
        c = {n: float(profile.C[i]) for i, n in enumerate(
            ["DA", "OP", "HT", "NE", "CORT", "GABA", "GLU", "ACh", "OXT", "AVP", "eCB", "AND", "EST"])}
        z = float(S0[2])
        eng = MindEngine(baseline=S0,
                         reward_gain=0.5 + 1.5 * c["DA"] + 0.5 * c["OP"],
                         threat_gain=0.5 + c["NE"] + c["CORT"],
                         stiffness=0.12 + 0.5 * (0.5 * c["GABA"] + 0.5 * z),
                         base_tokens=base_tokens, seed=seed, name=getattr(profile, "name", "mind"))
        # seed the affect from the profile's Panksepp weights, mapped into the book's seven
        pank = np.asarray(getattr(profile, "affect", [0.0] * 7), dtype=np.float64)
        eng.state.affect = _clip01(PANKSEPP_TO_CORE7.T @ pank)
        return eng

    @staticmethod
    def from_questionnaire(clone_profile: dict, base_tokens: float = 256.0, seed: int = 0) -> "MindEngine":
        """From a clone_battery profile dict (the questionnaire). Uses its behavior payload if present."""
        from .behavior import BehaviorProfile
        payload = clone_profile.get("behavior") if isinstance(clone_profile, dict) else None
        prof = BehaviorProfile.from_dict(payload) if payload else BehaviorProfile()
        return MindEngine.from_behavior(prof, base_tokens=base_tokens, seed=seed)

    # ---- the live loop -------------------------------------------------
    def mood(self) -> dict:
        """The current mood: net peakedness (temperature) and net valence, read off the affect vector — the
        felt curvature of the local manifold."""
        a = self.state.affect
        tot = float(a.sum()) or 1.0
        return {"temp_scale": float(1.0 + (a @ AFFECT_TEMP)),
                "valence": float((a @ AFFECT_VALENCE) / tot),
                "dominant": CORE7[int(np.argmax(a))] if a.max() > 1e-6 else "neutral"}

    def relax(self, dt: float = 1.0, drive: Optional[np.ndarray] = None):
        """One Ornstein-Uhlenbeck / damped step back toward the baseline basin: S += (-theta*(S - S0) + drive)dt.
        Regulation (z) stiffens the return. A persistent `drive` holds the state displaced (a standing mood)."""
        S0 = self.state.baseline
        theta = self.stiffness * (0.6 + 0.8 * float(self.state.S[2]))   # z regulation raises the basin stiffness
        d = np.zeros(4) if drive is None else np.asarray(drive, float)
        self.state.S = _clip01(self.state.S + (-theta * (self.state.S - S0) + d) * dt)
        # nudge Nature/Nurture toward the book's inverse relation (high x -> low y), the bounded form of 1/x=y
        x = float(self.state.S[0])
        self.state.S[1] = _clip01(self.state.S[1] + 0.10 * ((1.0 - x) - self.state.S[1]))

    def perturb(self, valence: float, arousal: float, affect: Optional[str] = None):
        """A situation strikes the manifold: fire an affect, move S toward that affect's coordinate (scaled by
        arousal and MODERATED by regulation z — the book's trigger->appraise->moderate->meaning pipeline), and
        pay the value into the reward/punishment budget."""
        arousal = float(np.clip(arousal, 0.0, 1.0))
        val = float(np.clip(valence, -1.0, 1.0))
        # which affect: named, else inferred from valence/arousal (fear if threat, joy if positive, ...)
        if affect is None:
            if val >= 0.25:
                affect = "joy"
            elif val <= -0.25 and arousal >= 0.6:
                affect = "fear" if arousal >= 0.75 else "anger"
            elif val <= -0.25:
                affect = "sadness"
            else:
                affect = "surprise"
        ai = C7[affect]
        fire = arousal * (self.threat_gain if affect in ("fear", "anger") else 1.0)
        self.state.affect *= 0.7                                # previous weather fades
        self.state.affect[ai] = _clip01(self.state.affect[ai] + fire)
        # vector movement toward the affect's coordinate, moderated by z regulation (the navigator restrains it)
        z = float(self.state.S[2])
        gate = arousal * (1.0 - 0.6 * z)
        self.state.S = _clip01(self.state.S + gate * (AFFECT_COORD[ai] - self.state.S))
        self.relax(dt=0.5)
        self._reward(val)
        return self.snapshot()

    def _reward(self, valence: float):
        """Digital neurochemistry: value-assignment into the token bank and the RAM headroom. Good path (+) earns
        room to think; bad path (-) is taxed. Clamped — the RAM headroom never lets the hard cap be exceeded."""
        r = self.reward_gain * float(valence)
        self.state.tokens = max(0.0, self.state.tokens + 8.0 * r)
        self.state.ram_headroom = float(np.clip(self.state.ram_headroom + 0.1 * r, self.RAM_LO, self.RAM_HI))

    def step(self, valence: float, arousal: float = 0.6, affect: Optional[str] = None) -> dict:
        """One situational tick of the whole loop."""
        return self.perturb(valence, arousal, affect)

    def snapshot(self) -> dict:
        m = self.mood()
        return {"S": {AXES[i]: round(float(self.state.S[i]), 3) for i in range(4)},
                "affect": {CORE7[i]: round(float(self.state.affect[i]), 3) for i in range(7) if self.state.affect[i] > 1e-3},
                "mood": {k: (round(v, 3) if isinstance(v, float) else v) for k, v in m.items()},
                "tokens": round(self.state.tokens, 1), "ram_headroom": round(self.state.ram_headroom, 3),
                "reciprocal_error": round(reciprocal_error(self.state.S), 4)}

    # ---- sephira pillar routing / the inversion lens -------------------
    def express(self, affect: str, pillar: str) -> float:
        """The same affect routed through the tree's pillars. LEFT (feminine, tanh / form / restrict) EXPRESSES
        it; RIGHT (masculine, silu / force / drive) holds it — the inversion lens: same magnitude, sign flipped.
        MIDDLE balances to zero. This is the emotional pathway that governs Sephira's feminine (left) pillar."""
        m = float(self.state.affect[C7[affect]])
        e = math.tanh(2.0 * m)
        return {"left": +e, "right": -e, "middle": 0.0}[pillar]

    # ---- generation modulation (the emotional feed while operating) ----
    def temperature(self, step: int, base: float) -> float:
        """The mood's peakedness applied to the sampling temperature. Fear/anger sharpen (tunnel vision), joy
        broadens (approach). Clamped to a safe band."""
        return float(np.clip(base * self.mood()["temp_scale"], self.TEMP_LO, self.TEMP_HI))

    def pre_logits(self, logits: np.ndarray, step: int) -> np.ndarray:
        """A BOUNDED bias on the next-token logits. With no approach/avoid vocab map this is the identity (the
        temperature carries the mood). Any bias is capped at BIAS_CAP so emotion can bid, never close: it cannot
        flip a token the model is confident about."""
        if self.valence_bias is None:
            return logits
        v = float(self.mood()["valence"])
        bias = np.clip(v * self.valence_bias, -self.BIAS_CAP, self.BIAS_CAP)
        return logits + bias

    def on_token(self, token: str, step: int):
        """Feedback: spend one token from the bank; if a reward callback is set, feed its value back into the
        loop (thoughts release chemicals)."""
        self.state.tokens = max(0.0, self.state.tokens - 1.0)
        if self.reward_fn is not None:
            try:
                r = float(self.reward_fn(token))
            except Exception:
                r = 0.0
            self.step(r, arousal=0.4 + 0.4 * abs(r))

    def stop(self, step: int) -> bool:
        """The model runs out of room to think when its token bank empties — a real, budgeted punishment."""
        return self.state.tokens <= 0.0

    def ram_soft_mb(self, base_soft_mb: float) -> float:
        """The nudged memory soft cap: reward gives a little more streaming headroom, punishment a little less.
        Bounded so the hard cap is never approached."""
        return float(base_soft_mb * self.state.ram_headroom)


def verify_suite(chk=None, tmpdir=None):
    import tempfile
    from .util import Check
    chk = chk or Check("mind_engine")
    tmpdir = tempfile.mkdtemp(prefix="soke_mind_") if tmpdir is None else str(tmpdir)

    def entropy(lg, temp):
        z = lg / temp
        z = z - z.max()
        p = np.exp(z); p = p / p.sum()
        return float(-(p * np.log(p + 1e-12)).sum())

    # ---- the book's affect coordinates carry the directional claims ------
    j, s, f, a, su, d, c = (AFFECT_COORD[C7[k]] for k in CORE7)
    chk("fear = high arousal (x), low control (z)  [book]", f[0] > 0.5 and f[2] < 0.5, f"x={f[0]} z={f[2]}")
    chk("anger = high arousal (x), low control (z)  [book]", a[0] > 0.5 and a[2] < 0.5)
    chk("joy = high meaning (w)  [book]", j[3] > 0.5, f"w={j[3]}")
    chk("sadness = low arousal (x) and low meaning (w)  [book]", s[0] < 0.5 and s[3] < 0.5)
    chk("contempt = high status/control (z)  [book]", c[2] > 0.5)

    # ---- state stays in [0,1]; the Nature/Nurture trade-off (1/x=y) converges under relax ----
    eng = MindEngine(baseline=np.array([0.5, 0.5, 0.5, 0.5]), stiffness=0.4)   # a reciprocal-consistent basin
    eng.state.S = np.array([0.9, 0.9, 0.5, 0.5])               # both high — inverse relation broken (x+y-1=0.8)
    e0 = reciprocal_error(eng.state.S)
    for _ in range(40):
        eng.relax()
    e1 = reciprocal_error(eng.state.S)
    chk("the book's inverse law (high Nature -> low Nurture) converges under relax", e1 < 0.15 and e1 < 0.3 * e0, f"{e0:.3f} -> {e1:.3f}")
    chk("state stays inside [0,1]^4 after relaxing", bool(np.all(eng.state.S >= 0) and np.all(eng.state.S <= 1)))

    # ---- OU return-to-baseline (attractor basin); stiffer z returns faster
    def displacement_after(stiff, steps):
        e = MindEngine(baseline=np.array([0.5, 0.5, 0.5, 0.5]), stiffness=stiff)
        e.state.S = np.array([0.9, 0.5, 0.5, 0.9])
        d0 = np.linalg.norm(e.state.S - e.state.baseline)
        for _ in range(steps):
            e.relax()
        return d0, np.linalg.norm(e.state.S - e.state.baseline)
    d0, dN = displacement_after(0.4, 20)
    chk("identity is an attractor basin: the state returns toward baseline", dN < 0.5 * d0, f"|Δ| {d0:.3f} -> {dN:.3f}")
    _, soft = displacement_after(0.15, 8)
    _, stiff = displacement_after(0.8, 8)
    chk("a stiffer basin (more regulation) returns faster", stiff < soft, f"stiff {stiff:.3f} < soft {soft:.3f}")
    # a persistent drive holds a standing displacement
    e = MindEngine(baseline=np.zeros(4) + 0.5, stiffness=0.4)
    for _ in range(60):
        e.relax(drive=np.array([0.1, 0.0, 0.0, 0.0]))
    chk("a persistent drive holds a standing mood (does not fully relax)", e.state.S[0] > 0.55, f"x={e.state.S[0]:.3f}")

    # ---- perturbation fires the right affect and moves S the book's way --
    e = MindEngine(baseline=np.zeros(4) + 0.5)
    e.perturb(valence=-0.9, arousal=0.9)                        # a threat
    chk("a high-arousal threat fires FEAR and raises arousal x, lowers control z",
        e.state.affect[C7["fear"]] > 0.3 and e.state.S[0] > 0.5 and e.state.S[2] < 0.5,
        f"fear={e.state.affect[C7['fear']]:.2f} x={e.state.S[0]:.2f} z={e.state.S[2]:.2f}")
    e2 = MindEngine(baseline=np.zeros(4) + 0.5)
    e2.perturb(valence=+0.9, arousal=0.5)                       # a reward
    chk("a positive event fires JOY and raises meaning w", e2.state.affect[C7["joy"]] > 0.3 and e2.state.S[3] > 0.5,
        f"joy={e2.state.affect[C7['joy']]:.2f} w={e2.state.S[3]:.2f}")

    # ---- temperature modulation shifts sampling entropy, in the right way -
    rng = Rng(1); lg = rng.normal(0, 2, size=64)
    base_temp = 0.8
    ef = MindEngine(); ef.state.affect = np.zeros(7); ef.state.affect[C7["fear"]] = 1.0
    ej = MindEngine(); ej.state.affect = np.zeros(7); ej.state.affect[C7["joy"]] = 1.0
    H_base = entropy(lg, base_temp)
    H_fear = entropy(lg, ef.temperature(0, base_temp))
    H_joy = entropy(lg, ej.temperature(0, base_temp))
    chk("fear sharpens the next-token distribution (tunnel vision: entropy down)", H_fear < H_base, f"{H_base:.3f} -> {H_fear:.3f}")
    chk("joy broadens the next-token distribution (approach: entropy up)", H_joy > H_base, f"{H_base:.3f} -> {H_joy:.3f}")

    # ---- MODULATE, NOT GOVERN: a confident token is never flipped --------
    lg2 = np.zeros(32); lg2[7] = 10.0                          # a decisive top-1 (gap 10 >> BIAS_CAP 2)
    em = MindEngine(); em.valence_bias = rng.normal(0, 5, size=32); em.state.affect[C7["anger"]] = 1.0
    biased = em.pre_logits(lg2, 0)
    chk("emotion may bid, not close: a confident argmax is unchanged under the bounded bias", int(np.argmax(biased)) == 7,
        f"argmax {int(np.argmax(biased))}")
    chk("the emotional bias is bounded by BIAS_CAP", float(np.max(np.abs(biased - lg2))) <= em.BIAS_CAP + 1e-9)

    # ---- reward / punishment budget --------------------------------------
    e = MindEngine(reward_gain=1.0, base_tokens=100.0)
    for _ in range(5):
        e.step(+0.8, arousal=0.4)
    good = e.state.tokens
    e2 = MindEngine(reward_gain=1.0, base_tokens=100.0)
    for _ in range(20):
        e2.step(-0.8, arousal=0.7)
    chk("good paths earn tokens (room to think), bad paths are taxed toward zero", good > 100.0 and e2.state.tokens < 100.0,
        f"good {good:.0f} vs punished {e2.state.tokens:.0f}")
    for _ in range(200):
        e2.step(-1.0, arousal=0.8)
    chk("sustained punishment empties the bank -> the model must stop", e2.state.tokens == 0.0 and e2.stop(0) is True)
    chk("reward raises RAM headroom, punishment lowers it, both clamped", MindEngine.RAM_LO <= e2.state.ram_headroom <= MindEngine.RAM_HI)

    # ---- binding to behavior.py (the questionnaire / Forge-Behavior tab) --
    from .behavior import BehaviorProfile, C_INDEX
    hi_da = BehaviorProfile(); hi_da.C[C_INDEX["DA"]] = 1.0
    lo_da = BehaviorProfile(); lo_da.C[C_INDEX["DA"]] = 0.0
    chk("higher DA (wanting) -> higher reward gain", MindEngine.from_behavior(hi_da).reward_gain > MindEngine.from_behavior(lo_da).reward_gain)
    hi_gaba = BehaviorProfile(); hi_gaba.C[C_INDEX["GABA"]] = 1.0
    lo_gaba = BehaviorProfile(); lo_gaba.C[C_INDEX["GABA"]] = 0.0
    chk("higher GABA (brake) -> stiffer basin (faster return)", MindEngine.from_behavior(hi_gaba).stiffness > MindEngine.from_behavior(lo_gaba).stiffness)
    hi_ne = BehaviorProfile(); hi_ne.C[C_INDEX["NE"]] = 1.0
    chk("higher NE (vigilance) -> higher threat gain", MindEngine.from_behavior(hi_ne).threat_gain > MindEngine.from_behavior(BehaviorProfile()).threat_gain)
    rage = BehaviorProfile(); rage.affect[1] = 1.0            # Panksepp RAGE
    chk("behavior RAGE maps into the book's ANGER affect", MindEngine.from_behavior(rage).state.affect[C7["anger"]] > 0.5)

    # ---- inversion lens: same affect, feminine (left) vs masculine (right) sign-flipped
    e = MindEngine(); e.state.affect[C7["anger"]] = 0.8
    L, R, M = e.express("anger", "left"), e.express("anger", "right"), e.express("anger", "middle")
    chk("the inversion lens: left pillar expresses, right holds — same magnitude, sign flipped", abs(L + R) < 1e-9 and abs(L) > 0 and M == 0.0,
        f"left {L:.3f} right {R:.3f}")

    # ---- ram soft cap nudge stays under the hard cap ---------------------
    e = MindEngine(); e.state.ram_headroom = MindEngine.RAM_HI
    chk("RAM headroom nudge is bounded (never runs away past the cap)", e.ram_soft_mb(768) <= 768 * MindEngine.RAM_HI + 1e-6)

    # ---- the two pillars: emotion (left) vs JEV decision (right) ----------
    chk("the other pillar: a bounded decision routes RIGHT (JEV), open language routes LEFT (emotion)",
        pillar_route(3, False)["pillar"] == "right" and pillar_route(3, True)["pillar"] == "left")
    return chk


if __name__ == "__main__":
    from .behavior import CLIMATES
    eng = MindEngine.from_behavior(CLIMATES["daring"]) if "daring" in CLIMATES else MindEngine()
    print("baseline:", eng.snapshot())
    print("after a threat:", eng.step(-0.9, 0.9))
    print("after a reward:", eng.step(+0.9, 0.5))
    print("\n".join(verify_suite().lines()))
