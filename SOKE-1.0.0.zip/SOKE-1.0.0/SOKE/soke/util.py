"""
soke.util — shared helpers (stdlib only).

Conventions inherited from ENLIL: canonical JSON, sha256 content hashes,
atomic JSON writes, unix-time helpers, and the epistemic tag vocabulary.
"""
from __future__ import annotations

import hashlib
import json
import os
import struct
import sys
import time
import zlib
from pathlib import Path
from typing import Optional, Any

# --------------------------------------------------------------------------
# Epistemic tags (RESONANT MIND §1 / ENLIL)
# --------------------------------------------------------------------------
FAST_TAGS = ("VERIFIED", "SOURCED", "INFERRED", "GUESS")
LEDGER_TAGS = ("ESTABLISHED", "FRONTIER", "CONJECTURAL", "REFUTED", "OPEN", "ADOPTED")
# MFP truth values
TRUE, FALSE, UNDECIDED, CONTRADICTION = "⊤", "⊥", "?", "⊥⊥"
MFP_STATUS = ("TRUE", "FALSE", "EMPIRICALLY_TRUE", "ACCEPTED", "UNVERIFIED", "REFUTED", "OPEN")

TOL = 1e-9          # standing numeric tolerance (two plug-ins, error < 1e-9)


def now() -> int:
    return int(time.time())


def now_ns() -> int:
    return time.time_ns()


def iso_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True, default=_json_default)


def _json_default(o: Any):
    try:
        import numpy as np  # local import: util must stay importable without numpy
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, np.generic):
            return o.item()
    except Exception:
        pass
    if isinstance(o, Path):
        return str(o)
    if isinstance(o, bytes):
        return o.hex()
    if isinstance(o, set):
        return sorted(o)
    raise TypeError(f"not JSON serializable: {type(o).__name__}")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_8(data: bytes) -> int:
    """First 8 bytes of sha256 as an unsigned 64-bit integer (SFF checksum field)."""
    return struct.unpack("<Q", hashlib.sha256(data).digest()[:8])[0]


def content_hash(obj: Any) -> str:
    return sha256_hex(canonical_json(obj).encode("utf-8"))


def crc32(data: bytes) -> int:
    return zlib.crc32(data) & 0xFFFFFFFF


def file_sha256(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def atomic_write_json(path: Path, obj: Any) -> None:
    atomic_write_bytes(Path(path), json.dumps(obj, indent=1, sort_keys=True, default=_json_default).encode("utf-8"))


def read_json(path: Path, default: Any = None) -> Any:
    path = Path(path)
    if not path.exists():
        return default
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def human_bytes(n: float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024.0:
            return f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} PB"


def is_windows() -> bool:
    return os.name == "nt" or sys.platform.startswith("win")


def dev_mode() -> bool:
    """SOKE_DEV=1 lifts the Windows-only guard (used by the self-test harness)."""
    return os.environ.get("SOKE_DEV", "") not in ("", "0", "false", "False")


def data_root() -> Path:
    """
    Data root: %SOKE_HOME% if set, else <install dir>\\soke_data.
    """
    env = os.environ.get("SOKE_HOME")
    if env:
        return Path(env)
    return Path(__file__).resolve().parent.parent / "soke_data"


class Check:
    """Tiny PASS/FAIL recorder shared by every module's falsifier suite."""

    def __init__(self, name: str = "suite"):
        self.name = name
        self.rows: list[tuple[bool, str, str]] = []

    def __call__(self, name: str, cond: bool, detail: str = "") -> bool:
        ok = bool(cond)
        self.rows.append((ok, name, detail))
        return ok

    @property
    def passed(self) -> int:
        return sum(1 for r in self.rows if r[0])

    @property
    def total(self) -> int:
        return len(self.rows)

    @property
    def ok(self) -> bool:
        return self.passed == self.total

    def lines(self) -> list[str]:
        out = []
        for ok, name, detail in self.rows:
            tag = "PASS" if ok else "FAIL"
            out.append(f"  [{tag}] {name}" + (f" — {detail}" if detail else ""))
        out.append(f"  {self.name}: {self.passed}/{self.total} PASS")
        return out

    def report(self) -> str:
        return "\n".join(self.lines())


# ---------------------------------------------------------------- corpus folders
TEXT_SUFFIXES = {".txt", ".md", ".markdown", ".rst", ".text", ".log", ".csv", ".tsv", ".json", ".jsonl", ".yaml", ".yml",
                 ".xml", ".html", ".htm", ".tex", ".bib", ".ini", ".cfg", ".toml", ".conf", ".srt", ".vtt",
                 ".py", ".pyw", ".js", ".ts", ".jsx", ".tsx", ".c", ".h", ".cpp", ".hpp", ".cc", ".cs", ".java", ".go", ".rs",
                 ".rb", ".php", ".pl", ".sh", ".bat", ".ps1", ".sql", ".r", ".m", ".jl", ".lua", ".swift", ".kt", ".scala",
                 ".docx", ".pdf", ".epub", ".htm", ".html", ".xhtml"}
SKIP_DIRS = {".git", ".hg", ".svn", "__pycache__", "node_modules", ".venv", "venv", ".idea", ".vscode", "soke_data",
             "$RECYCLE.BIN", "System Volume Information"}


def looks_like_text(path, sniff: int = 4096) -> bool:
    """Extension gate first; then a NUL-byte sniff of the first 4 KB (docx is a zip and always accepted)."""
    p = Path(path)
    if p.suffix.lower() in (".pdf", ".epub", ".htm", ".html", ".xhtml"):
        return True
    if p.suffix.lower() == ".docx":
        return True
    if p.suffix.lower() not in TEXT_SUFFIXES:
        return False
    try:
        with open(p, "rb") as f:
            head = f.read(sniff)
    except OSError:
        return False
    return b"\x00" not in head


def expand_corpus(paths, max_files: int = 20000, min_bytes: int = 1) -> tuple[list, dict]:
    """
    Files and folders -> the list of text-like files SOKE will learn from (folders walked recursively,
    hidden/tool folders skipped, binaries dropped by extension + NUL sniff, duplicates removed, sorted).
    Returns (files, report) where report counts what was kept and what was skipped and why.
    """
    files: list = []
    seen: set = set()
    rep = {"folders": 0, "kept": 0, "skipped_binary": 0, "skipped_ext": 0, "skipped_empty": 0, "missing": 0, "bytes": 0}
    for raw in paths or []:
        p = Path(raw)
        if p.is_dir():
            rep["folders"] += 1
            for sub in sorted(p.rglob("*")):
                if len(files) >= max_files:
                    break
                if any(part in SKIP_DIRS or part.startswith(".") for part in sub.relative_to(p).parts[:-1]):
                    continue
                if not sub.is_file() or sub.name.startswith("."):
                    continue
                _consider(sub, files, seen, rep, min_bytes)
        elif p.is_file():
            _consider(p, files, seen, rep, min_bytes, forced=True)
        else:
            rep["missing"] += 1
    return files, rep


def _consider(p: Path, files: list, seen: set, rep: dict, min_bytes: int, forced: bool = False) -> None:
    try:
        key = str(p.resolve()).lower()
        size = p.stat().st_size
    except OSError:
        rep["missing"] += 1
        return
    if key in seen:
        return
    if size < min_bytes:
        rep["skipped_empty"] += 1
        return
    if p.suffix.lower() not in TEXT_SUFFIXES and not forced:
        rep["skipped_ext"] += 1
        return
    if not looks_like_text(p) and not (forced and p.suffix.lower() in (".docx", ".pdf", ".epub", ".htm", ".html", ".xhtml")):
        if forced:
            # a file the operator picked by hand is read as text anyway unless it is plainly binary
            try:
                with open(p, "rb") as f:
                    if b"\x00" in f.read(4096):
                        rep["skipped_binary"] += 1
                        return
            except OSError:
                rep["missing"] += 1
                return
        else:
            rep["skipped_binary"] += 1
            return
    seen.add(key)
    files.append(p)
    rep["kept"] += 1
    rep["bytes"] += size


def app_log(message: str, root=None) -> None:
    """Append one timestamped line to <data root>/logs/soke.log (never raises)."""
    import time as _t
    try:
        d = Path(root or data_root()) / "logs"
        d.mkdir(parents=True, exist_ok=True)
        with open(d / "soke.log", "a", encoding="utf-8") as f:
            f.write(f"[{_t.strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")
    except Exception:
        pass


# ------------------------------------------------------------------ settings
def default_model_dir() -> Path:
    """Where GGUF models live by default: Ollama's blob store (%OLLAMA_MODELS%\\blobs, else ~\\.ollama\\models\\blobs)."""
    env = os.environ.get("OLLAMA_MODELS")
    base = Path(env) if env else Path(os.path.expanduser("~")) / ".ollama" / "models"
    return base / "blobs"


def load_settings(root: Optional[Path] = None) -> dict:
    """soke_data\\settings.json with defaults filled in: model_dir (scan) and export_dir (save) — both the Ollama
    blob store unless the operator changed them."""
    root = Path(root or data_root())
    d = read_json(root / "settings.json", {}) or {}
    md = str(default_model_dir())
    d.setdefault("model_dir", md)
    d.setdefault("export_dir", d.get("model_dir", md))
    return d


def save_settings(d: dict, root: Optional[Path] = None) -> Path:
    root = Path(root or data_root())
    root.mkdir(parents=True, exist_ok=True)
    p = root / "settings.json"
    with open(p, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=1)
    return p
