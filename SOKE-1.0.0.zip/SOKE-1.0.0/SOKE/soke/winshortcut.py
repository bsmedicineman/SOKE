"""
soke.winshortcut — create Windows .lnk shortcuts from Python with ctypes + COM (IShellLinkW).

Why not PowerShell's WScript.Shell: on machines with an Application Control policy (Smart App
Control / WDAC) PowerShell runs in Constrained Language Mode, where New-Object -ComObject is
refused, so the installer's shortcut step silently produced nothing (observed on the operator's
machine). python.exe is an ordinary signed process and may call COM directly.

Usage (from INSTALL.bat):
    python -m soke.winshortcut "<target.bat>" "<lnk path>" "<working dir>" "<icon.ico>" "<description>"
Exit code 0 and the .lnk exists on success; the batch file verifies the file itself.
"""
from __future__ import annotations

import ctypes
import os
import sys
from ctypes import POINTER, byref, c_int, c_void_p, c_wchar_p
from pathlib import Path

if os.name == "nt":
    from ctypes import wintypes

    class GUID(ctypes.Structure):
        _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16), ("Data3", ctypes.c_uint16),
                    ("Data4", ctypes.c_ubyte * 8)]

        @classmethod
        def from_str(cls, s: str) -> "GUID":
            s = s.strip("{}")
            p = s.split("-")
            g = cls()
            g.Data1 = int(p[0], 16)
            g.Data2 = int(p[1], 16)
            g.Data3 = int(p[2], 16)
            tail = bytes.fromhex(p[3] + p[4])
            for i in range(8):
                g.Data4[i] = tail[i]
            return g

    CLSID_ShellLink = GUID.from_str("{00021401-0000-0000-C000-000000000046}")
    IID_IShellLinkW = GUID.from_str("{000214F9-0000-0000-C000-000000000046}")
    IID_IPersistFile = GUID.from_str("{0000010B-0000-0000-C000-000000000046}")
    CLSCTX_INPROC_SERVER = 1
    HRESULT = ctypes.c_long

    def _method(obj: c_void_p, index: int, *argtypes):
        """Bind vtable slot `index` of COM object `obj` as a callable (stdcall on x86, plain on x64)."""
        vtbl = ctypes.cast(obj, POINTER(POINTER(c_void_p)))[0]
        proto = ctypes.WINFUNCTYPE(HRESULT, c_void_p, *argtypes)
        return proto(vtbl[index])

    def create_shortcut(target: str, lnk_path: str, workdir: str = "", icon: str = "", description: str = "",
                        arguments: str = "", show_cmd: int = 1) -> None:
        ole32 = ctypes.WinDLL("ole32")
        ole32.CoInitialize.restype = HRESULT
        ole32.CoInitialize.argtypes = [c_void_p]
        ole32.CoCreateInstance.restype = HRESULT
        ole32.CoCreateInstance.argtypes = [POINTER(GUID), c_void_p, wintypes.DWORD, POINTER(GUID), POINTER(c_void_p)]
        ole32.CoInitialize(None)
        link = c_void_p()
        hr = ole32.CoCreateInstance(byref(CLSID_ShellLink), None, CLSCTX_INPROC_SERVER, byref(IID_IShellLinkW), byref(link))
        if hr != 0 or not link:
            raise OSError(f"CoCreateInstance(ShellLink) failed: 0x{hr & 0xFFFFFFFF:08X}")
        try:
            # IShellLinkW vtable: 0-2 IUnknown | 3 GetPath 4 GetIDList 5 SetIDList 6 GetDescription 7 SetDescription
            # 8 GetWorkingDirectory 9 SetWorkingDirectory 10 GetArguments 11 SetArguments 12 GetHotkey 13 SetHotkey
            # 14 GetShowCmd 15 SetShowCmd 16 GetIconLocation 17 SetIconLocation 18 SetRelativePath 19 Resolve 20 SetPath
            _check(_method(link, 20, c_wchar_p)(link, target), "SetPath")
            if workdir:
                _check(_method(link, 9, c_wchar_p)(link, workdir), "SetWorkingDirectory")
            if arguments:
                _check(_method(link, 11, c_wchar_p)(link, arguments), "SetArguments")
            if description:
                _check(_method(link, 7, c_wchar_p)(link, description), "SetDescription")
            if icon:
                _check(_method(link, 17, c_wchar_p, c_int)(link, icon, 0), "SetIconLocation")
            _check(_method(link, 15, c_int)(link, int(show_cmd)), "SetShowCmd")
            pf = c_void_p()
            _check(_method(link, 0, POINTER(GUID), POINTER(c_void_p))(link, byref(IID_IPersistFile), byref(pf)), "QueryInterface(IPersistFile)")
            try:
                # IPersistFile vtable: 0-2 IUnknown | 3 GetClassID 4 IsDirty 5 Load 6 Save 7 SaveCompleted 8 GetCurFile
                _check(_method(pf, 6, c_wchar_p, c_int)(pf, lnk_path, 1), "Save")
            finally:
                _method(pf, 2)(pf)                           # Release
        finally:
            _method(link, 2)(link)                           # Release

    def _check(hr: int, what: str) -> None:
        if hr != 0:
            raise OSError(f"{what} failed: 0x{hr & 0xFFFFFFFF:08X}")

    def desktop_dir() -> Path:
        """The real Desktop folder (handles OneDrive-redirected desktops): SHGetFolderPathW(CSIDL_DESKTOPDIRECTORY)."""
        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        shell32 = ctypes.WinDLL("shell32")
        if shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf) == 0 and buf.value:
            return Path(buf.value)
        return Path(os.path.expanduser("~")) / "Desktop"

    def programs_dir() -> Path:
        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        shell32 = ctypes.WinDLL("shell32")
        if shell32.SHGetFolderPathW(None, 0x0002, None, 0, buf) == 0 and buf.value:   # CSIDL_PROGRAMS
            return Path(buf.value)
        return Path(os.environ.get("APPDATA", os.path.expanduser("~"))) / "Microsoft" / "Windows" / "Start Menu" / "Programs"


def ensure_shortcuts(install_dir, force: bool = False) -> dict:
    """Create the Desktop and Start-Menu shortcuts if they are missing (Windows only; never raises).
    Called by the window on start-up so an updated-in-place install repairs its own icon."""
    rep = {"desktop": "skipped", "programs": "skipped"}
    if os.name != "nt":
        return rep
    install_dir = Path(install_dir)
    target = str(install_dir / "SOKE.bat")
    icon = str(install_dir / "soke.ico")
    for key, folder in (("desktop", desktop_dir), ("programs", programs_dir)):
        try:
            d = folder()
            lnk = d / "SOKE.lnk"
            if lnk.exists() and not force:
                rep[key] = f"exists: {lnk}"
                continue
            d.mkdir(parents=True, exist_ok=True)
            create_shortcut(target, str(lnk), str(install_dir), icon, "SOKE - SFF model writer (BS Medicineman / Knight Industries)", show_cmd=7)
            rep[key] = f"created: {lnk}" if lnk.exists() else f"failed: {lnk} not written"
        except Exception as e:
            rep[key] = f"failed: {type(e).__name__}: {e}"
            if key == "desktop":
                # last resort: a plain launcher copy on the Desktop (works under every policy)
                try:
                    import shutil
                    dst = desktop_dir() / "SOKE.bat"
                    if not dst.exists():
                        shutil.copy2(target, dst)
                    rep[key] += f"; launcher copied: {dst}"
                except Exception as e2:
                    rep[key] += f"; launcher copy failed: {e2}"
    return rep


def main(argv: list[str]) -> int:
    if os.name != "nt":
        print("winshortcut: Windows only")
        return 2
    if len(argv) < 2:
        print(__doc__)
        return 2
    target = str(Path(argv[0]).resolve())
    where = argv[1]
    workdir = argv[2] if len(argv) > 2 else str(Path(target).parent)
    icon = argv[3] if len(argv) > 3 else ""
    desc = argv[4] if len(argv) > 4 else "SOKE"
    if where.lower() == "desktop":
        lnk = desktop_dir() / "SOKE.lnk"
    elif where.lower() == "programs":
        lnk = programs_dir() / "SOKE.lnk"
    else:
        lnk = Path(where)
    lnk.parent.mkdir(parents=True, exist_ok=True)
    try:
        create_shortcut(target, str(lnk), workdir, icon, desc, show_cmd=7)      # 7 = SW_SHOWMINNOACTIVE (console stays out of the way)
    except Exception as e:
        print(f"winshortcut: {e}")
        return 1
    if not lnk.exists():
        print(f"winshortcut: {lnk} was not written")
        return 1
    print(f"shortcut: {lnk}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
