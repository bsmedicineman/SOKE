"""
soke.connectome_engine — a connectome (neurons + synapses) as a SOKE substrate.

WHAT THIS IS
    A directed weighted graph of neurons (nodes) and synapses (edges) that is (a) built from a real
    connectome slice or a synthetic one, (b) stored *inside* an SFF file paged + checksummed, (c) run as a
    toy activation loop, and (d) exposed as inputs / outputs so the rest of SOKE can learn on top of it.
    The connectome is the SCAFFOLD (the wiring); SOKE's LM / forge / behavior engines are the decision layer.

WHAT IS BUILT AND VERIFIED (offline, in the self-test — stdlib + numpy only):
    - CSR graph (indptr/indices/weights) built from an edge list, a CSV, or a deterministic synthetic source.
    - Store to / load from SFF (the graph rides as float32 tensors on a helix; body-ids, type and ROI names
      ride as experiment rows). Never networkx, never fully loaded when you don't want it.
    - `step()` / `simulate()`  — a decayed tanh propagation, one operation per line, proven with plug-ins.
    - `pathways()`             — k shortest weighted synapse routes between two neuron groups (Dijkstra).
    - `group()` / `descending()` / `sensory()` — regex over neuron types (the input/output taps).
    - `LinearReadout`          — a real, fitted (least-squares) map from descending activity to an action.

WHAT IS SOURCED / OPTIONAL (runs on the operator's machine, not here):
    - `Connectome.from_neuprint(...)` pulls male-cns:v1.0 (or any dataset) via the `neuprint` package and an
      access token. That package and token are the operator's; this module imports neuprint only if present
      and says so plainly if it is not. Column names follow the neuprint-python API (SOURCED, not re-derived).

WHAT IS DECLARED, NOT BUILT (honest scaffolding — no engine is faked):
    - JEV scorer, KIMI-style MoE router, FlexGen paging backend do not exist in this tree. The adapters
      `feature_vector()` and `routing_prior()` produce exactly the vectors/priors those engines would consume,
      and say the consumer is not present. Wire them when/if those engines land.

BS Medicineman / Knight Industries — "the answer is never on the line"
"""
from __future__ import annotations

import csv
import heapq
import re
from pathlib import Path
from typing import Callable, Iterable, Optional

import numpy as np

from .rng import Rng
from .sff import SFFReader, SFFWriter, TensorInfo, HELIX_KIND_KNOWLEDGE
from .teeth import ENC_F32

# a connectome helix carries these float32 tensors (all values exact in f32 at 100k–500k scale):
#   deg[n]        out-degree per node          (each < 2^24)
#   indices[nnz]  post-synaptic node index     (each < n_nodes < 2^24)
#   weights[nnz]  synapse count per edge        (small integers)
#   type_code[n]  neuron-type id -> type_names
_T_DEG, _T_IDX, _T_W, _T_TYPE = "cnx.deg", "cnx.indices", "cnx.weights", "cnx.type_code"
_EXP_META, _EXP_BODY = 40, 41           # experiment-row kinds inside the SFF


class Connectome:
    """A directed weighted neuron graph in CSR form. Row = pre-synaptic neuron, column = post-synaptic."""

    def __init__(self, n: int, indptr: np.ndarray, indices: np.ndarray, weights: np.ndarray,
                 body_ids: Optional[np.ndarray] = None, type_code: Optional[np.ndarray] = None,
                 type_names: Optional[list] = None, name: str = "connectome"):
        self.n = int(n)
        self.indptr = np.ascontiguousarray(indptr, dtype=np.int64)
        self.indices = np.ascontiguousarray(indices, dtype=np.int32)
        self.weights = np.ascontiguousarray(weights, dtype=np.float32)
        self.body_ids = None if body_ids is None else np.ascontiguousarray(body_ids, dtype=np.int64)
        self.type_code = (np.zeros(self.n, dtype=np.int32) if type_code is None
                          else np.ascontiguousarray(type_code, dtype=np.int32))
        self.type_names = list(type_names) if type_names is not None else ["unknown"]
        self.name = name
        if self.indptr.size != self.n + 1:
            raise ValueError(f"indptr must have n+1={self.n + 1} entries, got {self.indptr.size}")
        if self.indices.size != self.weights.size or self.indices.size != int(self.indptr[-1]):
            raise ValueError("indices/weights length must equal indptr[-1] (nnz)")
        self._edge_src: Optional[np.ndarray] = None      # per-edge source node, built on first step

    # ---- properties -------------------------------------------------------
    @property
    def n_nodes(self) -> int:
        return self.n

    @property
    def n_edges(self) -> int:
        return int(self.indices.size)

    def edge_src(self) -> np.ndarray:
        """The pre-synaptic node of every edge (cached). Length nnz."""
        if self._edge_src is None:
            self._edge_src = np.repeat(np.arange(self.n, dtype=np.int64), np.diff(self.indptr))
        return self._edge_src

    # ---- builders ---------------------------------------------------------
    @staticmethod
    def from_edges(edges: Iterable, name: str = "connectome") -> "Connectome":
        """Build from an iterable of (pre, post, weight[, pre_type, post_type]). `pre`/`post` are any hashable
        neuron ids (e.g. neuprint bodyId int64). Parallel edges are merged (weights summed)."""
        id_of: dict = {}
        type_of: dict = {}                                # node index -> type string
        src, dst, w = [], [], []

        def idx(key, typ=None):
            i = id_of.get(key)
            if i is None:
                i = len(id_of); id_of[key] = i
            if typ is not None and i not in type_of:
                type_of[i] = str(typ)
            return i

        for e in edges:
            pre, post, weight = e[0], e[1], e[2]
            pt = e[3] if len(e) > 3 else None
            qt = e[4] if len(e) > 4 else None
            a = idx(pre, pt); b = idx(post, qt)
            src.append(a); dst.append(b); w.append(float(weight))
        n = len(id_of)
        if n == 0:
            return Connectome(0, np.zeros(1, np.int64), np.zeros(0, np.int32), np.zeros(0, np.float32), name=name)
        src = np.asarray(src, dtype=np.int64)
        dst = np.asarray(dst, dtype=np.int64)
        w = np.asarray(w, dtype=np.float64)
        # merge duplicate (pre,post) by summing weight — vectorized, no python loop over edges
        key = src * np.int64(n) + dst
        uniq, inv = np.unique(key, return_inverse=True)
        wsum = np.zeros(uniq.size, dtype=np.float64)
        np.add.at(wsum, inv, w)
        su = (uniq // np.int64(n)).astype(np.int64)
        du = (uniq % np.int64(n)).astype(np.int64)
        order = np.lexsort((du, su))                       # sort by pre, then post -> CSR order
        indices = du[order].astype(np.int32)
        weights = wsum[order].astype(np.float32)
        counts = np.bincount(su, minlength=n).astype(np.int64)
        indptr = np.zeros(n + 1, dtype=np.int64)
        indptr[1:] = np.cumsum(counts)
        # node types
        body_ids = np.array([k for k, _ in sorted(id_of.items(), key=lambda kv: kv[1])], dtype=np.int64) \
            if all(isinstance(k, (int, np.integer)) for k in id_of) else None
        names_seen: dict = {}
        type_code = np.zeros(n, dtype=np.int32)
        type_names = ["unknown"]; names_seen["unknown"] = 0
        for i in range(n):
            t = type_of.get(i, "unknown")
            c = names_seen.get(t)
            if c is None:
                c = len(type_names); names_seen[t] = c; type_names.append(t)
            type_code[i] = c
        return Connectome(n, indptr, indices, weights, body_ids=body_ids, type_code=type_code,
                          type_names=type_names, name=name)

    @staticmethod
    def synthetic(n_nodes: int = 2000, avg_degree: int = 12, seed: int = 0, w_max: int = 20,
                  name: str = "synthetic") -> "Connectome":
        """A deterministic connectome for testing/scaling (no numpy.random). Nodes are split into sensory /
        interneuron / descending (DN.*) groups so the input/output taps have something to bite on."""
        rng = Rng(seed)
        n = int(n_nodes)
        m = int(n * avg_degree)
        pre = rng.integers(0, n, size=m).astype(np.int64)
        post = rng.integers(0, n, size=m).astype(np.int64)
        w = rng.integers(1, w_max + 1, size=m).astype(np.float64)
        # type layout: first 30% sensory, last 10% descending, middle interneuron
        n_sen = max(1, int(0.30 * n)); n_dn = max(1, int(0.10 * n))
        type_code = np.ones(n, dtype=np.int32)             # 1 = interneuron
        type_code[:n_sen] = 0                              # 0 = sensory
        type_code[n - n_dn:] = 2                           # 2 = descending
        type_names = ["SEN.mechano", "IN.local", "DN.motor"]
        # build via from_edges to reuse the merge/CSR path (keys are node indices here)
        edges = zip(pre.tolist(), post.tolist(), w.tolist())
        c = Connectome.from_edges(edges, name=name)
        # from_edges relabels by first-seen; remap types through its body_ids (node index == key here)
        tc = np.ones(c.n, dtype=np.int32)
        if c.body_ids is not None:
            orig = c.body_ids.astype(np.int64)
            tc = type_code[orig]
        c.type_code = tc
        c.type_names = type_names
        c.body_ids = None                                  # synthetic ids carry no meaning
        return c

    @staticmethod
    def from_csv(path, pre_col: str = "bodyId_pre", post_col: str = "bodyId_post",
                 weight_col: str = "weight", pre_type_col: Optional[str] = "type_pre",
                 post_type_col: Optional[str] = "type_post", name: Optional[str] = None) -> "Connectome":
        """Read an edge list from a CSV (the columns neuprint's fetch_adjacencies exports, by default)."""
        rows = []
        with open(path, newline="", encoding="utf-8") as f:
            rd = csv.DictReader(f)
            for r in rd:
                pre = int(float(r[pre_col])); post = int(float(r[post_col]))
                w = float(r.get(weight_col, 1) or 1)
                pt = r.get(pre_type_col) if pre_type_col else None
                qt = r.get(post_type_col) if post_type_col else None
                rows.append((pre, post, w, pt, qt))
        return Connectome.from_edges(rows, name=name or Path(path).stem)

    @staticmethod
    def from_neuprint(dataset: str = "male-cns:v1.0", token: Optional[str] = None,
                      server: str = "https://neuprint.janelia.org", type_regex: str = "DN.*",
                      max_nodes: int = 200_000, name: Optional[str] = None):
        """OPTIONAL: pull a slice via the `neuprint` package (operator's token). SOURCED from neuprint-python;
        not exercised in this environment. Raises a clear error if the package/token is missing."""
        try:
            from neuprint import Client, fetch_adjacencies, NeuronCriteria as NC
        except Exception as e:                             # pragma: no cover - depends on the operator's env
            raise RuntimeError("neuprint is not installed. On your machine: pip install neuprint-python, "
                               "then pass your neuPrint token. (This fetch runs on your machine, not in SOKE's "
                               f"cloud sandbox.)  [{type(e).__name__}: {e}]")
        if not token:
            raise RuntimeError("a neuPrint access token is required (get it from your neuprint.janelia.org account).")
        Client(server, dataset=dataset, token=token)      # pragma: no cover
        neuron_df, conn_df = fetch_adjacencies(NC(type=type_regex, regex=True), None)  # pragma: no cover
        tmap = {int(r.bodyId): (r.type if isinstance(r.type, str) else "unknown")     # pragma: no cover
                for r in neuron_df.itertuples()} if neuron_df is not None else {}
        rows = []                                                                     # pragma: no cover
        for r in conn_df.itertuples():                                                # pragma: no cover
            pre, post = int(r.bodyId_pre), int(r.bodyId_post)
            rows.append((pre, post, float(getattr(r, "weight", 1) or 1), tmap.get(pre), tmap.get(post)))
            if len(tmap) and len(rows) >= max_nodes * 8:
                break
        return Connectome.from_edges(rows, name=name or dataset)                       # pragma: no cover

    # ---- neuron taps (regex over type names) ------------------------------
    def group(self, pattern: str) -> np.ndarray:
        """Node indices whose type name matches `pattern` (regex, anchored with fullmatch on the type name)."""
        rx = re.compile(pattern)
        codes = [c for c, nm in enumerate(self.type_names) if rx.fullmatch(nm) or rx.match(nm)]
        if not codes:
            return np.zeros(0, dtype=np.int64)
        want = np.zeros(len(self.type_names), dtype=bool)
        want[codes] = True
        return np.nonzero(want[self.type_code])[0].astype(np.int64)

    def descending(self) -> np.ndarray:
        """Descending / motor-output neurons (types beginning DN)."""
        return self.group("DN.*")

    def sensory(self) -> np.ndarray:
        """Sensory-input neurons (types beginning SEN)."""
        return self.group("SEN.*")

    # ---- activation ------------------------------------------------------
    def step(self, activity: np.ndarray, input_idx: Optional[np.ndarray] = None,
             input_val: Optional[np.ndarray] = None, decay: float = 0.8, syn_scale: float = 100.0) -> np.ndarray:
        """One tick. Semantics (fixed, unlike the article's dict version which KeyErrors on unseen nodes and
        mixes decayed/undecayed state):
            a'      = decay * a                       (leak)
            a'[in] += input                           (inject, onto the leaked state)
            a'[post] += tanh(a[pre]) * w / syn_scale  (propagate from the PREVIOUS state along every synapse)
        Returns a new float32 vector; `a` is not mutated."""
        a = np.ascontiguousarray(activity, dtype=np.float32)
        if a.size != self.n:
            raise ValueError(f"activity must have {self.n} entries, got {a.size}")
        out = a * np.float32(decay)                                      # leak
        if input_idx is not None and input_val is not None and len(input_idx):
            np.add.at(out, np.asarray(input_idx, dtype=np.int64), np.asarray(input_val, dtype=np.float32))
        if self.n_edges:
            pre = np.tanh(a)                                             # from the previous state
            contrib = (pre[self.edge_src()] * self.weights) / np.float32(syn_scale)
            np.add.at(out, self.indices.astype(np.int64), contrib.astype(np.float32))
        return out

    def simulate(self, input_idx, input_val, ticks: int = 8, readout_idx: Optional[np.ndarray] = None,
                 decay: float = 0.8, syn_scale: float = 100.0, memguard=None, record: bool = False):
        """Run `ticks` steps injecting the same input each tick. Returns the readout vector (or, with
        record=True, the [ticks x len(readout)] history). Activity is a single dense f32 vector (n*4 bytes)."""
        a = np.zeros(self.n, dtype=np.float32)
        ridx = self.descending() if readout_idx is None else np.asarray(readout_idx, dtype=np.int64)
        hist = []
        for _ in range(int(ticks)):
            a = self.step(a, input_idx, input_val, decay=decay, syn_scale=syn_scale)
            if memguard is not None:
                memguard.check("connectome.simulate")
            if record:
                hist.append(a[ridx].copy() if ridx.size else np.zeros(0, np.float32))
        if record:
            return np.array(hist, dtype=np.float32)
        return a[ridx].copy() if ridx.size else np.zeros(0, np.float32)

    # ---- pathways (k shortest weighted synapse routes) --------------------
    def pathways(self, src_idx, dst_idx, k: int = 1, max_hops: int = 8) -> list:
        """Up to `k` lowest-cost routes from any node in `src_idx` to any node in `dst_idx`. Edge cost is
        1/weight (a stronger synapse is a cheaper hop), so a route maximises synaptic strength. Dijkstra with
        a hop cap; returns [(path_list, cost), ...] cheapest first."""
        src = set(int(x) for x in np.asarray(src_idx, dtype=np.int64).tolist())
        dst = set(int(x) for x in np.asarray(dst_idx, dtype=np.int64).tolist())
        if not src or not dst:
            return []
        pq = [(0.0, s, 0, (s,)) for s in src]
        heapq.heapify(pq)
        best_cost: dict = {}
        found: list = []
        while pq and len(found) < k:
            cost, node, hops, path = heapq.heappop(pq)
            if node in dst:
                found.append((list(path), cost))
                continue
            if hops >= max_hops:
                continue
            prev = best_cost.get(node)
            if prev is not None and prev <= cost:
                continue
            best_cost[node] = cost
            a, b = int(self.indptr[node]), int(self.indptr[node + 1])
            nbrs = self.indices[a:b]
            wts = self.weights[a:b]
            for j in range(nbrs.size):
                nb = int(nbrs[j]); wj = float(wts[j])
                if wj <= 0 or nb in path:
                    continue
                heapq.heappush(pq, (cost + 1.0 / wj, nb, hops + 1, path + (nb,)))
        return found

    # ---- adapters for SOKE's decision engines (consumers not present here) ----
    def feature_vector(self, activity: np.ndarray, readout_idx: Optional[np.ndarray] = None) -> np.ndarray:
        """The descending-activity feature vector a JEV-style scorer would score over labels. (No JEV engine in
        this tree yet — this returns exactly what it would consume.)"""
        idx = self.descending() if readout_idx is None else np.asarray(readout_idx, dtype=np.int64)
        a = np.ascontiguousarray(activity, dtype=np.float32)
        return a[idx].copy() if idx.size else np.zeros(0, np.float32)

    def routing_prior(self, cluster_map: dict) -> dict:
        """Given {expert_name: [node indices]}, a routing prior a MoE router could use: each expert's share of
        total incoming synaptic weight, normalised to sum 1. (No MoE router in this tree yet — this is the
        prior it would read.)"""
        in_w = np.zeros(self.n, dtype=np.float64)
        np.add.at(in_w, self.indices.astype(np.int64), self.weights.astype(np.float64))
        raw = {name: float(in_w[np.asarray(idx, dtype=np.int64)].sum()) for name, idx in cluster_map.items()}
        tot = sum(raw.values()) or 1.0
        return {k: v / tot for k, v in raw.items()}

    # ---- SFF storage -----------------------------------------------------
    def to_sff(self, path, memguard=None, extra_meta: Optional[dict] = None) -> dict:
        """Write the connectome into an SFF file: the CSR arrays ride as float32 tensors on one helix; the
        body-ids and the type names ride as experiment rows; a compact lineage records provenance. Paged and
        checksummed; nothing is required to be resident to READ a slice later (see Connectome.from_sff)."""
        path = Path(path)
        meta = {"model_id": self.name, "kind": "connectome",
                "connectome": {"n_nodes": self.n, "n_edges": self.n_edges,
                               "n_types": len(self.type_names), "has_body_ids": self.body_ids is not None}}
        if extra_meta:
            meta.update(extra_meta)
        w = SFFWriter(path, file_kind=0, meta=meta, model_id=self.name)
        hid = w.add_helix("connectome", domain_id=0, register_kind=5, kind=HELIX_KIND_KNOWLEDGE)
        deg = np.diff(self.indptr).astype(np.float32)
        w.write_tensor(_T_DEG, deg, hid, ENC_F32)
        w.write_tensor(_T_IDX, self.indices.astype(np.float32), hid, ENC_F32)
        w.write_tensor(_T_W, self.weights.astype(np.float32), hid, ENC_F32)
        w.write_tensor(_T_TYPE, self.type_code.astype(np.float32), hid, ENC_F32)
        # provenance: a root node + one node per type (bounded by #types)
        root = w.add_lineage_node(6, f"connectome:{self.name}")
        for c, nm in enumerate(self.type_names):
            tnode = w.add_lineage_node(4, f"type:{nm}")
            w.add_lineage_edge(root, tnode, 17)
        w.add_exp(_EXP_META, {"n_nodes": self.n, "n_edges": self.n_edges, "type_names": self.type_names,
                              "syn_scale": 100.0})
        if self.body_ids is not None:                      # store body-ids losslessly in bounded chunks
            step = 50_000
            for i in range(0, self.body_ids.size, step):
                w.add_exp(_EXP_BODY, {"offset": int(i), "body_ids": self.body_ids[i:i + step].tolist()})
        if memguard is not None:
            memguard.check("connectome.to_sff")
        w.commit()
        w.close()
        return {"path": str(path), "n_nodes": self.n, "n_edges": self.n_edges, "bytes": path.stat().st_size}

    @staticmethod
    def from_sff(path, name: Optional[str] = None) -> "Connectome":
        rd = SFFReader(Path(path))
        deg = np.rint(rd.read_tensor(_T_DEG)).astype(np.int64)
        indices = np.rint(rd.read_tensor(_T_IDX)).astype(np.int32)
        weights = rd.read_tensor(_T_W).astype(np.float32)
        type_code = np.rint(rd.read_tensor(_T_TYPE)).astype(np.int32)
        n = deg.size
        indptr = np.zeros(n + 1, dtype=np.int64)
        indptr[1:] = np.cumsum(deg)
        type_names = ["unknown"]
        body_parts: dict = {}
        for ex in rd.experiments():
            if ex.get("type") in (_EXP_META, "connectome_meta") or ex.get("exp_type") == _EXP_META:
                pass
            payload = ex.get("payload", ex)
            if isinstance(payload, dict) and "type_names" in payload:
                type_names = payload["type_names"]
            if isinstance(payload, dict) and "body_ids" in payload:
                body_parts[int(payload["offset"])] = payload["body_ids"]
        body_ids = None
        if body_parts:
            arr = []
            for off in sorted(body_parts):
                arr.extend(body_parts[off])
            body_ids = np.array(arr, dtype=np.int64)
        rd.close()
        return Connectome(n, indptr, indices, weights, body_ids=body_ids, type_code=type_code,
                          type_names=type_names, name=name or Path(path).stem)

    # ---- description -----------------------------------------------------
    def describe(self) -> str:
        by_type = {nm: int((self.type_code == c).sum()) for c, nm in enumerate(self.type_names)}
        top = sorted(by_type.items(), key=lambda kv: -kv[1])[:6]
        lines = [f"Connectome '{self.name}': {self.n:,} neurons, {self.n_edges:,} synapses "
                 f"({self.n_edges / max(self.n, 1):.1f} out/neuron).",
                 "  types: " + ", ".join(f"{nm}×{c}" for nm, c in top),
                 f"  taps: sensory={self.sensory().size}  descending(DN.*)={self.descending().size}",
                 "  storage: rides in SFF as float32 CSR tensors (paged, checksummed); a slice can be read "
                 "without loading the whole graph.",
                 "  decision layer: feature_vector() feeds a JEV-style scorer, routing_prior() feeds a MoE "
                 "router — those engines are NOT in this tree yet; the taps are ready for them."]
        return "\n".join(lines)


class LinearReadout:
    """A real, fitted linear map from a readout (descending) activity vector to an action score per label.
    Fit by least squares (closed form, deterministic). This is the '5th step': SOKE learns ON TOP of the
    connectome scaffold. A bigger MLP / PPO policy is roadmap; this one is exact and testable."""

    def __init__(self, W: Optional[np.ndarray] = None, b: Optional[np.ndarray] = None, labels: Optional[list] = None):
        self.W = W
        self.b = b
        self.labels = labels or []

    def fit(self, X: np.ndarray, Y: np.ndarray, labels: Optional[list] = None, ridge: float = 1e-6) -> "LinearReadout":
        """X: [samples x features] descending activity. Y: [samples x n_labels] one-hot (or targets). Solves
        min ||[X 1] @ [W;b] - Y||^2 with a tiny ridge for conditioning (eager numpy.linalg only)."""
        X = np.ascontiguousarray(X, dtype=np.float64)
        Y = np.ascontiguousarray(Y, dtype=np.float64)
        if X.ndim != 2 or Y.ndim != 2 or X.shape[0] != Y.shape[0]:
            raise ValueError("X [S x F] and Y [S x L] must share the sample axis")
        Xa = np.concatenate([X, np.ones((X.shape[0], 1))], axis=1)
        A = Xa.T @ Xa + ridge * np.eye(Xa.shape[1])
        theta = np.linalg.solve(A, Xa.T @ Y)
        self.W = theta[:-1].astype(np.float32)
        self.b = theta[-1].astype(np.float32)
        self.labels = list(labels) if labels is not None else [f"label{i}" for i in range(Y.shape[1])]
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        x = np.ascontiguousarray(x, dtype=np.float32)
        return (x @ self.W + self.b).astype(np.float32)

    def act(self, x: np.ndarray):
        """Return (label, scores) — the argmax action a connectome tick drives."""
        s = self.predict(x)
        i = int(np.argmax(s))
        return (self.labels[i] if i < len(self.labels) else i), s


def _one_hot(y: np.ndarray, n: int) -> np.ndarray:
    y = np.asarray(y, dtype=np.int64)
    o = np.zeros((y.size, n), dtype=np.float64)
    o[np.arange(y.size), y] = 1.0
    return o


class MLPPolicy:
    """A small tanh MLP over the connectome's readout (descending) activity → an action distribution. Two ways
    to train it, both real and both proven in the self-test:
        fit_supervised(X, y)     backprop / gradient descent on softmax cross-entropy (imitation / labels)
        reinforce(states, R)     REINFORCE policy-gradient with a moving baseline (reward, no labels)
    Deterministic (seeded soke.rng, never numpy.random); eager numpy only. A full PPO clip is roadmap — this
    is the baseline-subtracted policy gradient it would build on."""

    def __init__(self, n_in: int, n_hidden: int = 16, n_out: int = 3, labels: Optional[list] = None, seed: int = 0):
        r = Rng(seed)
        s1 = (2.0 / (n_in + n_hidden)) ** 0.5
        s2 = (2.0 / (n_hidden + n_out)) ** 0.5
        self.W1 = (r.normal(0, 1, size=(n_in, n_hidden)) * s1)
        self.b1 = np.zeros(n_hidden)
        self.W2 = (r.normal(0, 1, size=(n_hidden, n_out)) * s2)
        self.b2 = np.zeros(n_out)
        self.labels = list(labels) if labels else [f"a{i}" for i in range(n_out)]
        self._rng = Rng(seed + 1)

    def _forward(self, X):
        h = np.tanh(X @ self.W1 + self.b1)
        z = h @ self.W2 + self.b2
        return h, z

    def probs(self, X) -> np.ndarray:
        X = np.atleast_2d(np.ascontiguousarray(X, dtype=np.float64))
        _, z = self._forward(X)
        z = z - z.max(axis=1, keepdims=True)
        e = np.exp(z)
        return e / e.sum(axis=1, keepdims=True)

    def act(self, x):
        p = self.probs(x)[0]
        i = int(np.argmax(p))
        return (self.labels[i] if i < len(self.labels) else i), p

    def fit_supervised(self, X, y, epochs: int = 300, lr: float = 0.2, l2: float = 1e-4) -> "MLPPolicy":
        """Gradient descent on softmax cross-entropy. y is integer labels (or a one-hot / target matrix)."""
        X = np.ascontiguousarray(X, dtype=np.float64)
        Y = _one_hot(y, self.W2.shape[1]) if np.ndim(y) == 1 else np.ascontiguousarray(y, dtype=np.float64)
        n = max(X.shape[0], 1)
        for _ in range(int(epochs)):
            h, z = self._forward(X)
            z = z - z.max(axis=1, keepdims=True)
            e = np.exp(z); P = e / e.sum(axis=1, keepdims=True)
            dz = (P - Y) / n
            dW2 = h.T @ dz + l2 * self.W2; db2 = dz.sum(0)
            dh = (dz @ self.W2.T) * (1.0 - h * h)
            dW1 = X.T @ dh + l2 * self.W1; db1 = dh.sum(0)
            self.W2 -= lr * dW2; self.b2 -= lr * db2
            self.W1 -= lr * dW1; self.b1 -= lr * db1
        return self

    def accuracy(self, X, y) -> float:
        return float((self.probs(X).argmax(axis=1) == np.asarray(y, dtype=np.int64)).mean())

    def reinforce(self, states, reward_fn: Callable, epochs: int = 300, lr: float = 0.1) -> "MLPPolicy":
        """REINFORCE with a moving-average baseline. `states` is [N x n_in]; `reward_fn(i, action)->reward`
        scores the action the policy sampled for state i. Ascends expected reward (no labels needed)."""
        states = np.ascontiguousarray(states, dtype=np.float64)
        n, L = states.shape[0], self.W2.shape[1]
        base = 0.0
        for _ in range(int(epochs)):
            P = self.probs(states)                                  # [N x L]
            u = self._rng.random(size=n)
            a = (u[:, None] < np.cumsum(P, axis=1)).argmax(axis=1)  # inverse-CDF sample
            rew = np.array([float(reward_fn(i, int(a[i]))) for i in range(n)])
            adv = (rew - base)[:, None]
            base = 0.9 * base + 0.1 * float(rew.mean())
            G = (_one_hot(a, L) - P) * adv / n                      # dJ/dz (ascend)
            h, _ = self._forward(states)
            dW2 = h.T @ G; db2 = G.sum(0)
            dh = (G @ self.W2.T) * (1.0 - h * h)
            dW1 = states.T @ dh; db1 = dh.sum(0)
            self.W2 += lr * dW2; self.b2 += lr * db2               # += : gradient ASCENT on reward
            self.W1 += lr * dW1; self.b1 += lr * db1
        return self

    def greedy_reward(self, states, reward_fn: Callable) -> float:
        """Mean reward if the policy acts greedily (argmax) on each state — the metric REINFORCE should raise."""
        acts = self.probs(states).argmax(axis=1)
        return float(np.mean([reward_fn(i, int(acts[i])) for i in range(len(acts))]))


# ==========================================================================
def verify_suite(chk=None, tmpdir=None):
    import tempfile
    from .util import Check
    chk = chk or Check("connectome_engine")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_cnx_"))

    # ---- a tiny hand graph with known numbers: 0 --100--> 1 --50--> 2 -----
    hand = Connectome.from_edges([(0, 1, 100.0, "SEN.a", "IN.b"), (1, 2, 50.0, "IN.b", "DN.motor")], name="hand")
    chk("from_edges builds CSR (3 nodes, 2 edges)", hand.n == 3 and hand.n_edges == 2, hand.describe().splitlines()[0])
    chk("edge_src maps each edge to its pre-neuron", hand.edge_src().tolist() == [0, 1])

    # step math, plug-in #1: a=[1,0,0], decay=0.8, scale=100 -> out[1]=tanh(1)=0.761594...
    a0 = np.array([1.0, 0.0, 0.0], dtype=np.float32)
    o1 = hand.step(a0, decay=0.8, syn_scale=100.0)
    exp1_1 = np.tanh(1.0) * 100.0 / 100.0
    chk("step plug-in #1: propagate tanh(1)*100/100 to node 1", abs(float(o1[1]) - exp1_1) < 1e-6, f"{float(o1[1]):.9f} vs {exp1_1:.9f}")
    chk("step plug-in #1: node 0 only leaks (0.8*1)", abs(float(o1[0]) - 0.8) < 1e-6, f"{float(o1[0]):.9f}")
    chk("step plug-in #1: node 2 gets tanh(0)=0", abs(float(o1[2]) - 0.0) < 1e-9, f"{float(o1[2]):.9f}")

    # step math, plug-in #2: a=[2,3,-1], decay=0.5, scale=10 -> out[2]=0.5*(-1)+tanh(3)*50/10
    a1 = np.array([2.0, 3.0, -1.0], dtype=np.float32)
    o2 = hand.step(a1, decay=0.5, syn_scale=10.0)
    exp2_2 = 0.5 * (-1.0) + np.tanh(3.0) * 50.0 / 10.0
    exp2_1 = 0.5 * 3.0 + np.tanh(2.0) * 100.0 / 10.0
    chk("step plug-in #2: node 2 = leak + tanh(3)*50/10", abs(float(o2[2]) - exp2_2) < 1e-5, f"{float(o2[2]):.6f} vs {exp2_2:.6f}")
    chk("step plug-in #2: node 1 = leak + tanh(2)*100/10", abs(float(o2[1]) - exp2_1) < 1e-5, f"{float(o2[1]):.6f} vs {exp2_1:.6f}")

    # decay-only: no edges -> exact geometric leak
    empty = Connectome.from_edges([(0, 0, 0.0)], name="self")   # a single zero-weight self-loop
    va = np.array([4.0], dtype=np.float32)
    vb = empty.step(va, decay=0.3, syn_scale=100.0)
    chk("zero-weight edge contributes nothing; pure 0.3 leak", abs(float(vb[0]) - 1.2) < 1e-6, f"{float(vb[0]):.9f}")

    # input injection onto the leaked state
    o3 = hand.step(a0, input_idx=[2], input_val=[5.0], decay=0.8, syn_scale=100.0)
    chk("input injects onto the leaked state at node 2", abs(float(o3[2]) - 5.0) < 1e-6, f"{float(o3[2]):.6f}")

    # ---- taps (regex over type names) ------------------------------------
    chk("descending() finds DN.motor", hand.descending().tolist() == [2])
    chk("sensory() finds SEN.a", hand.sensory().tolist() == [0])
    chk("group regex 'IN.*' finds the interneuron", hand.group("IN.*").tolist() == [1])

    # ---- pathways --------------------------------------------------------
    paths = hand.pathways([0], [2], k=1, max_hops=4)
    chk("pathway 0->2 goes through 1 at cost 1/100+1/50", len(paths) == 1 and paths[0][0] == [0, 1, 2]
        and abs(paths[0][1] - (1 / 100 + 1 / 50)) < 1e-9, str(paths))
    chk("no route to an unreachable target returns empty", hand.pathways([2], [0], k=1) == [])

    # ---- synthetic + SFF round-trip --------------------------------------
    syn = Connectome.synthetic(n_nodes=1500, avg_degree=8, seed=3)
    chk("synthetic has sensory and descending taps", syn.sensory().size > 0 and syn.descending().size > 0,
        f"sen={syn.sensory().size} dn={syn.descending().size}")
    sff = tmpdir / "c.sff"
    syn.to_sff(sff)
    back = Connectome.from_sff(sff)
    chk("SFF round-trip: node/edge counts preserved", back.n == syn.n and back.n_edges == syn.n_edges, f"{back.n},{back.n_edges}")
    chk("SFF round-trip: CSR arrays bit-exact", np.array_equal(back.indptr, syn.indptr)
        and np.array_equal(back.indices, syn.indices) and np.array_equal(back.weights, syn.weights))
    chk("SFF round-trip: type codes + names preserved", np.array_equal(back.type_code, syn.type_code)
        and back.type_names == syn.type_names)
    chk("SFF round-trip: descending tap identical after reload", np.array_equal(back.descending(), syn.descending()))

    # ---- simulate + readout ----------------------------------------------
    sen = syn.sensory(); dn = syn.descending()
    hist = syn.simulate(sen[:16], np.ones(min(16, sen.size), np.float32), ticks=6, readout_idx=dn, record=True)
    chk("simulate returns a [ticks x |readout|] history", hist.shape == (6, dn.size), str(hist.shape))
    chk("activity stays finite over the run", np.all(np.isfinite(hist)))

    # ---- LinearReadout recovers a known linear map -----------------------
    rng = Rng(11)
    Xtr = rng.normal(0, 1, size=(200, 5))
    Wtrue = rng.normal(0, 1, size=(5, 3))
    btrue = rng.normal(0, 1, size=(3,))
    Ytr = Xtr @ Wtrue + btrue
    ro = LinearReadout().fit(Xtr, Ytr, labels=["flee", "approach", "idle"])
    pred = ro.predict(Xtr[0].astype(np.float32))
    chk("LinearReadout recovers the linear map (err < 1e-3)", float(np.max(np.abs(pred - Ytr[0]))) < 1e-3,
        f"max|Δ| {float(np.max(np.abs(pred - Ytr[0]))):.2e}")
    lab, _ = ro.act(Xtr[0].astype(np.float32))
    chk("readout emits a labeled action", lab in ("flee", "approach", "idle"), str(lab))

    # ---- routing prior (MoE-facing adapter) ------------------------------
    prior = syn.routing_prior({"sensory": syn.sensory(), "descending": syn.descending(), "inter": syn.group("IN.*")})
    chk("routing_prior normalises to 1", abs(sum(prior.values()) - 1.0) < 1e-9, str({k: round(v, 3) for k, v in prior.items()}))

    # ---- feature vector adapter ------------------------------------------
    fv = syn.feature_vector(np.ones(syn.n, np.float32), dn)
    chk("feature_vector returns the descending slice", fv.shape == (dn.size,) and np.allclose(fv, 1.0))

    # ---- MLPPolicy: backprop learns a NONLINEAR map (XOR the linear readout cannot) ----
    Xxor = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=np.float64)
    yxor = np.array([0, 1, 1, 0])                      # XOR — not linearly separable
    pol = MLPPolicy(2, n_hidden=8, n_out=2, labels=["off", "on"], seed=2).fit_supervised(Xxor, yxor, epochs=800, lr=0.5)
    chk("MLPPolicy backprop solves XOR (100% — a linear readout cannot)", pol.accuracy(Xxor, yxor) == 1.0,
        f"acc {pol.accuracy(Xxor, yxor):.2f}")
    lin_xor = LinearReadout().fit(Xxor, _one_hot(yxor, 2))
    lin_acc = float((np.array([lin_xor.predict(x.astype(np.float32)).argmax() for x in Xxor]) == yxor).mean())
    chk("null recorded: the LINEAR readout fails XOR (that is why the MLP exists)", lin_acc < 1.0, f"linear acc {lin_acc:.2f}")

    # ---- REINFORCE raises reward on a contextual bandit (optimal action == context) ----
    ctx = np.array([0, 1, 2] * 20)
    S = _one_hot(ctx, 3)                               # state = one-hot context
    def reward_fn(i, a):
        return 1.0 if a == ctx[i] else 0.0
    rl = MLPPolicy(3, n_hidden=8, n_out=3, labels=["flee", "approach", "idle"], seed=5)
    r0 = rl.greedy_reward(S, reward_fn)
    rl.reinforce(S, reward_fn, epochs=400, lr=0.3)
    r1 = rl.greedy_reward(S, reward_fn)
    chk("REINFORCE raises greedy reward toward optimal (>0.95)", r1 > 0.95 and r1 > r0 + 0.3, f"{r0:.2f} -> {r1:.2f}")

    # ---- a policy trained on the connectome's OWN motor output ------------
    # task: from the descending (motor) readout alone, decode WHICH sensory group was stimulated.
    dn2 = syn.descending()
    sen_all = syn.sensory()
    grpA, grpB = sen_all[:40], sen_all[40:80]
    jit = Rng(7)
    feats, labels = [], []
    for c, grp in ((0, grpA), (1, grpB)):
        for _ in range(20):
            vals = (1.0 + 0.1 * jit.normal(0, 1, size=grp.size)).astype(np.float32)
            feats.append(syn.simulate(grp, vals, ticks=6, readout_idx=dn2))
            labels.append(c)
    feats = np.array(feats, dtype=np.float64); labels = np.array(labels, dtype=np.int64)
    cp = MLPPolicy(dn2.size, n_hidden=12, n_out=2, seed=1).fit_supervised(feats, labels, epochs=500, lr=0.3)
    chk("a policy decodes which sensory group fired, from motor output alone (>=90%)", cp.accuracy(feats, labels) >= 0.9,
        f"acc {cp.accuracy(feats, labels):.2f}")
    return chk


if __name__ == "__main__":
    c = Connectome.synthetic(3000, 10, seed=1)
    print(c.describe())
    print("\n".join(verify_suite().lines()))
