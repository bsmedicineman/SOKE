"""
soke.ledger — the LEDGER layer: one append-only, hash-chained, HMAC-signed
record of every proof, grounding, route, descent, fork, heal, null and node.

Each entry is filed twice (DLP cross-index): by protocol (how it was made) and
by domain (what it is about).

Record (JSONL, one per line):
  {"seq", "t", "protocol", "domain", "event", "payload", "prev", "hash", "sig"}
  hash = sha256(prev + canonical_json({seq,t,protocol,domain,event,payload}))
  sig  = hmac_sha256(key, hash)          (ed25519 is not in the stdlib; HMAC with a
                                           local key is what this build signs with —
                                           declared, not hidden)
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import threading
from pathlib import Path
from typing import Any, Iterator, Optional

from .util import canonical_json, iso_now, now

GENESIS = "GENESIS"
PROTOCOLS = ("MFP", "LFP", "DLP", "CRP", "OSP", "ALM", "EFP", "SOP", "HMS", "SFF", "ORB", "SYS")


class Ledger:
    def __init__(self, path: Path, key_path: Optional[Path] = None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.key_path = Path(key_path) if key_path else self.path.parent / "ledger.key"
        self._lock = threading.Lock()
        self._key = self._load_or_create_key()
        self._head = GENESIS
        self._seq = 0
        self._recover_head()

    # ------------------------------------------------------------------ keys
    def _load_or_create_key(self) -> bytes:
        if self.key_path.exists():
            return bytes.fromhex(self.key_path.read_text().strip())
        key = secrets.token_bytes(32)
        self.key_path.parent.mkdir(parents=True, exist_ok=True)
        self.key_path.write_text(key.hex())
        return key

    def _recover_head(self) -> None:
        if not self.path.exists():
            return
        last = None
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    last = line
        if last:
            try:
                rec = json.loads(last)
                self._head = rec["hash"]
                self._seq = int(rec["seq"]) + 1
            except Exception:
                pass

    # --------------------------------------------------------------- writing
    def append(self, protocol: str, event: str, payload: Any = None, domain: str = "sys") -> dict:
        with self._lock:
            body = {"seq": self._seq, "t": now(), "iso": iso_now(), "protocol": protocol,
                    "domain": domain, "event": event, "payload": payload}
            h = hashlib.sha256((self._head + canonical_json(body)).encode("utf-8")).hexdigest()
            sig = hmac.new(self._key, h.encode("utf-8"), hashlib.sha256).hexdigest()
            rec = dict(body)
            rec["prev"] = self._head
            rec["hash"] = h
            rec["sig"] = sig
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, sort_keys=True, default=str) + "\n")
            self._head = h
            self._seq += 1
            return rec

    @property
    def head(self) -> str:
        return self._head

    # --------------------------------------------------------------- reading
    def iter_records(self) -> Iterator[dict]:
        if not self.path.exists():
            return
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    yield json.loads(line)

    def verify_chain(self) -> tuple[bool, int, Optional[int]]:
        """Returns (ok, n_records, first_bad_seq)."""
        prev = GENESIS
        n = 0
        for rec in self.iter_records():
            body = {k: rec[k] for k in ("seq", "t", "iso", "protocol", "domain", "event", "payload")}
            h = hashlib.sha256((prev + canonical_json(body)).encode("utf-8")).hexdigest()
            if h != rec.get("hash") or rec.get("prev") != prev:
                return False, n, rec.get("seq")
            sig = hmac.new(self._key, h.encode("utf-8"), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(sig, rec.get("sig", "")):
                return False, n, rec.get("seq")
            prev = h
            n += 1
        return True, n, None

    def by_protocol(self, protocol: str) -> list[dict]:
        return [r for r in self.iter_records() if r.get("protocol") == protocol]

    def by_domain(self, domain: str) -> list[dict]:
        return [r for r in self.iter_records() if r.get("domain") == domain]

    def tail(self, n: int = 50) -> list[dict]:
        rows = list(self.iter_records())
        return rows[-n:]

    def export_bytes(self) -> bytes:
        """Raw JSONL bytes for embedding into an SFF LDG section."""
        if not self.path.exists():
            return b""
        return self.path.read_bytes()


class NullLedger(Ledger):
    """In-memory ledger for tests (no files)."""

    def __init__(self):  # noqa: D107
        self.path = Path(os.devnull)
        self.key_path = Path(os.devnull)
        self._lock = threading.Lock()
        self._key = b"\x00" * 32
        self._head = GENESIS
        self._seq = 0
        self.records: list[dict] = []

    def append(self, protocol: str, event: str, payload: Any = None, domain: str = "sys") -> dict:
        with self._lock:
            body = {"seq": self._seq, "t": now(), "iso": iso_now(), "protocol": protocol,
                    "domain": domain, "event": event, "payload": payload}
            h = hashlib.sha256((self._head + canonical_json(body)).encode("utf-8")).hexdigest()
            rec = dict(body)
            rec["prev"] = self._head
            rec["hash"] = h
            rec["sig"] = hmac.new(self._key, h.encode("utf-8"), hashlib.sha256).hexdigest()
            self.records.append(rec)
            self._head = h
            self._seq += 1
            return rec

    def iter_records(self) -> Iterator[dict]:
        yield from list(self.records)

    def export_bytes(self) -> bytes:
        return "".join(json.dumps(r, sort_keys=True, default=str) + "\n" for r in self.records).encode("utf-8")
