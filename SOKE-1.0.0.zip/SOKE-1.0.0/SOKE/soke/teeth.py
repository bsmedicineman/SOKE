"""
soke.teeth — the tooth and page codecs of the SFF format.

Two kinds of teeth ride the helices:

1. PAGE teeth (parametric helices): a page is up to PAGE_VALUES float32 values of
   one tensor, encoded in a declared *storage gauge* chosen per page by the
   Third Law of storage: among the encodings that fit the bit budget, keep the
   one with the smallest measured reconstruction error; record the steel-man
   baseline (linear group quantization, i.e. the GGUF Q8_0 / Q4_0 layouts) and
   the verdict (VERIFIED cut / TIE / NULL). Ties are recorded as ties.

   encodings:
     0 F32     raw float32                                   32.0 bpv
     1 F16     float16                                       16.0 bpv
     2 LIN8    group-32 f16 scale + int8   (== Q8_0 bits)     8.5 bpv
     3 LIN4    group-32 f16 scale + 4-bit  (== Q4_0 bits)     4.5 bpv
     4 L8      log2 gauge, group-32 (lo,hi f16) + sign bits + u8   10.0 bpv
     5 L4      log2 gauge, group-32 (lo,hi f16) + sign bits + u4    6.0 bpv
     6 DELTA8  group-32 f16 scale + int8 of (page - base page)      8.5 bpv  (checkpoint deltas)
     7 ZERO    all-zero page (sparse, zero-packed)                   0.0 bpv
     8 RAW     verbatim bytes of an unsupported source type          n/a
     9 TOOTH   knowledge tooth run (see below)                       n/a

2. KNOWLEDGE teeth (helical memory): the byte tooth of the data-recording spec:
     byte 0      : TT LLLLLL   (TT = base A/C/T/G -> 0..3, LLLLLL = payload length 0..62)
                   L == 63 means extended: next 4 bytes = u32 payload length
     payload     : record bytes
     last byte   : XOR checksum of header + payload
   A record is: domain u16 | flags u8 | gauge u8 | pair_ref u32 | cross_ref u32 |
                ident_len u16 | ident | text_len u32 | text | sha256(32)
"""
from __future__ import annotations

import hashlib
import struct
from dataclasses import dataclass
from typing import Optional

import numpy as np

from .rng import Rng

PAGE_VALUES = 4096
GROUP = 32

ENC_F32, ENC_F16, ENC_LIN8, ENC_LIN4, ENC_L8, ENC_L4, ENC_DELTA8, ENC_ZERO, ENC_RAW, ENC_TOOTH = range(10)
ENC_NAMES = {ENC_F32: "F32", ENC_F16: "F16", ENC_LIN8: "LIN8", ENC_LIN4: "LIN4", ENC_L8: "L8",
             ENC_L4: "L4", ENC_DELTA8: "DELTA8", ENC_ZERO: "ZERO", ENC_RAW: "RAW", ENC_TOOTH: "TOOTH"}
ENC_BY_NAME = {v: k for k, v in ENC_NAMES.items()}
ENC_BPV = {ENC_F32: 32.0, ENC_F16: 16.0, ENC_LIN8: 8.5, ENC_LIN4: 4.5, ENC_L8: 10.0, ENC_L4: 6.0,
           ENC_DELTA8: 8.5, ENC_ZERO: 0.0}
# storage gauge each encoding lives in (SFF register_kind codes: 0=R 1=Q 2=T 3=L 4=H 5=LIN)
ENC_GAUGE = {ENC_F32: 5, ENC_F16: 5, ENC_LIN8: 5, ENC_LIN4: 5, ENC_L8: 3, ENC_L4: 3, ENC_DELTA8: 5, ENC_ZERO: 5}

BASE_CODE = {"A": 0, "C": 1, "T": 2, "G": 3}
CODE_BASE = {v: k for k, v in BASE_CODE.items()}
# Base-pairing rules (SOKE Layout §5.3 / HELICAL_MEMORY_SYSTEM). The data-recording HMS v1.0
# draft used the opposite convention (A-G, C-T legal); the SOKE layout is the adopted default and
# the table is configurable in META.pairing_rules.
LEGAL_PAIRS = {frozenset("AT"), frozenset("CG"), frozenset("AC"), frozenset("TG")}
ILLEGAL_PAIRS = {frozenset("AG"), frozenset("CT")}


def pair_legal(a: str, b: str, legal: Optional[set] = None) -> bool:
    legal = legal or LEGAL_PAIRS
    return frozenset((a, b)) in legal


# ==========================================================================
# helpers
# ==========================================================================
def _pad32(x: np.ndarray) -> tuple[np.ndarray, int]:
    n = x.size
    rem = (-n) % GROUP
    if rem:
        x = np.concatenate([x, np.zeros(rem, dtype=x.dtype)])
    return x, n


def _f16_bytes(a: np.ndarray) -> bytes:
    return np.asarray(a, dtype=np.float16).tobytes()


def _from_f16(b: bytes, n: int) -> np.ndarray:
    return np.frombuffer(b, dtype=np.float16, count=n).astype(np.float32)


def pack_nibbles(q: np.ndarray) -> bytes:
    """q: uint8 array of 4-bit codes, length multiple of 2 -> low nibble first (GGUF Q4_0 order per group)."""
    q = q.astype(np.uint8)
    lo = q[0::2] & 0xF
    hi = q[1::2] & 0xF
    return (lo | (hi << 4)).astype(np.uint8).tobytes()


def unpack_nibbles(b: bytes, n: int) -> np.ndarray:
    a = np.frombuffer(b, dtype=np.uint8, count=(n + 1) // 2)
    out = np.empty(a.size * 2, dtype=np.uint8)
    out[0::2] = a & 0xF
    out[1::2] = a >> 4
    return out[:n]


# ==========================================================================
# PAGE encoders / decoders
# ==========================================================================
def encode_page(x: np.ndarray, enc: int, base: Optional[np.ndarray] = None) -> bytes:
    x = np.ascontiguousarray(x, dtype=np.float32).ravel()
    if enc == ENC_F32:
        return x.tobytes()
    if enc == ENC_F16:
        return _f16_bytes(x)
    if enc == ENC_ZERO:
        return b""
    if enc == ENC_LIN8:
        return _enc_lin(x, 8)
    if enc == ENC_LIN4:
        return _enc_lin(x, 4)
    if enc == ENC_L8:
        return _enc_log(x, 8)
    if enc == ENC_L4:
        return _enc_log(x, 4)
    if enc == ENC_DELTA8:
        if base is None:
            raise ValueError("DELTA8 needs a base page")
        return _enc_lin(x - np.ascontiguousarray(base, dtype=np.float32).ravel(), 8)
    raise ValueError(f"cannot encode enc={enc} as a numeric page")


def decode_page(b: bytes, enc: int, count: int, base: Optional[np.ndarray] = None) -> np.ndarray:
    if enc == ENC_F32:
        return np.frombuffer(b, dtype=np.float32, count=count).copy()
    if enc == ENC_F16:
        return _from_f16(b, count)
    if enc == ENC_ZERO:
        return np.zeros(count, dtype=np.float32)
    if enc == ENC_LIN8:
        return _dec_lin(b, 8, count)
    if enc == ENC_LIN4:
        return _dec_lin(b, 4, count)
    if enc == ENC_L8:
        return _dec_log(b, 8, count)
    if enc == ENC_L4:
        return _dec_log(b, 4, count)
    if enc == ENC_DELTA8:
        if base is None:
            raise ValueError("DELTA8 needs a base page")
        return _dec_lin(b, 8, count) + np.ascontiguousarray(base, dtype=np.float32).ravel()[:count]
    raise ValueError(f"cannot decode enc={enc} as a numeric page")


# ---- linear group quantization (the steel-man; bit-identical layout family to Q8_0 / Q4_0)
def _enc_lin(x: np.ndarray, bits: int) -> bytes:
    xp, n = _pad32(x)
    g = xp.reshape(-1, GROUP)
    amax_idx = np.argmax(np.abs(g), axis=1)
    amax = g[np.arange(g.shape[0]), amax_idx]           # signed max-magnitude value (GGUF convention)
    if bits == 8:
        d = amax / 127.0
        d16 = d.astype(np.float16)
        dd = d16.astype(np.float32)
        inv = np.where(dd != 0, 1.0 / np.where(dd != 0, dd, 1.0), 0.0)
        q = np.clip(np.rint(g * inv[:, None]), -127, 127).astype(np.int8)
        return d16.tobytes() + q.tobytes()
    else:
        d = amax / -8.0
        d16 = d.astype(np.float16)
        dd = d16.astype(np.float32)
        inv = np.where(dd != 0, 1.0 / np.where(dd != 0, dd, 1.0), 0.0)
        q = np.clip(np.rint(g * inv[:, None]) + 8, 0, 15).astype(np.uint8)
        return d16.tobytes() + pack_nibbles(q.ravel())


def _dec_lin(b: bytes, bits: int, count: int) -> np.ndarray:
    ng = (count + GROUP - 1) // GROUP
    d = np.frombuffer(b, dtype=np.float16, count=ng).astype(np.float32)
    off = ng * 2
    if bits == 8:
        q = np.frombuffer(b, dtype=np.int8, count=ng * GROUP, offset=off).astype(np.float32).reshape(ng, GROUP)
        out = q * d[:, None]
    else:
        q = unpack_nibbles(b[off:off + ng * GROUP // 2], ng * GROUP).astype(np.float32).reshape(ng, GROUP)
        out = (q - 8.0) * d[:, None]
    return out.ravel()[:count].astype(np.float32)


# ---- log2 gauge quantization (L-register storage): uniform *relative* error inside the group
def _enc_log(x: np.ndarray, bits: int) -> bytes:
    xp, n = _pad32(x)
    g = xp.reshape(-1, GROUP)
    ng = g.shape[0]
    sign = (g < 0).astype(np.uint8)
    mag = np.abs(g)
    nz = mag > 0
    levels = (1 << bits) - 1                     # code 0 reserved for exact zero
    lo = np.zeros(ng, dtype=np.float32)
    hi = np.zeros(ng, dtype=np.float32)
    codes = np.zeros_like(g, dtype=np.uint8)
    for i in range(ng):
        m = mag[i][nz[i]]
        if m.size == 0:
            continue
        lm = np.log2(m)
        lo[i], hi[i] = lm.min(), lm.max()
    lo16 = lo.astype(np.float16)
    hi16 = hi.astype(np.float16)
    lo_r = lo16.astype(np.float32)
    hi_r = hi16.astype(np.float32)
    span = np.maximum(hi_r - lo_r, 1e-12)
    lm_all = np.where(nz, np.log2(np.where(nz, mag, 1.0)), 0.0)
    c = np.rint((lm_all - lo_r[:, None]) / span[:, None] * (levels - 1)) + 1
    c = np.clip(c, 1, levels).astype(np.uint8)
    codes = np.where(nz, c, 0).astype(np.uint8)
    sign_bits = np.packbits(sign, axis=1, bitorder="little")   # 4 bytes per group
    payload = lo16.tobytes() + hi16.tobytes() + sign_bits.tobytes()
    if bits == 8:
        payload += codes.tobytes()
    else:
        payload += pack_nibbles(codes.ravel())
    return payload


def _dec_log(b: bytes, bits: int, count: int) -> np.ndarray:
    ng = (count + GROUP - 1) // GROUP
    lo = np.frombuffer(b, dtype=np.float16, count=ng).astype(np.float32)
    hi = np.frombuffer(b, dtype=np.float16, count=ng, offset=ng * 2).astype(np.float32)
    off = ng * 4
    sign_bits = np.frombuffer(b, dtype=np.uint8, count=ng * 4, offset=off).reshape(ng, 4)
    sign = np.unpackbits(sign_bits, axis=1, bitorder="little")[:, :GROUP]
    off += ng * 4
    levels = (1 << bits) - 1
    if bits == 8:
        codes = np.frombuffer(b, dtype=np.uint8, count=ng * GROUP, offset=off).reshape(ng, GROUP)
    else:
        codes = unpack_nibbles(b[off:off + ng * GROUP // 2], ng * GROUP).reshape(ng, GROUP)
    span = np.maximum(hi - lo, 1e-12)
    lm = lo[:, None] + (codes.astype(np.float32) - 1.0) / (levels - 1) * span[:, None]
    mag = np.exp2(lm)
    out = np.where(codes == 0, 0.0, mag) * np.where(sign == 1, -1.0, 1.0)
    return out.ravel()[:count].astype(np.float32)


# ==========================================================================
# Third Law of storage — gauge selection per page
# ==========================================================================
BUDGET_ENCODINGS = {
    # budget name -> (baseline steel-man, candidates within the same bit band)
    "f32": (ENC_F32, [ENC_F32]),
    "f16": (ENC_F16, [ENC_F16]),
    "8bit": (ENC_LIN8, [ENC_LIN8, ENC_L8]),
    "4bit": (ENC_LIN4, [ENC_LIN4, ENC_L4]),
}


@dataclass
class PageChoice:
    enc: int
    payload: bytes
    mse: float
    baseline_enc: int
    baseline_mse: float
    status: str          # VERIFIED (>=33.3% error cut vs baseline), TIE, NULL, or EXACT
    cut: float


def choose_encoding(x: np.ndarray, budget: str = "8bit", allow_zero: bool = True) -> PageChoice:
    x = np.ascontiguousarray(x, dtype=np.float32).ravel()
    if allow_zero and not np.any(x):
        return PageChoice(ENC_ZERO, b"", 0.0, ENC_ZERO, 0.0, "EXACT", 0.0)
    base_enc, cands = BUDGET_ENCODINGS[budget]
    best = None
    base_mse = None
    for enc in cands:
        payload = encode_page(x, enc)
        y = decode_page(payload, enc, x.size)
        mse = float(np.mean((y - x) ** 2))
        if enc == base_enc:
            base_mse = mse
        if best is None or mse < best[2]:
            best = (enc, payload, mse)
    enc, payload, mse = best
    if base_mse is None:
        base_mse = mse
    if enc == base_enc or base_mse == 0:
        status, cut = ("EXACT" if mse == 0 else "BASELINE"), 0.0
    else:
        cut = (base_mse - mse) / base_mse
        status = "VERIFIED" if cut >= 1.0 / 3.0 else ("TIE" if cut > 0 else "NULL")
        if status != "VERIFIED":
            # eviction condition: below the one-third cut the orthometric route is struck; keep the baseline
            enc, payload, mse = base_enc, encode_page(x, base_enc), base_mse
    return PageChoice(enc, payload, mse, base_enc, base_mse, status, cut)


# ==========================================================================
# KNOWLEDGE teeth
# ==========================================================================
_REC_HDR = struct.Struct("<HBBIIH")     # domain, flags, gauge, pair_ref, cross_ref, ident_len


@dataclass
class ToothRecord:
    base: str                 # A/C/T/G
    domain: int
    ident: str
    text: str
    gauge: int = 5            # SFF register kind
    flags: int = 0            # bit0 = PAIRED_PENDING, bit1 = verified, bit2 = numeric payload
    pair_ref: int = 0xFFFFFFFF
    cross_ref: int = 0xFFFFFFFF
    invariant: bytes = b""

    def compute_invariant(self) -> bytes:
        h = hashlib.sha256()
        h.update(self.base.encode())
        h.update(struct.pack("<H", self.domain))
        h.update(self.ident.encode("utf-8"))
        h.update(b"\x00")
        h.update(self.text.encode("utf-8"))
        return h.digest()

    def to_bytes(self) -> bytes:
        if not self.invariant:
            self.invariant = self.compute_invariant()
        ident_b = self.ident.encode("utf-8")
        text_b = self.text.encode("utf-8")
        return (_REC_HDR.pack(self.domain, self.flags, self.gauge, self.pair_ref, self.cross_ref, len(ident_b))
                + ident_b + struct.pack("<I", len(text_b)) + text_b + self.invariant)

    @staticmethod
    def from_bytes(base: str, b: bytes) -> "ToothRecord":
        domain, flags, gauge, pair_ref, cross_ref, ident_len = _REC_HDR.unpack_from(b, 0)
        off = _REC_HDR.size
        ident = b[off:off + ident_len].decode("utf-8")
        off += ident_len
        text_len = struct.unpack_from("<I", b, off)[0]
        off += 4
        text = b[off:off + text_len].decode("utf-8", errors="replace")
        off += text_len
        inv = b[off:off + 32]
        return ToothRecord(base, domain, ident, text, gauge, flags, pair_ref, cross_ref, inv)


def encode_tooth(base: str, payload: bytes) -> bytes:
    tt = BASE_CODE[base] << 6
    if len(payload) < 63:
        hdr = bytes([tt | len(payload)])
    else:
        hdr = bytes([tt | 63]) + struct.pack("<I", len(payload))
    chk = 0
    for byte in hdr + payload:
        chk ^= byte
    return hdr + payload + bytes([chk])


def decode_tooth(b: bytes, off: int = 0) -> tuple[str, bytes, int]:
    """Returns (base, payload, next_offset). Raises ValueError on checksum failure."""
    h0 = b[off]
    base = CODE_BASE[h0 >> 6]
    ln = h0 & 63
    p = off + 1
    hdr_end = p
    if ln == 63:
        ln = struct.unpack_from("<I", b, p)[0]
        p += 4
        hdr_end = p
    payload = bytes(b[p:p + ln])
    chk = b[p + ln]
    x = 0
    for byte in bytes(b[off:hdr_end]) + payload:
        x ^= byte
    if x != chk:
        raise ValueError(f"tooth checksum mismatch at offset {off}")
    return base, payload, p + ln + 1


def encode_tooth_run(records: list[ToothRecord]) -> bytes:
    return b"".join(encode_tooth(r.base, r.to_bytes()) for r in records)


def decode_tooth_run(b: bytes) -> list[ToothRecord]:
    out = []
    off = 0
    n = len(b)
    while off < n:
        base, payload, off = decode_tooth(b, off)
        out.append(ToothRecord.from_bytes(base, payload))
    return out


def iter_tooth_run(b: bytes):
    """Streaming decode: yields (record_offset, ToothRecord)."""
    off = 0
    n = len(b)
    while off < n:
        start = off
        base, payload, off = decode_tooth(b, off)
        yield start, ToothRecord.from_bytes(base, payload)


# ==========================================================================
# self-checks
# ==========================================================================
def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("teeth")
    rng = Rng(369)
    x = rng.normal(0, 0.02, PAGE_VALUES).astype(np.float32)
    x[:5] = 0
    for enc, tol in ((ENC_F32, 0.0), (ENC_F16, 5e-4), (ENC_LIN8, 1e-2), (ENC_LIN4, 0.15), (ENC_L8, 1e-2), (ENC_L4, 0.2)):
        y = decode_page(encode_page(x, enc), enc, x.size)
        rel = float(np.sqrt(np.mean((y - x) ** 2)) / np.sqrt(np.mean(x ** 2)))
        chk(f"page round trip {ENC_NAMES[enc]}", y.shape == x.shape and rel <= tol, f"rel rmse {rel:.2e}")
    # exactness of log gauge on zeros and signs
    z = np.array([0, -1, 2, -4, 8, 0, 0.5, -0.25] + [0] * 24, dtype=np.float32)
    y = decode_page(encode_page(z, ENC_L8), ENC_L8, z.size)
    chk("L8 exact zeros and signs", np.all((y == 0) == (z == 0)) and np.all(np.sign(y) == np.sign(z)), "")
    chk("L8 powers of two within 1% relative", np.allclose(y[1:5], z[1:5], rtol=1e-2), f"{y[1:5]}")
    # odd-length page + delta
    x2 = rng.normal(0, 1, 1000).astype(np.float32)
    y2 = decode_page(encode_page(x2, ENC_LIN8), ENC_LIN8, 1000)
    chk("odd page length LIN8", y2.size == 1000 and np.max(np.abs(y2 - x2)) < 0.05)
    d = x2 + rng.normal(0, 1e-3, 1000).astype(np.float32)
    yd = decode_page(encode_page(d, ENC_DELTA8, base=x2), ENC_DELTA8, 1000, base=x2)
    chk("DELTA8 vs base", np.max(np.abs(yd - d)) < 1e-4, f"max err {np.max(np.abs(yd - d)):.2e}")
    # outlier-channel page (one x100 value per group, the LLM outlier regime): log gauge wins the 8-bit band
    w = rng.normal(0, 1, PAGE_VALUES)
    w[::GROUP] *= 100.0
    pc = choose_encoding(w.astype(np.float32), "8bit")
    chk("Third-Law storage: outlier page picks L8 (>=33% MSE cut)", pc.enc == ENC_L8 and pc.status == "VERIFIED", f"cut {pc.cut * 100:.1f}% ({ENC_NAMES[pc.enc]})")
    pcn = choose_encoding(x, "8bit")
    chk("Third-Law storage: gaussian page keeps baseline (tie declared)", pcn.enc == ENC_LIN8 and pcn.status in ("BASELINE", "TIE", "NULL"), f"{pcn.status} cut {pcn.cut * 100:.1f}%")
    # second route for the verdict: recompute both errors independently
    w32 = w.astype(np.float32)
    yb = decode_page(encode_page(w32, ENC_LIN8), ENC_LIN8, PAGE_VALUES)
    yl = decode_page(encode_page(w32, ENC_L8), ENC_L8, PAGE_VALUES)
    mb, ml = float(np.mean((yb - w32) ** 2)), float(np.mean((yl - w32) ** 2))
    chk("Third-Law storage second route", abs(mb - pc.baseline_mse) <= 1e-6 * mb and abs(ml - pc.mse) <= 1e-6 * ml and ml < mb * (2 / 3), f"lin {mb:.3e} log {ml:.3e}")
    pz = choose_encoding(np.zeros(64, np.float32))
    chk("zero page packs to ZERO", pz.enc == ENC_ZERO and pz.payload == b"")
    # knowledge teeth
    r = ToothRecord("A", 1, "peano_axioms", "0 is a natural number; every n has a successor S(n)", gauge=1)
    run = encode_tooth_run([r, ToothRecord("T", 1, "induction", "P(0) and P(n)->P(n+1) gives forall n P(n)", gauge=2)])
    back = decode_tooth_run(run)
    chk("tooth run round trip", len(back) == 2 and back[0].ident == "peano_axioms" and back[1].base == "T")
    chk("tooth invariant hash carried", back[0].invariant == r.compute_invariant())
    bad = bytearray(run)
    bad[5] ^= 0x01
    try:
        decode_tooth_run(bytes(bad))
        chk("tooth checksum catches corruption", False)
    except ValueError:
        chk("tooth checksum catches corruption", True)
    big = ToothRecord("G", 2, "long", "x" * 5000)
    chk("extended tooth (>63 bytes)", decode_tooth_run(encode_tooth_run([big]))[0].text == "x" * 5000)
    chk("pairing rules A-T legal, A-G illegal", pair_legal("A", "T") and not pair_legal("A", "G"))
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
