"""
soke.rng — SOKE's own random number generator (no numpy.random).

Why: Windows Application Control policies (Smart App Control / WDAC) can block
numpy's compiled `numpy/random/*.pyd` extension modules even when numpy's core
loads fine — observed on the operator's machine ("DLL load failed while
importing bit_generator: An Application Control policy has blocked this file").
Everything below uses only numpy core integer/float array arithmetic, so the
program runs wherever `import numpy` succeeds.

Generator: counter-based SplitMix64.
    state_k  = seed + (k + 1) * GOLDEN          (mod 2^64)
    out_k    = mix(state_k)                     (the SplitMix64 finalizer)
Output k depends only on (seed, k), so draws are reproducible regardless of
how they are chunked, and the whole state is one integer counter — trivially
saved and restored (`state` property).

Verified in verify_suite: determinism, chunk-independence, uniform moments,
normal moments, integer range/uniformity (chi-square), choice(p) frequencies,
permutation validity, state round-trip; second route: the same outputs from a
pure-Python scalar SplitMix64.
"""
from __future__ import annotations

import math
from typing import Optional, Sequence, Union

import numpy as np

GOLDEN = 0x9E3779B97F4A7C15
_M1 = 0xBF58476D1CE4E5B9
_M2 = 0x94D049BB133111EB
_MASK = (1 << 64) - 1
_U64 = np.uint64


def _mix_array(z: np.ndarray) -> np.ndarray:
    """SplitMix64 finalizer on a uint64 array (wrapping arithmetic)."""
    with np.errstate(over="ignore"):
        z = (z ^ (z >> _U64(30))) * _U64(_M1)
        z = (z ^ (z >> _U64(27))) * _U64(_M2)
        return z ^ (z >> _U64(31))


def splitmix64_scalar(seed: int, k: int) -> int:
    """Pure-Python second route: output k of the sequence for `seed`."""
    z = (seed + (k + 1) * GOLDEN) & _MASK
    z = ((z ^ (z >> 30)) * _M1) & _MASK
    z = ((z ^ (z >> 27)) * _M2) & _MASK
    return (z ^ (z >> 31)) & _MASK


def _seed64(seed: Optional[Union[int, str, bytes]]) -> int:
    if seed is None:
        import os
        return int.from_bytes(os.urandom(8), "little")
    if isinstance(seed, (bytes, bytearray)):
        seed = int.from_bytes(bytes(seed)[:8].ljust(8, b"\0"), "little")
    if isinstance(seed, str):
        import hashlib
        seed = int.from_bytes(hashlib.sha256(seed.encode("utf-8")).digest()[:8], "little")
    seed = int(seed) & _MASK
    # scramble the seed itself so that seeds 0, 1, 2 give unrelated streams
    return splitmix64_scalar(seed, 0x5EED)


class _BitGenShim:
    """`rng.bit_generator.state` compatibility with the numpy Generator API used in older code."""

    def __init__(self, rng: "Rng"):
        self._rng = rng

    @property
    def state(self) -> dict:
        return self._rng.state

    @state.setter
    def state(self, s: dict) -> None:
        self._rng.state = s


class Rng:
    """Deterministic vectorized generator. All array outputs are float64/int64 unless asked otherwise."""

    def __init__(self, seed: Optional[Union[int, str, bytes]] = None):
        self._seed = _seed64(seed)
        self._counter = 0
        self.bit_generator = _BitGenShim(self)

    # ---------------------------------------------------------------- state
    @property
    def state(self) -> dict:
        return {"seed": self._seed, "counter": self._counter}

    @state.setter
    def state(self, s: dict) -> None:
        self._seed = int(s["seed"]) & _MASK
        self._counter = int(s["counter"])

    def spawn(self, n: int = 1) -> list["Rng"]:
        """Independent child generators (seeded from this stream)."""
        return [Rng(int(v)) for v in self.raw(n)]

    # ------------------------------------------------------------------ raw
    def raw(self, n: int) -> np.ndarray:
        """n uint64 outputs, consuming n counters."""
        n = int(n)
        if n < 0:
            raise ValueError("n must be >= 0")
        with np.errstate(over="ignore"):
            k = np.arange(self._counter + 1, self._counter + n + 1, dtype=np.uint64)
            z = k * _U64(GOLDEN) + _U64(self._seed)
        self._counter += n
        return _mix_array(z)

    # -------------------------------------------------------------- uniform
    def random(self, size=None) -> Union[float, np.ndarray]:
        """Uniform in [0, 1) with 53-bit resolution."""
        n, shape = _size(size)
        u = (self.raw(n) >> _U64(11)).astype(np.float64) * (1.0 / 9007199254740992.0)
        return _reshape(u, shape, size)

    def uniform(self, low: float = 0.0, high: float = 1.0, size=None):
        return low + (high - low) * self.random(size)

    # --------------------------------------------------------------- normal
    def normal(self, loc: float = 0.0, scale: float = 1.0, size=None):
        """Gaussian via Box–Muller (pairs; an odd request consumes one extra draw)."""
        n, shape = _size(size)
        m = (n + 1) // 2
        u = (self.raw(2 * m) >> _U64(11)).astype(np.float64) * (1.0 / 9007199254740992.0)
        u1 = 1.0 - u[:m]                      # (0, 1]  -> log is finite
        u2 = u[m:]
        r = np.sqrt(-2.0 * np.log(u1))
        th = (2.0 * math.pi) * u2
        out = np.empty(2 * m, dtype=np.float64)
        out[0::2] = r * np.cos(th)
        out[1::2] = r * np.sin(th)
        out = out[:n] * float(scale) + float(loc)
        return _reshape(out, shape, size)

    def standard_normal(self, size=None):
        return self.normal(0.0, 1.0, size)

    # ------------------------------------------------------------- integers
    def integers(self, low: int, high: Optional[int] = None, size=None, dtype=np.int64):
        """Integers in [low, high) (numpy Generator convention). Modulo reduction of 64-bit outputs:
        bias <= range / 2^64, i.e. below 1e-13 for every range used in SOKE."""
        if high is None:
            low, high = 0, low
        low, high = int(low), int(high)
        if high <= low:
            raise ValueError("high must be > low")
        span = high - low
        n, shape = _size(size)
        r = self.raw(n) % _U64(span)
        out = r.astype(np.int64) + low
        out = out.astype(dtype)
        return _reshape(out, shape, size)

    # --------------------------------------------------------------- choice
    def choice(self, a, size=None, replace: bool = True, p=None):
        """Sample from range(a) or from a sequence; optional probabilities p; without replacement supported."""
        if isinstance(a, (int, np.integer)):
            n_items = int(a)
            items = None
        else:
            items = np.asarray(a)
            n_items = len(items)
        n, shape = _size(size)
        if p is not None:
            p = np.asarray(p, dtype=np.float64).ravel()
            if p.shape[0] != n_items:
                raise ValueError("p must have one entry per item")
            s = float(p.sum())
            if not (s > 0) or np.any(p < 0):
                raise ValueError("p must be non-negative with a positive sum")
            cdf = np.cumsum(p / s)
            cdf[-1] = 1.0
            if replace or n == 1:
                idx = np.searchsorted(cdf, self.random(n), side="right")
                idx = np.minimum(idx, n_items - 1)
            else:
                # sequential draws without replacement (weights renormalised each step)
                w = p.copy(); idx = np.empty(n, dtype=np.int64)
                for i in range(n):
                    c = np.cumsum(w / w.sum()); c[-1] = 1.0
                    j = int(min(np.searchsorted(c, float(self.random()), side="right"), n_items - 1))
                    idx[i] = j; w[j] = 0.0
        elif replace:
            idx = self.integers(0, n_items, n)
        else:
            if n > n_items:
                raise ValueError("cannot draw more items than exist without replacement")
            idx = self.permutation(n_items)[:n]
        idx = np.asarray(idx, dtype=np.int64)
        out = idx if items is None else items[idx]
        return _reshape(out, shape, size)

    def permutation(self, n: int) -> np.ndarray:
        return np.argsort(self.random(int(n)), kind="stable")

    def shuffle(self, x) -> None:
        idx = self.permutation(len(x))
        x[:] = np.asarray(x)[idx]

    def bytes(self, n: int) -> bytes:
        return self.integers(0, 256, n, dtype=np.uint8).tobytes()


def _size(size):
    if size is None:
        return 1, None
    if isinstance(size, (int, np.integer)):
        return int(size), (int(size),)
    shape = tuple(int(s) for s in size)
    n = 1
    for s in shape:
        n *= s
    return n, shape


def _reshape(arr: np.ndarray, shape, size):
    if size is None:
        return arr.reshape(-1)[0].item() if arr.dtype.kind in "fiu" else arr.reshape(-1)[0]
    return arr.reshape(shape)


def default_rng(seed=None) -> Rng:
    return Rng(seed)


# --------------------------------------------------------------------- tests
def verify_suite(chk=None):
    from .util import Check
    chk = chk or Check("rng")
    r1, r2 = Rng(42), Rng(42)
    a = r1.random(1000); b = r2.random(1000)
    chk("determinism: same seed same stream", bool(np.array_equal(a, b)))
    r3 = Rng(42); c = np.concatenate([r3.random(300), r3.random(700)])
    chk("chunk-independence: 300+700 == 1000", bool(np.array_equal(a, c)))
    chk("different seeds differ", not np.array_equal(Rng(1).random(50), Rng(2).random(50)))
    # second route: pure-Python scalar SplitMix64 reproduces the vectorised outputs
    r4 = Rng(7); raw = r4.raw(5)
    seed = r4.state["seed"]
    ok = all(int(raw[k]) == splitmix64_scalar(seed, k) for k in range(5))
    chk("second route: scalar SplitMix64 == vectorised", ok, f"first={int(raw[0])}")
    u = Rng(3).random(200_000)
    chk("uniform moments", abs(u.mean() - 0.5) < 0.005 and abs(u.var() - 1 / 12) < 0.002, f"mean={u.mean():.4f} var={u.var():.4f}")
    chk("uniform range [0,1)", float(u.min()) >= 0.0 and float(u.max()) < 1.0)
    z = Rng(5).normal(0, 1, 200_000)
    k4 = float(np.mean(z ** 4))
    chk("normal moments (mean, var, kurtosis 3)", abs(z.mean()) < 0.01 and abs(z.var() - 1) < 0.02 and abs(k4 - 3) < 0.1,
        f"mean={z.mean():.4f} var={z.var():.4f} m4={k4:.3f}")
    z2 = Rng(5).normal(2.0, 0.5, (100, 100))
    chk("normal loc/scale/shape", z2.shape == (100, 100) and abs(z2.mean() - 2) < 0.02 and abs(z2.std() - 0.5) < 0.01)
    ii = Rng(9).integers(0, 256, 256_000)
    counts = np.bincount(ii, minlength=256)
    chi2 = float(np.sum((counts - 1000.0) ** 2 / 1000.0))
    chk("integers in range", int(ii.min()) >= 0 and int(ii.max()) <= 255)
    chk("integers uniform (chi2 255 dof ~ 255 ± 70)", 150 < chi2 < 400, f"chi2={chi2:.1f}")
    chk("integers scalar form", isinstance(Rng(1).integers(0, 10), int))
    chk("integers dtype uint8", Rng(1).integers(0, 256, 10, dtype=np.uint8).dtype == np.uint8)
    p = np.array([0.1, 0.2, 0.7]); d = Rng(11).choice(3, size=100_000, p=p)
    freq = np.bincount(d, minlength=3) / d.size
    chk("choice(p) frequencies", bool(np.all(np.abs(freq - p) < 0.01)), str(np.round(freq, 3)))
    chk("choice(p) scalar", isinstance(Rng(1).choice(256, p=np.ones(256) / 256), int))
    perm = Rng(13).permutation(500)
    chk("permutation is a permutation", bool(np.array_equal(np.sort(perm), np.arange(500))))
    sel = Rng(13).choice(50, size=20, replace=False)
    chk("choice without replacement: distinct", len(set(sel.tolist())) == 20 and int(sel.max()) < 50)
    r5 = Rng(21); r5.random(17); st = r5.state; x1 = r5.normal(0, 1, 9)
    r5.state = st; x2 = r5.normal(0, 1, 9)
    chk("state save/restore replays", bool(np.array_equal(x1, x2)))
    r6 = Rng(21); r6.random(17); r6.bit_generator.state = st
    chk("bit_generator.state shim", bool(np.array_equal(r6.normal(0, 1, 9), x1)))
    chk("string seed accepted", Rng("soke").random(3).shape == (3,))
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
