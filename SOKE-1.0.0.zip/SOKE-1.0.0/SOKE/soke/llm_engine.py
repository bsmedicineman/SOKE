"""
soke.llm_engine — streaming inference for GGUF transformer models (llama / qwen2 / qwen2moe), numpy only.

The whole point: weights stay in the file. Every matrix product runs over row chunks of the
quantized tensor — dequantize a chunk, multiply, drop it — so a 7 B model scores text under the
same 1 GB ceiling as everything else in SOKE (slowly). Small models can be made resident
(dequantized once, Q8-style int8 + scale, or f32) when the memory guard allows.

Supported (VERIFIED against llama.cpp on synthetic models, see tests/crosscheck_llama_cpp.py):
  * llama    — RMSNorm, RoPE (interleaved pairs; llama-3 `rope_freqs` factors honoured), GQA, SwiGLU,
               optional Mixtral-style routed experts (softmax top-k, renormalised)
  * qwen2    — as llama with NEOX RoPE (rotate halves) and q/k/v biases, tied embeddings allowed
  * qwen2moe — qwen2 + routed experts (softmax top-k, NOT renormalised) + an always-on shared expert
               gated by sigmoid(x · w_shexp)  — the layout SOKE's forge writes for "math always on"

What this is not: fast. numpy on CPU, dequantizing on the way. Scoring (teacher-forced NLL over a
batch of tokens) amortises the dequantization and is the forge's fitness signal; token-by-token
chat is usable for models that fit resident under the guard (roughly <= 0.7 B parameters).
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator, Optional

import numpy as np

from .gguf_rewrites import DEQUANT, GGML_TYPES, GGUFReader
from .memguard import MemGuard
from .rng import Rng
from .tokenizer import Tokenizer

MB = 1 << 20


# ==========================================================================
# configuration from GGUF metadata
# ==========================================================================
@dataclass
class LLMConfig:
    arch: str
    n_vocab: int
    n_embd: int
    n_layer: int
    n_ff: int
    n_head: int
    n_head_kv: int
    head_dim: int
    n_rot: int
    rope_theta: float
    rms_eps: float
    rope_type: str                 # "norm" (interleaved pairs) | "neox" (halves)
    n_ctx_train: int
    n_expert: int = 0
    n_expert_used: int = 0
    n_ff_exp: int = 0
    n_ff_shexp: int = 0
    expert_norm_w: bool = False    # renormalise top-k weights (Mixtral/llama yes, qwen2moe no)
    has_shexp: bool = False
    tied_output: bool = False
    qkv_bias: bool = False
    act: str = "silu"              # feed-forward gate activation: "silu" (llama/qwen) | "gelu" (gemma/gemma2)
    embed_scale: float = 1.0       # token embeddings are multiplied by this (gemma/gemma2: sqrt(n_embd))
    attn_scale: float = 0.0        # denominator under sqrt for the attention score; 0 -> use head_dim
    attn_softcap: float = 0.0      # >0 -> soft-cap attention logits: s*tanh(a/s) before the mask (gemma2)
    final_softcap: float = 0.0     # >0 -> soft-cap output logits: s*tanh(l/s) (gemma2)
    post_norm: bool = False        # gemma2: extra norm on the attention output and the ffn output (pre-residual)

    @staticmethod
    def from_kv(kv: dict, tensor_names: set) -> "LLMConfig":
        arch = str(kv.get("general.architecture", "llama"))
        a = arch

        def g(key, default=None):
            return kv.get(f"{a}.{key}", default)

        n_embd = int(g("embedding_length"))
        n_head = int(g("attention.head_count"))
        n_head_kv = int(g("attention.head_count_kv", n_head))
        head_dim = int(g("attention.key_length", n_embd // n_head))
        n_rot = int(g("rope.dimension_count", head_dim))
        n_vocab = int(g("vocab_size", len(kv.get("tokenizer.ggml.tokens", []))))
        is_gemma = arch in ("gemma", "gemma2")
        _asc = g("attn_logit_softcapping")
        _fsc = g("final_logit_softcapping")
        cfg = LLMConfig(
            arch=arch, n_vocab=n_vocab, n_embd=n_embd, n_layer=int(g("block_count")),
            n_ff=int(g("feed_forward_length", 0)), n_head=n_head, n_head_kv=n_head_kv, head_dim=head_dim, n_rot=n_rot,
            rope_theta=float(g("rope.freq_base", 10000.0)), rms_eps=float(g("attention.layer_norm_rms_epsilon", 1e-6)),
            rope_type="neox" if arch in ("qwen2", "qwen2moe", "qwen3", "qwen3moe", "gemma", "gemma2", "phi3", "olmoe") else "norm",
            n_ctx_train=int(g("context_length", 2048)),
            n_expert=int(g("expert_count", 0)), n_expert_used=int(g("expert_used_count", 0)),
            n_ff_exp=int(g("expert_feed_forward_length", g("feed_forward_length", 0))),
            n_ff_shexp=int(g("expert_shared_feed_forward_length", 0)),
            expert_norm_w=(arch == "llama"), has_shexp=(arch in ("qwen2moe", "qwen3moe") and "blk.0.ffn_gate_shexp.weight" in tensor_names),
            tied_output="output.weight" not in tensor_names, qkv_bias="blk.0.attn_q.bias" in tensor_names,
            act="gelu" if is_gemma else "silu",
            embed_scale=math.sqrt(n_embd) if is_gemma else 1.0,
            # gemma pre-scales Q by 1/sqrt(query_pre_attn_scalar) (=head_dim for 2B/9B); everyone else uses head_dim
            attn_scale=float(g("attention.query_pre_attn_scalar", head_dim)) if is_gemma else float(head_dim),
            attn_softcap=float(_asc) if _asc is not None else 0.0,
            final_softcap=float(_fsc) if _fsc is not None else 0.0,
            post_norm=(arch == "gemma2"),
        )
        return cfg


# ==========================================================================
# weight store: streaming / resident access to GGUF tensors
# ==========================================================================
class WeightStore:
    """Row-chunked access to a GGUF's tensors. y = x @ W^T never materialises W unless it is resident."""

    def __init__(self, path, memguard: Optional[MemGuard] = None, chunk_bytes: int = 48 * MB,
                 resident: str = "auto", resident_budget_mb: int = 520):
        self.path = Path(path)
        self.gr = GGUFReader(self.path)
        self.mg = memguard or MemGuard()
        self.chunk_bytes = chunk_bytes
        self._res: dict[str, tuple] = {}          # name -> ("f32", arr) | ("q8", codes int8 (rows, cols), scales f32 (rows, cols//32))
        self.mode = "stream"
        total_params = sum(t.n_elem for t in self.gr.tensors.values())
        if resident == "f32" or (resident == "auto" and total_params * 4 <= resident_budget_mb * MB):
            self.mode = "f32"
        elif resident == "q8" or (resident == "auto" and total_params * 1.06 <= resident_budget_mb * MB):
            self.mode = "q8"
        self.dequant_values = 0
        self.matmul_flops = 0.0

    def close(self) -> None:
        self.gr.close()
        self._res.clear()

    @property
    def kv(self) -> dict:
        return self.gr.kv

    def names(self) -> set:
        return set(self.gr.tensors)

    def has(self, name: str) -> bool:
        return name in self.gr.tensors

    def shape(self, name: str) -> tuple:
        return tuple(self.gr.tensors[name].shape)

    # ------------------------------------------------------------ raw access
    def rows(self, name: str, r0: int, r1: int) -> np.ndarray:
        """Dequantized rows [r0, r1) of a 2-D tensor (rows = ne1, cols = ne0)."""
        t = self.gr.tensors[name]
        cols = t.shape[-1]
        _, bs, ts = GGML_TYPES[t.ggml_type]
        assert cols % bs == 0, f"{name}: row length {cols} not a multiple of the block size {bs}"
        bpr = cols // bs * ts                        # bytes per row
        self.gr.f.seek(t.abs_offset + r0 * bpr)
        raw = self.gr._read((r1 - r0) * bpr)
        fn = DEQUANT.get(t.ggml_type)
        if fn is None:
            raise ValueError(f"{name}: type {t.type_name} has no dequantizer")
        out = np.asarray(fn(raw), dtype=np.float32).reshape(r1 - r0, cols)
        self.dequant_values += out.size
        return out

    def full(self, name: str) -> np.ndarray:
        """Whole tensor as f32 (small tensors: norms, biases, gate vectors) — cached."""
        key = name
        hit = self._res.get(key)
        if hit is not None and hit[0] == "f32":
            return hit[1]
        t = self.gr.tensors[name]
        shape = t.shape
        if len(shape) == 1:
            arr = self.rows(name, 0, 1).reshape(shape) if False else np.asarray(DEQUANT[t.ggml_type](self._raw_all(name)), dtype=np.float32).reshape(shape)
        else:
            arr = self.rows(name, 0, int(np.prod(shape[:-1]))).reshape(shape)
        self._res[key] = ("f32", arr)
        return arr

    def _raw_all(self, name: str) -> bytes:
        t = self.gr.tensors[name]
        _, bs, ts = GGML_TYPES[t.ggml_type]
        self.gr.f.seek(t.abs_offset)
        return self.gr._read(t.n_elem // bs * ts)

    def make_resident(self, name: str) -> None:
        """Bring a 2-D tensor into memory in the store's resident mode (respecting the guard)."""
        if name in self._res:
            return
        t = self.gr.tensors[name]
        rows, cols = int(np.prod(t.shape[:-1])), t.shape[-1]
        if self.mode == "f32":
            self._res[name] = ("f32", self.rows(name, 0, rows).reshape(t.shape))
        elif self.mode == "q8" and cols % 32 != 0:
            self._res[name] = ("f32", self.rows(name, 0, rows).reshape(t.shape))
        elif self.mode == "q8":
            g = 32
            step = max(1, self.chunk_bytes // (cols * 4))
            codes = np.empty((rows, cols), dtype=np.int8)
            scales = np.empty((rows, cols // g), dtype=np.float32)
            for r0 in range(0, rows, step):
                r1 = min(rows, r0 + step)
                blk = self.rows(name, r0, r1).reshape(r1 - r0, cols // g, g)
                amax = np.max(np.abs(blk), axis=2)
                sc = amax / 127.0
                inv = np.where(sc > 0, 1.0 / np.where(sc > 0, sc, 1.0), 0.0)
                codes[r0:r1] = np.clip(np.rint(blk * inv[:, :, None]), -127, 127).astype(np.int8).reshape(r1 - r0, cols)
                scales[r0:r1] = sc
            self._res[name] = ("q8", codes, scales)
        self.mg.check(f"resident {name}")

    # ------------------------------------------------------------ products
    def matmul_T(self, x: np.ndarray, name: str) -> np.ndarray:
        """x @ W^T for W stored as (out, in): returns (T, out). Chunked over W's rows."""
        t = self.gr.tensors[name]
        out_dim, in_dim = int(np.prod(t.shape[:-1])), t.shape[-1]
        assert x.shape[-1] == in_dim, f"{name}: x has {x.shape[-1]} features, W has {in_dim}"
        self.matmul_flops += 2.0 * x.shape[0] * in_dim * out_dim
        res = self._res.get(name)
        if res is None and self.mode in ("f32", "q8"):
            self.make_resident(name)
            res = self._res.get(name)
        if res is not None and res[0] == "f32":
            return x @ res[1].reshape(out_dim, in_dim).T
        y = np.empty((x.shape[0], out_dim), dtype=np.float32)
        if res is not None and res[0] == "q8":
            codes, scales = res[1], res[2]
            step = max(1, self.chunk_bytes // (in_dim * 4))
            for r0 in range(0, out_dim, step):
                r1 = min(out_dim, r0 + step)
                w = (codes[r0:r1].reshape(r1 - r0, -1, 32).astype(np.float32) * scales[r0:r1][:, :, None]).reshape(r1 - r0, in_dim)
                y[:, r0:r1] = x @ w.T
            return y
        step = max(1, self.chunk_bytes // (in_dim * 4))
        for r0 in range(0, out_dim, step):
            r1 = min(out_dim, r0 + step)
            y[:, r0:r1] = x @ self.rows(name, r0, r1).T
        return y

    def embed(self, name: str, ids: np.ndarray) -> np.ndarray:
        """Rows of the embedding table for token ids (each row dequantized on demand; small cache)."""
        t = self.gr.tensors[name]
        res = self._res.get(name)
        if res is not None and res[0] == "f32":
            return res[1][ids]
        out = np.empty((len(ids), t.shape[-1]), dtype=np.float32)
        cache = self.__dict__.setdefault("_emb_cache", {})
        for i, tid in enumerate(ids):
            tid = int(tid)
            row = cache.get(tid)
            if row is None:
                row = self.rows(name, tid, tid + 1)[0]
                if len(cache) < 4096:
                    cache[tid] = row
            out[i] = row
        return out


# ==========================================================================
# the model
# ==========================================================================
def rms_norm(x: np.ndarray, w: np.ndarray, eps: float) -> np.ndarray:
    return x * (1.0 / np.sqrt(np.mean(x * x, axis=-1, keepdims=True) + eps)) * w


def silu(x: np.ndarray) -> np.ndarray:
    return x / (1.0 + np.exp(-x))


def softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
    m = np.max(x, axis=axis, keepdims=True)
    e = np.exp(x - m)
    return e / np.sum(e, axis=axis, keepdims=True)


def gelu(x: np.ndarray) -> np.ndarray:
    """gelu with the tanh approximation (gemma's gelu_pytorch_tanh; matches ggml_gelu)."""
    return 0.5 * x * (1.0 + np.tanh(0.7978845608028654 * (x + 0.044715 * x * x * x)))


# architectures whose full forward pass this engine runs as an advisor. Everything else can still be
# imported, repacked, shrunk and inspected (that is tensor-level and arch-agnostic) — only *running* it
# for chat needs the arch here. Grouped so the error message can name families.
SUPPORTED_ARCHS = ("llama", "mistral", "qwen2", "qwen2moe", "gemma", "gemma2")


class UnsupportedArch(ValueError):
    """Raised when a GGUF's architecture has no runnable forward pass here. A ValueError subclass so existing
    `except ValueError` handlers still catch it; carries `.arch` and a human-readable, catchable message."""
    def __init__(self, arch: str):
        self.arch = arch
        super().__init__(
            f"The advisor engine can't run a {arch!r} model yet.\n"
            f"Runnable architectures: {', '.join(SUPPORTED_ARCHS)}.\n"
            f"You can still Import / repack / shrink / Inspect this model — those work on any GGUF.")


class LLM:
    def __init__(self, path=None, memguard: Optional[MemGuard] = None, resident: str = "auto", chunk_bytes: int = 48 * MB,
                 store=None):
        """path: a GGUF file; or store: any object with the WeightStore interface (the forge's SpecStore)."""
        self.mg = memguard or MemGuard()
        if store is None:
            self.path = Path(path)
            self.store = WeightStore(self.path, self.mg, chunk_bytes=chunk_bytes, resident=resident)
        else:
            self.path = getattr(store, "path", None)
            self.store = store
        self.kv = self.store.kv
        self.cfg = LLMConfig.from_kv(self.kv, self.store.names())
        if self.cfg.arch not in SUPPORTED_ARCHS:
            raise UnsupportedArch(self.cfg.arch)
        self.tok = Tokenizer(self.kv)
        self._rope_cache: dict[int, tuple[np.ndarray, np.ndarray]] = {}
        self.freq_factors = self.store.full("rope_freqs.weight") if self.store.has("rope_freqs.weight") else None

    def close(self) -> None:
        self.store.close()

    # ------------------------------------------------------------ rope
    def _rope(self, pos0: int, T: int) -> tuple[np.ndarray, np.ndarray]:
        c = self.cfg
        half = c.n_rot // 2
        inv = 1.0 / (c.rope_theta ** (np.arange(0, c.n_rot, 2, dtype=np.float64) / c.n_rot))
        if self.freq_factors is not None:
            inv = inv / self.freq_factors[:half].astype(np.float64)
        pos = np.arange(pos0, pos0 + T, dtype=np.float64)[:, None]
        ang = pos * inv[None, :]                          # (T, half)
        return np.cos(ang).astype(np.float32), np.sin(ang).astype(np.float32)

    def _apply_rope(self, x: np.ndarray, cos: np.ndarray, sin: np.ndarray) -> np.ndarray:
        """x: (H, T, D). neox: rotate halves; norm: rotate interleaved pairs. Only the first n_rot dims."""
        c = self.cfg
        nr = c.n_rot
        xr, xp = x[..., :nr], x[..., nr:]
        if c.rope_type == "neox":
            h = nr // 2
            x1, x2 = xr[..., :h], xr[..., h:]
            o1 = x1 * cos - x2 * sin
            o2 = x2 * cos + x1 * sin
            out = np.concatenate([o1, o2], axis=-1)
        else:
            x1, x2 = xr[..., 0::2], xr[..., 1::2]
            o1 = x1 * cos - x2 * sin
            o2 = x2 * cos + x1 * sin
            out = np.empty_like(xr)
            out[..., 0::2] = o1
            out[..., 1::2] = o2
        return np.concatenate([out, xp], axis=-1) if xp.shape[-1] else out

    # ------------------------------------------------------------ blocks
    def _attention(self, l: int, h: np.ndarray, pos0: int, cache: Optional[dict]) -> np.ndarray:
        c, S = self.cfg, self.store
        T = h.shape[0]
        q = S.matmul_T(h, f"blk.{l}.attn_q.weight")
        k = S.matmul_T(h, f"blk.{l}.attn_k.weight")
        v = S.matmul_T(h, f"blk.{l}.attn_v.weight")
        if c.qkv_bias:
            q += S.full(f"blk.{l}.attn_q.bias")
            k += S.full(f"blk.{l}.attn_k.bias")
            v += S.full(f"blk.{l}.attn_v.bias")
        q = q.reshape(T, c.n_head, c.head_dim).transpose(1, 0, 2)          # (H, T, D)
        k = k.reshape(T, c.n_head_kv, c.head_dim).transpose(1, 0, 2)
        v = v.reshape(T, c.n_head_kv, c.head_dim).transpose(1, 0, 2)
        cos, sin = self._rope(pos0, T)
        q = self._apply_rope(q, cos, sin)
        k = self._apply_rope(k, cos, sin)
        if cache is not None:
            kc, vc = cache.get(l, (None, None))
            if kc is not None:
                k = np.concatenate([kc, k], axis=1)
                v = np.concatenate([vc, v], axis=1)
            cache[l] = (k, v)
        rep = c.n_head // c.n_head_kv
        if rep > 1:
            k = np.repeat(k, rep, axis=0)
            v = np.repeat(v, rep, axis=0)
        Tk = k.shape[1]
        att = (q @ k.transpose(0, 2, 1)) / math.sqrt(c.attn_scale if c.attn_scale > 0 else c.head_dim)   # (H, T, Tk)
        if c.attn_softcap > 0:                                              # gemma2: cap logits before the mask
            att = c.attn_softcap * np.tanh(att / c.attn_softcap)
        # causal mask: query i (absolute pos0+i) may see keys 0..pos0+i
        mask = np.tril(np.ones((T, Tk), dtype=bool), k=Tk - T)
        att = np.where(mask[None], att, -1e30)
        att = softmax(att, axis=-1)
        o = (att @ v).transpose(1, 0, 2).reshape(T, c.n_head * c.head_dim)
        return S.matmul_T(o, f"blk.{l}.attn_output.weight")

    def _ffn_dense(self, x: np.ndarray, gate: str, up: str, down: str) -> np.ndarray:
        """SwiGLU block silu(x G^T) * (x U^T) @ D^T, with the (T, n_ff) activation kept under the chunk budget."""
        S = self.store
        n_ff = int(np.prod(S.shape(gate)[:-1]))
        return self._ffn_glu(x, gate, up, down, 0, 0, n_ff, x.shape[-1])

    def _ffn_expert(self, x: np.ndarray, l: int, e: int) -> np.ndarray:
        """Expert e of the merged 3-D expert tensors: rows [e*n_ff_exp, (e+1)*n_ff_exp) of gate/up, and the
        matching slab of down (stored as (n_expert, n_embd, n_ff_exp))."""
        c = self.cfg
        nfe = c.n_ff_exp
        gname, uname, dname = f"blk.{l}.ffn_gate_exps.weight", f"blk.{l}.ffn_up_exps.weight", f"blk.{l}.ffn_down_exps.weight"
        return self._ffn_glu(x, gname, uname, dname, e * nfe, e * c.n_embd, nfe, c.n_embd)

    def _ffn_glu(self, x: np.ndarray, gname: str, uname: str, dname: str, g_base: int, d_base: int, n_ff: int, n_out: int) -> np.ndarray:
        """silu(x @ G[g_base:g_base+n_ff]^T) * (x @ U[same]^T) @ D[d_base:d_base+n_out, :]^T, streamed over the
        ff axis so the (T, n_ff) activation never exceeds the store's chunk budget (a 3,000-token pack against a
        4,864-wide FFN would otherwise need three 60 MB temporaries per layer)."""
        S = self.store
        T = x.shape[0]
        f_step = n_ff if T * n_ff * 4 <= S.chunk_bytes else max(self.FF_STEP_MIN, S.chunk_bytes // (T * 4))
        out = None
        for j0 in range(0, n_ff, f_step):
            j1 = min(n_ff, j0 + f_step)
            g = self._matmul_slab(x, gname, g_base + j0, g_base + j1)
            u = self._matmul_slab(x, uname, g_base + j0, g_base + j1)
            a = (gelu(g) if self.cfg.act == "gelu" else silu(g)) * u
            del g, u
            y = self._matmul_slab(a, dname, d_base, d_base + n_out, j0, j1)
            out = y if out is None else out + y
        return out

    def _matmul_slab(self, x: np.ndarray, name: str, r0: int, r1: int, c0: Optional[int] = None, c1: Optional[int] = None) -> np.ndarray:
        """x @ W[r0:r1, c0:c1]^T where W is viewed as (rows, cols) (3-D expert tensors: (n_expert*rows, cols)).
        Rows are streamed in chunk_bytes slices; the column window (default: all) selects the ff slice of a down
        projection."""
        S = self.store
        cols = S.shape(name)[-1]
        c0 = 0 if c0 is None else c0
        c1 = cols if c1 is None else c1
        res = S._res.get(name)
        if res is None and S.mode in ("f32", "q8"):
            S.make_resident(name)
            res = S._res.get(name)
        if res is not None and res[0] == "f32":
            w = res[1].reshape(-1, cols)[r0:r1]
            return x @ (w if (c0 == 0 and c1 == cols) else w[:, c0:c1]).T
        y = np.empty((x.shape[0], r1 - r0), dtype=np.float32)
        step = max(1, S.chunk_bytes // (cols * 4))
        for a in range(r0, r1, step):
            b = min(r1, a + step)
            if res is not None and res[0] == "q8":
                codes, scales = res[1], res[2]
                w = (codes[a:b].reshape(b - a, -1, 32).astype(np.float32) * scales[a:b][:, :, None]).reshape(b - a, cols)
            else:
                w = S.rows(name, a, b)
            if not (c0 == 0 and c1 == cols):
                w = w[:, c0:c1]
            y[:, a - r0:b - r0] = x @ w.T
        return y

    def _ffn(self, l: int, x: np.ndarray) -> np.ndarray:
        c, S = self.cfg, self.store
        if c.n_expert == 0:
            return self._ffn_dense(x, f"blk.{l}.ffn_gate.weight", f"blk.{l}.ffn_up.weight", f"blk.{l}.ffn_down.weight")
        # routed experts
        logits = S.matmul_T(x, f"blk.{l}.ffn_gate_inp.weight")                 # (T, n_expert)
        probs = softmax(logits, axis=-1)
        k = c.n_expert_used
        top = np.argsort(-probs, axis=-1)[:, :k]                                   # (T, k)
        w = np.take_along_axis(probs, top, axis=-1)
        if c.expert_norm_w:
            w = w / np.sum(w, axis=-1, keepdims=True)
        out = np.zeros_like(x)
        for e in range(c.n_expert):
            sel = np.nonzero(np.any(top == e, axis=-1))[0]
            if sel.size == 0:
                continue
            we = np.sum(np.where(top[sel] == e, w[sel], 0.0), axis=-1)[:, None]
            out[sel] += we * self._ffn_expert(x[sel], l, e)
        if c.has_shexp:
            gate = 1.0 / (1.0 + np.exp(-S.matmul_T(x, f"blk.{l}.ffn_gate_inp_shexp.weight")))     # (T, 1)
            sh = self._ffn_dense(x, f"blk.{l}.ffn_gate_shexp.weight", f"blk.{l}.ffn_up_shexp.weight", f"blk.{l}.ffn_down_shexp.weight")
            out += gate * sh
        self.last_route = top
        return out

    def _attention_packed(self, l: int, h: np.ndarray, lens: list[int]) -> np.ndarray:
        """Attention for several sequences packed along the token axis (each sequence starts at position 0):
        the projections run on the whole pack once (one dequantization), RoPE/softmax per sequence."""
        c, S = self.cfg, self.store
        T = h.shape[0]
        q = S.matmul_T(h, f"blk.{l}.attn_q.weight")
        k = S.matmul_T(h, f"blk.{l}.attn_k.weight")
        v = S.matmul_T(h, f"blk.{l}.attn_v.weight")
        if c.qkv_bias:
            q += S.full(f"blk.{l}.attn_q.bias"); k += S.full(f"blk.{l}.attn_k.bias"); v += S.full(f"blk.{l}.attn_v.bias")
        out = np.empty((T, c.n_head * c.head_dim), dtype=np.float32)
        rep = c.n_head // c.n_head_kv
        off = 0
        for L in lens:
            qs = q[off:off + L].reshape(L, c.n_head, c.head_dim).transpose(1, 0, 2)
            ks = k[off:off + L].reshape(L, c.n_head_kv, c.head_dim).transpose(1, 0, 2)
            vs = v[off:off + L].reshape(L, c.n_head_kv, c.head_dim).transpose(1, 0, 2)
            cos, sin = self._rope(0, L)
            qs = self._apply_rope(qs, cos, sin); ks = self._apply_rope(ks, cos, sin)
            if rep > 1:
                ks = np.repeat(ks, rep, axis=0); vs = np.repeat(vs, rep, axis=0)
            att = (qs @ ks.transpose(0, 2, 1)) / math.sqrt(c.attn_scale if c.attn_scale > 0 else c.head_dim)
            if c.attn_softcap > 0:
                att = c.attn_softcap * np.tanh(att / c.attn_softcap)
            att = np.where(np.tril(np.ones((L, L), dtype=bool))[None], att, -1e30)
            att = softmax(att, axis=-1)
            out[off:off + L] = (att @ vs).transpose(1, 0, 2).reshape(L, c.n_head * c.head_dim)
            off += L
        return S.matmul_T(out, f"blk.{l}.attn_output.weight")

    def hidden_batch(self, seqs: list, layer_from: int = 0, h0: Optional[np.ndarray] = None, layer_to: Optional[int] = None,
                     snap_at=None, snaps: Optional[dict] = None) -> np.ndarray:
        """Hidden states for several sequences packed along the token axis (returns (sum(len), n_embd)).
        Every weight tensor is dequantized once per layer for the whole pack. snap_at: layer indices whose INPUT
        hidden state is stored in `snaps` (the forge's boundary cache for partial recompute)."""
        c, S = self.cfg, self.store
        lens = [len(x) for x in seqs]
        if h0 is None:
            h = S.embed("token_embd.weight", np.concatenate([np.asarray(x) for x in seqs]))
            if c.embed_scale != 1.0:                                       # gemma: h *= sqrt(n_embd)
                h = h * np.float32(c.embed_scale)
        else:
            h = h0
        L = c.n_layer if layer_to is None else layer_to
        snap_at = set(snap_at or ())
        for l in range(layer_from, L):
            if l in snap_at and snaps is not None:
                snaps[l] = h.copy()
            n1 = rms_norm(h, S.full(f"blk.{l}.attn_norm.weight"), c.rms_eps)
            a = self._attention_packed(l, n1, lens)
            if c.post_norm:                                                # gemma2: norm the attention output first
                a = rms_norm(a, S.full(f"blk.{l}.post_attention_norm.weight"), c.rms_eps)
            h = h + a
            n2 = rms_norm(h, S.full(f"blk.{l}.ffn_norm.weight"), c.rms_eps)
            f = self._ffn(l, n2)
            if c.post_norm:                                                # gemma2: norm the ffn output first
                f = rms_norm(f, S.full(f"blk.{l}.post_ffw_norm.weight"), c.rms_eps)
            h = h + f
            if l % 4 == 3:
                self.mg.check(f"layer {l}")
        if L in snap_at and snaps is not None:
            snaps[L] = h.copy()
        return h

    LOGIT_BUDGET = 32 * 2 ** 20      # bytes for one (T, vocab-chunk) f32 logits block
    FF_STEP_MIN = 256                # smallest ff slice of a chunked SwiGLU block
    VOCAB_STEP_MIN = 64              # smallest vocabulary slice of a streamed logits block

    def _vocab_step(self, T: int, D: int) -> int:
        """Vocabulary rows per streamed logits block: bounded by the weight chunk AND by the logits block size,
        so a 3,000-token pack never materialises more than ~32 MB of logits at once (three f32 temporaries)."""
        S = self.store
        by_weights = max(self.VOCAB_STEP_MIN, S.chunk_bytes // (D * 4))
        by_logits = max(self.VOCAB_STEP_MIN, self.LOGIT_BUDGET // (max(1, T) * 4))
        return int(min(by_weights, by_logits))

    @staticmethod
    def _lse_update(lg: np.ndarray, m: np.ndarray, s: np.ndarray) -> tuple:
        """Running log-sum-exp over vocabulary chunks: f32 block temporaries, f64 running max/sum."""
        cm = np.max(lg, axis=1).astype(np.float64)
        nm = np.maximum(m, cm)
        ex = np.exp(lg - nm[:, None].astype(np.float32))
        s = s * np.exp(m - nm) + np.sum(ex, axis=1, dtype=np.float64)
        return nm, s

    def nll_batch(self, seqs: list, layer_from: int = 0, h0: Optional[np.ndarray] = None, snap_at=None, snaps: Optional[dict] = None) -> dict:
        """Per-sequence teacher-forced NLL for a pack of sequences, vocabulary streamed once for the whole pack."""
        c, S = self.cfg, self.store
        inputs = [list(x)[:-1] for x in seqs]
        targets_l = [list(x)[1:] for x in seqs]
        h = self.hidden_batch(inputs, layer_from=layer_from, h0=h0, snap_at=snap_at, snaps=snaps)
        hn = rms_norm(h, S.full("output_norm.weight"), c.rms_eps)
        name = "token_embd.weight" if c.tied_output else "output.weight"
        T = hn.shape[0]
        targets = np.asarray([t for tl in targets_l for t in tl])
        m = np.full(T, -np.inf, dtype=np.float64); s = np.zeros(T, dtype=np.float64); tl_ = np.zeros(T, dtype=np.float64)
        shp = S.shape(name)
        V, D = int(np.prod(shp[:-1])), shp[-1]
        res = S._res.get(name)
        step = self._vocab_step(T, D)
        for r0 in range(0, V, step):
            r1 = min(V, r0 + step)
            if res is not None and res[0] == "f32":
                w = res[1].reshape(V, D)[r0:r1]
            elif res is not None and res[0] == "q8":
                w = (res[1][r0:r1].reshape(r1 - r0, -1, 32).astype(np.float32) * res[2][r0:r1][:, :, None]).reshape(r1 - r0, D)
            else:
                w = S.rows(name, r0, r1)
            lg = hn @ w.T                                                          # (T, r1-r0) f32
            del w
            if c.final_softcap > 0:                                                # gemma2 (elementwise, per-block safe)
                lg = c.final_softcap * np.tanh(lg / c.final_softcap)
            m, s = self._lse_update(lg, m, s)
            hit = (targets >= r0) & (targets < r1)
            if np.any(hit):
                tl_[hit] = lg[hit, targets[hit] - r0]
            del lg
        per = (m + np.log(s)) - tl_
        out = []; off = 0
        for tl in targets_l:
            out.append(float(np.mean(per[off:off + len(tl)])) if tl else float("nan")); off += len(tl)
        return {"per_seq": out, "nll": float(np.mean(per)) if T else float("nan"), "tokens": int(T), "per_token": per.astype(np.float32)}

    # ------------------------------------------------------------ forward
    def hidden(self, ids: np.ndarray, pos0: int = 0, cache: Optional[dict] = None, layer_from: int = 0,
               h0: Optional[np.ndarray] = None, layer_to: Optional[int] = None) -> np.ndarray:
        """Hidden states after the last block (before the output norm). layer_from/h0 let the forge
        re-run only the layers after a change (h0 = the cached input of layer_from)."""
        c, S = self.cfg, self.store
        h = S.embed("token_embd.weight", np.asarray(ids)) if h0 is None else h0
        if h0 is None and c.embed_scale != 1.0:                            # gemma: h *= sqrt(n_embd)
            h = h * np.float32(c.embed_scale)
        L = c.n_layer if layer_to is None else layer_to
        for l in range(layer_from, L):
            n1 = rms_norm(h, S.full(f"blk.{l}.attn_norm.weight"), c.rms_eps)
            a = self._attention(l, n1, pos0, cache)
            if c.post_norm:                                                # gemma2: norm the attention output first
                a = rms_norm(a, S.full(f"blk.{l}.post_attention_norm.weight"), c.rms_eps)
            h = h + a
            n2 = rms_norm(h, S.full(f"blk.{l}.ffn_norm.weight"), c.rms_eps)
            f = self._ffn(l, n2)
            if c.post_norm:                                                # gemma2: norm the ffn output first
                f = rms_norm(f, S.full(f"blk.{l}.post_ffw_norm.weight"), c.rms_eps)
            h = h + f
            if l % 4 == 3:
                self.mg.check(f"layer {l}")
        return h

    def logits(self, h_last: np.ndarray) -> np.ndarray:
        """Full logits (T, n_vocab) for the normalised final hidden states — only for small vocab*T."""
        c, S = self.cfg, self.store
        hn = rms_norm(h_last, S.full("output_norm.weight"), c.rms_eps)
        name = "token_embd.weight" if c.tied_output else "output.weight"
        lg = S.matmul_T(hn, name)
        if c.final_softcap > 0:                                            # gemma2: cap the output logits
            lg = c.final_softcap * np.tanh(lg / c.final_softcap)
        return lg

    def nll(self, ids: list[int], layer_from: int = 0, h0: Optional[np.ndarray] = None) -> dict:
        """Teacher-forced negative log-likelihood per token (nats), streamed over the vocabulary."""
        c, S = self.cfg, self.store
        ids = list(ids)
        if len(ids) < 2:
            return {"nll": float("nan"), "tokens": 0}
        h = self.hidden(np.asarray(ids[:-1]), layer_from=layer_from, h0=h0)
        hn = rms_norm(h, S.full("output_norm.weight"), c.rms_eps)
        name = "token_embd.weight" if c.tied_output else "output.weight"
        T = hn.shape[0]
        targets = np.asarray(ids[1:])
        m = np.full(T, -np.inf, dtype=np.float64)
        s = np.zeros(T, dtype=np.float64)
        tl = np.zeros(T, dtype=np.float64)
        shp = S.shape(name)
        V, D = int(np.prod(shp[:-1])), shp[-1]
        res = S._res.get(name)
        step = self._vocab_step(T, D)
        for r0 in range(0, V, step):
            r1 = min(V, r0 + step)
            if res is not None and res[0] == "f32":
                w = res[1].reshape(V, D)[r0:r1]
            elif res is not None and res[0] == "q8":
                w = (res[1][r0:r1].reshape(r1 - r0, -1, 32).astype(np.float32) * res[2][r0:r1][:, :, None]).reshape(r1 - r0, D)
            else:
                w = S.rows(name, r0, r1)
            lg = hn @ w.T                                                          # (T, r1-r0) f32
            del w
            if c.final_softcap > 0:                                                # gemma2 (elementwise, per-block safe)
                lg = c.final_softcap * np.tanh(lg / c.final_softcap)
            m, s = self._lse_update(lg, m, s)
            hit = (targets >= r0) & (targets < r1)
            if np.any(hit):
                tl[hit] = lg[hit, targets[hit] - r0]
            del lg
        lse = m + np.log(s)
        per = lse - tl
        return {"nll": float(np.mean(per)), "tokens": int(T), "per_token": per.astype(np.float32), "hidden_in": None}

    def score_text(self, text: str, max_tokens: int = 512) -> dict:
        ids = self.tok.encode(text, add_special=True, parse_special=True)[:max_tokens]
        r = self.nll(ids)
        r["bits_per_token"] = r["nll"] / math.log(2) if r["tokens"] else float("nan")
        return r

    # ------------------------------------------------------------ generate
    def generate(self, prompt: str, max_new: int = 64, temperature: float = 0.7, top_k: int = 40, seed: int = 0,
                 chat: bool = True, stop_on_eos: bool = True, on_token=None, controller=None) -> tuple[str, dict]:
        c, S = self.cfg, self.store
        text = self.tok.chat_prompt(prompt) if chat else prompt
        ids = self.tok.encode(text, add_special=not chat, parse_special=True)
        cache: dict = {}
        rng = Rng(seed)
        out_ids: list[int] = []
        t0 = time.time()
        h = self.hidden(np.asarray(ids), pos0=0, cache=cache)
        pos = len(ids)
        eos = {int(self.tok.eos_id)} if self.tok.eos_id is not None else set()
        for sp in ("<|im_end|>", "<|eot_id|>", "<|end_of_text|>", "</s>"):
            if sp in self.tok.special:
                eos.add(self.tok.special[sp])
        for step in range(max_new):
            lg = self.logits(h[-1:])[0]
            temp = temperature
            if controller is not None:                            # the live emotional feed (mind_engine): bounded
                if controller.stop(step):                         # budget spent -> the model runs out of room to think
                    break
                lg = controller.pre_logits(lg, step)              # a capped bias (bid, not close)
                temp = controller.temperature(step, temperature)  # mood peakedness (fear sharpens, joy broadens)
            if temp <= 0:
                nxt = int(np.argmax(lg))
            else:
                lg = lg / temp
                if top_k and top_k < lg.size:
                    idx = np.argpartition(-lg, top_k)[:top_k]
                    p = softmax(lg[idx])
                    nxt = int(idx[int(rng.choice(idx.size, p=p))])
                else:
                    p = softmax(lg)
                    nxt = int(rng.choice(lg.size, p=p))
            if stop_on_eos and nxt in eos:
                break
            out_ids.append(nxt)
            if on_token:
                on_token(self.tok.decode([nxt]))
            if controller is not None:
                controller.on_token(self.tok.decode([nxt]), step)  # feedback: spend a token, feel the result
            h = self.hidden(np.asarray([nxt]), pos0=pos, cache=cache)
            pos += 1
        dt = time.time() - t0
        return self.tok.decode(out_ids), {"tokens": len(out_ids), "seconds": round(dt, 2), "tok_per_s": round(len(out_ids) / dt, 2) if dt > 0 else None,
                                          "resident_mode": S.mode, "rss_mb": self.mg.status()["rss_mb"]}


# ==========================================================================
# self-test: a tiny synthetic llama model written by our own writer and read back
# ==========================================================================
def verify_suite(chk=None, tmpdir: Optional[Path] = None):
    import tempfile
    from .util import Check
    from .gguf_rewrites import write_gguf, quant_q8_0
    chk = chk or Check("llm")
    tmpdir = Path(tmpdir or tempfile.mkdtemp(prefix="soke_llm_"))
    rng = Rng(5)
    # tiny llama: vocab 64 (byte-ish tokens), n_embd 32, 2 layers, 4 heads (kv 2), n_ff 48
    V, E, L, H, HKV, F = 64, 32, 2, 4, 2, 64
    D = E // H
    tokens = [f"t{i}" for i in range(V)]
    kv = {"general.architecture": "llama", "general.name": "tiny", "llama.block_count": L, "llama.context_length": 64,
          "llama.embedding_length": E, "llama.feed_forward_length": F, "llama.attention.head_count": H,
          "llama.attention.head_count_kv": HKV, "llama.rope.freq_base": 10000.0, "llama.attention.layer_norm_rms_epsilon": 1e-5,
          "llama.rope.dimension_count": D, "llama.vocab_size": V, "tokenizer.ggml.model": "gpt2", "tokenizer.ggml.pre": "default",
          "tokenizer.ggml.tokens": tokens, "tokenizer.ggml.token_type": [1] * V, "tokenizer.ggml.merges": [],
          "tokenizer.ggml.bos_token_id": 0, "tokenizer.ggml.eos_token_id": 1}
    W = {}
    def mat(shape, scale=0.1):
        return rng.normal(0, scale, shape).astype(np.float32)
    W["token_embd.weight"] = mat((V, E))
    W["output_norm.weight"] = np.ones(E, np.float32) + mat((E,), 0.05)
    for l in range(L):
        W[f"blk.{l}.attn_norm.weight"] = np.ones(E, np.float32)
        W[f"blk.{l}.ffn_norm.weight"] = np.ones(E, np.float32)
        W[f"blk.{l}.attn_q.weight"] = mat((H * D, E))
        W[f"blk.{l}.attn_k.weight"] = mat((HKV * D, E))
        W[f"blk.{l}.attn_v.weight"] = mat((HKV * D, E))
        W[f"blk.{l}.attn_output.weight"] = mat((E, H * D))
        W[f"blk.{l}.ffn_gate.weight"] = mat((F, E))
        W[f"blk.{l}.ffn_up.weight"] = mat((F, E))
        W[f"blk.{l}.ffn_down.weight"] = mat((E, F))
    tl = []
    for name, arr in W.items():
        dims = tuple(reversed(arr.shape))
        if arr.ndim == 2 and arr.shape[1] % 32 == 0 and "embd" not in name:
            raw = quant_q8_0(arr); tl.append((name, dims, 8, iter([raw]), len(raw)))
        else:
            raw = arr.astype(np.float32).tobytes(); tl.append((name, dims, 0, iter([raw]), len(raw)))
    gp = tmpdir / "tiny-llama.gguf"
    write_gguf(gp, kv, tl)
    # reference forward in plain numpy (no streaming), using the same dequantized weights the file holds
    from .gguf_rewrites import deq_q8_0
    Wd = {k: (deq_q8_0(quant_q8_0(v)).reshape(v.shape) if (v.ndim == 2 and v.shape[1] % 32 == 0 and "embd" not in k) else v) for k, v in W.items()}
    ids = [3, 17, 42, 5, 9, 60, 2, 33]
    def ref_forward(ids):
        x = Wd["token_embd.weight"][ids]
        T = len(ids)
        inv = 1.0 / (10000.0 ** (np.arange(0, D, 2) / D)); ang = np.arange(T)[:, None] * inv[None]; cos, sin = np.cos(ang), np.sin(ang)
        def rope(z):   # (h, T, D) interleaved pairs
            z1, z2 = z[..., 0::2], z[..., 1::2]; o = np.empty_like(z); o[..., 0::2] = z1 * cos - z2 * sin; o[..., 1::2] = z2 * cos + z1 * sin; return o
        for l in range(L):
            n1 = rms_norm(x, Wd[f"blk.{l}.attn_norm.weight"], 1e-5)
            q = (n1 @ Wd[f"blk.{l}.attn_q.weight"].T).reshape(T, H, D).transpose(1, 0, 2)
            k = (n1 @ Wd[f"blk.{l}.attn_k.weight"].T).reshape(T, HKV, D).transpose(1, 0, 2)
            v = (n1 @ Wd[f"blk.{l}.attn_v.weight"].T).reshape(T, HKV, D).transpose(1, 0, 2)
            q, k = rope(q), rope(k)
            k = np.repeat(k, H // HKV, axis=0); v = np.repeat(v, H // HKV, axis=0)
            a = q @ k.transpose(0, 2, 1) / math.sqrt(D); a = np.where(np.tril(np.ones((T, T), bool))[None], a, -1e30); a = softmax(a)
            o = (a @ v).transpose(1, 0, 2).reshape(T, E) @ Wd[f"blk.{l}.attn_output.weight"].T
            x = x + o
            n2 = rms_norm(x, Wd[f"blk.{l}.ffn_norm.weight"], 1e-5)
            x = x + (silu(n2 @ Wd[f"blk.{l}.ffn_gate.weight"].T) * (n2 @ Wd[f"blk.{l}.ffn_up.weight"].T)) @ Wd[f"blk.{l}.ffn_down.weight"].T
        return rms_norm(x, Wd["output_norm.weight"], 1e-5) @ Wd["token_embd.weight"].T
    ref = ref_forward(ids)
    for mode in ("stream", "q8", "f32"):
        m = LLM(gp, resident=mode, chunk_bytes=1024)             # tiny chunks: many row chunks per matmul
        lg = m.logits(m.hidden(np.asarray(ids)))
        tol = 2e-2 if mode == "q8" else 1e-4
        chk(f"{mode}: logits match the plain reference (chunked matmuls, tied output)", np.max(np.abs(lg - ref)) < tol, f"max |d| {np.max(np.abs(lg - ref)):.2e}")
        # nll streamed over vocab == nll from full logits
        full = ref - np.max(ref, axis=1, keepdims=True); lp = full - np.log(np.sum(np.exp(full), axis=1, keepdims=True))
        want = -np.mean([lp[i, ids[i + 1]] for i in range(len(ids) - 1)])
        r = m.nll(ids)
        chk(f"{mode}: streamed NLL == full-logit NLL", abs(r["nll"] - want) < (2e-2 if mode == "q8" else 1e-4), f"{r['nll']:.5f} vs {want:.5f}")
        # kv-cache generation == recompute
        cache = {}
        h1 = m.hidden(np.asarray(ids[:5]), pos0=0, cache=cache)
        h2 = m.hidden(np.asarray(ids[5:]), pos0=5, cache=cache)
        hf = m.hidden(np.asarray(ids))
        chk(f"{mode}: kv-cache incremental == full pass", np.max(np.abs(np.concatenate([h1, h2]) - hf)) < 1e-4)
        m.close()
    # memory-bounded paths: SwiGLU streamed over the ff axis and logits streamed in small vocabulary blocks
    # must reproduce the whole-pack result (these paths carry the forge's 3,000-token probe packs under 1 GB)
    m = LLM(gp, resident="stream", chunk_bytes=256)
    m.FF_STEP_MIN, m.VOCAB_STEP_MIN, m.LOGIT_BUDGET = 8, 8, 64            # 8 ff slices per block, 8-row logits blocks
    lg = m.logits(m.hidden(np.asarray(ids)))
    chk("ff-chunked SwiGLU (8 slices) == plain reference", np.max(np.abs(lg - ref)) < 1e-4, f"max |d| {np.max(np.abs(lg - ref)):.2e}")
    r = m.nll(ids)
    chk("vocab-blocked NLL (8-row blocks, f32 blocks / f64 sums) == full-logit NLL", abs(r["nll"] - want) < 1e-5, f"{r['nll']:.6f} vs {want:.6f}")
    m.close()
    # packed batch == per-sequence, and boundary snapshots allow partial recompute
    m = LLM(gp, resident="f32")
    seqs = [ids, ids[:6], [1, 2, 3, 4, 5, 6, 7]]
    single = [m.nll(x)["nll"] for x in seqs]
    snaps = {}
    b = m.nll_batch(seqs, snap_at={1}, snaps=snaps)
    chk("packed batch NLL == per-sequence NLL", all(abs(a - c) < 1e-5 for a, c in zip(single, b["per_seq"])), f"{single} vs {b['per_seq']}")
    b2 = m.nll_batch(seqs, layer_from=1, h0=snaps[1])
    chk("recompute from a boundary snapshot == full pass", all(abs(a - c) < 1e-6 for a, c in zip(b["per_seq"], b2["per_seq"])))
    m.close()
    # layer_from / h0 partial recompute (the forge's trick)
    m = LLM(gp, resident="f32")
    hA = m.hidden(np.asarray(ids), layer_to=1)
    hB = m.hidden(np.asarray(ids), layer_from=1, h0=hA)
    chk("partial recompute from a cached layer input == full pass", np.max(np.abs(hB - m.hidden(np.asarray(ids)))) < 1e-5)
    txt, info = m.generate("t3t4", max_new=4, temperature=0.0, chat=False)
    chk("greedy generation runs (4 tokens)", info["tokens"] == 4, str(info))
    # the live emotional feed: mind_engine as a generation controller — its token budget governs length
    from .mind_engine import MindEngine
    eng = MindEngine(base_tokens=3.0)                            # a 3-token "room to think"
    txt2, info2 = m.generate("t3t4", max_new=20, temperature=0.0, chat=False, controller=eng)
    chk("mind_engine controls live generation: the token budget stops it at 3, not max_new=20",
        info2["tokens"] == 3 and eng.state.tokens == 0.0, f"tokens {info2['tokens']}, bank {eng.state.tokens}")
    m.close()

    # ---- gemma2: the arch the operator hit ("architecture 'gemma2' is not supported"). A tiny gemma2-shaped
    # GGUF, all f32 (arch math isolated from quant noise), cross-checked against a plain-numpy reference that
    # includes every gemma2 delta: embedding scale sqrt(n_embd), independent head_dim (n_head*head_dim != n_embd),
    # query_pre_attn_scalar attention scale, attention soft-cap, dual per-layer norms (post_attention + post_ffw),
    # gelu-gated FFN, tied output, and final-logit soft-cap.
    rng2 = Rng(7)
    V2, E2, L2, H2, HKV2, D2, F2 = 48, 16, 2, 4, 2, 8, 32       # H2*D2 = 32 != E2 = 16 (independent head_dim)
    ASC, FSC, QPA = 5.0, 10.0, 12.0                            # small caps to sit in the tanh's curved region
    toks2 = [f"g{i}" for i in range(V2)]
    kv2 = {"general.architecture": "gemma2", "general.name": "tinyg", "gemma2.block_count": L2,
           "gemma2.context_length": 64, "gemma2.embedding_length": E2, "gemma2.feed_forward_length": F2,
           "gemma2.attention.head_count": H2, "gemma2.attention.head_count_kv": HKV2,
           "gemma2.attention.key_length": D2, "gemma2.attention.value_length": D2, "gemma2.rope.dimension_count": D2,
           "gemma2.rope.freq_base": 10000.0, "gemma2.attention.layer_norm_rms_epsilon": 1e-5,
           "gemma2.attn_logit_softcapping": ASC, "gemma2.final_logit_softcapping": FSC,
           "gemma2.attention.query_pre_attn_scalar": QPA, "gemma2.vocab_size": V2,
           "tokenizer.ggml.model": "gpt2", "tokenizer.ggml.pre": "default", "tokenizer.ggml.tokens": toks2,
           "tokenizer.ggml.token_type": [1] * V2, "tokenizer.ggml.merges": [],
           "tokenizer.ggml.bos_token_id": 0, "tokenizer.ggml.eos_token_id": 1}
    def m2(shape, sc=0.1):
        return rng2.normal(0, sc, shape).astype(np.float32)
    Wg = {"token_embd.weight": m2((V2, E2)), "output_norm.weight": np.ones(E2, np.float32) + m2((E2,), 0.05)}
    for l in range(L2):
        Wg[f"blk.{l}.attn_norm.weight"] = np.ones(E2, np.float32) + m2((E2,), 0.05)
        Wg[f"blk.{l}.post_attention_norm.weight"] = np.ones(E2, np.float32) + m2((E2,), 0.05)
        Wg[f"blk.{l}.ffn_norm.weight"] = np.ones(E2, np.float32) + m2((E2,), 0.05)
        Wg[f"blk.{l}.post_ffw_norm.weight"] = np.ones(E2, np.float32) + m2((E2,), 0.05)
        Wg[f"blk.{l}.attn_q.weight"] = m2((H2 * D2, E2))
        Wg[f"blk.{l}.attn_k.weight"] = m2((HKV2 * D2, E2))
        Wg[f"blk.{l}.attn_v.weight"] = m2((HKV2 * D2, E2))
        Wg[f"blk.{l}.attn_output.weight"] = m2((E2, H2 * D2))
        Wg[f"blk.{l}.ffn_gate.weight"] = m2((F2, E2))
        Wg[f"blk.{l}.ffn_up.weight"] = m2((F2, E2))
        Wg[f"blk.{l}.ffn_down.weight"] = m2((E2, F2))
    tl2 = [(name, tuple(reversed(arr.shape)), 0, iter([arr.astype(np.float32).tobytes()]), arr.nbytes) for name, arr in Wg.items()]
    gp2 = tmpdir / "tiny-gemma2.gguf"
    write_gguf(gp2, kv2, tl2)
    ids2 = [3, 17, 42, 5, 9, 30, 2, 11]
    half2 = D2 // 2
    inv2 = 1.0 / (10000.0 ** (np.arange(0, D2, 2) / D2)); ang2 = np.arange(len(ids2))[:, None] * inv2[None]
    cos2, sin2 = np.cos(ang2), np.sin(ang2)
    def rope2(z):    # (h, T, D2) neox: rotate the two halves
        z1, z2 = z[..., :half2], z[..., half2:]
        return np.concatenate([z1 * cos2 - z2 * sin2, z2 * cos2 + z1 * sin2], axis=-1)
    def ref_g(ids):
        T = len(ids)
        x = Wg["token_embd.weight"][ids] * math.sqrt(E2)                    # embedding scale
        sc = 1.0 / math.sqrt(QPA)                                          # query_pre_attn_scalar
        for l in range(L2):
            n1 = rms_norm(x, Wg[f"blk.{l}.attn_norm.weight"], 1e-5)
            q = (n1 @ Wg[f"blk.{l}.attn_q.weight"].T).reshape(T, H2, D2).transpose(1, 0, 2)
            k = (n1 @ Wg[f"blk.{l}.attn_k.weight"].T).reshape(T, HKV2, D2).transpose(1, 0, 2)
            v = (n1 @ Wg[f"blk.{l}.attn_v.weight"].T).reshape(T, HKV2, D2).transpose(1, 0, 2)
            q, k = rope2(q), rope2(k)
            k = np.repeat(k, H2 // HKV2, axis=0); v = np.repeat(v, H2 // HKV2, axis=0)
            a = (q @ k.transpose(0, 2, 1)) * sc
            a = ASC * np.tanh(a / ASC)                                     # attention soft-cap
            a = np.where(np.tril(np.ones((T, T), bool))[None], a, -1e30); a = softmax(a)
            o = (a @ v).transpose(1, 0, 2).reshape(T, H2 * D2) @ Wg[f"blk.{l}.attn_output.weight"].T
            o = rms_norm(o, Wg[f"blk.{l}.post_attention_norm.weight"], 1e-5)   # post-attention norm
            x = x + o
            n2 = rms_norm(x, Wg[f"blk.{l}.ffn_norm.weight"], 1e-5)
            f = (gelu(n2 @ Wg[f"blk.{l}.ffn_gate.weight"].T) * (n2 @ Wg[f"blk.{l}.ffn_up.weight"].T)) @ Wg[f"blk.{l}.ffn_down.weight"].T
            f = rms_norm(f, Wg[f"blk.{l}.post_ffw_norm.weight"], 1e-5)         # post-ffn norm
            x = x + f
        lg = rms_norm(x, Wg["output_norm.weight"], 1e-5) @ Wg["token_embd.weight"].T
        return FSC * np.tanh(lg / FSC)                                     # final-logit soft-cap
    refg = ref_g(ids2)
    for mode in ("stream", "f32"):
        mg2 = LLM(gp2, resident=mode, chunk_bytes=512)
        chk(f"gemma2 [{mode}]: config decoded (gelu, embed×{math.sqrt(E2):.0f}, softcaps {ASC:.0f}/{FSC:.0f}, head_dim {D2}≠n_embd/n_head)",
            mg2.cfg.act == "gelu" and abs(mg2.cfg.embed_scale - math.sqrt(E2)) < 1e-6 and mg2.cfg.attn_softcap == ASC
            and mg2.cfg.final_softcap == FSC and mg2.cfg.post_norm and mg2.cfg.head_dim == D2 and mg2.cfg.attn_scale == QPA)
        lg2 = mg2.logits(mg2.hidden(np.asarray(ids2)))
        chk(f"gemma2 [{mode}]: logits match the plain reference", np.max(np.abs(lg2 - refg)) < 1e-4, f"max |d| {np.max(np.abs(lg2 - refg)):.2e}")
        fullg = refg - np.max(refg, axis=1, keepdims=True); lpg = fullg - np.log(np.sum(np.exp(fullg), axis=1, keepdims=True))
        wantg = -np.mean([lpg[i, ids2[i + 1]] for i in range(len(ids2) - 1)])
        rg = mg2.nll(ids2)
        chk(f"gemma2 [{mode}]: streamed NLL == full-logit NLL (final soft-cap on both routes)", abs(rg["nll"] - wantg) < 1e-4, f"{rg['nll']:.5f} vs {wantg:.5f}")
        cg = {}; hg1 = mg2.hidden(np.asarray(ids2[:5]), pos0=0, cache=cg); hg2 = mg2.hidden(np.asarray(ids2[5:]), pos0=5, cache=cg)
        chk(f"gemma2 [{mode}]: kv-cache incremental == full pass (post-norms + soft-cap through the cache path)",
            np.max(np.abs(np.concatenate([hg1, hg2]) - mg2.hidden(np.asarray(ids2)))) < 1e-4)
        mg2.close()
    # packed-batch path (the forge's probe route) must also carry the gemma2 deltas
    mgb = LLM(gp2, resident="f32")
    seqsg = [ids2, ids2[:6], [1, 2, 3, 4, 5, 6, 7]]
    singleg = [mgb.nll(x)["nll"] for x in seqsg]
    bg = mgb.nll_batch(seqsg)
    chk("gemma2 packed-batch NLL == per-sequence NLL (post-norms + soft-cap in the packed forward)",
        all(abs(a - c) < 1e-5 for a, c in zip(singleg, bg["per_seq"])), f"{singleg} vs {bg['per_seq']}")
    mgb.close()
    # the friendly, catchable error for an arch with no forward pass here (import/inspect still work on it)
    kvx = {("mamba2" + k[6:] if k.startswith("gemma2") else k): v for k, v in kv2.items()}
    kvx["general.architecture"] = "mamba2"                              # config parses; the arch just has no forward here
    gpx = tmpdir / "tiny-unsupported.gguf"
    tlx = [(name, tuple(reversed(arr.shape)), 0, iter([arr.astype(np.float32).tobytes()]), arr.nbytes) for name, arr in Wg.items()]
    write_gguf(gpx, kvx, tlx)
    try:
        LLM(gpx); chk("unsupported arch raises", False)
    except UnsupportedArch as e:
        chk("unsupported arch -> catchable UnsupportedArch(ValueError) naming the arch and the import/inspect path",
            e.arch == "mamba2" and isinstance(e, ValueError) and "Import" in str(e))
    return chk


if __name__ == "__main__":
    print(verify_suite().report())
