"""
soke.gui_forge — the Forge tab: build a new GGUF from a template while harvesting weights from other GGUFs.

Six pages, in the order you use them:
    1 Donors    scan the model folder (Ollama blobs by default) -> pick the models to harvest from (one family)
    2 Template  presets and a per-layer, per-topic grid you edit cell by cell: donor / blend / extrapolation
    3 Probes    the text the trials are judged on, routed to topics by the knowledge tower
    4 Behavior  the fine-tuning layer: emotion + logic pillars (climate + C/S_e), and the clone battery. It
                MODULATES the loop (tilts proposals, tightens the accept bar) and rides the export as metadata +
                streamed helix teeth, never as weights. Task loss stays the only judge.
    5 Learn     trial and error: every operator on/off, priority topic, Start/Stop, the live trial log
    6 Export    write the .gguf (+ .sff sidecar + Modelfile), then talk to it
"""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from .util import expand_corpus, human_bytes, load_settings, save_settings

from . import theme as _T
BG = _T.PAPER
FG = _T.INK
ACC = _T.ACCENT
OK = _T.OK
WARN = _T.WARN
BAD = _T.BAD
DIM = _T.DIM
SLATE = _T.SLATE
PAPER_HI = _T.PAPER_HI
FACE = _T.FACE
MONO = _T.MONO

# expanded topic-expert vocabulary (drawn from the knowledge tower's domains) for the presets
TOPIC_SETS = {
    "stem":       ["math", "science", "technology", "language"],
    "broad8":     ["math", "language", "science", "technology", "culture", "art", "philosophy", "behavior"],
    "humanities": ["language", "philosophy", "religion", "art", "music", "culture"],
    "reasoning":  ["math", "logic", "science", "language", "philosophy"],
    "code":       ["technology", "math", "language", "science"],
    "math_core":  ["math", "measurement", "science", "language"],
    "knowledge_tree": ["math", "logic", "language", "science", "technology", "measurement", "behavior",
                       "psychology", "morality", "philosophy", "art", "music", "culture", "religion"],
}
# preset RECIPES modeled on known model families. Each fills the Template controls (kind + topics + experts
# used + always-on) which you can then tweak by hand. (kind, topics-key, n_used, shared_topic, gate)
PRESET_CONFIGS = [
    ("Qwen2.5-MoE style — math always-on",          "math-always-on", "broad8",        2, "math",     "lexicon"),
    ("Mixtral 8×7B style — 8 routed experts",        "all-routed",     "broad8",        2, "",         "lexicon"),
    ("DeepSeek-MoE — many small experts, top-2",     "all-routed",     "knowledge_tree",2, "",         "lexicon"),
    ("Phi dense — one compact trunk",                "dense",          "stem",          1, "",         "lexicon"),
    ("Gemma dense — wide trunk",                     "dense",          "broad8",        1, "",         "lexicon"),
    ("Llama dense — plain decoder",                  "dense",          "stem",          1, "",         "lexicon"),
    ("Mathstral — math-forward dense",               "dense",          "math_core",     1, "",         "lexicon"),
    ("Command-R style — broad routed",               "math-always-on", "knowledge_tree",2, "language", "lexicon"),
    ("Reasoning-MoE — math + logic always-on",       "math-always-on", "reasoning",     2, "math",     "lexicon"),
    ("Science-forward MoE",                          "math-always-on", "broad8",        2, "science",  "lexicon"),
    ("Language-forward MoE",                         "math-always-on", "broad8",        2, "language", "lexicon"),
    ("Humanities MoE — art / philosophy / religion", "all-routed",     "humanities",    2, "",         "lexicon"),
    ("Code-forward MoE",                             "math-always-on", "code",          2, "technology","lexicon"),
    ("Knowledge-tree MoE — one expert per branch",   "all-routed",     "knowledge_tree",3, "",         "lexicon"),
    ("Interleave two donors by layer",               "interleave",     "stem",          1, "",         "lexicon"),
    ("Stack — every layer twice (deeper)",           "stack",          "stem",          1, "",         "lexicon"),
    ("Random soup — a search starting point",        "random",         "broad8",        2, "math",     "random"),
]
PRESETS = [(c[0], c[1]) for c in PRESET_CONFIGS]     # (label, kind) for the combobox
PRESET_BY_LABEL = {c[0]: c for c in PRESET_CONFIGS}

# 10 probe presets — named judge sets. Each is a topic list the probes are routed into.
PROBE_PRESETS = {
    "STEM core (math, science, tech, language)": ["math", "science", "technology", "language"],
    "Broad 8": ["math", "language", "science", "technology", "culture", "art", "philosophy", "behavior"],
    "Math only": ["math"],
    "Reasoning (math, logic, science, philosophy)": ["math", "logic", "science", "philosophy"],
    "Humanities (language, philosophy, religion, art, music)": ["language", "philosophy", "religion", "art", "music"],
    "Code (technology, math, language)": ["technology", "math", "language"],
    "Science": ["science", "measurement", "technology"],
    "Religion + Philosophy + Art": ["religion", "philosophy", "art"],
    "Language modeling (general)": ["language", "general"],
    "Knowledge tree (one per branch)": ["math", "logic", "language", "science", "technology", "measurement",
                                        "behavior", "psychology", "morality", "philosophy", "art", "music", "culture", "religion"],
}
OP_LABELS = {"swap_attn": "swap attention donor", "swap_expert": "swap an expert's donor", "blend_expert": "blend two donors in an expert",
             "task_attn": "task-arithmetic attention", "swap_shared": "swap / blend the always-on expert", "gate_scale": "rescale a gate",
             "gate_reinit": "re-seed a gate", "shexp_gain": "rescale the always-on expert", "swap_topics": "swap two experts' topics",
             "swap_layer_src": "re-source a layer (l±1)", "add_expert": "GROW: add an expert", "drop_expert": "HEAL: drop an expert",
             "dup_layer": "GROW: duplicate a layer", "drop_layer": "HEAL: drop a layer", "extrapolate": "extrapolate past the donors (novel weights)"}


def _font(size=10, bold=False):
    import os
    fam = "Segoe UI" if os.name == "nt" else "DejaVu Sans"
    return (fam, size, "bold") if bold else (fam, size)


class ForgeTab:
    def __init__(self, app, frame: ttk.Frame):
        self.app = app
        self.f = frame
        self.donors = []                 # all inventoried
        self.spec = None
        self.probes = None
        self.trainer = None
        self.sources: list[str] = []
        self.export_path: Optional[Path] = None
        self.forge_dir = self.app.root_dir / "forge"
        self.settings = load_settings(self.app.root_dir)
        self._build()

    # ------------------------------------------------------------- layout
    def _build(self) -> None:
        nb = ttk.Notebook(self.f)
        nb.pack(fill="both", expand=True, padx=6, pady=6)
        self.nb = nb
        self.p_donors, self.p_tpl, self.p_probes, self.p_behavior, self.p_learn, self.p_export = (ttk.Frame(nb) for _ in range(6))
        for fr, n in ((self.p_donors, "1 Donors"), (self.p_tpl, "2 Template"), (self.p_probes, "3 Probes"),
                      (self.p_behavior, "4 Behavior"), (self.p_learn, "5 Learn"), (self.p_export, "6 Export & Chat")):
            nb.add(fr, text=n)
        self.behavior = None                                     # a soke.behavior.BehaviorProfile once set
        self.clone_profile = None                                # a clone_profile dict once a battery is run/loaded
        self._build_donors(); self._build_template(); self._build_probes(); self._build_behavior(); self._build_learn(); self._build_export()

    # ---- 1 donors
    def _build_donors(self) -> None:
        t = self.p_donors
        top = tk.Frame(t, bg=BG); top.pack(fill="x", padx=6, pady=(6, 2))
        tk.Label(top, text="Model folder", bg=BG, fg=DIM).pack(side="left")
        self.v_model_dir = tk.StringVar(value=self.settings.get("model_dir", ""))
        e = ttk.Entry(top, textvariable=self.v_model_dir, width=64); e.pack(side="left", padx=4)
        e.bind("<Return>", lambda _e: self.scan_folder())
        ttk.Button(top, text="Browse…", command=self._browse_model_dir).pack(side="left")
        ttk.Button(top, text="Scan", style="Accent.TButton", command=self.scan_folder).pack(side="left", padx=6)
        ttk.Button(top, text="Ollama manifests", command=self.scan_ollama).pack(side="left")
        row = tk.Frame(t, bg=BG); row.pack(fill="x", padx=6, pady=(0, 4))
        tk.Label(row, text="Family", bg=BG, fg=DIM).pack(side="left")
        self.v_family = tk.StringVar()
        self.cb_family = ttk.Combobox(row, textvariable=self.v_family, width=44, state="readonly")
        self.cb_family.pack(side="left", padx=4)
        self.cb_family.bind("<<ComboboxSelected>>", lambda e: self._fill_donor_table())
        tk.Label(t, text="The model folder is where SOKE looks for models and saves the ones it forges (default: Ollama's blob store — every .gguf and "
                         "every blob that starts with the GGUF magic is listed, blobs labelled from Ollama's manifests). Donors must share one family "
                         "(same width, depth, heads and vocabulary) to fill the same slots byte-for-byte. Tick the ones to harvest from; the first ticked "
                         "donor is the base (embeddings, norms).", bg=BG, fg=DIM, wraplength=1100, justify="left").pack(anchor="w", padx=8)
        cols = ("use", "id", "model", "arch", "size", "shape", "quant")
        self.tree_d = ttk.Treeview(t, columns=cols, show="headings", height=14, selectmode="browse")
        for c, w in zip(cols, (50, 50, 420, 80, 90, 220, 160)):
            self.tree_d.heading(c, text=c); self.tree_d.column(c, width=w, anchor="w")
        self.tree_d.pack(fill="both", expand=True, padx=6, pady=6)
        self.tree_d.bind("<Button-1>", self._toggle_donor)
        self.lbl_d = tk.Label(t, text="No models scanned yet.", bg=BG, fg=DIM, anchor="w"); self.lbl_d.pack(fill="x", padx=8)
        self.use: dict[str, bool] = {}

    def _save_settings(self) -> None:
        try:
            save_settings(self.settings, self.app.root_dir)
        except Exception as e:
            self.app.log(f"[forge] settings not saved: {e}")

    def _browse_model_dir(self) -> None:
        d = filedialog.askdirectory(title="Folder with models (.gguf files or Ollama blobs)", initialdir=self.v_model_dir.get() or None)
        if d:
            self.v_model_dir.set(d)
            self.scan_folder()

    def scan_ollama(self) -> None:
        """The manifest route: whatever Ollama's own manifests point at (same result as scanning the blob store)."""
        def job():
            from .forge import inventory_ollama
            return inventory_ollama()
        self.app.run_job("scan ollama", job, self._inventory_done)

    def scan_folder(self) -> None:
        d = self.v_model_dir.get().strip()
        if not d:
            messagebox.showinfo("SOKE", "Choose a model folder first."); return
        if not Path(d).is_dir():
            messagebox.showinfo("SOKE", f"Not a folder:\n{d}"); return
        if d != self.settings.get("model_dir"):
            self.settings["model_dir"] = d
            self._save_settings()
        self.lbl_d.config(text=f"scanning {d} …", fg=DIM)

        def job():
            from .forge import inventory_folder
            return inventory_folder(d)
        self.app.run_job("scan folder", job, self._inventory_done)

    def _inventory_done(self, donors) -> None:
        from .forge import family_groups
        self.donors = donors
        groups = family_groups(donors)
        fams = sorted(groups, key=lambda s: -len(groups[s]))
        self.cb_family["values"] = [f"{s}   ({len(groups[s])} donors)" for s in fams]
        if fams:
            self.cb_family.current(0)
        self._fill_donor_table()
        from .forge import donor_status
        unread = [d for d in donors if donor_status(d) == "arch"]
        moe = [d for d in donors if donor_status(d) == "moe"]
        if not donors:
            self.lbl_d.config(text="No GGUF models found in that folder (looked for *.gguf files and blobs starting with the GGUF magic).", fg=WARN)
        else:
            txt = f"{len(donors)} models found, {len(fams)} families usable"
            if unread:
                txt += f"; {len(unread)} skipped (architecture not supported by the forge yet: " + ", ".join(sorted({d.arch for d in unread})) + ")"
            if moe:
                txt += f"; {len(moe)} mixture-of-experts files listed for chat only (" + ", ".join(d.label for d in moe[:4]) + ("…" if len(moe) > 4 else "") + ")"
            self.lbl_d.config(text=txt + ".", fg=OK)
        try:
            self.forge_dir.mkdir(parents=True, exist_ok=True)
            (self.forge_dir / "inventory.json").write_text(json.dumps([d.to_dict() for d in donors], indent=1), encoding="utf-8")
        except Exception:
            pass

    def _family_sig(self) -> Optional[str]:
        v = self.v_family.get()
        return v.split("   (")[0] if v else None

    def _fill_donor_table(self) -> None:
        from .forge import donor_status
        self.tree_d.delete(*self.tree_d.get_children())
        sig = self._family_sig()
        for d in self.donors:
            if d.sig != sig or donor_status(d) != "ok":            # MoE / unsupported files are chat-only, never donors
                continue
            self.use.setdefault(d.id, True)
            qs = sorted({v for k, v in d.types.items() if k.startswith("ffn") or k.startswith("attn_q")})
            from .gguf_rewrites import GGML_TYPES
            qn = "/".join(GGML_TYPES.get(q, ("?",))[0] for q in qs)
            self.tree_d.insert("", "end", iid=d.id, values=("☑" if self.use[d.id] else "☐", d.id, d.label, d.arch, human_bytes(d.size),
                                                            f"{d.hp.get('n_layer')} layers × {d.hp.get('n_embd')} · ff {d.hp.get('n_ff')}", qn))

    def _toggle_donor(self, ev) -> None:
        row = self.tree_d.identify_row(ev.y)
        col = self.tree_d.identify_column(ev.x)
        if row and col == "#1":
            self.use[row] = not self.use.get(row, True)
            self.tree_d.set(row, "use", "☑" if self.use[row] else "☐")

    def chosen_donors(self):
        from .forge import donor_status
        sig = self._family_sig()
        return [d for d in self.donors if d.sig == sig and donor_status(d) == "ok" and self.use.get(d.id, True)]

    # ---- 2 template
    def _build_template(self) -> None:
        t = self.p_tpl
        top = tk.Frame(t, bg=BG); top.pack(fill="x", padx=6, pady=(6, 2))
        tk.Label(top, text="Preset", bg=BG, fg=DIM).pack(side="left")
        self.v_preset = tk.StringVar(value=PRESETS[0][0])
        _cbp = ttk.Combobox(top, textvariable=self.v_preset, values=[p[0] for p in PRESETS], width=40, state="readonly")
        _cbp.pack(side="left", padx=4); _cbp.bind("<<ComboboxSelected>>", lambda e: self._apply_preset())
        ttk.Button(top, text="Build template", style="Accent.TButton", command=self.build_template).pack(side="left", padx=10)
        row1 = tk.Frame(t, bg=BG); row1.pack(fill="x", padx=6, pady=(0, 4))
        tk.Label(row1, text="Topics (one expert each)", bg=BG, fg=DIM).pack(side="left")
        self.v_topics = tk.StringVar(value="math,language,science,technology")
        ttk.Entry(row1, textvariable=self.v_topics, width=44).pack(side="left", padx=4)
        tk.Label(row1, text="always-on", bg=BG, fg=DIM).pack(side="left", padx=(10, 2))
        self.v_shared = tk.StringVar(value="math")
        ttk.Entry(row1, textvariable=self.v_shared, width=10).pack(side="left")
        tk.Label(row1, text="experts used per token", bg=BG, fg=DIM).pack(side="left", padx=(10, 2))
        self.v_used = tk.StringVar(value="2")
        ttk.Entry(row1, textvariable=self.v_used, width=4).pack(side="left")
        tk.Label(row1, text="gate init", bg=BG, fg=DIM).pack(side="left", padx=(10, 2))
        self.v_gate = tk.StringVar(value="lexicon")
        ttk.Combobox(row1, textvariable=self.v_gate, values=["lexicon", "random", "zeros"], width=8, state="readonly").pack(side="left")
        row2 = tk.Frame(t, bg=BG); row2.pack(fill="x", padx=6)
        ttk.Button(row2, text="Load template…", command=self.load_template).pack(side="left")
        ttk.Button(row2, text="Save template…", command=self.save_template).pack(side="left", padx=4)
        ttk.Button(row2, text="Duplicate layer", command=lambda: self._layer_op("dup")).pack(side="left", padx=(16, 0))
        ttk.Button(row2, text="Delete layer", command=lambda: self._layer_op("del")).pack(side="left", padx=4)
        ttk.Button(row2, text="Set source layer…", command=lambda: self._layer_op("src")).pack(side="left")
        ttk.Button(row2, text="Fill column…", command=self._fill_column).pack(side="left", padx=(16, 0))
        tk.Label(t, text="Double-click a cell to choose what fills that slot: a donor (exact copy), a blend of two donors, or an extrapolation past them. "
                         "Rows are layers of the new model; a layer can be sourced from any donor layer (depth surgery).", bg=BG, fg=DIM, wraplength=1100, justify="left").pack(anchor="w", padx=8, pady=(4, 0))
        self.tree_t = ttk.Treeview(t, columns=("layer",), show="headings", height=16)
        self.tree_t.pack(fill="both", expand=True, padx=6, pady=6)
        self.tree_t.bind("<Double-1>", self._edit_cell)
        self.lbl_t = tk.Label(t, text="No template yet.", bg=BG, fg=DIM, anchor="w", wraplength=1100, justify="left"); self.lbl_t.pack(fill="x", padx=8)

    def _apply_preset(self) -> None:
        """Fill the Template controls from the chosen preset recipe (kind + topics + experts used + always-on)."""
        c = PRESET_BY_LABEL.get(self.v_preset.get())
        if not c:
            return
        _, kind, topics_key, n_used, shared, gate = c
        self.v_topics.set(",".join(TOPIC_SETS.get(topics_key, ["math", "language", "science"])))
        self.v_used.set(str(n_used)); self.v_shared.set(shared or "math"); self.v_gate.set(gate)
        self.app.log(f"[forge] preset '{self.v_preset.get()}' -> {kind}, topics {topics_key}, used {n_used}, always-on {shared or 'none'}")

    def build_template(self) -> None:
        from .forge import ForgeSpec
        donors = self.chosen_donors()
        if not donors:
            messagebox.showinfo("SOKE", "Scan and tick at least one donor on page 1 first.")
            return
        kind = dict(PRESETS)[self.v_preset.get()]
        topics = [x.strip() for x in self.v_topics.get().split(",") if x.strip()]
        try:
            self.spec = ForgeSpec.preset(kind, donors, topics, shared_topic=self.v_shared.get().strip() or "math",
                                         n_used=int(self.v_used.get() or 2), gate_init=self.v_gate.get())
        except Exception as e:
            messagebox.showerror("SOKE", f"Could not build the template: {e}")
            return
        self._show_spec()

    def _show_spec(self) -> None:
        sp = self.spec
        if sp is None:
            return
        moe = bool(sp.layers[0].get("experts"))
        cols = ["layer", "src", "attention"] + (["always-on"] if any(l.get("shared", {}).get("topic") for l in sp.layers) else []) + \
               ([f"expert: {e['topic']}" for e in sp.layers[0]["experts"]] if moe else ["ffn"])
        self.tree_t["columns"] = cols
        for c in cols:
            self.tree_t.heading(c, text=c); self.tree_t.column(c, width=70 if c in ("layer", "src") else 150, anchor="w")
        self.tree_t.delete(*self.tree_t.get_children())
        for i, l in enumerate(sp.layers):
            vals = [i, l.get("src_layer", i), self._op_text(l["attn"])]
            if "always-on" in cols:
                sh = l.get("shared") or {}
                vals.append(self._op_text(sh.get("op")) + (f" ×{sh.get('gain', 2.0):.1f}" if sh.get("topic") else "") if sh else "—")
            if moe:
                vals += [self._op_text(e["op"]) for e in l["experts"]]
            else:
                vals.append(self._op_text(l["ffn"]))
            self.tree_t.insert("", "end", iid=str(i), values=vals)
        self.lbl_t.config(text=sp.summary() + f"   fingerprint {sp.fingerprint()}")

    @staticmethod
    def _op_text(op) -> str:
        if not op:
            return "—"
        k = op.get("kind")
        if k == "copy":
            return op["donor"]
        if k == "blend":
            return "blend " + "+".join(f"{d}×{w:.2f}" for d, w in op["weights"].items())
        if k == "task":
            return f"{op['base']} + " + " + ".join(f"{l:.2f}·({d}−{op['base']})" for d, l in op["deltas"].items())
        if k == "slerp":
            return f"slerp {op['a']}→{op['b']} t={op['t']:.2f}"
        if k == "zeros":
            return "zeros"
        return k

    def _edit_cell(self, ev) -> None:
        if self.spec is None:
            return
        row = self.tree_t.identify_row(ev.y); col = self.tree_t.identify_column(ev.x)
        if not row:
            return
        ci = int(col[1:]) - 1
        cols = list(self.tree_t["columns"])
        cname = cols[ci]
        li = int(row)
        layer = self.spec.layers[li]
        if cname in ("layer",):
            return
        if cname == "src":
            v = simpledialog.askinteger("Source layer", f"Which donor layer feeds layer {li}? (0..{self.spec.d['hp']['n_layer'] - 1})", parent=self.app, initialvalue=layer.get("src_layer", li))
            if v is not None:
                layer["src_layer"] = max(0, min(int(self.spec.d["hp"]["n_layer"]) - 1, v))
            self._show_spec(); return
        op = self._ask_op(f"layer {li} · {cname}")
        if op is None:
            return
        if cname == "attention":
            layer["attn"] = op
        elif cname == "always-on":
            if layer.get("shared"):
                layer["shared"]["op"] = op
        elif cname == "ffn":
            layer["ffn"] = op
        elif cname.startswith("expert: "):
            topic = cname[len("expert: "):]
            for e in layer["experts"]:
                if e["topic"] == topic:
                    e["op"] = op
        self._show_spec()

    def _ask_op(self, what: str):
        """Small dialog: donor copy / blend / extrapolate."""
        from .forge import op_blend, op_copy, op_task
        ids = list(self.spec.donors)
        win = tk.Toplevel(self.app); win.title(f"Fill {what}"); win.configure(bg=BG); win.grab_set()
        res = {"op": None}
        tk.Label(win, text=f"What fills {what}?", bg=BG, fg=FG, font=_font(11, True)).pack(anchor="w", padx=10, pady=(10, 4))
        v_kind = tk.StringVar(value="copy"); v_a = tk.StringVar(value=ids[0]); v_b = tk.StringVar(value=ids[-1]); v_t = tk.StringVar(value="0.5")
        for txt, val in (("copy one donor exactly", "copy"), ("blend donor A and donor B (t = share of B)", "blend"), ("extrapolate: A + t·(B − A)   (t > 1 goes beyond the donors)", "task"), ("zeros (switch the slot off)", "zeros")):
            ttk.Radiobutton(win, text=txt, value=val, variable=v_kind).pack(anchor="w", padx=14)
        r = tk.Frame(win, bg=BG); r.pack(anchor="w", padx=14, pady=6)
        tk.Label(r, text="A", bg=BG, fg=DIM).pack(side="left"); ttk.Combobox(r, textvariable=v_a, values=ids, width=6, state="readonly").pack(side="left", padx=4)
        tk.Label(r, text="B", bg=BG, fg=DIM).pack(side="left"); ttk.Combobox(r, textvariable=v_b, values=ids, width=6, state="readonly").pack(side="left", padx=4)
        tk.Label(r, text="t", bg=BG, fg=DIM).pack(side="left"); ttk.Entry(r, textvariable=v_t, width=6).pack(side="left", padx=4)

        def ok():
            k = v_kind.get(); a, b = v_a.get(), v_b.get()
            try:
                t = float(v_t.get())
            except ValueError:
                t = 0.5
            if k == "copy":
                res["op"] = op_copy(a)
            elif k == "blend":
                res["op"] = op_blend({a: 1 - t, b: t}) if a != b else op_copy(a)
            elif k == "task":
                res["op"] = op_task(a, {b: t}) if a != b else op_copy(a)
            else:
                res["op"] = {"kind": "zeros"}
            win.destroy()
        ttk.Button(win, text="OK", style="Accent.TButton", command=ok).pack(side="left", padx=14, pady=10)
        ttk.Button(win, text="Cancel", command=win.destroy).pack(side="left")
        self.app.wait_window(win)
        return res["op"]

    def _fill_column(self) -> None:
        if self.spec is None:
            return
        cols = [c for c in self.tree_t["columns"] if c not in ("layer", "src")]
        c = simpledialog.askstring("Fill column", "Column to fill for every layer:\n" + "\n".join(cols), parent=self.app, initialvalue=cols[-1])
        if not c or c not in cols:
            return
        op = self._ask_op(f"every layer · {c}")
        if op is None:
            return
        for layer in self.spec.layers:
            if c == "attention":
                layer["attn"] = op
            elif c == "always-on" and layer.get("shared"):
                layer["shared"]["op"] = op
            elif c == "ffn":
                layer["ffn"] = op
            elif c.startswith("expert: "):
                for e in layer["experts"]:
                    if e["topic"] == c[len("expert: "):]:
                        e["op"] = op
        self._show_spec()

    def _layer_op(self, what: str) -> None:
        if self.spec is None:
            return
        sel = self.tree_t.selection()
        li = int(sel[0]) if sel else None
        L = self.spec.layers
        if what == "dup" and li is not None:
            L.insert(li + 1, json.loads(json.dumps(L[li])))
        elif what == "del" and li is not None and len(L) > 1:
            del L[li]
        elif what == "src" and li is not None:
            v = simpledialog.askinteger("Source layer", f"Donor layer for layer {li}:", parent=self.app, initialvalue=L[li].get("src_layer", li))
            if v is not None:
                L[li]["src_layer"] = max(0, min(int(self.spec.d["hp"]["n_layer"]) - 1, v))
        self._show_spec()

    def load_template(self) -> None:
        from .forge import ForgeSpec
        f = filedialog.askopenfilename(title="Template", filetypes=[("Forge template", "*.json")])
        if f:
            self.spec = ForgeSpec.from_json(Path(f).read_text(encoding="utf-8")); self._show_spec()

    def save_template(self) -> None:
        if self.spec is None:
            return
        f = filedialog.asksaveasfilename(title="Save template", defaultextension=".json", initialdir=str(self.forge_dir), initialfile="template.json")
        if f:
            Path(f).write_text(self.spec.to_json(), encoding="utf-8"); self.app.log(f"template saved: {f}")

    # ---- 3 probes
    def _build_probes(self) -> None:
        t = self.p_probes
        top = tk.Frame(t, bg=BG); top.pack(fill="x", padx=6, pady=6)
        ttk.Button(top, text="Add a folder", style="Accent.TButton", command=self._add_folder).pack(side="left")
        ttk.Button(top, text="Add files", command=self._add_files).pack(side="left", padx=4)
        ttk.Button(top, text="Clear", command=self._clear_sources).pack(side="left")
        tk.Label(top, text="chunks per topic", bg=BG, fg=DIM).pack(side="left", padx=(16, 2))
        self.v_per = tk.StringVar(value="6"); ttk.Entry(top, textvariable=self.v_per, width=4).pack(side="left")
        tk.Label(top, text="hold-out per topic", bg=BG, fg=DIM).pack(side="left", padx=(10, 2))
        self.v_hold = tk.StringVar(value="2"); ttk.Entry(top, textvariable=self.v_hold, width=4).pack(side="left")
        tk.Label(top, text="tokens per chunk", bg=BG, fg=DIM).pack(side="left", padx=(10, 2))
        self.v_tok = tk.StringVar(value="192"); ttk.Entry(top, textvariable=self.v_tok, width=5).pack(side="left")
        ttk.Button(top, text="Build probes", style="Accent.TButton", command=self.build_probes).pack(side="left", padx=10)
        row = tk.Frame(t, bg=BG); row.pack(fill="x", padx=6, pady=(0, 2))
        tk.Label(row, text="Probe preset", bg=BG, fg=DIM).pack(side="left")
        self.v_probe_preset = tk.StringVar(value="(use the template's topics)")
        _pp = ttk.Combobox(row, textvariable=self.v_probe_preset, values=["(use the template's topics)"] + list(PROBE_PRESETS), width=44, state="readonly")
        _pp.pack(side="left", padx=4); _pp.bind("<<ComboboxSelected>>", lambda e: self._apply_probe_preset())
        tk.Label(row, text="topics", bg=BG, fg=DIM).pack(side="left", padx=(10, 2))
        self.v_probe_topics = tk.StringVar(value="")
        ttk.Entry(row, textvariable=self.v_probe_topics, width=50).pack(side="left")
        tk.Label(row, text="(blank = the template's topics; the Home advisor can also generate probes)", bg=BG, fg=DIM).pack(side="left", padx=4)
        tk.Label(t, text="The probes are the judge: text chunks routed to your topics by the knowledge tower. Trials must lower the loss on the training chunks; "
                         "hold-out chunks are scored but never optimised (the over-fit guard). More chunks = slower but fairer trials.", bg=BG, fg=DIM, wraplength=1100, justify="left").pack(anchor="w", padx=8)
        self.src_list = tk.Listbox(t, height=6, bg=PAPER_HI, fg=FG, selectbackground=SLATE); self.src_list.pack(fill="x", padx=6, pady=4)
        self.lbl_p = tk.Label(t, text="No probes yet.", bg=BG, fg=DIM, anchor="w", wraplength=1100, justify="left"); self.lbl_p.pack(fill="x", padx=8)

    def _apply_probe_preset(self) -> None:
        tl = PROBE_PRESETS.get(self.v_probe_preset.get())
        self.v_probe_topics.set(",".join(tl) if tl else "")

    def _add_folder(self) -> None:
        d = filedialog.askdirectory(title="Folder of text to judge the trials on")
        if d and d not in self.sources:
            self.sources.append(d); self.src_list.insert("end", "folder:  " + d)

    def _add_files(self) -> None:
        for f in filedialog.askopenfilenames(title="Files to judge the trials on"):
            if f not in self.sources:
                self.sources.append(f); self.src_list.insert("end", "file:  " + f)

    def _clear_sources(self) -> None:
        self.sources = []; self.src_list.delete(0, "end")

    def build_probes(self) -> None:
        if self.spec is None:
            messagebox.showinfo("SOKE", "Build a template first (page 2): the probes use its tokenizer and topics.")
            return
        if not self.sources:
            messagebox.showinfo("SOKE", "Add a folder or files of text first.")
            return
        spec, srcs = self.spec, list(self.sources) + list(self.app.imports.files)
        per, hold, tok = int(self.v_per.get() or 6), int(self.v_hold.get() or 2), int(self.v_tok.get() or 192)
        probe_topics = [x.strip() for x in self.v_probe_topics.get().split(",") if x.strip()]

        def job():
            from .forge_loop import build_probes
            from .gguf_rewrites import GGUFReader
            from .tokenizer import Tokenizer
            gr = GGUFReader(spec.donors[spec.d["base"]]["path"]); tk_ = Tokenizer(gr.kv); gr.close()
            base_topics = probe_topics or list(spec.topics)
            topics = list(base_topics) + (["general"] if "general" not in base_topics else [])
            return build_probes(srcs, tk_, topics, per_topic=per, holdout_per_topic=hold, max_tokens=tok,
                                progress=lambda d: self.app.q.put(("status", f"probes: {d['chunks']} chunks routed")))

        def done(p):
            self.probes = p
            counts = {t: (len(p.train.get(t, [])), len(p.holdout.get(t, []))) for t in p.topics}
            empty = [t for t, (a, b) in counts.items() if a == 0]
            self.lbl_p.config(text=f"probes ready: {p.n_tokens} tokens · per topic (train, hold-out): {counts}" + (f"  — no text was routed to {empty}; those topics cannot be judged" if empty else ""),
                              fg=WARN if empty else OK)
        self.app.run_job("build probes", job, done)

    # ---- 4 behavior (the fine-tuning layer: emotion + logic pillars, and the clone battery)
    def _build_behavior(self) -> None:
        from .behavior import CLIMATES, C_NAMES, C_GLOSS
        t = self.p_behavior
        tk.Label(t, text="The behavior map is the fine-tuning layer. It rides BESIDE the weights - as GGUF metadata and streamed helix teeth, never baked in - "
                         "and it MODULATES the trial loop: it tilts which move is tried and which topic gets attention, and it may only make the accept bar "
                         "stricter, never looser. Task loss stays the only judge. Emotion bids; the logic proof-state, the priority veto and the loss law close.",
                 bg=BG, fg=DIM, wraplength=1120, justify="left").pack(anchor="w", padx=8, pady=(6, 2))
        top = tk.Frame(t, bg=BG); top.pack(fill="x", padx=6, pady=4)
        tk.Label(top, text="Climate", bg=BG, fg=DIM).pack(side="left")
        self.v_climate = tk.StringVar(value="neutral")
        cb = ttk.Combobox(top, textvariable=self.v_climate, values=list(CLIMATES.keys()), width=14, state="readonly")
        cb.pack(side="left", padx=4); cb.bind("<<ComboboxSelected>>", lambda e: self._load_climate())
        self.v_logic = tk.BooleanVar(value=True)
        ttk.Checkbutton(top, text="logic pillar (proof-state veto: ⊥ drop / ? no-grow / ⊥⊥ freeze+rollback)", variable=self.v_logic, command=self._sync_behavior).pack(side="left", padx=(12, 0))
        ttk.Button(top, text="Apply as neutral off", command=self._behavior_off).pack(side="left", padx=8)
        body = tk.Frame(t, bg=BG); body.pack(fill="both", expand=True, padx=6, pady=4)
        # left: the 13 machine chemicals
        chem = tk.LabelFrame(body, text=" machine chemicals C (gain 0-100) - each maps to a forge knob ", bg=BG, fg=ACC); chem.pack(side="left", fill="y", padx=(0, 6))
        self.v_chem = {}
        for i, name in enumerate(C_NAMES):
            row = tk.Frame(chem, bg=BG); row.grid(row=i, column=0, sticky="w", padx=4, pady=0)
            tk.Label(row, text=f"{name:4s}", bg=BG, fg=FG, font=MONO, width=5).pack(side="left")
            v = tk.IntVar(value=50); self.v_chem[name] = v
            ttk.Scale(row, from_=0, to=100, variable=v, length=150, command=lambda _e: self._sync_behavior()).pack(side="left")
            tk.Label(row, text=C_GLOSS[name][:34], bg=BG, fg=DIM, font=_T.font(7)).pack(side="left", padx=4)
        # middle: the 4-D emotion string and the clone
        mid = tk.Frame(body, bg=BG); mid.pack(side="left", fill="y", padx=6)
        se = tk.LabelFrame(mid, text=" S_e - the 4-D emotion string ", bg=BG, fg=ACC); se.pack(fill="x")
        self.v_se = {}
        for i, (nm, lbl) in enumerate([("x", "x nature"), ("y", "y nurture"), ("z", "z regulation"), ("w", "w meaning")]):
            row = tk.Frame(se, bg=BG); row.pack(anchor="w", padx=4)
            tk.Label(row, text=lbl, bg=BG, fg=DIM, width=12, anchor="w").pack(side="left")
            v = tk.IntVar(value=50); self.v_se[nm] = v
            ttk.Scale(row, from_=0, to=100, variable=v, length=150, command=lambda _e: self._sync_behavior()).pack(side="left")
        clone = tk.LabelFrame(mid, text=" personality clone (Digital Psychoanalyst) ", bg=BG, fg=ACC); clone.pack(fill="x", pady=(8, 0))
        tk.Label(clone, text="Capture YOUR word→feeling map, priors, veto style into soke.clone.* + psychology helix. Consent-gated; you can SKIP/STOP any time.",
                 bg=BG, fg=DIM, wraplength=300, justify="left", font=_T.font(7)).pack(anchor="w", padx=4)
        ttk.Button(clone, text="Run the clone battery…", command=self._open_clone).pack(anchor="w", padx=4, pady=2)
        self.v_clone_consent = tk.BooleanVar(value=False)
        ttk.Checkbutton(clone, text="write soke.clone.* metadata on export (my consent)", variable=self.v_clone_consent).pack(anchor="w", padx=4)
        self.lbl_clone = tk.Label(clone, text="no clone profile loaded", bg=BG, fg=DIM, anchor="w", wraplength=300, justify="left"); self.lbl_clone.pack(anchor="w", padx=4)
        r = tk.Frame(clone, bg=BG); r.pack(anchor="w", padx=4, pady=2)
        ttk.Button(r, text="Load profile…", command=self._load_clone_file).pack(side="left")
        ttk.Button(r, text="Save profile…", command=self._save_behavior_file).pack(side="left", padx=4)
        # right: live read-out of the derived knobs
        self.lbl_beh = tk.Label(body, text="", bg=PAPER_HI, fg=OK, anchor="nw", justify="left", font=("Consolas", 9), wraplength=300, padx=8, pady=6); self.lbl_beh.pack(side="left", fill="both", expand=True, padx=6)
        self._load_climate()

    def _load_climate(self) -> None:
        from .behavior import CLIMATES, C_NAMES
        prof = CLIMATES.get(self.v_climate.get())
        if prof is None:
            return
        for i, name in enumerate(C_NAMES):
            self.v_chem[name].set(int(round(prof.C[i] * 100)))
        for i, nm in enumerate(("x", "y", "z", "w")):
            self.v_se[nm].set(int(round(prof.S_e[i] * 100)))
        self._sync_behavior()

    def _sync_behavior(self) -> None:
        from .behavior import BehaviorProfile, C_NAMES, AFFECTS
        C = [self.v_chem[n].get() / 100.0 for n in C_NAMES]
        S_e = [self.v_se[nm].get() / 100.0 for nm in ("x", "y", "z", "w")]
        prof = BehaviorProfile(C=C, S_e=S_e, name=self.v_climate.get(), logic_enabled=self.v_logic.get())
        prof.affect[AFFECTS.index("SEEKING")] = prof.c("DA"); prof.affect[AFFECTS.index("CARE")] = prof.c("OXT")
        if self.clone_profile is not None:
            prof.clone = self.clone_profile
        self.behavior = prof
        self._show_knobs()

    def _behavior_off(self) -> None:
        self.behavior = None
        self.lbl_beh.config(text="behavior OFF - the loop runs unmodulated (task loss only).")

    def _show_knobs(self) -> None:
        if self.behavior is None:
            return
        k = self.behavior.knobs(); h = self.behavior.happiness_mix(); reg = self.behavior.regularizers()
        m = self.behavior.op_weight_multipliers()
        txt = (f"climate '{self.behavior.name}'  logic={'on' if self.behavior.logic_enabled else 'off'}\n\n"
               f"accept bar:  min_gain x{k['min_gain_mult']:.2f}  (>=1: emotion may only tighten)\n"
               f"heal_first:  {k['heal_first']}  (CORT high -> no grow, heal instead)\n"
               f"explore:     x{k['explore_bonus']:.2f}   contest x{m.get('swap_attn', 1):.2f}\n"
               f"focus worst: {k['focus_worst']:.2f}   patience {k['patience']}\n"
               f"grow ops:    add_expert x{m.get('add_expert', 1):.2f}  dup_layer x{m.get('dup_layer', 1):.2f}\n\n"
               f"happiness:   Exc {h['Excitement']:.2f}  Bnd {h['Boundlessness']:.2f}  Dar {h['Daring']:.2f}\n"
               f"regularizers (logged, clamped, never the objective):\n"
               f"  L_want_like {reg['L_want_like']:.2f}  L_cort_decay {reg['L_cort_decay']:.2f}\n"
               f"  L_veto_bypass {reg['L_veto_bypass']} (0)  L_oxt_weapon {reg['L_oxt_weapon']:.2f}")
        self.lbl_beh.config(text=txt)

    def _save_behavior_file(self) -> None:
        if self.behavior is None:
            self._sync_behavior()
        f = filedialog.asksaveasfilename(title="Save behavior profile", defaultextension=".json", initialdir=str(self.forge_dir), initialfile="behavior.json")
        if f:
            Path(f).write_text(self.behavior.to_json(), encoding="utf-8"); self.app.log(f"behavior profile saved: {f}")

    def _load_clone_file(self) -> None:
        f = filedialog.askopenfilename(title="Clone / behavior profile", filetypes=[("Profile", "*.json")])
        if not f:
            return
        import json as _json
        from .behavior import BehaviorProfile, C_NAMES
        d = _json.loads(Path(f).read_text(encoding="utf-8"))
        prof = BehaviorProfile.from_dict(d.get("profile", d))
        for i, name in enumerate(C_NAMES):
            self.v_chem[name].set(int(round(prof.C[i] * 100)))
        for i, nm in enumerate(("x", "y", "z", "w")):
            self.v_se[nm].set(int(round(prof.S_e[i] * 100)))
        self.clone_profile = prof.clone or (d.get("profile", {}).get("clone"))
        self._sync_behavior()
        self.lbl_clone.config(text=f"loaded {Path(f).name}" + (f"  ({len(self.clone_profile.get('lexicon', {}))} lexicon pairs)" if self.clone_profile else ""), fg=OK)

    def _open_clone(self) -> None:
        CloneWindow(self)

    def _clone_done(self, profile_dict, teeth) -> None:
        """called by CloneWindow when the battery exports: adopt the clone into the behavior profile."""
        self.clone_profile = profile_dict.get("clone", profile_dict)
        self._clone_teeth = teeth
        self.v_clone_consent.set(bool(profile_dict.get("consent", {}).get("store")))
        self._sync_behavior()
        self.lbl_clone.config(text=f"clone captured: {len(self.clone_profile.get('lexicon', {}))} lexicon pairs, veto_style {self.clone_profile.get('veto_style')}", fg=OK)

    # ---- 5 learn
    def _build_learn(self) -> None:
        t = self.p_learn
        top = tk.Frame(t, bg=BG); top.pack(fill="x", padx=6, pady=6)
        tk.Label(top, text="priority topic", bg=BG, fg=DIM).pack(side="left")
        self.v_prio = tk.StringVar(value="math"); ttk.Entry(top, textvariable=self.v_prio, width=10).pack(side="left", padx=4)
        tk.Label(top, text="may not worsen by more than", bg=BG, fg=DIM).pack(side="left")
        self.v_tol = tk.StringVar(value="2"); ttk.Entry(top, textvariable=self.v_tol, width=4).pack(side="left", padx=2); tk.Label(top, text="%", bg=BG, fg=DIM).pack(side="left")
        tk.Label(top, text="min gain (nats)", bg=BG, fg=DIM).pack(side="left", padx=(10, 2))
        self.v_gain = tk.StringVar(value="0.001"); ttk.Entry(top, textvariable=self.v_gain, width=7).pack(side="left")
        tk.Label(top, text="trials", bg=BG, fg=DIM).pack(side="left", padx=(10, 2))
        self.v_trials = tk.StringVar(value="40"); ttk.Entry(top, textvariable=self.v_trials, width=5).pack(side="left")
        tk.Label(top, text="minutes", bg=BG, fg=DIM).pack(side="left", padx=(10, 2))
        self.v_minutes = tk.StringVar(value="60"); ttk.Entry(top, textvariable=self.v_minutes, width=5).pack(side="left")
        self.btn_start = ttk.Button(top, text="Start trials", style="Accent.TButton", command=self.start); self.btn_start.pack(side="left", padx=10)
        ttk.Button(top, text="Stop", command=self.stop_run).pack(side="left")
        ops = tk.LabelFrame(t, text=" operators the loop may try (untick to forbid) ", bg=BG, fg=ACC); ops.pack(fill="x", padx=6, pady=4)
        self.op_vars: dict[str, tk.BooleanVar] = {}
        for i, (k, label) in enumerate(OP_LABELS.items()):
            v = tk.BooleanVar(value=True); self.op_vars[k] = v
            ttk.Checkbutton(ops, text=label, variable=v).grid(row=i // 4, column=i % 4, sticky="w", padx=6, pady=1)
        self.lbl_score = tk.Label(t, text="scores appear here (lower is better; nats per token)", bg=BG, fg=OK, anchor="w", font=_font(11, True), wraplength=1100, justify="left")
        self.lbl_score.pack(fill="x", padx=8, pady=(4, 0))
        cols = ("n", "operator", "what changed", "before", "after", "verdict", "hold-out", "s")
        self.tree_l = ttk.Treeview(t, columns=cols, show="headings", height=14)
        for c, w in zip(cols, (40, 110, 520, 80, 80, 80, 80, 50)):
            self.tree_l.heading(c, text=c); self.tree_l.column(c, width=w, anchor="w")
        self.tree_l.pack(fill="both", expand=True, padx=6, pady=6)

    def start(self) -> None:
        if self.spec is None or self.probes is None:
            messagebox.showinfo("SOKE", "Need a template (page 2) and probes (page 3) first.")
            return
        if self.trainer is not None and not self.trainer.stop and getattr(self, "_running", False):
            return
        from .forge_loop import ForgeTrainer
        from .ledger import Ledger
        from .meta_optimizer import ResearchDB
        name = self.spec.d.get("name", "forge")
        save_dir = self.forge_dir / name
        allow = [k for k, v in self.op_vars.items() if v.get()]
        try:
            tol = float(self.v_tol.get()) / 100.0; gain = float(self.v_gain.get()); n_tr = int(self.v_trials.get()); mins = float(self.v_minutes.get())
        except ValueError:
            messagebox.showerror("SOKE", "Check the numbers (tolerance %, min gain, trials, minutes)."); return
        if self.behavior is None:
            self._sync_behavior()
        self.trainer = ForgeTrainer(self.spec, self.probes, memguard=self.app.mg, ledger=Ledger(self.app.root_dir / "ledger" / "events.jsonl"),
                                    research_db=ResearchDB(self.app.root_dir / "research.db"), on_event=lambda k, p: self.app.q.put(("forge", (k, p))),
                                    priority_topic=self.v_prio.get().strip() or None, tol_priority=tol, min_gain=gain, allow_ops=allow, save_dir=save_dir,
                                    behavior=self.behavior)
        self._running = True
        self.tree_l.delete(*self.tree_l.get_children())
        self.lbl_score.config(text="scoring the starting template on the probes… (every donor tensor is read once per pass)")
        tr = self.trainer

        def job():
            return tr.run(max_trials=n_tr, time_budget_s=mins * 60)

        def done(rep):
            self._running = False
            self.spec = tr.spec
            self._show_spec()
            bx = rep.get("behavior")
            btail = (f" · behavior '{bx['name']}': proof-vetoes {bx['proof_vetoes']}, macro-blocked {bx['macro_blocked']}, veto-bypass {bx['veto_bypass']} (must be 0)"
                     if bx else "")
            self.lbl_score.config(text=f"done: {rep['accepted']} accepted, {rep['nulls']} nulls · train {rep['train']['total']:.4f} · hold-out {rep['holdout']['total']:.4f} "
                                       f"· best hold-out {rep['best_holdout']:.4f} · {rep['evals']} evaluations, {rep['eval_seconds']} s" + btail)
            self.app.log(f"[forge] {json.dumps(rep, default=str)[:600]}")

        def fail(err):
            self._running = False
            self.lbl_score.config(text=f"stopped with an error: {err}", fg=BAD)
        self.app.run_job("forge trials", job, done, on_error=fail)

    def stop_run(self) -> None:
        if self.trainer is not None:
            self.trainer.stop = True
            self.lbl_score.config(text="stopping after the current trial…")

    def on_event(self, kind: str, p: dict) -> None:
        if kind == "baseline":
            tr = p["train"]; ho = p["holdout"]
            self.lbl_score.config(text="start: train " + f"{tr['total']:.4f}  " + "  ".join(f"{k} {v:.3f}" for k, v in tr["topics"].items()) + f"   · hold-out {ho['total']:.4f}", fg=OK)
        elif kind == "trial":
            self.tree_l.insert("", "end", values=(p["n"], p["op"], p["desc"], f"{p['before']:.4f}", f"{p['after']:.4f}" if p["after"] == p["after"] else "nan",
                                                  "KEPT" if p["accepted"] else "null", f"{p['holdout']:.4f}" if p.get("holdout") is not None else "", p.get("seconds", "")))
            self.tree_l.see(self.tree_l.get_children()[-1])
            if p["accepted"] and self.trainer is not None and self.trainer.score:
                s = self.trainer.score
                self.lbl_score.config(text=f"trial {p['n']} kept: train {s['total']:.4f}  " + "  ".join(f"{k} {v:.3f}" for k, v in s["topics"].items()) + (f"   · hold-out {p['holdout']:.4f}" if p.get("holdout") is not None else ""), fg=OK)
        elif kind == "overfit_guard":
            self.app.log(f"[forge] over-fit guard: stepped back to the best hold-out template ({p['best_holdout']:.4f})")
        elif kind == "proof_veto":
            self.app.log(f"[forge] logic pillar: P={p.get('state')} vetoed {p.get('op')} - {p.get('desc','')[:80]}")

    # ---- 5 export & chat
    def _build_export(self) -> None:
        t = self.p_export
        top = tk.Frame(t, bg=BG); top.pack(fill="x", padx=6, pady=6)
        tk.Label(top, text="name", bg=BG, fg=DIM).pack(side="left")
        self.v_name = tk.StringVar(value="soke-forge"); ttk.Entry(top, textvariable=self.v_name, width=24).pack(side="left", padx=4)
        self.v_which = tk.StringVar(value="holdout")
        ttk.Radiobutton(top, text="best on hold-out (recommended)", value="holdout", variable=self.v_which).pack(side="left", padx=(10, 0))
        ttk.Radiobutton(top, text="current template", value="current", variable=self.v_which).pack(side="left")
        ttk.Button(top, text="Export .gguf + .sff", style="Accent.TButton", command=self.export).pack(side="left", padx=10)
        ttk.Button(top, text="Tandem tree (optional)…", command=self._open_tandem).pack(side="left")
        row = tk.Frame(t, bg=BG); row.pack(fill="x", padx=6, pady=(0, 4))
        tk.Label(row, text="Save to", bg=BG, fg=DIM).pack(side="left")
        self.v_export_dir = tk.StringVar(value=self.settings.get("export_dir", ""))
        ttk.Entry(row, textvariable=self.v_export_dir, width=64).pack(side="left", padx=4)
        ttk.Button(row, text="Browse…", command=self._browse_export_dir).pack(side="left")
        self.exp_prog = ttk.Progressbar(t, maximum=100); self.exp_prog.pack(fill="x", padx=6)
        self.lbl_e = tk.Label(t, text="Writes name.gguf (runs in llama.cpp / Ollama / LM Studio), name.sff beside it (template, every tensor's donor, the trial ledger) "
                                      "and name.Modelfile — then  ollama create name -f name.Modelfile  registers it with Ollama.",
                              bg=BG, fg=DIM, anchor="w", wraplength=1100, justify="left"); self.lbl_e.pack(fill="x", padx=8, pady=4)
        chat = tk.LabelFrame(t, text=" talk to it (SOKE's own engine; slow but honest) ", bg=BG, fg=ACC); chat.pack(fill="both", expand=True, padx=6, pady=6)
        r = tk.Frame(chat, bg=BG); r.pack(fill="x", padx=6, pady=4)
        ttk.Button(r, text="Model .gguf", command=self._pick_model).pack(side="left")
        self.v_model = tk.StringVar(); ttk.Entry(r, textvariable=self.v_model, width=60).pack(side="left", padx=4)
        tk.Label(r, text="max tokens", bg=BG, fg=DIM).pack(side="left"); self.v_max = tk.StringVar(value="48"); ttk.Entry(r, textvariable=self.v_max, width=5).pack(side="left", padx=4)
        r2 = tk.Frame(chat, bg=BG); r2.pack(fill="x", padx=6)
        self.v_prompt = tk.StringVar(value="What is a prime number?"); e = ttk.Entry(r2, textvariable=self.v_prompt, width=80); e.pack(side="left"); e.bind("<Return>", lambda _e: self.ask())
        ttk.Button(r2, text="Ask", style="Accent.TButton", command=self.ask).pack(side="left", padx=6)
        self.chat_out = tk.Text(chat, height=10, bg=PAPER_HI, fg=FG, font=MONO, wrap="word"); self.chat_out.pack(fill="both", expand=True, padx=6, pady=6)

    def _browse_export_dir(self) -> None:
        d = filedialog.askdirectory(title="Folder to save forged models in", initialdir=self.v_export_dir.get() or None)
        if d:
            self.v_export_dir.set(d)

    def _open_tandem(self) -> None:
        TandemWindow(self)

    def export(self) -> None:
        if self.spec is None:
            messagebox.showinfo("SOKE", "Build a template first."); return
        name = "".join(c if c.isalnum() or c in "-_." else "-" for c in self.v_name.get().strip()) or "soke-forge"
        d = self.v_export_dir.get().strip() or str(self.forge_dir)
        try:
            Path(d).mkdir(parents=True, exist_ok=True)
        except OSError as e:
            messagebox.showerror("SOKE", f"Cannot use that folder: {e}"); return
        if d != self.settings.get("export_dir"):
            self.settings["export_dir"] = d
            self._save_settings()
        out = Path(d) / f"{name}.gguf"
        spec = self.trainer.best_holdout_spec if (self.trainer is not None and self.v_which.get() == "holdout") else (self.trainer.spec if self.trainer is not None else self.spec)
        spec = spec.copy(); spec.d["name"] = name
        self.exp_prog["value"] = 0

        behavior = self.behavior
        consent = {"store": bool(self.v_clone_consent.get())} if self.v_clone_consent.get() else {"store": False}
        teeth = getattr(self, "_clone_teeth", None)

        def job():
            from .forge import assemble
            from .ledger import Ledger
            return assemble(spec, out, memguard=self.app.mg, ledger=Ledger(self.app.root_dir / "ledger" / "events.jsonl"),
                            behavior=behavior, clone_consent=consent, clone_teeth=teeth,
                            progress=lambda d: self.app.q.put(("forge", ("export", d))))

        def done(st):
            self.exp_prog["value"] = 100
            self.export_path = out
            self.v_model.set(str(out))
            from .forge import write_modelfile
            mf = write_modelfile(out, name)
            btail = f" · behavior: {st['behavior']['pillars']}, {st.get('helix_teeth', 0)} helix teeth (metadata only, not in weights)" if st.get("behavior") else ""
            self.lbl_e.config(text=f"written {out}  ({human_bytes(st['bytes'])}; {st['exact']} tensors copied byte-for-byte, {st['novel']} novel/requantized; "
                                   f"{st['elapsed_s']} s; peak {st['peak_rss_mb']:.0f} MB) · sidecar {Path(st['sidecar']).name if st.get('sidecar') else '-'}" + btail + " · "
                                   f"Ollama:  ollama create {name} -f \"{mf}\"", fg=OK)
            self.app.log(self.lbl_e.cget("text"))
        self.app.run_job("forge export", job, done)

    def on_export_event(self, d: dict) -> None:
        self.exp_prog["value"] = 100.0 * d["i"] / max(1, d["n"])
        self.app.status_var.set(f"export {d['i']}/{d['n']} {d['tensor']} · RSS {d['rss_mb']:.0f} MB")

    def _pick_model(self) -> None:
        f = filedialog.askopenfilename(title="GGUF model", initialdir=self.v_export_dir.get() or None, filetypes=[("GGUF", "*.gguf"), ("All files (Ollama blobs)", "*")])
        if f:
            self.v_model.set(f)

    def ask(self) -> None:
        p = self.v_model.get().strip()
        if not p:
            messagebox.showinfo("SOKE", "Export a model (or choose a .gguf) first."); return
        prompt = self.v_prompt.get(); mx = int(self.v_max.get() or 48)
        self.chat_out.delete("1.0", "end"); self.chat_out.insert("end", "loading + thinking… (the first answer also reads the weights)\n")

        def job():
            from .llm_engine import LLM
            m = LLM(p, memguard=self.app.mg)
            pieces = []
            txt, info = m.generate(prompt, max_new=mx, temperature=0.7, on_token=lambda s: self.app.q.put(("forge", ("token", s))))
            m.close()
            return txt, info

        def done(res):
            txt, info = res
            self.chat_out.delete("1.0", "end")
            self.chat_out.insert("end", txt + f"\n\n[{info['tokens']} tokens, {info['seconds']} s, {info.get('tok_per_s')} tok/s, weights {info['resident_mode']}, RSS {info['rss_mb']} MB]")

        def fail(err):
            self.chat_out.delete("1.0", "end"); self.chat_out.insert("end", f"could not run it: {err}")
        self.app.run_job("forge chat", job, done, on_error=fail)

    def on_token(self, s: str) -> None:
        self.chat_out.insert("end", s); self.chat_out.see("end")


class CloneWindow:
    """The Digital Psychoanalyst battery in a window: contract + consent, then one item at a time with
    SKIP / PASS / LATER / STOP, a one-line 'weight, not law' mimic after each committed answer, then export."""

    def __init__(self, tab: "ForgeTab"):
        self.tab = tab
        self.app = tab.app
        from .clone_battery import CloneBattery, SESSIONS
        self.SESSIONS = SESSIONS
        self.cb = None
        self.win = tk.Toplevel(self.app); self.win.title("SOKE · Digital Psychoanalyst — clone battery"); self.win.configure(bg=BG); self.win.geometry("760x560")
        self._consent_screen()

    def _consent_screen(self) -> None:
        from .clone_battery import CloneBattery, SESSION_CONTRACT
        for w in self.win.winfo_children():
            w.destroy()
        tk.Label(self.win, text="The session contract", bg=BG, fg=ACC, font=_font(13, True)).pack(anchor="w", padx=12, pady=(12, 2))
        tk.Label(self.win, text=SESSION_CONTRACT, bg=BG, fg=FG, wraplength=720, justify="left").pack(anchor="w", padx=12)
        f = tk.Frame(self.win, bg=BG); f.pack(anchor="w", padx=12, pady=8)
        tk.Label(f, text="Session length", bg=BG, fg=DIM).grid(row=0, column=0, sticky="w")
        self.v_sess = tk.StringVar(value="STANDARD")
        ttk.Combobox(f, textvariable=self.v_sess, values=list(self.SESSIONS.keys()), width=10, state="readonly").grid(row=0, column=1, sticky="w", padx=4)
        tk.Label(f, text={k: v for k, v in self.SESSIONS.items()}["STANDARD"], bg=BG, fg=DIM).grid(row=0, column=2, sticky="w")
        self.v_user = tk.StringVar(value="you")
        tk.Label(f, text="Profile id", bg=BG, fg=DIM).grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Entry(f, textvariable=self.v_user, width=16).grid(row=1, column=1, sticky="w", padx=4, pady=(6, 0))
        con = tk.LabelFrame(self.win, text=" consent (you decide; nothing is written to a model unless you say so) ", bg=BG, fg=ACC); con.pack(fill="x", padx=12, pady=6)
        self.v_store = tk.BooleanVar(value=False); self.v_adapt = tk.BooleanVar(value=False); self.v_forks = tk.BooleanVar(value=False)
        ttk.Checkbutton(con, text="1. store answers in helix + GGUF metadata", variable=self.v_store).pack(anchor="w", padx=6)
        ttk.Checkbutton(con, text="2. allow emotion-conditioning adapters", variable=self.v_adapt).pack(anchor="w", padx=6)
        ttk.Checkbutton(con, text="3. allow later forks by other users", variable=self.v_forks).pack(anchor="w", padx=6)
        r = tk.Frame(con, bg=BG); r.pack(anchor="w", padx=6, pady=2)
        tk.Label(r, text="4. hard-red topics never to ask (comma list):", bg=BG, fg=DIM).pack(side="left")
        self.v_red = tk.StringVar(); ttk.Entry(r, textvariable=self.v_red, width=40).pack(side="left", padx=4)
        b = tk.Frame(self.win, bg=BG); b.pack(anchor="w", padx=12, pady=8)
        ttk.Button(b, text="Begin", style="Accent.TButton", command=self._begin).pack(side="left")
        ttk.Button(b, text="Cancel", command=self.win.destroy).pack(side="left", padx=6)

    def _begin(self) -> None:
        from .clone_battery import CloneBattery
        self.cb = CloneBattery(user_id=self.v_user.get().strip() or "you", session=self.v_sess.get())
        self.cb.set_consent(store=self.v_store.get(), adapters=self.v_adapt.get(), forks=self.v_forks.get(),
                            hard_red=[t for t in self.v_red.get().split(",") if t.strip()])
        self._ask_screen()

    def _ask_screen(self) -> None:
        for w in self.win.winfo_children():
            w.destroy()
        self.lbl_q = tk.Label(self.win, text="", bg=BG, fg=FG, wraplength=720, justify="left", font=_font(12)); self.lbl_q.pack(anchor="w", padx=12, pady=(14, 4))
        row = tk.Frame(self.win, bg=BG); row.pack(anchor="w", padx=12)
        tk.Label(row, text="answer", bg=BG, fg=DIM).pack(side="left")
        self.v_ans = tk.StringVar(); e = ttk.Entry(row, textvariable=self.v_ans, width=42); e.pack(side="left", padx=4); e.bind("<Return>", lambda _e: self._commit())
        tk.Label(row, text="intensity", bg=BG, fg=DIM).pack(side="left", padx=(8, 2))
        self.v_int = tk.IntVar(value=5); ttk.Scale(row, from_=0, to=10, variable=self.v_int, length=120).pack(side="left")
        self.extra = tk.Frame(self.win, bg=BG); self.extra.pack(anchor="w", padx=12, pady=4)
        self.v_pick = tk.StringVar(value=""); self.v_neg = tk.StringVar(value="")
        b = tk.Frame(self.win, bg=BG); b.pack(anchor="w", padx=12, pady=6)
        ttk.Button(b, text="Commit", style="Accent.TButton", command=self._commit).pack(side="left")
        for tok in ("SKIP", "PASS", "LATER", "STOP"):
            ttk.Button(b, text=tok, command=lambda t=tok: self._token(t)).pack(side="left", padx=3)
        self.lbl_mimic = tk.Label(self.win, text="", bg=BG, fg=OK, wraplength=720, justify="left"); self.lbl_mimic.pack(anchor="w", padx=12, pady=(4, 0))
        self.log = tk.Text(self.win, height=10, bg=PAPER_HI, fg=FG, font=MONO, wrap="word"); self.log.pack(fill="both", expand=True, padx=12, pady=8)
        self._next()

    def _next(self) -> None:
        it = self.cb.next_item()
        if it is None:
            return self._finish()
        self._it = it
        self.lbl_q.config(text=self.cb.prompt(it))
        for w in self.extra.winfo_children():
            w.destroy()
        if it.battery == "H":
            tk.Label(self.extra, text="pick", bg=BG, fg=DIM).pack(side="left")
            self.v_pick.set(""); ttk.Combobox(self.extra, textvariable=self.v_pick, values=["LOGIC", "FEELING", "BRAID", "VETO"], width=10, state="readonly").pack(side="left", padx=4)
        if it.battery == "E":
            tk.Label(self.extra, text="negative pole feeling", bg=BG, fg=DIM).pack(side="left")
            self.v_neg.set(""); ttk.Entry(self.extra, textvariable=self.v_neg, width=20).pack(side="left", padx=4)
        self.v_ans.set("")

    def _commit(self) -> None:
        it = self._it
        res = self.cb.answer(response=self.v_ans.get(), intensity=float(self.v_int.get()), pick=self.v_pick.get(), invert_response=self.v_neg.get())
        if res.get("mimic"):
            self.lbl_mimic.config(text=res["mimic"])
            self.log.insert("end", f"[{it.battery}] {it.cue} -> {self.v_ans.get()!r} @{self.v_int.get()}\n"); self.log.see("end")
        self._next()

    def _token(self, tok: str) -> None:
        res = self.cb.answer(token=tok)
        if res.get("stopped"):
            return self._finish()
        if res.get("offer_stop"):
            self.lbl_mimic.config(text="three skips in a row — press STOP to end, or keep going.", fg=WARN)
        self._next()

    def _finish(self) -> None:
        end = self.cb.end_script()
        for w in self.win.winfo_children():
            w.destroy()
        tk.Label(self.win, text="Session complete", bg=BG, fg=ACC, font=_font(13, True)).pack(anchor="w", padx=12, pady=(14, 4))
        txt = (f"Written: {end['teeth_written']} teeth\nLexicon pairs: {end['lexicon_pairs']}\nInversion pairs: {end['inversion_pairs']}\n"
               f"Pillar tilt: {end['pillar_tilt']}\nBaseline C: " + ", ".join(f"{k} {v:.2f}" for k, v in list(end['baseline_C'].items())[:6]) + " …")
        tk.Label(self.win, text=txt, bg=BG, fg=FG, justify="left", font=MONO).pack(anchor="w", padx=12)
        prof = self.cb.build_profile()
        self.tab._clone_done(prof.to_dict(), self.cb.helix_teeth())
        b = tk.Frame(self.win, bg=BG); b.pack(anchor="w", padx=12, pady=10)

        def save():
            f = filedialog.asksaveasfilename(title="Save clone profile", defaultextension=".json", initialdir=str(self.tab.forge_dir), initialfile=f"clone_{self.cb.user_id}.json")
            if f:
                self.cb.export(f, name=f"clone:{self.cb.user_id}"); self.app.log(f"clone profile saved: {f}")
        ttk.Button(b, text="Save clone_profile.json", style="Accent.TButton", command=save).pack(side="left")
        ttk.Button(b, text="Done (use on the Behavior page)", command=self.win.destroy).pack(side="left", padx=6)
        self.app.log(f"[clone] captured {end['teeth_written']} answers; tilt {end['pillar_tilt']}; consent.store={self.cb.consent['store']}")


class TandemWindow:
    """Optional: sketch a tandem knowledge-tree — a math driver over a tree of per-branch gguf models. This
    defines the structure and routing and can run one branch; the driver-orchestrated multi-model runtime is
    not built yet (declared, not faked)."""

    def __init__(self, tab):
        self.tab = tab; self.app = tab.app
        from .tandem import TandemSpec
        self.spec = TandemSpec.scaffold("tandem")
        self.win = tk.Toplevel(self.app); self.win.title("SOKE · Tandem knowledge-tree (optional)"); self.win.configure(bg=BG); self.win.geometry("720x520")
        tk.Label(self.win, text="Tandem / knowledge-tree GGUFs (optional, scaffold)", bg=BG, fg=SLATE, font=_font(12, True)).pack(anchor="w", padx=12, pady=(10, 2))
        tk.Label(self.win, text="One small math 'driver' model routes a prompt down a tree; each branch is its own small gguf you forge separately. "
                                "Smaller files overall, and each branch is independently fine-tunable. SOKE routes a prompt to a branch and can run "
                                "that one branch; the driver orchestrating several models at once is not built yet.", bg=BG, fg=DIM, wraplength=690, justify="left").pack(anchor="w", padx=12)
        self.txt = tk.Text(self.win, height=20, wrap="word", font=MONO); _T.sunken_text(self.txt); self.txt.pack(fill="both", expand=True, padx=12, pady=8)
        self.txt.insert("end", self.spec.describe())
        row = tk.Frame(self.win, bg=BG); row.pack(fill="x", padx=12, pady=(0, 10))
        r = tk.Frame(self.win, bg=BG); r.pack(fill="x", padx=12)
        tk.Label(r, text="route a test prompt:", bg=BG, fg=DIM).pack(side="left")
        self.v_prompt = tk.StringVar(value="prove that the derivative of x^2 is 2x")
        ttk.Entry(r, textvariable=self.v_prompt, width=48).pack(side="left", padx=4)
        ttk.Button(r, text="Route", command=self._route).pack(side="left")
        ttk.Button(row, text="Save scaffold JSON…", style="Accent.TButton", command=self._save).pack(side="left")
        ttk.Button(row, text="Close", command=self.win.destroy).pack(side="left", padx=6)

    def _route(self):
        path = self.spec.route(self.v_prompt.get())
        self.txt.insert("end", f"\n> route {self.v_prompt.get()!r} -> {' / '.join(path)}\n")
        self.txt.see("end")

    def _save(self):
        f = filedialog.asksaveasfilename(title="Save tandem scaffold", defaultextension=".json", initialdir=str(self.tab.forge_dir), initialfile="tandem_spec.json")
        if f:
            Path(f).write_text(self.spec.to_json(), encoding="utf-8"); self.app.log(f"tandem scaffold saved: {f}")
