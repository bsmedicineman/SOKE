import numpy as np, sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.dirname(__import__('os').path.abspath(__file__))))
import gguf
from gguf import GGUFWriter, GGMLQuantizationType as T, quants
from soke.gguf_rewrites import GGUFReader, convert_gguf_to_sff
from soke.rng import Rng
from soke.sff import SFFReader
from soke.memguard import MemGuard
rng=Rng(7)
w=GGUFWriter("/tmp/offA.gguf","llama")
w.add_name("offA"); w.add_block_count(2); w.add_context_length(2048); w.add_embedding_length(256)
w.add_array("tokenizer.ggml.tokens",["<s>","a","b","c"]); w.add_uint32("general.file_type",15)
srcs={}
for name,shape,qt in [("token_embd.weight",(300,256),T.Q4_0),("blk.0.ffn_down.weight",(256,512),T.Q5_0),("blk.0.attn_q.weight",(256,256),T.Q5_1),
                      ("blk.1.ffn_up.weight",(512,256),T.Q8_0),("output_norm.weight",(256,),T.F16),("blk.1.attn_norm.weight",(256,),T.F32),
                      ("blk.0.ffn_gate.weight",(256,512),T.Q4_1),("blk.1.attn_k.weight",(256,256),T.BF16)]:
    x=(rng.normal(0,0.05,shape)*np.exp2(rng.uniform(-3,3,shape))).astype(np.float32)
    srcs[name]=x
    if qt==T.F16: w.add_tensor(name, x.astype(np.float16))
    elif qt==T.F32: w.add_tensor(name, x)
    else:
        q=quants.quantize(x, qt); w.add_tensor(name, q, raw_dtype=qt)
w.write_header_to_file(); w.write_kv_data_to_file(); w.write_tensors_to_file(); w.close()
gr=GGUFReader("/tmp/offA.gguf")
print("my reader:", gr.summary()["types"], gr.kv["tokenizer.ggml.tokens"], "v", gr.version, "align", gr.alignment)
off=gguf.GGUFReader("/tmp/offA.gguf")
ok=True
for name,x in srcs.items():
    t=gr.tensors[name]; mine=gr.read_tensor(name)
    ot=[tt for tt in off.tensors if tt.name==name][0]
    data=np.asarray(ot.data)
    if t.ggml_type in (0,1,30):
        ref = (data.view(np.uint16).astype(np.uint32)<<16).view(np.float32) if t.ggml_type==30 else data.astype(np.float32)
        ref=ref.reshape(t.shape)
    else:
        ref=quants.dequantize(data, T(t.ggml_type)).astype(np.float32).reshape(t.shape)
    d=float(np.max(np.abs(mine-ref))); rel=float(np.sqrt(np.mean((mine-x)**2))/np.sqrt(np.mean(x**2)))
    print(f"  {name:<26} {t.type_name:<5} {str(mine.shape):<12} max|mine-official| {d:.2e}  rel-rmse vs f32 source {rel:.4f}")
    ok = ok and d==0.0 and mine.shape==x.shape
print("TEST A (official writer/quantizer -> SOKE reader/dequant):", "PASS" if ok else "FAIL")
st=convert_gguf_to_sff("/tmp/offA.gguf","/tmp/offA.sff",budget="8bit",memguard=MemGuard())
rd=SFFReader("/tmp/offA.sff"); y=rd.read_tensor("token_embd.weight"); x=gr.read_tensor("token_embd.weight")
print("SFF 8-bit band round trip vs dequantized source: rel-rmse", round(float(np.sqrt(np.mean((y-x)**2))/np.sqrt(np.mean(x**2))),5))
print("storage verdicts:", [(r['pipeline'].split(':')[1][:22], r['status'], round(r['cut_pct'],1)) for r in rd.opt_rows()])
