import numpy as np, sys, time, os
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.dirname(__import__('os').path.abspath(__file__))))
from gguf import GGMLQuantizationType as T, quants
from soke.gguf_rewrites import write_gguf, GGML_TYPES
from soke.rng import Rng
rng=Rng(11)
D, FF, V, L = 4096, 11008, 32000, 4
def gen_rows(rows, cols, qt, seed):
    r=Rng(seed)
    def it():
        for i in range(0, rows, 512):
            n=min(512, rows-i)
            x=(r.normal(0,0.02,(n,cols))).astype(np.float32)
            x[:, :cols//64] *= 8.0     # outlier channels, LLM-style
            yield quants.quantize(x, qt).tobytes() if qt not in (T.F16,T.F32) else x.astype(np.float16 if qt==T.F16 else np.float32).tobytes()
    _,bs,ts=GGML_TYPES[int(qt)]
    return it(), rows*cols//bs*ts
tensors=[]
seed=0
def add(name, rows, cols, qt):
    global seed
    seed+=1
    it,nb=gen_rows(rows, cols, qt, seed)
    tensors.append((name,(cols,rows),int(qt),it,nb))
add("token_embd.weight", V, D, T.Q8_0)
for l in range(L):
    for n in ("attn_q","attn_k","attn_v","attn_output"):
        add(f"blk.{l}.{n}.weight", D, D, T.Q4_0)
    add(f"blk.{l}.ffn_gate.weight", FF, D, T.Q4_0)
    add(f"blk.{l}.ffn_up.weight", FF, D, T.Q4_0)
    add(f"blk.{l}.ffn_down.weight", D, FF, T.Q4_0)
    add(f"blk.{l}.attn_norm.weight", 1, D, T.F32)
    add(f"blk.{l}.ffn_norm.weight", 1, D, T.F32)
add("output_norm.weight", 1, D, T.F32)
add("output.weight", V, D, T.Q8_0)
t0=time.time()
n=write_gguf("/tmp/big.gguf", {"general.architecture":"llama","general.name":"big-synthetic","llama.block_count":L,"llama.embedding_length":D,
                              "llama.feed_forward_length":FF,"llama.attention.head_count":32,"tokenizer.ggml.tokens":[f"t{i}" for i in range(V)]}, tensors)
print("wrote", n/2**20, "MB in", round(time.time()-t0,1), "s")
