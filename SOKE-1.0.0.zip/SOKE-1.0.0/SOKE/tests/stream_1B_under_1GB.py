import numpy as np, sys, time, os, threading
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.dirname(__import__('os').path.abspath(__file__))))
import gguf
from soke.gguf_rewrites import GGUFReader, convert_gguf_to_sff, DEQUANT
from soke.sff import SFFReader
from soke.memguard import MemGuard, RSSMonitor, rss_bytes
# 1. official reader parses my streamed file
off=gguf.GGUFReader("/tmp/big.gguf")
print("official reader: tensors", len(off.tensors), "first", off.tensors[0].name, off.tensors[0].tensor_type.name, off.tensors[0].shape)
gr=GGUFReader("/tmp/big.gguf"); s=gr.summary(); print("soke reader:", s["n_tensors"], "tensors", s["params"]/1e6, "M params", s["types"])
# 2. streaming conversion under the memory guard with an RSS monitor
mg=MemGuard(soft_mb=768, hard_mb=900, chunk_mb=16)
mon=RSSMonitor(mg, 0.05); mon.start()
t0=time.time(); last=[0]
def prog(d):
    if d["i"]%8==0 or d["i"]==d["n"]: print(f"  {d['i']:3d}/{d['n']} {d['tensor'][:28]:<28} {d['type']:<5} pages {d['pages']:6d} {d['status']:<8} rss {d['rss_mb']:.0f} MB  {d['elapsed']:.0f}s", flush=True)
st=convert_gguf_to_sff("/tmp/big.gguf","/tmp/big.sff",budget="8bit",memguard=mg,progress=prog)
peak=mon.stop()
print("conversion:", {k:v for k,v in st.items() if k!='budget'}); print("PEAK RSS during conversion: %.0f MB (hard cap 900 MB)  -> %s" % (peak/2**20, "UNDER 1 GB" if peak < 1024*2**20 else "OVER"))
# 3. spot-check pages against source dequant; SFF reader memory
rd=SFFReader("/tmp/big.sff"); print("sff summary:", {k:v for k,v in rd.summary().items() if k in ('size','tensors','pages_total','pages_by_encoding','params','opt_rows')})
name="blk.2.ffn_down.weight"
r0=rss_bytes(); tw=time.perf_counter()
rows=rd.tensor_rows(name, 1000, 1004)                 # touches ~ (4*11008)/4096 ≈ 11 pages
tw=(time.perf_counter()-tw)*1e3; dw=(rss_bytes()-r0)/2**20     # measured BEFORE the source tensor is loaded for comparison
src=np.concatenate([c for _,c in gr.iter_chunks(name)]).reshape(gr.tensors[name].shape)[1000:1004]
print("row window read: %.1f ms, RSS delta %.1f MB; max abs err vs source" % (tw, dw), float(np.max(np.abs(rows-src))), "rel-rmse", float(np.sqrt(np.mean((rows-src)**2))/np.sqrt(np.mean(src**2))))
ver=rd.verify(deep=False); print("verify sections:", ver["ok"], ver["sections"])
vs=[r["status"] for r in rd.opt_rows()]; print("storage verdicts:", {k: vs.count(k) for k in set(vs)})
print("elapsed", round(time.time()-t0,1), "s; sff size", os.path.getsize("/tmp/big.sff")/2**20, "MB vs gguf", os.path.getsize("/tmp/big.gguf")/2**20, "MB")
