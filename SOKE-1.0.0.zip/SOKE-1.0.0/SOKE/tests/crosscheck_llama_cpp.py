"""
Cross-check SOKE's numpy inference engine against llama.cpp (llama-cpp-python) on synthetic models.

Builds tiny random-weight GGUFs with the official `gguf` writer for three architectures — llama (GQA,
interleaved RoPE), qwen2 (NEOX RoPE, q/k/v biases, tied output) and qwen2moe (routed experts + shared
expert) — using the real Qwen2 / Llama-3 vocabularies from llama.cpp's models/ggml-vocab-*.gguf, then
compares per-position logits of the same token sequence. Needs: pip install gguf llama-cpp-python.

    python tests/crosscheck_llama_cpp.py <vocab_dir> [out_dir]
"""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("SOKE_DEV", "1")
import numpy as np
import gguf
from llama_cpp import Llama
from soke.gguf_rewrites import GGUFReader
from soke.llm_engine import LLM
from soke.rng import Rng

vocab_dir = sys.argv[1]
out_dir = sys.argv[2] if len(sys.argv) > 2 else "/tmp/soke_xcheck"
os.makedirs(out_dir, exist_ok=True)
rng = Rng(11)


def load_vocab(name):
    gr = GGUFReader(os.path.join(vocab_dir, name))
    kv = {k: v for k, v in gr.kv.items() if k.startswith("tokenizer.")}
    gr.close()
    return kv


def add_tokenizer(w: gguf.GGUFWriter, tkv: dict):
    w.add_tokenizer_model(tkv["tokenizer.ggml.model"])
    if "tokenizer.ggml.pre" in tkv:
        w.add_tokenizer_pre(tkv["tokenizer.ggml.pre"])
    w.add_token_list(tkv["tokenizer.ggml.tokens"])
    w.add_token_types(tkv["tokenizer.ggml.token_type"])
    if "tokenizer.ggml.merges" in tkv:
        w.add_token_merges(tkv["tokenizer.ggml.merges"])
    if "tokenizer.ggml.scores" in tkv:
        w.add_token_scores(tkv["tokenizer.ggml.scores"])
    for key, fn in (("tokenizer.ggml.bos_token_id", w.add_bos_token_id), ("tokenizer.ggml.eos_token_id", w.add_eos_token_id),
                    ("tokenizer.ggml.unknown_token_id", w.add_unk_token_id), ("tokenizer.ggml.padding_token_id", w.add_pad_token_id)):
        if key in tkv:
            fn(int(tkv[key]))
    if "tokenizer.ggml.add_bos_token" in tkv:
        w.add_add_bos_token(bool(tkv["tokenizer.ggml.add_bos_token"]))


def mat(shape, scale=0.08):
    return rng.normal(0, scale, shape).astype(np.float32)


def build(arch, path, tkv, E=64, L=2, H=4, HKV=2, F=96, n_exp=0, n_used=0, F_exp=0, F_sh=0, qtype="F32"):
    V = len(tkv["tokenizer.ggml.tokens"])
    D = E // H
    w = gguf.GGUFWriter(path, arch)
    w.add_name("soke-xcheck-" + arch)
    w.add_block_count(L); w.add_context_length(256); w.add_embedding_length(E); w.add_feed_forward_length(F)
    w.add_head_count(H); w.add_head_count_kv(HKV); w.add_rope_freq_base(10000.0 if arch == "llama" else 1000000.0)
    w.add_layer_norm_rms_eps(1e-6); w.add_rope_dimension_count(D); w.add_vocab_size(V); w.add_file_type(0)
    if n_exp:
        w.add_expert_count(n_exp); w.add_expert_used_count(n_used); w.add_expert_feed_forward_length(F_exp)
        if F_sh:
            w.add_expert_shared_feed_forward_length(F_sh)
    add_tokenizer(w, tkv)
    tensors = {}
    tensors["token_embd.weight"] = mat((V, E), 0.05)
    tensors["output_norm.weight"] = 1.0 + mat((E,), 0.1)
    if arch != "qwen2":                                    # qwen2 case exercises tied output; others write output
        tensors["output.weight"] = mat((V, E), 0.05)
    for l in range(L):
        p = f"blk.{l}."
        tensors[p + "attn_norm.weight"] = 1.0 + mat((E,), 0.1)
        tensors[p + "ffn_norm.weight"] = 1.0 + mat((E,), 0.1)
        tensors[p + "attn_q.weight"] = mat((H * D, E)); tensors[p + "attn_k.weight"] = mat((HKV * D, E)); tensors[p + "attn_v.weight"] = mat((HKV * D, E))
        tensors[p + "attn_output.weight"] = mat((E, H * D))
        if arch in ("qwen2", "qwen2moe"):
            tensors[p + "attn_q.bias"] = mat((H * D,), 0.05); tensors[p + "attn_k.bias"] = mat((HKV * D,), 0.05); tensors[p + "attn_v.bias"] = mat((HKV * D,), 0.05)
        if n_exp:
            tensors[p + "ffn_gate_inp.weight"] = mat((n_exp, E), 0.3)
            tensors[p + "ffn_gate_exps.weight"] = mat((n_exp, F_exp, E)); tensors[p + "ffn_up_exps.weight"] = mat((n_exp, F_exp, E)); tensors[p + "ffn_down_exps.weight"] = mat((n_exp, E, F_exp))
            if F_sh:
                tensors[p + "ffn_gate_inp_shexp.weight"] = mat((E,), 0.3)
                tensors[p + "ffn_gate_shexp.weight"] = mat((F_sh, E)); tensors[p + "ffn_up_shexp.weight"] = mat((F_sh, E)); tensors[p + "ffn_down_shexp.weight"] = mat((E, F_sh))
        else:
            tensors[p + "ffn_gate.weight"] = mat((F, E)); tensors[p + "ffn_up.weight"] = mat((F, E)); tensors[p + "ffn_down.weight"] = mat((E, F))
    for name, arr in tensors.items():
        if qtype == "Q8_0" and arr.ndim >= 2 and arr.shape[-1] % 32 == 0 and "norm" not in name:
            q = gguf.quants.quantize(arr, gguf.GGMLQuantizationType.Q8_0)
            w.add_tensor(name, q, raw_shape=q.shape, raw_dtype=gguf.GGMLQuantizationType.Q8_0)
        else:
            w.add_tensor(name, arr)
    w.write_header_to_file(); w.write_kv_data_to_file(); w.write_tensors_to_file(); w.close()
    return path


def compare(path, text, label, quantized=False):
    llm = Llama(model_path=path, n_ctx=256, logits_all=True, verbose=False, n_threads=2, n_gpu_layers=0)
    ids = llm.tokenize(text.encode("utf-8"), add_bos=False, special=True)
    llm.reset(); llm.eval(ids)
    ref = np.array(llm.scores[:len(ids)], dtype=np.float32)
    m = LLM(path, resident="f32")
    ours_ids = m.tok.encode(text, add_special=False, parse_special=True)
    same_tok = ours_ids == list(ids)
    lg = m.logits(m.hidden(np.asarray(ids)))
    d = np.max(np.abs(lg - ref)); scale = np.max(np.abs(ref))
    agree = float(np.mean(np.argmax(lg, axis=1) == np.argmax(ref, axis=1)))
    # streamed NLL vs llama.cpp log-softmax
    r = m.nll(list(ids))
    refl = ref - ref.max(axis=1, keepdims=True); refl = refl - np.log(np.exp(refl).sum(axis=1, keepdims=True))
    want = -float(np.mean([refl[i, ids[i + 1]] for i in range(len(ids) - 1)]))
    m.close(); del llm
    # llama.cpp runs quantized weights through Q8 x Q8 integer dot products (activations quantized too):
    # ~1e-2 logit noise is theirs, not a layout error — the NLL and argmax still have to agree.
    tol = 6e-2 if quantized else 2e-3
    ok = d < tol * max(1.0, scale) and same_tok and abs(r["nll"] - want) < 2e-3 and agree > 0.95
    print(f"{'PASS' if ok else 'FAIL'} {label}: tokens {len(ids)} same_tokenization={same_tok} max|dlogit|={d:.2e} (scale {scale:.2f}) argmax_agree={agree:.3f} nll ours {r['nll']:.5f} vs llama.cpp {want:.5f}")
    return ok


qkv = load_vocab("ggml-vocab-qwen2.gguf")
lkv = load_vocab("ggml-vocab-llama-bpe.gguf")
text = "The theorem states that every bounded sequence has a convergent subsequence. Prove it: 2+2=4!"
results = []
results.append(compare(build("qwen2", os.path.join(out_dir, "x-qwen2.gguf"), qkv), text, "qwen2 dense (neox rope, qkv bias, tied output, F32)"))
results.append(compare(build("qwen2", os.path.join(out_dir, "x-qwen2-q8.gguf"), qkv, qtype="Q8_0"), text, "qwen2 dense Q8_0 weights", quantized=True))
results.append(compare(build("llama", os.path.join(out_dir, "x-llama.gguf"), lkv, H=4, HKV=1), text, "llama dense (GQA 4:1, interleaved rope, output.weight)"))
results.append(compare(build("qwen2moe", os.path.join(out_dir, "x-qwen2moe.gguf"), qkv, n_exp=4, n_used=2, F_exp=80, F_sh=96), text, "qwen2moe (4 experts top-2 + shared expert)"))
# llama-arch MoE: llama.cpp sizes the experts by feed_forward_length (expert_feed_forward_length is ignored for this arch)
results.append(compare(build("llama", os.path.join(out_dir, "x-llama-moe.gguf"), lkv, H=4, HKV=2, F=64, n_exp=3, n_used=2, F_exp=64), text, "llama MoE (Mixtral style, renormalised top-2)"))
# ---- the forge: donors -> template -> exported GGUF -> llama.cpp runs it and agrees with the live template model
from soke.forge import ForgeSpec, SpecStore, assemble, describe_gguf
donors = []
for k in range(3):
    rng = Rng(500 + k)
    pth = build("qwen2", os.path.join(out_dir, f"donor{k}.gguf"), qkv, qtype="Q8_0" if k % 2 == 0 else "F32")
    donors.append(describe_gguf(pth, label=f"donor{k}", donor_id=f"D{k}"))
sp = ForgeSpec.preset("math-always-on", donors, ["math", "language", "science", "technology"], shared_topic="math", n_used=2,
                      topic_donor={"math": "D0", "language": "D1", "science": "D2", "technology": "D1"})
sp.layers[1]["experts"][0]["op"] = {"kind": "blend", "weights": {"D1": 0.6, "D2": 0.4}}        # a novel (blended) expert
sp.layers[0]["attn"] = {"kind": "task", "base": "D0", "deltas": {"D1": 0.5}}                   # a task-arithmetic attention block
forged = os.path.join(out_dir, "forged-qwen2moe.gguf")
st = assemble(sp, forged, sidecar=False)
live = LLM(store=SpecStore(sp))
llm = Llama(model_path=forged, n_ctx=256, logits_all=True, verbose=False, n_threads=2, n_gpu_layers=0)
ids = llm.tokenize(text.encode("utf-8"), add_bos=False, special=True)
llm.reset(); llm.eval(ids)
ref = np.array(llm.scores[:len(ids)], dtype=np.float32)
lg_live = live.logits(live.hidden(np.asarray(ids)))
d = float(np.max(np.abs(lg_live - ref))); scale = float(np.max(np.abs(ref)))
agree = float(np.mean(np.argmax(lg_live, axis=1) == np.argmax(ref, axis=1)))
ok = d < 6e-2 * max(1.0, scale) and agree > 0.95
results.append(ok)
print(f"{'PASS' if ok else 'FAIL'} forge math-always-on (2 exact experts + 1 blended, task-arith attention): llama.cpp runs the exported file; "
      f"max|dlogit| vs live template {d:.2e} (scale {scale:.2f}) argmax_agree={agree:.3f}; exact {st['exact']} novel {st['novel']} tensors")
live.close(); del llm
sp2 = ForgeSpec.preset("all-routed", donors, ["math", "language", "science"], n_used=2)
forged2 = os.path.join(out_dir, "forged-all-routed.gguf")
st2 = assemble(sp2, forged2, sidecar=False)
live2 = LLM(store=SpecStore(sp2))
llm = Llama(model_path=forged2, n_ctx=256, logits_all=True, verbose=False, n_threads=2, n_gpu_layers=0)
llm.reset(); llm.eval(ids); ref2 = np.array(llm.scores[:len(ids)], dtype=np.float32)
lg2 = live2.logits(live2.hidden(np.asarray(ids)))
d2 = float(np.max(np.abs(lg2 - ref2))); ok2 = d2 < 6e-2 * max(1.0, float(np.max(np.abs(ref2)))) and float(np.mean(np.argmax(lg2, 1) == np.argmax(ref2, 1))) > 0.95
results.append(ok2)
print(f"{'PASS' if ok2 else 'FAIL'} forge all-routed on qwen2 (silent 32-wide shared expert): llama.cpp agrees, max|dlogit| {d2:.2e}")
live2.close(); del llm
# ---- behavioral conditioning (1.3.0): the same forge, now with a behavior + clone profile written as GGUF
#      metadata + streamed helix. llama.cpp must still load it and agree with the live template (metadata is inert).
from soke.behavior import CLIMATES, gguf_metadata
from soke.clone_battery import CloneBattery
cb = CloneBattery(user_id="bs"); cb.set_consent(store=True)
it = cb.next_item()
for _ in range(8):
    if it is None:
        break
    cb.answer(response="steady", intensity=6); it = cb.next_item()
prof = cb.build_profile(); prof.name = "bs-clone"
forged3 = os.path.join(out_dir, "forged-behavior.gguf")
st3 = assemble(sp, forged3, behavior=prof, clone_consent={"store": True}, clone_teeth=cb.helix_teeth(), sidecar=True)
live3 = LLM(store=SpecStore(sp))
llm = Llama(model_path=forged3, n_ctx=256, logits_all=True, verbose=False, n_threads=2, n_gpu_layers=0)
llm.reset(); llm.eval(ids); ref3 = np.array(llm.scores[:len(ids)], dtype=np.float32)
lg3 = live3.logits(live3.hidden(np.asarray(ids)))
d3 = float(np.max(np.abs(lg3 - ref3)))
agree3 = float(np.mean(np.argmax(lg3, 1) == np.argmax(ref3, 1)))
md = llm.metadata
sky = sorted(k for k in md if k.startswith("soke."))
ok3 = (d3 < 6e-2 * max(1.0, float(np.max(np.abs(ref3)))) and agree3 > 0.95
       and md.get("soke.emotion.policy") == "modulate_not_govern"
       and md.get("soke.logic.policy") == "veto_and_shape_not_erase"
       and "soke.clone.user_id" in md and st3.get("helix_teeth", 0) >= 12)
results.append(ok3)
print(f"{'PASS' if ok3 else 'FAIL'} forge + behavior/clone conditioning: llama.cpp loads it, agrees (max|dlogit| {d3:.2e}, argmax {agree3:.3f}); "
      f"{len(sky)} soke.* keys exposed, policies modulate_not_govern / veto_and_shape_not_erase, {st3.get('helix_teeth')} helix teeth in the .sff")
live3.close(); del llm
print("ALL PASS" if all(results) else "FAILURES")
sys.exit(0 if all(results) else 1)
