@echo off
setlocal EnableExtensions
title SOKE command line
cd /d "%~dp0"
set "PYCMD="
for %%C in ("py -3" "python" "python3") do (
    if not defined PYCMD (
        %%~C -c "import sys;sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1 && set "PYCMD=%%~C"
    )
)
if not defined PYCMD (
    echo Python 3.10+ was not found. Run INSTALL.bat first.
    pause
    exit /b 1
)
echo SOKE command line.  Type:  soke -h
echo   soke selftest                       soke train --corpus C:\my\folder      soke convert model.gguf
echo   soke inspect model.sff --verify     soke generate model.sff --prompt "..."  soke status
doskey soke=%PYCMD% "%~dp0soke_main.py" $*
cmd /k
