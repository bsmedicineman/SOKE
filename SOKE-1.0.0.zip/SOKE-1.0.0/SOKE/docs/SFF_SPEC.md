# SFF — SOKE File Format, version 1.0 (spec revision 1.3)

Magic `SKNT`. Little-endian throughout. All offsets are absolute from the start of the file.
Status of every layout below: **VERIFIED** by `soke/sff.py` write→read round trips (15 checks),
append/rollback/compaction runs, and deep checksum verification; the 1.07 B-parameter streaming
conversion in `tests/stream_1B_under_1GB.py` exercises the same code at scale.

## 1. File layout

```
[header 64 B] [segment 0 sections ...] [directory 0] [segment 1 sections ...] [directory 1] ...
```

A **segment** is one commit. The header points at the newest directory; older directories become
garbage until `compact()` rewrites the file. Sections of *replaceable* types (META, HLX1, TNS1,
PMP1, REG1, IDX1) are re-emitted whole on every commit; *append-only* types (PTB1, PDT1, LIN1,
PAT1, EXP1, OPT1, LDG1) accumulate, one entry per segment, and readers concatenate them in
offset order.

## 2. Header (64 bytes)

| off | size | field |
|---|---|---|
| 0 | 4 | magic `SKNT` |
| 4 | 2 | major (1) |
| 6 | 2 | minor (0) |
| 8 | 1 | endianness (0 = little) |
| 9 | 1 | file_kind (0 SFF-model, 1 SFF-knowledge, 2 SFF-patch, 3 SFF-forge-sidecar) |
| 10 | 2 | header_flags |
| 12 | 8 | creation_unix_ns |
| 20 | 8 | soke_build_id (sha256[:8] of the build string) |
| 28 | 8 | dir_offset |
| 36 | 4 | section_count |
| 40 | 8 | payload_checksum = sha256[:8] of the concatenated directory-entry checksums |
| 48 | 8 | reserved |
| 56 | 8 | header_checksum = sha256[:8] of bytes 0..55 |

Deviation from the SOKE Layout draft (declared): xxHash64 is not in the Python standard library;
sha256 truncated to 8 bytes is used for every 64-bit checksum, and the payload checksum chains the
section checksums instead of re-hashing the whole payload on every append.

## 3. Directory

`SECT` · u32 count · entries of 32 bytes:
`section_id u16 | type u16 | flags u32 (flags >> 16 = segment) | offset u64 | length u64 | checksum u64 (sha256[:8] of the section bytes)`.

Section types: 1 META · 2 HLX1 · 3 PTB1 · 4 PDT1 · 5 PMP1 · 6 TNS1 · 7 REG1 · 8 LIN1 · 9 PAT1 · 10 EXP1 · 11 OPT1 · 12 LDG1 · 13 IDX1.

## 4. Sections

**META** — `META` · u32 count · TLVs `type u16 | flags u16 | len u32 | value(JSON)`. Types: 1 model_id,
2 schema ("SFF-1.0"), 3 author, 4 cost_model, 5 gauge_policy, 6 lineage_root, 7 arch, 8 tokenizer,
9 page_values, 10 created_by, 11 source, 12 notes, 13 pairing_rules, 14 tower, 15 state, 16 routes,
17 file_kind_name, 0x00FF = `key\0json` for any other key.

**HLX1** (helix registry) — `HLX1` · u32 count · `helix_id u32 | domain_id u16 | register_kind u8 (0 R, 1 Q, 2 T, 3 L, 4 H, 5 LIN) | kind u8 (0 tensor, 1 knowledge, 2 staging) | flags u32 | page_count u32 | frame_count u64 | name_len u16 | name utf-8`.

**PTB1** (page table) — `PTB1` · u32 count · entries of 44 bytes:
`page_id u32 | helix_id u32 | index u32 | offset u64 | length u32 | count u32 | base_page u32 | err f32 | crc32 u32 | encoding u8 | flags u8 | pad u16`.
flags: 1 key-frame, 2 zero, 4 raw, 8 tooth, 128 evicted (compaction dropped the bytes, entry kept for history).
For RAW pages `base_page` holds the source GGML type id.

**PDT1** (page data) — `PDT1` followed by raw page payloads; addressed only through PTB1.

**PMP1** (page map, the current state) — `PMP1` · u32 n_helices · per helix `helix_id u32 | n u32 | page_id u32 × n` (0xFFFFFFFF = missing).

**TNS1** (tensor registry) — `TNS1` · u32 count · `tensor_id u32 | helix_id u32 | dtype_orig u16 (GGML type id or 100 = native f32) | ndim u8 | flags u8 | dims u64 × ndim | n_elem u64 | page_start u32 | page_count u32 | enc_default u8 | bpv f32 | err_base f32 | err_chosen f32 | name (u16 len) | status (u16 len)`.

**REG1** (registers/gauges) — `REG1` · u32 count · `kind u8 | name (u16 len) | desc (u16 len)`.

**LIN1** (lineage) — `LIN1` · u32 n_nodes · u32 n_edges · nodes `node_id u32 | kind u8 (0 frame, 1 helix, 2 register, 3 external, 4 tensor, 5 checkpoint, 6 model) | flags u8 | ref_section u16 | ref_index u64 | label (u16 len)` · edges `src u32 | dst u32 | op u16 | flags u16 | timestamp_ns u64`.
ops: 0 quadrature, 1 harmonic, 2 gnomon, 3 leg_swap, 4 orth_solve, 5 agm, 6 lill, 10 train_step, 11 widen, 12 deepen, 13 add_expert, 14 heal_patch, 15 checkpoint, 16 rollback, 17 import, 18 consolidate.

**PAT1** (patch log, the history) — `PAT1` · u32 count · `patch_id u32 | helix u32 | index u32 | old_page u32 | new_page u32 | kind u16 | flags u16 | timestamp_ns u64 | note (u16 len)`.
kinds: 0 replace, 1 add, 2 scale, 3 gauge_change, 4 delta, 5 rollback, 6 prune, 7 requant.
Pages are never overwritten; the page map points at the current version; a rollback is a new
patch that re-points the map at an older page id.

**EXP1** (expansion / experiment records) — `EXP1` · u32 count · `exp_id u32 | exp_type u32 | timestamp_ns u64 | payload_len u32 | payload(JSON)`.

**OPT1** (Third-Law table) — `OPT1` · u32 count · `row_id u32 | pipeline (u16 len) | baseline_ops f64 | ortho_ops f64 | baseline_weighted f64 | ortho_weighted f64 | cut_pct×100 i32 | status u8 (0 VERIFIED, 1 DERIVED, 2 TIE, 3 BOUNDARY, 4 NULL, 5 EXACT, 6 BASELINE) | note (u16 len)`.
Every model file carries the calculus' certified rows (`calculus:*`) and one `storage:<tensor>` row per
imported/requantized tensor (baseline linear-band mse vs chosen-gauge mse).

**LDG1** (ledger) — `LDG1` · u32 n_bytes · JSONL records `{seq, t, iso, protocol, domain, event, payload, prev, hash, sig}`,
`hash = sha256(prev + canonical_json(body))`, `sig = HMAC-SHA256(local key, hash)`. Deviation (declared):
ed25519 is not in the standard library; signatures are HMAC with a key kept in `soke_data/ledger/ledger.key`.

**IDX1** (domain lattice index) — `IDX1` · u32 n_domains · per domain `domain_id u16 | n u32 | helix_id u32 × n` ·
u32 n_keys · sorted entries `key_hash u64 (FNV-1a 64 of a lower-cased word or ident) | page_id u32 | record_offset u32`.
Seek = binary search over `key_hash` (O(log N)), then one page read.

## 5. Page encodings (`soke/teeth.py`)

| code | name | layout | bits/value |
|---|---|---|---|
| 0 | F32 | raw float32 | 32 |
| 1 | F16 | float16 | 16 |
| 2 | LIN8 | per 32-value group: f16 scale + 32 × int8 (`Q8_0` layout family; a Q8_0 source round-trips exactly) | 8.5 |
| 3 | LIN4 | per group: f16 scale (= signed max / −8) + 32 × 4-bit, low nibble first (`Q4_0` family; exact for Q4_0 sources) | 4.5 |
| 4 | L8 | log2 gauge: per group f16 lo, f16 hi (log2 magnitude range), 4 sign bytes, 32 × u8 code (0 = exact zero) | 10 |
| 5 | L4 | log2 gauge, 4-bit codes | 6 |
| 6 | DELTA8 | LIN8 of (page − base page); `base_page` in the table entry; decoding follows the chain to a key-frame | 8.5 |
| 7 | ZERO | all-zero page, no payload | 0 |
| 8 | RAW | verbatim GGUF block bytes, one page = 4096 values (`count`), `base_page` = GGML type id; decoded on read by the GGML dequantizer when one exists (exact imports of Q4_1/Q5_*/Q8_1, K-quants, BF16, F64, ints); IQ*/TQ* pages are kept but not numeric in 1.x | source |
| 9 | TOOTH | knowledge tooth run (below) | — |

**Exact import** (default since 1.1.0): F32/F16 → native pages, Q8_0 → LIN8 and Q4_0 → LIN4 by byte transcoding (scales and codes untouched; LIN8 stores the 128 group scales first, then the 4096 codes; LIN4 packs consecutive values low-nibble-first whereas Q4_0 splits a block into low and high nibbles — the transcoder reorders nibbles only), everything else → RAW. No storage rows are written; the tensor status is EXACT.

**Third Law of storage** (`choose_encoding`, re-band mode): within a band (8bit: LIN8 vs L8; 4bit: LIN4 vs L4) the
page keeps the encoding with the smaller measured MSE, **but** the log gauge is kept only if it cuts the
baseline error by ≥ 33.3 %; below that the row is a TIE and the linear baseline stays. Every page
records its error; every tensor records baseline error, chosen error and verdict.
Measured: heavy-tailed / outlier-channel pages prefer L8 (cuts of 40–99 %); Gaussian pages tie (~5–10 %).

## 6. Knowledge teeth (`TOOTH` pages)

Byte tooth: `header = (base << 6) | len` with base A=0, C=1, T=2, G=3 and len 0..62; `len == 63` means an
extended tooth whose next 4 bytes are a u32 payload length. Payload, then one XOR checksum byte over
header + payload. Payload record:
`domain u16 | flags u8 (1 PAIRED_PENDING, 2 verified, 4 numeric) | gauge u8 | pair_ref u32 | cross_ref u32 | ident (u16 len) | text (u32 len) | sha256 invariant (32)`.

Base-pairing rules (META.pairing_rules, default = SOKE Layout): legal A–T, C–G, A–C, T–G; illegal A–G, C–T.
(The data-recording draft's HMS v1.0 used the opposite convention; the SOKE layout is adopted and the
table is configurable.)

## 7. Reading protocol

1. Read the 64-byte header; verify its checksum; seek the directory; verify the chain checksum.
2. Map the file; read META, HLX1, TNS1, PMP1, REG1, IDX1 (newest), concatenate PTB1 segments and index
   them by page id (dense array, O(1)).
3. To read tensor T rows [r0, r1): pages ⌊r0·cols / page_values⌋ .. ⌊(r1·cols − 1) / page_values⌋ of
   T's helix via the page map; decode each (following DELTA8 chains); slice. Nothing else is touched.
4. To seek knowledge: hash the query words, binary-search IDX1, read the hit pages, decode the tooth at
   `record_offset`; ride forward with a bounded window (the face gear).
5. To verify: every directory entry's sha256[:8]; deep = every page's CRC32.

Measured on a 0.70 GB SFF (1.07 B parameters, 261,641 pages, exact import): open 59 ms, +31 MB RSS; 4-row window read (11 pages) 0.4 ms, +0.1 MB; window bit-identical to the source dequant (max abs err 0.0).


## 8. Forge sidecar (`file_kind` 3, since 1.2.0)

A forged model is written as a plain `.gguf` (so llama.cpp / Ollama / LM Studio load it unchanged) plus an SFF file of
the same name beside it. The sidecar carries **no weights**. It holds:

- `META.source = {"kind": "forge", "family": <family signature>, "gguf": <path>}` and `META.arch = {"family": "forge-sidecar",
  "arch_out": qwen2moe|llama|qwen2, "spec": <the whole ForgeSpec template as JSON>}` — the template is enough to re-assemble
  the file bit-for-bit from the same donors (`soke forge-export`).
- `LIN1` — one node of kind 6 (model) and one node of kind 3 (external) per donor labelled `donor:<id>:<label>:<sha8>`
  (sha8 = sha256 of the donor's first MiB + size), edges op 17 (import) donor → model.
- `EXP1` — one record per tensor of the `.gguf`: `{"tensor", "exact": true, "from": <donor tensor>}` for byte-exact copies, or
  `{"tensor", "exact": false, "quant": <ggml type>, "slot": <the op that computed it>}` for blended / extrapolated /
  re-seeded tensors.
- `LDG1` — the trial ledger of the run that produced the template (every trial, accepted or null, hash-chained).
- `EXP1` behavior teeth (since 1.3.0) — when a behavior profile is attached, `META.behavior` carries the profile
  (`C`, `S_e`, `S_l`, affect, happiness, policies) and one `EXP1` record of `exp_type 2` per ACTG helix tooth:
  `{"helix": emotion|logic|behavior|psychology, "domain": level_8_emotion|…, "register": A|C|T|G, "text": …,
  "face_gear_window": 256}`. The emotion/logic/behavior teeth come from the behavior map; the psychology teeth are
  the clone battery's committed answers and are written ONLY with `consent.store`. The weights and the behavior
  conditioning are disjoint: the conditioning is metadata + these teeth, never a tensor.
