@echo off
setlocal EnableExtensions
title SOKE uninstall
cd /d "%~dp0"
echo This removes the SOKE desktop icon and Start Menu entry. Python and numpy are left in place.
for /f "usebackq delims=" %%D in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "[Environment]::GetFolderPath('Desktop')"`) do set "DESK=%%D"
if not defined DESK set "DESK=%USERPROFILE%\Desktop"
for /f "usebackq delims=" %%D in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "[Environment]::GetFolderPath('Programs')"`) do set "PROGS=%%D"
if exist "%DESK%\SOKE.lnk" del /q "%DESK%\SOKE.lnk"
if exist "%DESK%\SOKE.bat" del /q "%DESK%\SOKE.bat"
if defined PROGS if exist "%PROGS%\SOKE.lnk" del /q "%PROGS%\SOKE.lnk"
set /p ANS="Also delete the data folder soke_data (models, knowledge, ledger)?  [y/N] "
if /I "%ANS%"=="y" (
    rmdir /s /q "%~dp0soke_data"
    echo soke_data deleted.
)
echo Shortcuts removed. Delete this folder to remove the program files.
pause
