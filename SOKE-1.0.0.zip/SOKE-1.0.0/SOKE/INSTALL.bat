@echo off
setlocal EnableExtensions EnableDelayedExpansion
title SOKE 2.0.0 installer
cd /d "%~dp0"
echo.
echo   SOKE 2.0.0  -  Self-Optimizing Knowledge Engine  (SFF model writer)
echo   BS Medicineman / Knight Industries
echo.
echo   One-click install: Python 3.10+ (installed if missing), numpy, a desktop icon and a
echo   Start Menu entry, then a quick self-test. Nothing else is downloaded or installed.
echo.

set "PYCMD="
call :find_python
if not defined PYCMD (
    echo [1/5] Python 3.10+ not found - installing Python 3.12 for this user ...
    where winget >nul 2>&1
    if !errorlevel! == 0 (
        winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
    ) else (
        echo       winget is not available - downloading the official installer from python.org ...
        powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\python-3.12.7-amd64.exe'"
        "%TEMP%\python-3.12.7-amd64.exe" /passive InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_tcltk=1 Include_launcher=1
    )
    set "PATH=%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%LOCALAPPDATA%\Programs\Python\Launcher;%PATH%"
    call :find_python
)
if not defined PYCMD (
    echo.
    echo ERROR: Python could not be installed automatically.
    echo        Install Python 3.12 from https://www.python.org/downloads/windows/
    echo        (tick "Add python.exe to PATH" and keep "tcl/tk and IDLE" selected), then run INSTALL.bat again.
    pause
    exit /b 1
)
echo [1/5] Python: %PYCMD%
%PYCMD% -c "import sys;print('       ' + sys.version.split()[0] + '  ' + sys.executable)"

echo [2/5] numpy ...
%PYCMD% -m pip install --upgrade --quiet --disable-pip-version-check numpy >nul 2>&1
if errorlevel 1 %PYCMD% -m pip install --user --upgrade --quiet --disable-pip-version-check numpy
%PYCMD% -c "import numpy;print('       numpy ' + numpy.__version__)"
if errorlevel 1 (
    echo ERROR: numpy could not be imported. If the message above says an Application Control policy
    echo        blocked a file, Windows Smart App Control is refusing numpy's compiled files for this
    echo        Python version. Installing Python 3.12 (python.org) and running INSTALL.bat again usually
    echo        works, because its numpy build is widely used and already trusted.
    pause
    exit /b 1
)

echo [3/5] tkinter (the window) ...
%PYCMD% -c "import tkinter;print('       tk ' + str(tkinter.TkVersion))" 2>nul
if errorlevel 1 (
    echo       WARNING: tkinter is missing. Re-run the Python installer, choose Modify, tick "tcl/tk and IDLE".
    echo                The command line (SOKE-CLI.bat) works without it.
)

echo [4/5] desktop icon + Start Menu entry ...
if not exist "%~dp0soke_data" mkdir "%~dp0soke_data"
set "MADE="
rem route 1: python + COM (works even when PowerShell is locked to Constrained Language Mode by an Application Control policy)
%PYCMD% -m soke.winshortcut "%~dp0SOKE.bat" desktop "%~dp0." "%~dp0soke.ico" "SOKE - SFF model writer (BS Medicineman / Knight Industries)" >nul 2>&1 && set "MADE=python"
%PYCMD% -m soke.winshortcut "%~dp0SOKE.bat" programs "%~dp0." "%~dp0soke.ico" "SOKE - SFF model writer (BS Medicineman / Knight Industries)" >nul 2>&1
if not defined MADE (
    rem route 2: PowerShell + WScript.Shell
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$W=New-Object -ComObject WScript.Shell; foreach($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))){ $S=$W.CreateShortcut((Join-Path $d 'SOKE.lnk')); $S.TargetPath='%~dp0SOKE.bat'; $S.WorkingDirectory='%~dp0'; $S.IconLocation='%~dp0soke.ico,0'; $S.Description='SOKE - SFF model writer'; $S.Save() }" >nul 2>&1 && set "MADE=powershell"
)
for /f "usebackq delims=" %%D in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "[Environment]::GetFolderPath('Desktop')"`) do set "DESK=%%D"
if not defined DESK set "DESK=%USERPROFILE%\Desktop"
if exist "%DESK%\SOKE.lnk" (
    if not defined MADE set "MADE=an earlier install"
    echo       desktop icon: "%DESK%\SOKE.lnk"  (made by !MADE!)
) else (
    rem route 3: a plain launcher on the desktop - works under every policy
    copy /y "%~dp0SOKE.bat" "%DESK%\SOKE.bat" >nul 2>&1
    if exist "%DESK%\SOKE.bat" (
        echo       desktop launcher: "%DESK%\SOKE.bat"  (a .lnk shortcut could not be created on this machine)
    ) else (
        echo       WARNING: nothing could be placed on the desktop. Start SOKE with SOKE.bat in this folder.
    )
)

echo [5/5] quick self-test ...
%PYCMD% "%~dp0soke_main.py" selftest --quick --summary
if errorlevel 1 (
    echo.
    echo Self-test reported failures. SOKE is installed; send the lines above with any bug report.
) else (
    echo.
    echo Installed. Double-click the SOKE icon on the desktop (or SOKE.bat here) to start.
    echo First time?  Read QUICK START.txt - four steps.
)
echo.
pause
exit /b 0

:find_python
set "PYCMD="
for %%C in ("py -3" "python" "python3") do (
    if not defined PYCMD (
        %%~C -c "import sys;sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1 && set "PYCMD=%%~C"
    )
)
exit /b 0
