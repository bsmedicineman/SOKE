@echo off
setlocal EnableExtensions
title SOKE
cd /d "%~dp0"
set "PYCMD="
set "PYWCMD="
for %%C in ("py -3" "python" "python3") do (
    if not defined PYCMD (
        %%~C -c "import sys;sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1 && set "PYCMD=%%~C"
    )
)
if not defined PYCMD (
    echo Python 3.10+ was not found. Run INSTALL.bat first.
    pause
    exit /b 1
)
if "%~1"=="" goto :gui
%PYCMD% "%~dp0soke_main.py" %*
if errorlevel 1 (
    echo.
    echo SOKE exited with an error (see above).
    pause
)
exit /b %errorlevel%

:gui
rem the window runs without a console (pythonw); problems are written to soke_data\logs\soke.log
rem and shown in a message box. If pythonw is missing, fall back to the console interpreter.
for /f "usebackq delims=" %%P in (`%PYCMD% -c "import sys,os;p=os.path.join(os.path.dirname(sys.executable),'pythonw.exe');print(p if os.path.exists(p) else '')"`) do set "PYWCMD=%%P"
if defined PYWCMD (
    start "" "%PYWCMD%" "%~dp0soke_main.py" gui
    exit /b 0
)
%PYCMD% "%~dp0soke_main.py" gui
if errorlevel 1 (
    echo.
    echo SOKE exited with an error (see above, and soke_data\logs\soke.log).
    pause
)
exit /b %errorlevel%
