#!/usr/bin/env python3
"""
SOKE — Self-Optimizing Helical Knowledge Engine
Writes, trains, converts, heals, expands and streams SFF (.sff) models.

BS Medicineman / Knight Industries — "the answer is never on the line"

    SOKE.bat                      launch the Windows program (GUI)
    soke_main.py <command> ...    command line (see: soke_main.py -h)

This is a Windows program. Set SOKE_DEV=1 to run the self-test harness elsewhere.
"""
from __future__ import annotations

import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)


def _log_path() -> str:
    root = os.environ.get("SOKE_HOME") or os.path.join(HERE, "soke_data")
    d = os.path.join(root, "logs")
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        d = HERE
    return os.path.join(d, "soke.log")


def _fatal(title: str, message: str, details: str = "") -> None:
    """Write the problem to the log; show it in a message box when there is no console (pythonw)."""
    path = _log_path()
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] {title}\n{message}\n{details}\n")
    except OSError:
        pass
    text = f"{message}\n\nDetails were written to:\n{path}"
    sys.stderr.write(f"{title}: {message}\n{details}\n")
    if os.name == "nt" and (not sys.stdin or not sys.stdin.isatty() or sys.executable.lower().endswith("pythonw.exe")):
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, text, f"SOKE — {title}", 0x10)
        except Exception:
            pass


def _guard() -> None:
    if os.name != "nt" and os.environ.get("SOKE_DEV", "") in ("", "0", "false", "False"):
        sys.stderr.write("SOKE is a Windows program. (Developers: set SOKE_DEV=1 to run the harness elsewhere.)\n")
        sys.exit(2)
    if sys.version_info < (3, 10):
        _fatal("Python too old", f"SOKE needs Python 3.10 or newer (found {sys.version.split()[0]}). Run INSTALL.bat.")
        sys.exit(2)
    try:
        import numpy  # noqa: F401
    except ImportError as e:
        msg = "numpy is missing or could not load. Run INSTALL.bat (or: python -m pip install numpy)."
        if "Application Control" in str(e) or "blocked" in str(e):
            msg = ("Windows Application Control (Smart App Control) blocked one of numpy's compiled files, so numpy "
                   "cannot load in this Python. Install Python 3.12 from python.org and run INSTALL.bat again; its "
                   "numpy build is widely used and already trusted.")
        _fatal("numpy", msg, str(e))
        sys.exit(2)


def main() -> int:
    _guard()
    from soke.cli import main as cli_main
    try:
        return int(cli_main() or 0)
    except KeyboardInterrupt:
        return 130
    except SystemExit:
        raise
    except Exception as e:  # last line of defence: never die silently under pythonw
        _fatal("Unexpected error", f"{type(e).__name__}: {e}", traceback.format_exc())
        return 1


if __name__ == "__main__":
    sys.exit(main())
